Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297176588401926144",
  "text" : "Anyone know where I can get a custom book bound in NYC?",
  "id" : 297176588401926144,
  "created_at" : "Fri Feb 01 02:56:34 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297133817368563714",
  "text" : "Hiring an analyst is kind of like provisioning an expensive AWS instance with amazing semantic analysis and machine learning software.",
  "id" : 297133817368563714,
  "created_at" : "Fri Feb 01 00:06:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Woo Audio",
      "screen_name" : "WooAudio",
      "indices" : [ 15, 24 ],
      "id_str" : "237777758",
      "id" : 237777758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/nYjAYFRF",
      "expanded_url" : "http://wooaudio.com/products/wa7fireflies.html",
      "display_url" : "wooaudio.com/products/wa7fi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "296661730891808770",
  "text" : "Holy crap, the @WooAudio Firefly amp looks amazing. http://t.co/nYjAYFRF",
  "id" : 296661730891808770,
  "created_at" : "Wed Jan 30 16:50:43 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Natalia",
      "screen_name" : "NataliaZarina",
      "indices" : [ 13, 27 ],
      "id_str" : "74196868",
      "id" : 74196868
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 28, 35 ],
      "id_str" : "224321197",
      "id" : 224321197
    }, {
      "name" : "Jeff Solnet",
      "screen_name" : "jfsolnet",
      "indices" : [ 36, 45 ],
      "id_str" : "24945651",
      "id" : 24945651
    }, {
      "name" : "Alec Guzov",
      "screen_name" : "avguzov",
      "indices" : [ 46, 54 ],
      "id_str" : "262431125",
      "id" : 262431125
    }, {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 55, 69 ],
      "id_str" : "15593773",
      "id" : 15593773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosies",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296378042811547648",
  "geo" : {
  },
  "id_str" : "296379281947385856",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce @nataliazarina @zhamed @jfsolnet @avguzov @lexiberylross not it either #nosies",
  "id" : 296379281947385856,
  "in_reply_to_status_id" : 296378042811547648,
  "created_at" : "Tue Jan 29 22:08:21 +0000 2013",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dragon ",
      "screen_name" : "dragoninnovate",
      "indices" : [ 3, 18 ],
      "id_str" : "421859846",
      "id" : 421859846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/schnX37w",
      "expanded_url" : "http://bit.ly/T67FeQ",
      "display_url" : "bit.ly/T67FeQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "296334967070392323",
  "text" : "RT @dragoninnovate: Autodesk CEO Carl Bass: \"Don't divorce design from manufacturing.\" http://t.co/schnX37w",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http://t.co/schnX37w",
        "expanded_url" : "http://bit.ly/T67FeQ",
        "display_url" : "bit.ly/T67FeQ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "296324959066812417",
    "text" : "Autodesk CEO Carl Bass: \"Don't divorce design from manufacturing.\" http://t.co/schnX37w",
    "id" : 296324959066812417,
    "created_at" : "Tue Jan 29 18:32:30 +0000 2013",
    "user" : {
      "name" : "Dragon ",
      "screen_name" : "dragoninnovate",
      "protected" : false,
      "id_str" : "421859846",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2226528205/DI_gear_normal.jpg",
      "id" : 421859846,
      "verified" : false
    }
  },
  "id" : 296334967070392323,
  "created_at" : "Tue Jan 29 19:12:16 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schmidt",
      "screen_name" : "ericschmidt",
      "indices" : [ 12, 24 ],
      "id_str" : "93957809",
      "id" : 93957809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/K4pMs3yW",
      "expanded_url" : "http://www.washingtonpost.com/wp-srv/special/world/Google-unveils-detailed-map-of-North-Korea/index.html",
      "display_url" : "washingtonpost.com/wp-srv/special\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "296302030253867008",
  "text" : "I wonder if @EricSchmidt had a Google maps camera secretly strapped to him in North Korea? http://t.co/K4pMs3yW",
  "id" : 296302030253867008,
  "created_at" : "Tue Jan 29 17:01:23 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 9, 15 ],
      "id_str" : "17856596",
      "id" : 17856596
    }, {
      "name" : "Crashlytics",
      "screen_name" : "crashlytics",
      "indices" : [ 20, 32 ],
      "id_str" : "241762251",
      "id" : 241762251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "296248339438133248",
  "text" : "Congrats @Wayne and @crashlytics on joining the Twitter team!",
  "id" : 296248339438133248,
  "created_at" : "Tue Jan 29 13:28:02 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 50, 62 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 63, 77 ],
      "id_str" : "15593773",
      "id" : 15593773
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 78, 85 ],
      "id_str" : "224321197",
      "id" : 224321197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackHarvard",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295689327315415040",
  "geo" : {
  },
  "id_str" : "295715287620276224",
  "in_reply_to_user_id" : 110823121,
  "text" : "Congrats on another awesome #HackHarvard Demo Day @badboyboyce @lexiberylross @zhamed.",
  "id" : 295715287620276224,
  "in_reply_to_status_id" : 295689327315415040,
  "created_at" : "Mon Jan 28 02:09:53 +0000 2013",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arjun Reddy",
      "screen_name" : "atreddy",
      "indices" : [ 0, 8 ],
      "id_str" : "29041063",
      "id" : 29041063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295048061472866304",
  "geo" : {
  },
  "id_str" : "295323194829701120",
  "in_reply_to_user_id" : 29041063,
  "text" : "@atreddy touch typing on a Blackberry Bold is still an unmatched experience!",
  "id" : 295323194829701120,
  "in_reply_to_status_id" : 295048061472866304,
  "created_at" : "Sun Jan 27 00:11:51 +0000 2013",
  "in_reply_to_screen_name" : "atreddy",
  "in_reply_to_user_id_str" : "29041063",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber New York",
      "screen_name" : "Uber_NYC",
      "indices" : [ 0, 9 ],
      "id_str" : "272161214",
      "id" : 272161214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295322307101093889",
  "geo" : {
  },
  "id_str" : "295323002403446784",
  "in_reply_to_user_id" : 272161214,
  "text" : "@Uber_NYC got it. Just curious what would happen in the back end but I promise not to hit the button :P",
  "id" : 295323002403446784,
  "in_reply_to_status_id" : 295322307101093889,
  "created_at" : "Sun Jan 27 00:11:05 +0000 2013",
  "in_reply_to_screen_name" : "Uber_NYC",
  "in_reply_to_user_id_str" : "272161214",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber New York",
      "screen_name" : "Uber_NYC",
      "indices" : [ 0, 9 ],
      "id_str" : "272161214",
      "id" : 272161214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "295322053798662146",
  "in_reply_to_user_id" : 272161214,
  "text" : "@Uber_NYC what happens if I hit \"Cancel Trip\" in the app while I'm in the car? Seems like a weird corner case.",
  "id" : 295322053798662146,
  "created_at" : "Sun Jan 27 00:07:19 +0000 2013",
  "in_reply_to_screen_name" : "Uber_NYC",
  "in_reply_to_user_id_str" : "272161214",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "295027838820700160",
  "text" : "I'm tweeting from a Blackberry and I actually like it.",
  "id" : 295027838820700160,
  "created_at" : "Sat Jan 26 04:38:12 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RightInTheNostalgia",
      "indices" : [ 102, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "294243940054466560",
  "text" : "Talking to 8 year old that was playing w iPhone: \"have you played with a Game Boy?\" \"Is that an app?\" #RightInTheNostalgia",
  "id" : 294243940054466560,
  "created_at" : "Thu Jan 24 00:43:16 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 8, 20 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "Zach Weinersmith",
      "screen_name" : "ZachWeiner",
      "indices" : [ 88, 99 ],
      "id_str" : "20745130",
      "id" : 20745130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/tIZKvCvI",
      "expanded_url" : "http://www.kickstarter.com/projects/weiner/science-ruining-everything-since-1543-an-smbc-coll",
      "display_url" : "kickstarter.com/projects/weine\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "294177676619563009",
  "geo" : {
  },
  "id_str" : "294205094138875904",
  "in_reply_to_user_id" : 20745130,
  "text" : "Coolest @kickstarter campaign incentives I've seen (with an interactive map!) by SMBC's @ZachWeiner. http://t.co/tIZKvCvI",
  "id" : 294205094138875904,
  "in_reply_to_status_id" : 294177676619563009,
  "created_at" : "Wed Jan 23 22:08:55 +0000 2013",
  "in_reply_to_screen_name" : "ZachWeiner",
  "in_reply_to_user_id_str" : "20745130",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breitling Watches",
      "screen_name" : "BreitlingWatch",
      "indices" : [ 1, 16 ],
      "id_str" : "28002518",
      "id" : 28002518
    }, {
      "name" : "Mark Chou",
      "screen_name" : "markdchou",
      "indices" : [ 129, 139 ],
      "id_str" : "67686145",
      "id" : 67686145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/NyT7qUgc",
      "expanded_url" : "http://www.breitling.com/en/news/index.php?idContent=65296",
      "display_url" : "breitling.com/en/news/index.\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "294137425113006080",
  "text" : ".@BreitlingWatch, marketing a 38mm chrono as \"feminine\" alienates a huge fanbase of classic watch sizes. http://t.co/NyT7qUgc cc @markdchou",
  "id" : 294137425113006080,
  "created_at" : "Wed Jan 23 17:40:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 77, 89 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/3kungLHj",
      "expanded_url" : "http://kck.st/SATj5P",
      "display_url" : "kck.st/SATj5P"
    } ]
  },
  "geo" : {
  },
  "id_str" : "294128850919649282",
  "text" : "I just backed SCIENCE: Ruining Everything Since 1543 (an SMBC Collection) on @Kickstarter http://t.co/3kungLHj",
  "id" : 294128850919649282,
  "created_at" : "Wed Jan 23 17:05:57 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 0, 6 ],
      "id_str" : "3840",
      "id" : 3840
    }, {
      "name" : "MakerBot",
      "screen_name" : "makerbot",
      "indices" : [ 38, 47 ],
      "id_str" : "22021097",
      "id" : 22021097
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 51, 60 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293934933959921666",
  "geo" : {
  },
  "id_str" : "293935954538946560",
  "in_reply_to_user_id" : 3840,
  "text" : "@Jason happy to put you in touch with @Makerbot or @romotive re: robots!",
  "id" : 293935954538946560,
  "in_reply_to_status_id" : 293934933959921666,
  "created_at" : "Wed Jan 23 04:19:27 +0000 2013",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worthit",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "293897222779727873",
  "text" : "Venturing into the sub-freezing night for chicken and rice plate. #worthit",
  "id" : 293897222779727873,
  "created_at" : "Wed Jan 23 01:45:32 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 40, 46 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "293877845544038400",
  "text" : "Finding the movie you want on Netflix. \u201C@koush: ...which is harder: unsubscribing from Xbox Live or LinkedIn emails. Or running a marathon.\u201D",
  "id" : 293877845544038400,
  "created_at" : "Wed Jan 23 00:28:33 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GQ Magazine",
      "screen_name" : "GQMagazine",
      "indices" : [ 19, 30 ],
      "id_str" : "21701757",
      "id" : 21701757
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/293502805640110081/photo/1",
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/jzcMmzJP",
      "media_url" : "http://pbs.twimg.com/media/BBK7PydCYAAagWw.jpg",
      "id_str" : "293502805648498688",
      "id" : 293502805648498688,
      "media_url_https" : "https://pbs.twimg.com/media/BBK7PydCYAAagWw.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/jzcMmzJP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "293502805640110081",
  "text" : "Yea, screw you too @GQMagazine. http://t.co/jzcMmzJP",
  "id" : 293502805640110081,
  "created_at" : "Mon Jan 21 23:38:17 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Zerkin",
      "screen_name" : "noazark",
      "indices" : [ 3, 11 ],
      "id_str" : "8068472",
      "id" : 8068472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "293453157948874752",
  "text" : "RT @noazark: Yeeeah... I just had a brief conversation with the most powerful man in the world. On the downtown 3 train. Nice guy. http: ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/noazark/status/293194207265447937/photo/1",
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/cx93BXKY",
        "media_url" : "http://pbs.twimg.com/media/BBGik_8CYAE_Cy5.jpg",
        "id_str" : "293194207278030849",
        "id" : 293194207278030849,
        "media_url_https" : "https://pbs.twimg.com/media/BBGik_8CYAE_Cy5.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/cx93BXKY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "293194207265447937",
    "text" : "Yeeeah... I just had a brief conversation with the most powerful man in the world. On the downtown 3 train. Nice guy. http://t.co/cx93BXKY",
    "id" : 293194207265447937,
    "created_at" : "Mon Jan 21 03:12:01 +0000 2013",
    "user" : {
      "name" : "Noah Zerkin",
      "screen_name" : "noazark",
      "protected" : false,
      "id_str" : "8068472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1775950814/image1327341360_normal.png",
      "id" : 8068472,
      "verified" : false
    }
  },
  "id" : 293453157948874752,
  "created_at" : "Mon Jan 21 20:20:59 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McKinsey on BT",
      "screen_name" : "mck_biztech",
      "indices" : [ 33, 45 ],
      "id_str" : "14955144",
      "id" : 14955144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cloud",
      "indices" : [ 50, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/Ld9zuRNn",
      "expanded_url" : "http://bit.ly/S6m4bO",
      "display_url" : "bit.ly/S6m4bO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104052133, -74.0063696493 ]
  },
  "id_str" : "293402572612575232",
  "text" : "Aren't you guys still on Lotus? \"@mck_biztech: ...#cloud migrations require significant changes to traditional IT. http://t.co/Ld9zuRNn\u201D",
  "id" : 293402572612575232,
  "created_at" : "Mon Jan 21 16:59:59 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7103906941, -74.0063764975 ]
  },
  "id_str" : "293401021089189891",
  "text" : "How awesome would it be if Siri plugged into Uber?",
  "id" : 293401021089189891,
  "created_at" : "Mon Jan 21 16:53:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7639394874, -73.9731083404 ]
  },
  "id_str" : "292417932376551425",
  "text" : "Overheard TWICE at Apple store Genius Bar: \"my password is password.\"",
  "id" : 292417932376551425,
  "created_at" : "Fri Jan 18 23:47:22 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/JiT20s2B",
      "expanded_url" : "http://www.newscientist.com/article/dn23090-zoologger-the-first-solarpowered-vertebrate.html",
      "display_url" : "newscientist.com/article/dn2309\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "292373392542281728",
  "text" : "Oh man, there's a real life bulbasaur! Kind of. http://t.co/JiT20s2B",
  "id" : 292373392542281728,
  "created_at" : "Fri Jan 18 20:50:23 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uhoh",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7511071675, -73.9830218163 ]
  },
  "id_str" : "292345532851027968",
  "text" : "The subway started honking its horn... then I started wondering what it could possibly honking its horn at. #uhoh",
  "id" : 292345532851027968,
  "created_at" : "Fri Jan 18 18:59:41 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292064710529011712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.76393688, -73.9731262452 ]
  },
  "id_str" : "292072050519064576",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil lists are buried too far in the app interface for me to use them.",
  "id" : 292072050519064576,
  "in_reply_to_status_id" : 292064710529011712,
  "created_at" : "Fri Jan 18 00:52:57 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "china",
      "indices" : [ 100, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/tW7aTBfS",
      "expanded_url" : "http://shanghaiist.com/2013/01/18/watch_dude_gets_hauled_away_by_plai.php",
      "display_url" : "shanghaiist.com/2013/01/18/wat\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "292066454071816192",
  "text" : "Big Brother in broad daylight: protester gets disappeared by secret police in front of interviewer. #china http://t.co/tW7aTBfS",
  "id" : 292066454071816192,
  "created_at" : "Fri Jan 18 00:30:43 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i1 Biometrics, Inc.",
      "screen_name" : "i1biometrics",
      "indices" : [ 16, 29 ],
      "id_str" : "979177106",
      "id" : 979177106
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/291594175462375424/photo/1",
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/UMDgo4xm",
      "media_url" : "http://pbs.twimg.com/media/BAvzW4-CAAA9nSb.jpg",
      "id_str" : "291594175470764032",
      "id" : 291594175470764032,
      "media_url_https" : "https://pbs.twimg.com/media/BAvzW4-CAAA9nSb.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com/UMDgo4xm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "291594175462375424",
  "text" : "Great demo from @i1biometrics: mouth guards that measure head trauma for better sports medicine triage. http://t.co/UMDgo4xm",
  "id" : 291594175462375424,
  "created_at" : "Wed Jan 16 17:14:04 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 3, 15 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Hugo Van Vuuren",
      "screen_name" : "hvgo",
      "indices" : [ 29, 34 ],
      "id_str" : "18413446",
      "id" : 18413446
    }, {
      "name" : "Patrick Chung",
      "screen_name" : "patrickchung",
      "indices" : [ 35, 48 ],
      "id_str" : "41380155",
      "id" : 41380155
    }, {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 55, 61 ],
      "id_str" : "236921052",
      "id" : 236921052
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 71, 79 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "Inc. ",
      "screen_name" : "Inc",
      "indices" : [ 114, 118 ],
      "id_str" : "16896485",
      "id" : 16896485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/WyGnksPa",
      "expanded_url" : "http://pocket.co/sGfZm",
      "display_url" : "pocket.co/sGfZm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "289761578226704384",
  "text" : "RT @badboyboyce: Congrats to @hvgo @patrickchung &amp; @hseas &gt;&gt; @Harvard's Go-To Venture Capital Firm (via @inc) http://t.co/WyGnksPa",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/read-it-later-pro/id309601447?mt=8&uo=4\" rel=\"nofollow\">Read It Later Pro</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hugo Van Vuuren",
        "screen_name" : "hvgo",
        "indices" : [ 12, 17 ],
        "id_str" : "18413446",
        "id" : 18413446
      }, {
        "name" : "Patrick Chung",
        "screen_name" : "patrickchung",
        "indices" : [ 18, 31 ],
        "id_str" : "41380155",
        "id" : 41380155
      }, {
        "name" : "Harvard SEAS",
        "screen_name" : "hseas",
        "indices" : [ 38, 44 ],
        "id_str" : "236921052",
        "id" : 236921052
      }, {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 54, 62 ],
        "id_str" : "39585367",
        "id" : 39585367
      }, {
        "name" : "Inc. ",
        "screen_name" : "Inc",
        "indices" : [ 97, 101 ],
        "id_str" : "16896485",
        "id" : 16896485
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http://t.co/WyGnksPa",
        "expanded_url" : "http://pocket.co/sGfZm",
        "display_url" : "pocket.co/sGfZm"
      } ]
    },
    "geo" : {
    },
    "id_str" : "289690207173894145",
    "text" : "Congrats to @hvgo @patrickchung &amp; @hseas &gt;&gt; @Harvard's Go-To Venture Capital Firm (via @inc) http://t.co/WyGnksPa",
    "id" : 289690207173894145,
    "created_at" : "Fri Jan 11 11:08:22 +0000 2013",
    "user" : {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "protected" : false,
      "id_str" : "110823121",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1736585624/HaLongBay_Profile_Thumbnail_normal.jpg",
      "id" : 110823121,
      "verified" : false
    }
  },
  "id" : 289761578226704384,
  "created_at" : "Fri Jan 11 15:51:58 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thomas lueke",
      "screen_name" : "tlueke",
      "indices" : [ 0, 7 ],
      "id_str" : "18456879",
      "id" : 18456879
    }, {
      "name" : "Hotel Tonight",
      "screen_name" : "HotelTonight",
      "indices" : [ 22, 35 ],
      "id_str" : "19448539",
      "id" : 19448539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289697162688880640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7622282799, -73.9686480843 ]
  },
  "id_str" : "289761070183247872",
  "in_reply_to_user_id" : 18456879,
  "text" : "@tlueke I've used the @HotelTonight app with great results.",
  "id" : 289761070183247872,
  "in_reply_to_status_id" : 289697162688880640,
  "created_at" : "Fri Jan 11 15:49:57 +0000 2013",
  "in_reply_to_screen_name" : "tlueke",
  "in_reply_to_user_id_str" : "18456879",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joanne chang-myers",
      "screen_name" : "jbchang",
      "indices" : [ 66, 74 ],
      "id_str" : "31391307",
      "id" : 31391307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289756870892204032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7622148432, -73.9686489736 ]
  },
  "id_str" : "289759125078958081",
  "in_reply_to_user_id" : 31391307,
  "text" : "I don't even live in Boston anymore and I'm holding my breath for @jbchang's Flour Bakery 4 opening.",
  "id" : 289759125078958081,
  "in_reply_to_status_id" : 289756870892204032,
  "created_at" : "Fri Jan 11 15:42:13 +0000 2013",
  "in_reply_to_screen_name" : "jbchang",
  "in_reply_to_user_id_str" : "31391307",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/Oxjln7D2",
      "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=tpBwRX68fIY#",
      "display_url" : "youtube.com/watch?feature=\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "289508561216753664",
  "text" : "This VZW smart glasses video from CES is awkward, overly dramatic, and very Big Brother-y: http://t.co/Oxjln7D2!",
  "id" : 289508561216753664,
  "created_at" : "Thu Jan 10 23:06:34 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 3, 17 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/hT02LJGk",
      "expanded_url" : "http://bit.ly/U8enPF",
      "display_url" : "bit.ly/U8enPF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "289459227276242944",
  "text" : "RT @MikeBloomberg: The 830 new NYPD recruits were born in 52 different countries: http://t.co/hT02LJGk",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http://t.co/hT02LJGk",
        "expanded_url" : "http://bit.ly/U8enPF",
        "display_url" : "bit.ly/U8enPF"
      } ]
    },
    "geo" : {
    },
    "id_str" : "289459157021630464",
    "text" : "The 830 new NYPD recruits were born in 52 different countries: http://t.co/hT02LJGk",
    "id" : 289459157021630464,
    "created_at" : "Thu Jan 10 19:50:15 +0000 2013",
    "user" : {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "protected" : false,
      "id_str" : "16581604",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3374841513/ccdffb7ce6910ac43568ae2f7c68fe2b_normal.jpeg",
      "id" : 16581604,
      "verified" : true
    }
  },
  "id" : 289459227276242944,
  "created_at" : "Thu Jan 10 19:50:32 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/289451971629441024/photo/1",
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/Pvw7fBP0",
      "media_url" : "http://pbs.twimg.com/media/BARXCN0CYAAEKL0.jpg",
      "id_str" : "289451971637829632",
      "id" : 289451971637829632,
      "media_url_https" : "https://pbs.twimg.com/media/BARXCN0CYAAEKL0.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com/Pvw7fBP0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "289451971629441024",
  "text" : "Android PC on a stick! http://t.co/Pvw7fBP0",
  "id" : 289451971629441024,
  "created_at" : "Thu Jan 10 19:21:43 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ministry of Supply",
      "screen_name" : "MinistrySupply",
      "indices" : [ 45, 60 ],
      "id_str" : "462236193",
      "id" : 462236193
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/289207436060004352/photo/1",
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/ztuW8OJX",
      "media_url" : "http://pbs.twimg.com/media/BAN4oX1CEAAz21e.jpg",
      "id_str" : "289207436068392960",
      "id" : 289207436068392960,
      "media_url_https" : "https://pbs.twimg.com/media/BAN4oX1CEAAz21e.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com/ztuW8OJX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "289207436060004352",
  "text" : "I know what I'm wearing to work tomorrow. cc @MinistrySupply http://t.co/ztuW8OJX",
  "id" : 289207436060004352,
  "created_at" : "Thu Jan 10 03:10:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svbtle",
      "screen_name" : "Svbtle",
      "indices" : [ 1, 8 ],
      "id_str" : "776098190",
      "id" : 776098190
    }, {
      "name" : "SV Angel",
      "screen_name" : "svangel",
      "indices" : [ 27, 35 ],
      "id_str" : "31267919",
      "id" : 31267919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "289022383040393218",
  "text" : ".@svbtle raises money from @svangel - now I'm wondering how svangel is pronovnced.",
  "id" : 289022383040393218,
  "created_at" : "Wed Jan 09 14:54:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288703197768462336",
  "text" : "Why would Kingston name a flash drive HyperX Predator? Do people actually try to be cool when whipping out a flash drive?",
  "id" : 288703197768462336,
  "created_at" : "Tue Jan 08 17:46:20 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Tech Review",
      "screen_name" : "techreview",
      "indices" : [ 40, 51 ],
      "id_str" : "15808647",
      "id" : 15808647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.730558429, -73.9831195493 ]
  },
  "id_str" : "287759043571904513",
  "text" : "MIT friend: \"when I was arts editor for @TechReview I tried to start a street style blog but it ended up being the same 3 people.\"",
  "id" : 287759043571904513,
  "created_at" : "Sun Jan 06 03:14:36 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 3, 13 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287746584656084992",
  "text" : "RT @jenny8lee: Great game to play when drunk: Gitionary, guessing git commands via drawing. Mashup of version control + Pictionary. http ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/SH4HLwuE",
        "expanded_url" : "http://bit.ly/Z9jaQP",
        "display_url" : "bit.ly/Z9jaQP"
      } ]
    },
    "geo" : {
    },
    "id_str" : "287743840423657472",
    "text" : "Great game to play when drunk: Gitionary, guessing git commands via drawing. Mashup of version control + Pictionary. http://t.co/SH4HLwuE",
    "id" : 287743840423657472,
    "created_at" : "Sun Jan 06 02:14:12 +0000 2013",
    "user" : {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "protected" : false,
      "id_str" : "1976841",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1842465869/jenny_baby_graduation_cap_cropped_normal.jpg",
      "id" : 1976841,
      "verified" : true
    }
  },
  "id" : 287746584656084992,
  "created_at" : "Sun Jan 06 02:25:06 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/287278296281010178/photo/1",
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/G8ye7Q66",
      "media_url" : "http://pbs.twimg.com/media/A_yeFqHCUAASMOu.jpg",
      "id_str" : "287278296285204480",
      "id" : 287278296285204480,
      "media_url_https" : "https://pbs.twimg.com/media/A_yeFqHCUAASMOu.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/G8ye7Q66"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287278296281010178",
  "text" : "Thanks Siri! http://t.co/G8ye7Q66",
  "id" : 287278296281010178,
  "created_at" : "Fri Jan 04 19:24:18 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 0, 6 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287032423731040258",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7103858305, -74.0063729153 ]
  },
  "id_str" : "287085980853366785",
  "in_reply_to_user_id" : 586,
  "text" : "@sacca there a bar in St. Marks that has Molson on tap. I've been waiting to go there in a jersey and watch a Sabres game.",
  "id" : 287085980853366785,
  "in_reply_to_status_id" : 287032423731040258,
  "created_at" : "Fri Jan 04 06:40:06 +0000 2013",
  "in_reply_to_screen_name" : "sacca",
  "in_reply_to_user_id_str" : "586",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Webster",
      "screen_name" : "gwbstr",
      "indices" : [ 3, 10 ],
      "id_str" : "14422439",
      "id" : 14422439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "286702130465759232",
  "text" : "RT @gwbstr: If China wants innovation-based economy, needs political and institutional changes -Yasheng Huang in MIT Tech Review http:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/7CbbuRP2",
        "expanded_url" : "http://bit.ly/Uo0CMl",
        "display_url" : "bit.ly/Uo0CMl"
      } ]
    },
    "geo" : {
    },
    "id_str" : "286698445694177281",
    "text" : "If China wants innovation-based economy, needs political and institutional changes -Yasheng Huang in MIT Tech Review http://t.co/7CbbuRP2",
    "id" : 286698445694177281,
    "created_at" : "Thu Jan 03 05:00:10 +0000 2013",
    "user" : {
      "name" : "Graham Webster",
      "screen_name" : "gwbstr",
      "protected" : false,
      "id_str" : "14422439",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3483149064/a7e526b6e2011118081874ece1d8ffb3_normal.jpeg",
      "id" : 14422439,
      "verified" : false
    }
  },
  "id" : 286702130465759232,
  "created_at" : "Thu Jan 03 05:14:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/8xZ0bcdh",
      "expanded_url" : "http://online.wsj.com/article/SB10001424127887324374004578217121433322386.html",
      "display_url" : "online.wsj.com/article/SB1000\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286529337543499776",
  "text" : "Avis is buying Zipcar for .5 Instagrams. http://t.co/8xZ0bcdh",
  "id" : 286529337543499776,
  "created_at" : "Wed Jan 02 17:48:12 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7103949951, -74.0063753114 ]
  },
  "id_str" : "286188777834176513",
  "text" : "Where can i find the best Peking Duck in NYC?",
  "id" : 286188777834176513,
  "created_at" : "Tue Jan 01 19:14:56 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 3, 9 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "285983526183124992",
  "text" : "RT @sacca: What happens in 2013 is up to you.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "285982852208799744",
    "text" : "What happens in 2013 is up to you.",
    "id" : 285982852208799744,
    "created_at" : "Tue Jan 01 05:36:39 +0000 2013",
    "user" : {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "protected" : false,
      "id_str" : "586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1771648774/Sacca_profile_normal.jpg",
      "id" : 586,
      "verified" : true
    }
  },
  "id" : 285983526183124992,
  "created_at" : "Tue Jan 01 05:39:20 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 32, 40 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7563335161, -73.9962553607 ]
  },
  "id_str" : "285977717910953985",
  "text" : "I'm tweeting to amuse myself on @Timehop in a year! Hi 2014 Kane! Sincerely 2013 Kane.",
  "id" : 285977717910953985,
  "created_at" : "Tue Jan 01 05:16:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]