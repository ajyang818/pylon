Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20729439704842240",
  "text" : "Also full signal strength in the subway and a unified payment service. I love hong kongs efficiency",
  "id" : 20729439704842240,
  "created_at" : "Fri Dec 31 06:34:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20729199060852736",
  "text" : "Making new years plans with the intention that things will get out of hand really fast",
  "id" : 20729199060852736,
  "created_at" : "Fri Dec 31 06:33:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20646957445812224",
  "geo" : {
  },
  "id_str" : "20672461649481728",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow is tweeting again :D  happy day",
  "id" : 20672461649481728,
  "in_reply_to_status_id" : 20646957445812224,
  "created_at" : "Fri Dec 31 02:47:53 +0000 2010",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20502661308612608",
  "text" : "Waiting in line at Hong Kong International Airport. Excited to celebrate New Years here",
  "id" : 20502661308612608,
  "created_at" : "Thu Dec 30 15:33:10 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 70, 82 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 87, 95 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20400295183917056",
  "text" : "There were so many cute hapa babies on my Chicago -&gt; Toyko flight. @alishalisha and @aistern would've had a heyday.",
  "id" : 20400295183917056,
  "created_at" : "Thu Dec 30 08:46:24 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20386733279416320",
  "text" : "Greetings from Tokyo!  I can't believe I have to pay for internet here.",
  "id" : 20386733279416320,
  "created_at" : "Thu Dec 30 07:52:30 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankyouverymuch",
      "indices" : [ 79, 96 ]
    }, {
      "text" : "coach",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20176098746695681",
  "text" : "Why is it a first class luxury to board the plane first? I'd rather board last #thankyouverymuch #coach",
  "id" : 20176098746695681,
  "created_at" : "Wed Dec 29 17:55:31 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tsa",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20123694235914241",
  "text" : "#tsa does random bag checks at the gate now? Must be embarrassed by the guy that got a pistol through...",
  "id" : 20123694235914241,
  "created_at" : "Wed Dec 29 14:27:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20119346890145792",
  "text" : "RT @engadget: Fujifilm explains how its X100 hybrid viewfinder works, we nod and pretend to understand http://engt.co/eNvhr9",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "20026791913594880",
    "text" : "Fujifilm explains how its X100 hybrid viewfinder works, we nod and pretend to understand http://engt.co/eNvhr9",
    "id" : 20026791913594880,
    "created_at" : "Wed Dec 29 08:02:13 +0000 2010",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2409263463/5g2vkay1y34xj17ke81c_normal.jpeg",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 20119346890145792,
  "created_at" : "Wed Dec 29 14:10:00 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20114001547493376",
  "text" : "Flight on time from Buffalo. NYC needs to learn how to deal with a little snow.",
  "id" : 20114001547493376,
  "created_at" : "Wed Dec 29 13:48:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tron",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19266839456522240",
  "text" : "It was almost worth watching #tron for the fight scene with Daft Punk DJ'ing.  Almost.",
  "id" : 19266839456522240,
  "created_at" : "Mon Dec 27 05:42:27 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    }, {
      "name" : "Lore Sj\u00F6berg",
      "screen_name" : "loresjoberg",
      "indices" : [ 99, 111 ],
      "id_str" : "1891381",
      "id" : 1891381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18228387663319040",
  "text" : "RT @wired: A fun nighttime read: The best new webcomics of 2010 http://bit.ly/hIwfBN handpicked by @loresjoberg",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lore Sj\u00F6berg",
        "screen_name" : "loresjoberg",
        "indices" : [ 88, 100 ],
        "id_str" : "1891381",
        "id" : 1891381
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "18179361106563072",
    "text" : "A fun nighttime read: The best new webcomics of 2010 http://bit.ly/hIwfBN handpicked by @loresjoberg",
    "id" : 18179361106563072,
    "created_at" : "Fri Dec 24 05:41:12 +0000 2010",
    "user" : {
      "name" : "Wired",
      "screen_name" : "wired",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2958887633/eab60d838d5c4bb20fa52f0577a2c698_normal.jpeg",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 18228387663319040,
  "created_at" : "Fri Dec 24 08:56:00 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MI5",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18186765068140545",
  "text" : "Addicted to the BBC series #MI5",
  "id" : 18186765068140545,
  "created_at" : "Fri Dec 24 06:10:37 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17525844238925824",
  "text" : "Traded my fourth gen iPod Touch for my sister's first gen nano. Didn't like the feature creep on my music device!",
  "id" : 17525844238925824,
  "created_at" : "Wed Dec 22 10:24:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17388012224643072",
  "text" : "&lt;10 emails in inbox!  Gunning for zero this break.",
  "id" : 17388012224643072,
  "created_at" : "Wed Dec 22 01:16:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 5, 13 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17378705068269568",
  "text" : "Wow, @harvard finally overhauled the online course catalog!  Now if they'd only fix the mess that is my.harvard.edu...",
  "id" : 17378705068269568,
  "created_at" : "Wed Dec 22 00:39:40 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 3, 18 ],
      "id_str" : "18107808",
      "id" : 18107808
    }, {
      "name" : "Michael Calderone",
      "screen_name" : "mlcalderone",
      "indices" : [ 121, 133 ],
      "id_str" : "63004503",
      "id" : 63004503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17367561012256768",
  "text" : "RT @NaveenSrivatsa: When I read things like this, I wonder if Julian Assange really understands the value of leaks. (via @mlcalderone) h ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Calderone",
        "screen_name" : "mlcalderone",
        "indices" : [ 101, 113 ],
        "id_str" : "63004503",
        "id" : 63004503
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "17364386410663936",
    "text" : "When I read things like this, I wonder if Julian Assange really understands the value of leaks. (via @mlcalderone) http://yhoo.it/fXgUTS",
    "id" : 17364386410663936,
    "created_at" : "Tue Dec 21 23:42:46 +0000 2010",
    "user" : {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "protected" : true,
      "id_str" : "18107808",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1745313225/IMG_0625edited2_normal.jpg",
      "id" : 18107808,
      "verified" : false
    }
  },
  "id" : 17367561012256768,
  "created_at" : "Tue Dec 21 23:55:23 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 7, 17 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bing",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17337868934447105",
  "text" : "Thanks @microsoft and the #bing team for free wifi at boston logan airport",
  "id" : 17337868934447105,
  "created_at" : "Tue Dec 21 21:57:24 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tsa",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17333416630423553",
  "text" : "In line for a backscatter. Let's see what the big deal is #tsa",
  "id" : 17333416630423553,
  "created_at" : "Tue Dec 21 21:39:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 1, 12 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HTC",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17312758299107328",
  "text" : "\"@droid_life: DROID Incredible Receives One Of The First Polished Gingerbread ROMs - http://goo.gl/0fD1w\" - dang, that was fast #HTC",
  "id" : 17312758299107328,
  "created_at" : "Tue Dec 21 20:17:37 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16922222434197507",
  "text" : "RT @medialab: A Camera that Sees Around Corners:  http://econ.st/dFJeYZ",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "16909716454113280",
    "text" : "A Camera that Sees Around Corners:  http://econ.st/dFJeYZ",
    "id" : 16909716454113280,
    "created_at" : "Mon Dec 20 17:36:05 +0000 2010",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 16922222434197507,
  "created_at" : "Mon Dec 20 18:25:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16575099410845696",
  "text" : "\"being a smartass is acceptable and encouraged as long as you are right\" - my cs tf #harvard",
  "id" : 16575099410845696,
  "created_at" : "Sun Dec 19 19:26:26 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16572408664170496",
  "text" : "Turing machines own my life right now.",
  "id" : 16572408664170496,
  "created_at" : "Sun Dec 19 19:15:44 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16316951483645952",
  "text" : "RT @engadget: First hand-machined RED EPIC ships, gets lovingly toyed with http://engt.co/dTLb5y",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "16310287707676672",
    "text" : "First hand-machined RED EPIC ships, gets lovingly toyed with http://engt.co/dTLb5y",
    "id" : 16310287707676672,
    "created_at" : "Sun Dec 19 01:54:10 +0000 2010",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2409263463/5g2vkay1y34xj17ke81c_normal.jpeg",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 16316951483645952,
  "created_at" : "Sun Dec 19 02:20:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16202624797769729",
  "text" : "Also people here shipping amazon packages... You can have them directly sent as gifts in the first place!!",
  "id" : 16202624797769729,
  "created_at" : "Sat Dec 18 18:46:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 3, 16 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16201607393837056",
  "text" : "RT @kevinmitnick: Wow! The US Government ALSO held me in solitary confinement for almost 9 months in Los Angeles. It was hell. http://ti ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "16200512512724992",
    "text" : "Wow! The US Government ALSO held me in solitary confinement for almost 9 months in Los Angeles. It was hell. http://tinyurl.com/36a3ry9",
    "id" : 16200512512724992,
    "created_at" : "Sat Dec 18 18:37:57 +0000 2010",
    "user" : {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "protected" : false,
      "id_str" : "14666934",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/53807085/Mitnick_Color_normal.jpg",
      "id" : 14666934,
      "verified" : true
    }
  },
  "id" : 16201607393837056,
  "created_at" : "Sat Dec 18 18:42:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seriously",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16199889167851521",
  "text" : "The line wraps around the store but 3/5 registers are unmanned. #seriously??",
  "id" : 16199889167851521,
  "created_at" : "Sat Dec 18 18:35:29 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usps",
      "indices" : [ 16, 21 ]
    }, {
      "text" : "inefficiency",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16197897833947136",
  "text" : "Holiday time at #usps and they only open half the service counters... Damn #inefficiency",
  "id" : 16197897833947136,
  "created_at" : "Sat Dec 18 18:27:34 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15965954462715904",
  "text" : "Droid X finally got the #android market update",
  "id" : 15965954462715904,
  "created_at" : "Sat Dec 18 03:05:54 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Biz Review",
      "screen_name" : "HarvardBiz",
      "indices" : [ 0, 11 ],
      "id_str" : "14800270",
      "id" : 14800270
    }, {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "indices" : [ 16, 25 ],
      "id_str" : "742143",
      "id" : 742143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15848417318150144",
  "in_reply_to_user_id" : 14800270,
  "text" : "@harvardbiz and @bbcworld have confusingly similar twitter profile images",
  "id" : 15848417318150144,
  "created_at" : "Fri Dec 17 19:18:51 +0000 2010",
  "in_reply_to_screen_name" : "HarvardBiz",
  "in_reply_to_user_id_str" : "14800270",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 13, 20 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15702888835710976",
  "text" : "Playing with @google map update on #android",
  "id" : 15702888835710976,
  "created_at" : "Fri Dec 17 09:40:35 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "indices" : [ 3, 15 ],
      "id_str" : "717313",
      "id" : 717313
    }, {
      "name" : "Peter Bright",
      "screen_name" : "DrPizza",
      "indices" : [ 93, 101 ],
      "id_str" : "11375732",
      "id" : 11375732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15549978147561472",
  "text" : "RT @arstechnica: Stuxnet apparently as effective as a military strike: http://arst.ch/nju by @drpizza",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Bright",
        "screen_name" : "DrPizza",
        "indices" : [ 76, 84 ],
        "id_str" : "11375732",
        "id" : 11375732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "15509253754191872",
    "text" : "Stuxnet apparently as effective as a military strike: http://arst.ch/nju by @drpizza",
    "id" : 15509253754191872,
    "created_at" : "Thu Dec 16 20:51:08 +0000 2010",
    "user" : {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "protected" : false,
      "id_str" : "717313",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2215576731/ars-logo_normal.png",
      "id" : 717313,
      "verified" : true
    }
  },
  "id" : 15549978147561472,
  "created_at" : "Thu Dec 16 23:32:58 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nexusS",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15449210618912768",
  "text" : "Google is pretty bad at the whole product launch thing #nexusS",
  "id" : 15449210618912768,
  "created_at" : "Thu Dec 16 16:52:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "microsoft",
      "indices" : [ 82, 92 ]
    }, {
      "text" : "metro",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15347920396095488",
  "text" : "But the app is still prettier than third party options so I use it. Reminds me of #microsoft WP7 #metro UI",
  "id" : 15347920396095488,
  "created_at" : "Thu Dec 16 10:10:04 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 35, 43 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15347462285828096",
  "text" : "Features missing from the official @twitter #android app: mention type-ahead; auto url shortening; recommendations",
  "id" : 15347462285828096,
  "created_at" : "Thu Dec 16 10:08:14 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 12, 26 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15345668855959552",
  "text" : "Why doesn't @hackernewsbot use url shorteners??",
  "id" : 15345668855959552,
  "created_at" : "Thu Dec 16 10:01:07 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Canon",
      "indices" : [ 12, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15285498842976257",
  "text" : "Excited for #Canon 35 f1.4/L - time to see if it lives up to the hype",
  "id" : 15285498842976257,
  "created_at" : "Thu Dec 16 06:02:01 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http://t.co/7EtIyCa",
      "expanded_url" : "http://www.google.com/chrome/intl/en/p/cause/",
      "display_url" : "google.com/chrome/intl/en\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "15273133883789312",
  "text" : "Maxed out my Chrome for a Cause just now: http://t.co/7EtIyCa",
  "id" : 15273133883789312,
  "created_at" : "Thu Dec 16 05:12:53 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15155980996190208",
  "text" : "Confused as to why my Swype keyboard prioritizes 'totty' over 'you' when typing",
  "id" : 15155980996190208,
  "created_at" : "Wed Dec 15 21:27:22 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http://t.co/7EtIyCa",
      "expanded_url" : "http://www.google.com/chrome/intl/en/p/cause/",
      "display_url" : "google.com/chrome/intl/en\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "15125919534415872",
  "text" : "Chrome for a Cause: IE I'm about to lose Google a lot of money http://t.co/7EtIyCa",
  "id" : 15125919534415872,
  "created_at" : "Wed Dec 15 19:27:54 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15102086551183360",
  "text" : "3 ways to manage online id: own and build yourname.com; write blogs instead ofcommenting; curate accounts with major networking sites",
  "id" : 15102086551183360,
  "created_at" : "Wed Dec 15 17:53:12 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Biz Review",
      "screen_name" : "HarvardBiz",
      "indices" : [ 1, 12 ],
      "id_str" : "14800270",
      "id" : 14800270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15100294094389248",
  "text" : "\"@HarvardBiz: Management Tip: 3 Ways to Manage Your Online Identity http://s.hbr.org/gqogAc\" this is fairly ineffective SEO advice...",
  "id" : 15100294094389248,
  "created_at" : "Wed Dec 15 17:46:05 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSJ Business News",
      "screen_name" : "WSJbusiness",
      "indices" : [ 3, 15 ],
      "id_str" : "28140646",
      "id" : 28140646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14998922485301248",
  "text" : "RT @WSJBusiness: China Surpasses Japan in R&D http://on.wsj.com/dEfAvj",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "14982969257107456",
    "text" : "China Surpasses Japan in R&D http://on.wsj.com/dEfAvj",
    "id" : 14982969257107456,
    "created_at" : "Wed Dec 15 09:59:52 +0000 2010",
    "user" : {
      "name" : "WSJ Business News",
      "screen_name" : "WSJbusiness",
      "protected" : false,
      "id_str" : "28140646",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2190610562/wsj-twitter-business_normal.png",
      "id" : 28140646,
      "verified" : false
    }
  },
  "id" : 14998922485301248,
  "created_at" : "Wed Dec 15 11:03:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "finals",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "school",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14904371577884672",
  "text" : "Normally, Sony not bundling an HDMI cable with their PS3 would annoy me.  But right now I am thankful #finals #school",
  "id" : 14904371577884672,
  "created_at" : "Wed Dec 15 04:47:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14806229960368128",
  "text" : "It seems there area few Verizon deadzones scattered around my dorm... Including my bedroom",
  "id" : 14806229960368128,
  "created_at" : "Tue Dec 14 22:17:34 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14577880528850944",
  "text" : "Two courses down, two left. Four comp sci courses in one semester was one of my poorer life choices.",
  "id" : 14577880528850944,
  "created_at" : "Tue Dec 14 07:10:12 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 38, 46 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14440653643579393",
  "text" : "And that's why you make a good dev RT @digitil: if i didn't have to deal with school, i'd be coding all day everyday.",
  "id" : 14440653643579393,
  "created_at" : "Mon Dec 13 22:04:54 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 0, 5 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 6, 19 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14189294767833088",
  "geo" : {
  },
  "id_str" : "14250927208800256",
  "in_reply_to_user_id" : 418,
  "text" : "@dens @sunilnagaraj I just ctrl-t a new tab and paste- recopy in the url bar to strip formatting",
  "id" : 14250927208800256,
  "in_reply_to_status_id" : 14189294767833088,
  "created_at" : "Mon Dec 13 09:31:00 +0000 2010",
  "in_reply_to_screen_name" : "dens",
  "in_reply_to_user_id_str" : "418",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IncMagazine",
      "screen_name" : "IncMagazine",
      "indices" : [ 3, 15 ],
      "id_str" : "476158046",
      "id" : 476158046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14050375258607616",
  "text" : "RT @IncMagazine: Want people to open your emails? Write a compelling subject line. http://ow.ly/3nUsV",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "14032997749624832",
    "text" : "Want people to open your emails? Write a compelling subject line. http://ow.ly/3nUsV",
    "id" : 14032997749624832,
    "created_at" : "Sun Dec 12 19:05:02 +0000 2010",
    "user" : {
      "name" : "Inc. ",
      "screen_name" : "Inc",
      "protected" : false,
      "id_str" : "16896485",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2559773304/xguycpzbrtg964f3wxn9_normal.jpeg",
      "id" : 16896485,
      "verified" : true
    }
  },
  "id" : 14050375258607616,
  "created_at" : "Sun Dec 12 20:14:05 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14013792937582592",
  "text" : "Theyre giving out Red Bulls at Lamont 2-4 PM!",
  "id" : 14013792937582592,
  "created_at" : "Sun Dec 12 17:48:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14012995545862144",
  "text" : "RT @bznotes: Am an avid BB fan. Don't love IPhone or Android. But something's missing. \"RIM, and how a computing platform dies\" - http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "14005890747207680",
    "text" : "Am an avid BB fan. Don't love IPhone or Android. But something's missing. \"RIM, and how a computing platform dies\" - http://bit.ly/gQHlcy",
    "id" : 14005890747207680,
    "created_at" : "Sun Dec 12 17:17:19 +0000 2010",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 14012995545862144,
  "created_at" : "Sun Dec 12 17:45:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celena Chan",
      "screen_name" : "celenachan",
      "indices" : [ 1, 12 ],
      "id_str" : "18780101",
      "id" : 18780101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14012240332062720",
  "text" : "\"@celenachan: starting up twitter again..this time i'll stick to it!\" Nice to see friends coming back :)",
  "id" : 14012240332062720,
  "created_at" : "Sun Dec 12 17:42:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rockmelt",
      "screen_name" : "Rockmelt",
      "indices" : [ 30, 39 ],
      "id_str" : "37006113",
      "id" : 37006113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13755981976571904",
  "text" : "Any followers interested in a @rockmelt invite?",
  "id" : 13755981976571904,
  "created_at" : "Sun Dec 12 00:44:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mae",
      "screen_name" : "mxhuo",
      "indices" : [ 0, 6 ],
      "id_str" : "21170404",
      "id" : 21170404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13723855537315840",
  "geo" : {
  },
  "id_str" : "13724749972635648",
  "in_reply_to_user_id" : 21170404,
  "text" : "@mxhuo that's what she said",
  "id" : 13724749972635648,
  "in_reply_to_status_id" : 13723855537315840,
  "created_at" : "Sat Dec 11 22:40:10 +0000 2010",
  "in_reply_to_screen_name" : "mxhuo",
  "in_reply_to_user_id_str" : "21170404",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13702123912953856",
  "text" : "I am in love with Omega's ceramic and liquid metal Planet Ocean",
  "id" : 13702123912953856,
  "created_at" : "Sat Dec 11 21:10:15 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 0, 13 ],
      "id_str" : "101114131",
      "id" : 101114131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13406419298553856",
  "in_reply_to_user_id" : 101114131,
  "text" : "@blueasiacafe for dinner - thanks for the free boba :)",
  "id" : 13406419298553856,
  "created_at" : "Sat Dec 11 01:35:14 +0000 2010",
  "in_reply_to_screen_name" : "Blueasiacafe",
  "in_reply_to_user_id_str" : "101114131",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13324603359232000",
  "text" : "Andres on mass. ave. definitely gives the best asian haircuts in the square.",
  "id" : 13324603359232000,
  "created_at" : "Fri Dec 10 20:10:07 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 3, 14 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "droid",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13298993329086464",
  "text" : "RT @droid_life: DROID Does Destroy Blackberry Sales At Verizon - http://goo.gl/aGyQ6 #droid",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "droid",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "13297352211169280",
    "text" : "DROID Does Destroy Blackberry Sales At Verizon - http://goo.gl/aGyQ6 #droid",
    "id" : 13297352211169280,
    "created_at" : "Fri Dec 10 18:21:50 +0000 2010",
    "user" : {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "protected" : false,
      "id_str" : "96501375",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1639322866/dl_square_normal.jpg",
      "id" : 96501375,
      "verified" : true
    }
  },
  "id" : 13298993329086464,
  "created_at" : "Fri Dec 10 18:28:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4chan",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13168224380133376",
  "text" : "I'm also kind of surprised some black ops-y NSA type outfit hasn't DDoS'd #4chan into oblivion yet",
  "id" : 13168224380133376,
  "created_at" : "Fri Dec 10 09:48:44 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 16, 23 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chrome",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13167732522491904",
  "text" : "Applied to test @google's #Chrome notebook. Fingers crossed.",
  "id" : 13167732522491904,
  "created_at" : "Fri Dec 10 09:46:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 78, 86 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13166650777935872",
  "text" : "140 chinese characters hold WAY more information than 140 alphabet characters @twitter!",
  "id" : 13166650777935872,
  "created_at" : "Fri Dec 10 09:42:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "droidx",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13158865432481793",
  "text" : "Motorola finally pushed 2.2.1 OTA for #droidx",
  "id" : 13158865432481793,
  "created_at" : "Fri Dec 10 09:11:32 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13077843097419777",
  "text" : "finance v.consulting v. tech? oh, white-collar dilemmas...",
  "id" : 13077843097419777,
  "created_at" : "Fri Dec 10 03:49:35 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13040794822778881",
  "text" : "RT @wired: Dutch teen arrested for pro-WikiLeaks attack on Visa and MasterCard sites - http://wrd.tw/ifYuub",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "13019332162355201",
    "text" : "Dutch teen arrested for pro-WikiLeaks attack on Visa and MasterCard sites - http://wrd.tw/ifYuub",
    "id" : 13019332162355201,
    "created_at" : "Thu Dec 09 23:57:05 +0000 2010",
    "user" : {
      "name" : "Wired",
      "screen_name" : "wired",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2958887633/eab60d838d5c4bb20fa52f0577a2c698_normal.jpeg",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 13040794822778881,
  "created_at" : "Fri Dec 10 01:22:22 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12642148448993280",
  "text" : "RT @hackernewsbot: Visa.com Now Also Down Under DDoS... http://news.blogs.cnn.com/2010/12/08/visa-website-down-after-threat-from-wikilea ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://news.ycombinator.com/\" rel=\"nofollow\">Hacker News Bot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "12638058402807808",
    "text" : "Visa.com Now Also Down Under DDoS... http://news.blogs.cnn.com/2010/12/08/visa-website-down-after-threat-from-wikileaks-supporters/",
    "id" : 12638058402807808,
    "created_at" : "Wed Dec 08 22:42:02 +0000 2010",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/73596050/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 12642148448993280,
  "created_at" : "Wed Dec 08 22:58:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12638937235333120",
  "text" : "Jon Stewart's real laugh is really awkward.",
  "id" : 12638937235333120,
  "created_at" : "Wed Dec 08 22:45:32 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 3, 11 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campus",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "community",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12588125184335872",
  "text" : "RT @Harvard: Executive director of Harvard Center Shanghai named http://bit.ly/hZuw5o #campus #community",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "campus",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "community",
        "indices" : [ 81, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "12583096377417728",
    "text" : "Executive director of Harvard Center Shanghai named http://bit.ly/hZuw5o #campus #community",
    "id" : 12583096377417728,
    "created_at" : "Wed Dec 08 19:03:38 +0000 2010",
    "user" : {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "protected" : false,
      "id_str" : "39585367",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3349317264/1954930211e08d2ba39bb6a670049eb3_normal.png",
      "id" : 39585367,
      "verified" : true
    }
  },
  "id" : 12588125184335872,
  "created_at" : "Wed Dec 08 19:23:37 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 62, 75 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12530561088229377",
  "text" : "I also need to complete the Widener tradition... Race for it? @vcruzcontrol",
  "id" : 12530561088229377,
  "created_at" : "Wed Dec 08 15:34:53 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fanboy",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12524411085131776",
  "text" : "I got a PS3 for the sole purpose of playing the new Ace Combat, which doesn't come out til March #fanboy",
  "id" : 12524411085131776,
  "created_at" : "Wed Dec 08 15:10:26 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft News",
      "screen_name" : "MSFTnews",
      "indices" : [ 32, 41 ],
      "id_str" : "24741685",
      "id" : 24741685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12486122756112384",
  "text" : "Dinner in Cambridge courtesy of @MSFTnews tonight. Hopefully I'll make it to then after this all nighter at the engineering school.",
  "id" : 12486122756112384,
  "created_at" : "Wed Dec 08 12:38:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 7, 15 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 35, 43 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12208462540840960",
  "text" : "Caught @digitil using the official @twitter android app. Who's laughing now??",
  "id" : 12208462540840960,
  "created_at" : "Tue Dec 07 18:14:58 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12078576606121984",
  "text" : "Now that it's below freezing when can we expect some snow??",
  "id" : 12078576606121984,
  "created_at" : "Tue Dec 07 09:38:51 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11728257212743680",
  "text" : "A haiku: Glasses reflect screen; / Creased eyes betray frustration. / P = NP?",
  "id" : 11728257212743680,
  "created_at" : "Mon Dec 06 10:26:49 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roy Rodenstein",
      "screen_name" : "royrod",
      "indices" : [ 3, 10 ],
      "id_str" : "16954668",
      "id" : 16954668
    }, {
      "name" : "Venture Hacks",
      "screen_name" : "venturehacks",
      "indices" : [ 50, 63 ],
      "id_str" : "11620792",
      "id" : 11620792
    }, {
      "name" : "Elad Gil",
      "screen_name" : "eladgil",
      "indices" : [ 130, 138 ],
      "id_str" : "6535212",
      "id" : 6535212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11502442466250752",
  "text" : "RT @royrod: Yes, please, no more of these! :)  RT @venturehacks: 6 Startup Ideas Every Nerd Has http://vh.co/f44EGq. Too true. By @eladgil",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Venture Hacks",
        "screen_name" : "venturehacks",
        "indices" : [ 38, 51 ],
        "id_str" : "11620792",
        "id" : 11620792
      }, {
        "name" : "Elad Gil",
        "screen_name" : "eladgil",
        "indices" : [ 118, 126 ],
        "id_str" : "6535212",
        "id" : 6535212
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "9674331328086016",
    "text" : "Yes, please, no more of these! :)  RT @venturehacks: 6 Startup Ideas Every Nerd Has http://vh.co/f44EGq. Too true. By @eladgil",
    "id" : 9674331328086016,
    "created_at" : "Tue Nov 30 18:25:14 +0000 2010",
    "user" : {
      "name" : "Roy Rodenstein",
      "screen_name" : "royrod",
      "protected" : false,
      "id_str" : "16954668",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1809414318/Roy_Headshot_-_Small_normal.jpg",
      "id" : 16954668,
      "verified" : false
    }
  },
  "id" : 11502442466250752,
  "created_at" : "Sun Dec 05 19:29:30 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11376423738540032",
  "text" : "Finally beat the Half Life canon. Now work can begin in earnest.",
  "id" : 11376423738540032,
  "created_at" : "Sun Dec 05 11:08:45 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSJ Business News",
      "screen_name" : "WSJbusiness",
      "indices" : [ 3, 15 ],
      "id_str" : "28140646",
      "id" : 28140646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10906970194190336",
  "text" : "RT @WSJBusiness: Google Fails in Quest for Groupon http://on.wsj.com/i2ygCd",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "10898801904586753",
    "text" : "Google Fails in Quest for Groupon http://on.wsj.com/i2ygCd",
    "id" : 10898801904586753,
    "created_at" : "Sat Dec 04 03:30:51 +0000 2010",
    "user" : {
      "name" : "WSJ Business News",
      "screen_name" : "WSJbusiness",
      "protected" : false,
      "id_str" : "28140646",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2190610562/wsj-twitter-business_normal.png",
      "id" : 28140646,
      "verified" : false
    }
  },
  "id" : 10906970194190336,
  "created_at" : "Sat Dec 04 04:03:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 3, 10 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10874946670567424",
  "text" : "RT @cnnbrk: Unmanned Air Force space plane returns from secret, 7-month mission http://on.cnn.com/f5m5yH",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "10861119891570688",
    "text" : "Unmanned Air Force space plane returns from secret, 7-month mission http://on.cnn.com/f5m5yH",
    "id" : 10861119891570688,
    "created_at" : "Sat Dec 04 01:01:07 +0000 2010",
    "user" : {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "protected" : false,
      "id_str" : "428333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1762504301/128x128_cnnbrk_avatar_normal.gif",
      "id" : 428333,
      "verified" : true
    }
  },
  "id" : 10874946670567424,
  "created_at" : "Sat Dec 04 01:56:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10760549843345408",
  "text" : "About to give a presentation to people much smarter than me...",
  "id" : 10760549843345408,
  "created_at" : "Fri Dec 03 18:21:29 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 25, 35 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10749202380365824",
  "text" : "Why can't Harvard have a @momogoose food truck?",
  "id" : 10749202380365824,
  "created_at" : "Fri Dec 03 17:36:24 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BerryLine",
      "screen_name" : "BerryLine",
      "indices" : [ 37, 47 ],
      "id_str" : "25318551",
      "id" : 25318551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10735173582725121",
  "text" : "Someone come try all this with me RT @BerryLine: Nutella is at our Harvard Sq location now! we've still got Gingerbread",
  "id" : 10735173582725121,
  "created_at" : "Fri Dec 03 16:40:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "medialab",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10425606172835840",
  "text" : "Watching the Minority Report computer IN REAL LIFE at MIT #medialab",
  "id" : 10425606172835840,
  "created_at" : "Thu Dec 02 20:10:32 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10348940331319296",
  "text" : "RT @Gizmodo: NASA finds new life, different from all beings in Earth. This changes everything. http://gizmo.do/fjTD4Y",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "10333531850936320",
    "text" : "NASA finds new life, different from all beings in Earth. This changes everything. http://gizmo.do/fjTD4Y",
    "id" : 10333531850936320,
    "created_at" : "Thu Dec 02 14:04:40 +0000 2010",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1860214036/Gizmodo-Twitter-Avatar_normal.jpeg",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 10348940331319296,
  "created_at" : "Thu Dec 02 15:05:54 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lovecraft",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10279079341195264",
  "text" : "Just finished reading The Little Prince. It reminded me eerily of #Lovecraft's Beyond the Walls of Sleep.",
  "id" : 10279079341195264,
  "created_at" : "Thu Dec 02 10:28:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 68, 76 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 77, 88 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10107896650014720",
  "text" : "What do you know, official Google Reader app! http://engt.co/gyFo9b @digitil @droid_life",
  "id" : 10107896650014720,
  "created_at" : "Wed Dec 01 23:08:05 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "medialab",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10077666782748673",
  "text" : "There is a japanese game show being filmed at the #medialab. This is so weird.",
  "id" : 10077666782748673,
  "created_at" : "Wed Dec 01 21:07:57 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 48, 59 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10034994785296386",
  "text" : "What is the best google reader app for android? @droid_life",
  "id" : 10034994785296386,
  "created_at" : "Wed Dec 01 18:18:23 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10032374456782848",
  "text" : "You cannot play christmas music if it's above freezing with no snow!",
  "id" : 10032374456782848,
  "created_at" : "Wed Dec 01 18:07:59 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]