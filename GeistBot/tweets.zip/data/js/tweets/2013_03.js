Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielsuo",
      "screen_name" : "danielsuo",
      "indices" : [ 1, 11 ],
      "id_str" : "18029822",
      "id" : 18029822
    }, {
      "name" : "Floored, Inc.",
      "screen_name" : "Floored3D",
      "indices" : [ 16, 26 ],
      "id_str" : "486054029",
      "id" : 486054029
    }, {
      "name" : "Matterport",
      "screen_name" : "Matterport",
      "indices" : [ 39, 50 ],
      "id_str" : "313641373",
      "id" : 313641373
    }, {
      "name" : "miLES",
      "screen_name" : "MadeinLES",
      "indices" : [ 62, 72 ],
      "id_str" : "573264353",
      "id" : 573264353
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/318378932925759489/photo/1",
      "indices" : [ 104, 126 ],
      "url" : "http://t.co/7EphTIpSkN",
      "media_url" : "http://pbs.twimg.com/media/BGsb8-GCAAAi9_1.jpg",
      "id_str" : "318378932934148096",
      "id" : 318378932934148096,
      "media_url_https" : "https://pbs.twimg.com/media/BGsb8-GCAAAi9_1.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com/7EphTIpSkN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318378932925759489",
  "text" : ".@danielsuo and @floored3D preparing a @matterport to 3D-scan @MadeinLES. Whew, that was a lot of tags. http://t.co/7EphTIpSkN",
  "id" : 318378932925759489,
  "created_at" : "Sun Mar 31 15:07:07 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 3, 9 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318159675608682496",
  "geo" : {
  },
  "id_str" : "318250092165464064",
  "in_reply_to_user_id" : 18918415,
  "text" : "Re @koush: comp sci doesn't measure or observe; not technically science. More similar to applied philosophy and applied math.",
  "id" : 318250092165464064,
  "in_reply_to_status_id" : 318159675608682496,
  "created_at" : "Sun Mar 31 06:35:09 +0000 2013",
  "in_reply_to_screen_name" : "koush",
  "in_reply_to_user_id_str" : "18918415",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Lanning",
      "screen_name" : "yarlyyyy",
      "indices" : [ 0, 9 ],
      "id_str" : "18649631",
      "id" : 18649631
    }, {
      "name" : "brad_porter",
      "screen_name" : "brad_porter",
      "indices" : [ 10, 22 ],
      "id_str" : "17136362",
      "id" : 17136362
    }, {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 23, 29 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318204062652846081",
  "geo" : {
  },
  "id_str" : "318249701478645761",
  "in_reply_to_user_id" : 18649631,
  "text" : "@yarlyyyy @brad_porter @koush I would argue *true* comp sci is more applied philosophy than applied math; not really engineering either.",
  "id" : 318249701478645761,
  "in_reply_to_status_id" : 318204062652846081,
  "created_at" : "Sun Mar 31 06:33:36 +0000 2013",
  "in_reply_to_screen_name" : "yarlyyyy",
  "in_reply_to_user_id_str" : "18649631",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Kwong",
      "screen_name" : "raykwong",
      "indices" : [ 60, 69 ],
      "id_str" : "14926475",
      "id" : 14926475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http://t.co/p2KFaEgSkg",
      "expanded_url" : "http://bit.ly/YnwxQW",
      "display_url" : "bit.ly/YnwxQW"
    } ]
  },
  "in_reply_to_status_id_str" : "318166506917744641",
  "geo" : {
  },
  "id_str" : "318249160988049409",
  "in_reply_to_user_id" : 14926475,
  "text" : "How many have become unpotable in the same time period? \u201Cmt @raykwong: 28,000 rivers in China have vanished. http://t.co/p2KFaEgSkg\"",
  "id" : 318249160988049409,
  "in_reply_to_status_id" : 318166506917744641,
  "created_at" : "Sun Mar 31 06:31:27 +0000 2013",
  "in_reply_to_screen_name" : "raykwong",
  "in_reply_to_user_id_str" : "14926475",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Wegener",
      "screen_name" : "jwegener",
      "indices" : [ 0, 9 ],
      "id_str" : "3187821",
      "id" : 3187821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318200366221115393",
  "geo" : {
  },
  "id_str" : "318248472929267712",
  "in_reply_to_user_id" : 3187821,
  "text" : "@jwegener the three day battery life was easily the best part of that phone.",
  "id" : 318248472929267712,
  "in_reply_to_status_id" : 318200366221115393,
  "created_at" : "Sun Mar 31 06:28:43 +0000 2013",
  "in_reply_to_screen_name" : "jwegener",
  "in_reply_to_user_id_str" : "3187821",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Education Week",
      "screen_name" : "educationweek",
      "indices" : [ 25, 39 ],
      "id_str" : "15147042",
      "id" : 15147042
    }, {
      "name" : "The College Board",
      "screen_name" : "CollegeBoard",
      "indices" : [ 41, 54 ],
      "id_str" : "29716569",
      "id" : 29716569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/2xvzErCzwx",
      "expanded_url" : "http://blogs.edweek.org/edweek/curriculum/2013/03/ap_engineering_may_be_on_the_horizon.html",
      "display_url" : "blogs.edweek.org/edweek/curricu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "318105355664109570",
  "geo" : {
  },
  "id_str" : "318107710669348864",
  "in_reply_to_user_id" : 15147042,
  "text" : "This took way too long. \u201C@educationweek: @CollegeBoard exploring creation of AP program in engineering design. http://t.co/2xvzErCzwx\u201D",
  "id" : 318107710669348864,
  "in_reply_to_status_id" : 318105355664109570,
  "created_at" : "Sat Mar 30 21:09:23 +0000 2013",
  "in_reply_to_screen_name" : "educationweek",
  "in_reply_to_user_id_str" : "15147042",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318105159395856384",
  "text" : "It's amazing to think that all the shiny gadgets we have *today* won't even be worth the effort of trying to sell them in 5 years.",
  "id" : 318105159395856384,
  "created_at" : "Sat Mar 30 20:59:14 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 0, 11 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318091559797137409",
  "geo" : {
  },
  "id_str" : "318103290531422208",
  "in_reply_to_user_id" : 21160381,
  "text" : "@tomloverro the biggest problem w Square wallet is that it's actually not more compelling than a credit card.",
  "id" : 318103290531422208,
  "in_reply_to_status_id" : 318091559797137409,
  "created_at" : "Sat Mar 30 20:51:49 +0000 2013",
  "in_reply_to_screen_name" : "tomloverro",
  "in_reply_to_user_id_str" : "21160381",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318080965262053376",
  "text" : "Would cars be safer if brakes were controlled via electronic paddles on the steering wheel?",
  "id" : 318080965262053376,
  "created_at" : "Sat Mar 30 19:23:06 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/feedly/id396069556?mt=8&uo=4\" rel=\"nofollow\">feedly on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/fLjo47l8vz",
      "expanded_url" : "http://engt.co/Xjfot3",
      "display_url" : "engt.co/Xjfot3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "318067424723353600",
  "text" : "Of all the future-things I wanted as a kid, TVs with smell were pretty low in the list. http://t.co/fLjo47l8vz",
  "id" : 318067424723353600,
  "created_at" : "Sat Mar 30 18:29:18 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory Ortberg",
      "screen_name" : "mallelis",
      "indices" : [ 3, 12 ],
      "id_str" : "20951512",
      "id" : 20951512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318065140811591681",
  "text" : "RT @mallelis: Your ancestors tilled a flinty land; few of their children saw adulthood. You frequent a website to complain about brunch  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "318054325677088769",
    "text" : "Your ancestors tilled a flinty land; few of their children saw adulthood. You frequent a website to complain about brunch service.",
    "id" : 318054325677088769,
    "created_at" : "Sat Mar 30 17:37:15 +0000 2013",
    "user" : {
      "name" : "Mallory Ortberg",
      "screen_name" : "mallelis",
      "protected" : false,
      "id_str" : "20951512",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3469482540/f6cffaaa03319f8718338d7fb5e7610f_normal.jpeg",
      "id" : 20951512,
      "verified" : false
    }
  },
  "id" : 318065140811591681,
  "created_at" : "Sat Mar 30 18:20:13 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kim",
      "screen_name" : "pushingatoms",
      "indices" : [ 0, 13 ],
      "id_str" : "19954028",
      "id" : 19954028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317968300254564352",
  "in_reply_to_user_id" : 19954028,
  "text" : "@pushingatoms would love to read your book but don't have iPad - any way I can buy a PDF version?",
  "id" : 317968300254564352,
  "created_at" : "Sat Mar 30 11:55:25 +0000 2013",
  "in_reply_to_screen_name" : "pushingatoms",
  "in_reply_to_user_id_str" : "19954028",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 0, 5 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317892659383521280",
  "in_reply_to_user_id" : 1439921,
  "text" : "@kane still interested in the increased offer?",
  "id" : 317892659383521280,
  "created_at" : "Sat Mar 30 06:54:50 +0000 2013",
  "in_reply_to_screen_name" : "kane1735613",
  "in_reply_to_user_id_str" : "1439921",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http://t.co/OHLJIWTtz9",
      "expanded_url" : "http://bitcoin.org/bitcoin.pdf",
      "display_url" : "bitcoin.org/bitcoin.pdf"
    } ]
  },
  "in_reply_to_status_id_str" : "317837727682920448",
  "geo" : {
  },
  "id_str" : "317888174745612288",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick nothing beats the original. *Some* technical language but not too much. Def worth reading through. http://t.co/OHLJIWTtz9",
  "id" : 317888174745612288,
  "in_reply_to_status_id" : 317837727682920448,
  "created_at" : "Sat Mar 30 06:37:01 +0000 2013",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 7, 15 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 64, 71 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317822822128959488",
  "text" : "So the @twitter app crashes when I try to unfavorite a tweet by @etaooo.",
  "id" : 317822822128959488,
  "created_at" : "Sat Mar 30 02:17:20 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 22, 29 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317821675808894976",
  "text" : "It blows my mind that @Google Tasks is still a half-assed product with no API.",
  "id" : 317821675808894976,
  "created_at" : "Sat Mar 30 02:12:47 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317787736952164352",
  "geo" : {
  },
  "id_str" : "317792576377847808",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil that metaphor was somewhat forced.",
  "id" : 317792576377847808,
  "in_reply_to_status_id" : 317787736952164352,
  "created_at" : "Sat Mar 30 00:17:09 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 1, 13 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "metaquestion",
      "indices" : [ 40, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317778182453489664",
  "geo" : {
  },
  "id_str" : "317778429732859904",
  "in_reply_to_user_id" : 15101900,
  "text" : "\u201C@alishalisha: Is Klout still relevant? #metaquestion\u201D I think that automatically lowers your Klout score by like 10 points.",
  "id" : 317778429732859904,
  "in_reply_to_status_id" : 317778182453489664,
  "created_at" : "Fri Mar 29 23:20:56 +0000 2013",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317773852480503809",
  "text" : "OH: \"my mom just discovered texting and thinks it's like emails that I'm obligated to answer.\"",
  "id" : 317773852480503809,
  "created_at" : "Fri Mar 29 23:02:45 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http://t.co/Rkq8mkUJOr",
      "expanded_url" : "http://adblockplus.org/en/chrome",
      "display_url" : "adblockplus.org/en/chrome"
    } ]
  },
  "in_reply_to_status_id_str" : "317737833794269184",
  "geo" : {
  },
  "id_str" : "317744286944874496",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin goodbye ads. http://t.co/Rkq8mkUJOr",
  "id" : 317744286944874496,
  "in_reply_to_status_id" : 317737833794269184,
  "created_at" : "Fri Mar 29 21:05:16 +0000 2013",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/Xs5itIQHv5",
      "expanded_url" : "http://jobs.apple.com/us/search#&ss=Maps%20Ground%20Truth%20Manager%20-%20U.S.&t=0&so=&lo=0*USA&pN=0&openJobId=26868863",
      "display_url" : "jobs.apple.com/us/search#&ss=\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317743448553840640",
  "text" : "Apple's \"Ground Truth Manager\" sounds like a clandestine job w Orwellian secret police. http://t.co/Xs5itIQHv5",
  "id" : 317743448553840640,
  "created_at" : "Fri Mar 29 21:01:56 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster Olney",
      "screen_name" : "Buster_ESPN",
      "indices" : [ 64, 76 ],
      "id_str" : "88763317",
      "id" : 88763317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317711638742589441",
  "geo" : {
  },
  "id_str" : "317718624376868865",
  "in_reply_to_user_id" : 88763317,
  "text" : "Wow, I'm terrible w sports. I thought this was an SEC verdict. \u201C@Buster_ESPN: Posey gets nine years, $167 million, starting in 2013.\u201D",
  "id" : 317718624376868865,
  "in_reply_to_status_id" : 317711638742589441,
  "created_at" : "Fri Mar 29 19:23:17 +0000 2013",
  "in_reply_to_screen_name" : "Buster_ESPN",
  "in_reply_to_user_id_str" : "88763317",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/317712203849535490/photo/1",
      "indices" : [ 78, 100 ],
      "url" : "http://t.co/O3IvwBwWsG",
      "media_url" : "http://pbs.twimg.com/media/BGi9kOvCEAEq47R.jpg",
      "id_str" : "317712203857924097",
      "id" : 317712203857924097,
      "media_url_https" : "https://pbs.twimg.com/media/BGi9kOvCEAEq47R.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      } ],
      "display_url" : "pic.twitter.com/O3IvwBwWsG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317712203849535490",
  "text" : "An incredibly meta street vendor in SoHo is selling tables to street vendors. http://t.co/O3IvwBwWsG",
  "id" : 317712203849535490,
  "created_at" : "Fri Mar 29 18:57:47 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317682076453306368",
  "geo" : {
  },
  "id_str" : "317700323173101569",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil an optimist would say you never need a name badge when you show up at an event.",
  "id" : 317700323173101569,
  "in_reply_to_status_id" : 317682076453306368,
  "created_at" : "Fri Mar 29 18:10:34 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/60tFsX0aEY",
      "expanded_url" : "http://t.imehop.com/11Xyq6c",
      "display_url" : "t.imehop.com/11Xyq6c"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317695285994323969",
  "text" : "I bet IDC wishes people would just forget about this report. http://t.co/60tFsX0aEY",
  "id" : 317695285994323969,
  "created_at" : "Fri Mar 29 17:50:33 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317688690623254528",
  "geo" : {
  },
  "id_str" : "317693606481784834",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin should have dumped V in there while you were at it and we could have called it a day.",
  "id" : 317693606481784834,
  "in_reply_to_status_id" : 317688690623254528,
  "created_at" : "Fri Mar 29 17:43:52 +0000 2013",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 2, 10 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317692911946964992",
  "text" : "A @mailbox option to show archived emails in order of archiving (rather than received) would be clutch.",
  "id" : 317692911946964992,
  "created_at" : "Fri Mar 29 17:41:07 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    }, {
      "name" : "Scott Carleton",
      "screen_name" : "ScotterC",
      "indices" : [ 17, 26 ],
      "id_str" : "90048571",
      "id" : 90048571
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/317422926859227137/photo/1",
      "indices" : [ 89, 111 ],
      "url" : "http://t.co/PiEajfO2DM",
      "media_url" : "http://pbs.twimg.com/media/BGe2eF-CUAAJTar.jpg",
      "id_str" : "317422926867615744",
      "id" : 317422926867615744,
      "media_url_https" : "https://pbs.twimg.com/media/BGe2eF-CUAAJTar.jpg",
      "sizes" : [ {
        "h" : 715,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com/PiEajfO2DM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317393538188992513",
  "geo" : {
  },
  "id_str" : "317422926859227137",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo @kshsieh @scotterc have you read the authoritative book on that coding paradigm? http://t.co/PiEajfO2DM",
  "id" : 317422926859227137,
  "in_reply_to_status_id" : 317393538188992513,
  "created_at" : "Thu Mar 28 23:48:18 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 66, 74 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http://t.co/RW7ZJaUAOG",
      "expanded_url" : "http://t.imehop.com/10kSWME",
      "display_url" : "t.imehop.com/10kSWME"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317294764531802113",
  "text" : "Remember when Android Gingerbread was a big deal? I do, thanks to @timehop.  http://t.co/RW7ZJaUAOG",
  "id" : 317294764531802113,
  "created_at" : "Thu Mar 28 15:19:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Friends of Ai Weiwei",
      "screen_name" : "FriendsofAiWW",
      "indices" : [ 37, 51 ],
      "id_str" : "862974031",
      "id" : 862974031
    }, {
      "name" : "\u827E\u672A\u672A  Ai Weiwei",
      "screen_name" : "aiww",
      "indices" : [ 98, 103 ],
      "id_str" : "43654274",
      "id" : 43654274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http://t.co/BgCJdXso3W",
      "expanded_url" : "http://tmblr.co/ZUQmAyhFL-",
      "display_url" : "tmblr.co/ZUQmAyhFL-"
    } ]
  },
  "in_reply_to_status_id_str" : "317290110108454912",
  "geo" : {
  },
  "id_str" : "317290792920154113",
  "in_reply_to_user_id" : 862974031,
  "text" : "Ironically, that link doesn't work. \u201C@FriendsofAiWW: The Astonishing Speed of Chinese Censorship. @aiww  http://t.co/BgCJdXso3W\u201D",
  "id" : 317290792920154113,
  "in_reply_to_status_id" : 317290110108454912,
  "created_at" : "Thu Mar 28 15:03:14 +0000 2013",
  "in_reply_to_screen_name" : "FriendsofAiWW",
  "in_reply_to_user_id_str" : "862974031",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http://t.co/W4kSmI4MJY",
      "expanded_url" : "http://comp.social.gatech.edu/papers/cscw13.reddit.gilbert.pdf",
      "display_url" : "comp.social.gatech.edu/papers/cscw13.\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317265222387789824",
  "text" : "Wow, a GA Tech paper quantified Reddit reposts. http://t.co/W4kSmI4MJY",
  "id" : 317265222387789824,
  "created_at" : "Thu Mar 28 13:21:38 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http://t.co/DB1zy0c6IZ",
      "expanded_url" : "http://www.youtube.com/watch?v=U9eAiy0IGBI",
      "display_url" : "youtube.com/watch?v=U9eAiy\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317014530783854593",
  "text" : "I laughed watching this 1930 vid predicting 2000, then I realized we sound equally dumb trying to predict 2070. http://t.co/DB1zy0c6IZ",
  "id" : 317014530783854593,
  "created_at" : "Wed Mar 27 20:45:28 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perry Hewitt",
      "screen_name" : "perryhewitt",
      "indices" : [ 0, 12 ],
      "id_str" : "1363481",
      "id" : 1363481
    }, {
      "name" : "Houzz Inc",
      "screen_name" : "Houzz_inc",
      "indices" : [ 65, 75 ],
      "id_str" : "1119416251",
      "id" : 1119416251
    }, {
      "name" : "Harvard GSD",
      "screen_name" : "HarvardGSD",
      "indices" : [ 100, 111 ],
      "id_str" : "19272669",
      "id" : 19272669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316940444082778113",
  "geo" : {
  },
  "id_str" : "316984545629052928",
  "in_reply_to_user_id" : 1363481,
  "text" : "@perryhewitt if we're on lackluster logos, can we talk about how @houzz_inc's logo is *the same* as @HarvardGSD's?",
  "id" : 316984545629052928,
  "in_reply_to_status_id" : 316940444082778113,
  "created_at" : "Wed Mar 27 18:46:19 +0000 2013",
  "in_reply_to_screen_name" : "perryhewitt",
  "in_reply_to_user_id_str" : "1363481",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/feedly/id396069556?mt=8&uo=4\" rel=\"nofollow\">feedly on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/2xEcnI2Jws",
      "expanded_url" : "http://feedly.com/k/YDxTXs",
      "display_url" : "feedly.com/k/YDxTXs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316773022621134848",
  "text" : "A tribute to Hollywood's obsession with mainframes, the ultimate technical plot device. http://t.co/2xEcnI2Jws",
  "id" : 316773022621134848,
  "created_at" : "Wed Mar 27 04:45:48 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wut",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316741158632054784",
  "geo" : {
  },
  "id_str" : "316768503799619584",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil EU bailout would basically be a rescue of sheltered Russian money by German taxpayers #wut",
  "id" : 316768503799619584,
  "in_reply_to_status_id" : 316741158632054784,
  "created_at" : "Wed Mar 27 04:27:51 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316703179574243328",
  "text" : "OH: \"less think tanks, more do tanks.\"",
  "id" : 316703179574243328,
  "created_at" : "Wed Mar 27 00:08:16 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 1, 8 ],
      "id_str" : "224321197",
      "id" : 224321197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316591254983036928",
  "geo" : {
  },
  "id_str" : "316638182223523840",
  "in_reply_to_user_id" : 224321197,
  "text" : "\u201C@zhamed: Proud to finally announce I\u2019ve been selected as a Thiel Fellowship finalist!\" Fantastic job, Zach!",
  "id" : 316638182223523840,
  "in_reply_to_status_id" : 316591254983036928,
  "created_at" : "Tue Mar 26 19:50:00 +0000 2013",
  "in_reply_to_screen_name" : "zhamed",
  "in_reply_to_user_id_str" : "224321197",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 85, 91 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http://t.co/BUSKJ6BDrr",
      "expanded_url" : "http://www.youtube.com/watch?v=RskzYHPlh5U",
      "display_url" : "youtube.com/watch?v=RskzYH\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316582752482893825",
  "text" : "\"Your GPA only matters to people who have no other reason to find you interesting\" - @sacca's commencement address. http://t.co/BUSKJ6BDrr",
  "id" : 316582752482893825,
  "created_at" : "Tue Mar 26 16:09:44 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "indices" : [ 3, 12 ],
      "id_str" : "237573925",
      "id" : 237573925
    }, {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 21, 29 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316572658936463361",
  "text" : "RT @touhsieh: Having @Wegmans in Fenway will be like having a little piece of Buffalo here in Boston :)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wegmans Food Markets",
        "screen_name" : "Wegmans",
        "indices" : [ 7, 15 ],
        "id_str" : "66482863",
        "id" : 66482863
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "316570665316651010",
    "text" : "Having @Wegmans in Fenway will be like having a little piece of Buffalo here in Boston :)",
    "id" : 316570665316651010,
    "created_at" : "Tue Mar 26 15:21:42 +0000 2013",
    "user" : {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "protected" : false,
      "id_str" : "237573925",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3426911799/7f8f4371330b78b4712111654781af78_normal.jpeg",
      "id" : 237573925,
      "verified" : false
    }
  },
  "id" : 316572658936463361,
  "created_at" : "Tue Mar 26 15:29:38 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 55, 63 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http://t.co/GHY7xstKfN",
      "expanded_url" : "http://www.mixshape.ie",
      "display_url" : "mixshape.ie"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316566855684849666",
  "text" : "Microsoft's MixShape does an excellent job fine tuning @spotify playlists - been working to it all day. http://t.co/GHY7xstKfN",
  "id" : 316566855684849666,
  "created_at" : "Tue Mar 26 15:06:34 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http://t.co/a3h0VsN9fd",
      "expanded_url" : "http://blog.kanehsieh.com/2013/03/25/3d-printing-a-controversy/",
      "display_url" : "blog.kanehsieh.com/2013/03/25/3d-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316373000020713473",
  "text" : "3D Printing a Controversy - the overreaction to 3D printed guns. http://t.co/a3h0VsN9fd",
  "id" : 316373000020713473,
  "created_at" : "Tue Mar 26 02:16:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 15, 27 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 32, 40 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/a49DS3aQEF",
      "expanded_url" : "http://www.bizjournals.com/boston/blog/startups/2013/03/harvard-peter-boyce-startups-roughdraft.html?ana=twt",
      "display_url" : "bizjournals.com/boston/blog/st\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316350572624224257",
  "text" : "Great piece on @badboyboyce and @bznotes for their continuing work in Boston and Cambridge! http://t.co/a49DS3aQEF",
  "id" : 316350572624224257,
  "created_at" : "Tue Mar 26 00:47:08 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perry Hewitt",
      "screen_name" : "perryhewitt",
      "indices" : [ 1, 13 ],
      "id_str" : "1363481",
      "id" : 1363481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/QijWKGdoU2",
      "expanded_url" : "http://buff.ly/Y8cS7q",
      "display_url" : "buff.ly/Y8cS7q"
    } ]
  },
  "in_reply_to_status_id_str" : "316305693856628737",
  "geo" : {
  },
  "id_str" : "316306650342510592",
  "in_reply_to_user_id" : 1363481,
  "text" : "\u201C@perryhewitt: We're hiring: do you like the pursuit of knowledge, a storied brand, social media, and the internets? http://t.co/QijWKGdoU2\u201D",
  "id" : 316306650342510592,
  "in_reply_to_status_id" : 316305693856628737,
  "created_at" : "Mon Mar 25 21:52:36 +0000 2013",
  "in_reply_to_screen_name" : "perryhewitt",
  "in_reply_to_user_id_str" : "1363481",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perry Hewitt",
      "screen_name" : "perryhewitt",
      "indices" : [ 0, 12 ],
      "id_str" : "1363481",
      "id" : 1363481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316305693856628737",
  "geo" : {
  },
  "id_str" : "316306549704384512",
  "in_reply_to_user_id" : 1363481,
  "text" : "@perryhewitt I would totally do this if I didn't have a job right now.",
  "id" : 316306549704384512,
  "in_reply_to_status_id" : 316305693856628737,
  "created_at" : "Mon Mar 25 21:52:12 +0000 2013",
  "in_reply_to_screen_name" : "perryhewitt",
  "in_reply_to_user_id_str" : "1363481",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Chou",
      "screen_name" : "markdchou",
      "indices" : [ 0, 10 ],
      "id_str" : "67686145",
      "id" : 67686145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316273392431005696",
  "geo" : {
  },
  "id_str" : "316274454353305601",
  "in_reply_to_user_id" : 67686145,
  "text" : "@markdchou interesting, I much prefer nylon over steel for warmer months! Much lighter on wrist and machine washable.",
  "id" : 316274454353305601,
  "in_reply_to_status_id" : 316273392431005696,
  "created_at" : "Mon Mar 25 19:44:40 +0000 2013",
  "in_reply_to_screen_name" : "markdchou",
  "in_reply_to_user_id_str" : "67686145",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neal Doyle",
      "screen_name" : "ndoyle",
      "indices" : [ 0, 7 ],
      "id_str" : "15873557",
      "id" : 15873557
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 8, 15 ],
      "id_str" : "224321197",
      "id" : 224321197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316002570516717568",
  "geo" : {
  },
  "id_str" : "316272998820769792",
  "in_reply_to_user_id" : 15873557,
  "text" : "@ndoyle @zhamed I prefer Readability over Instapaper for its design and cross-platform ease of use.",
  "id" : 316272998820769792,
  "in_reply_to_status_id" : 316002570516717568,
  "created_at" : "Mon Mar 25 19:38:53 +0000 2013",
  "in_reply_to_screen_name" : "ndoyle",
  "in_reply_to_user_id_str" : "15873557",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 0, 5 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315916761881010176",
  "geo" : {
  },
  "id_str" : "315918167530680320",
  "in_reply_to_user_id" : 1439921,
  "text" : "@kane happy to match.",
  "id" : 315918167530680320,
  "in_reply_to_status_id" : 315916761881010176,
  "created_at" : "Sun Mar 24 20:08:55 +0000 2013",
  "in_reply_to_screen_name" : "kane1735613",
  "in_reply_to_user_id_str" : "1439921",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Co.Design",
      "screen_name" : "FastCoDesign",
      "indices" : [ 3, 16 ],
      "id_str" : "158865339",
      "id" : 158865339
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 32, 44 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "Nat'l Endow f/t Arts",
      "screen_name" : "NEAarts",
      "indices" : [ 107, 115 ],
      "id_str" : "41655821",
      "id" : 41655821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/vOtrDHsfxa",
      "expanded_url" : "http://trib.al/mIDtv4f",
      "display_url" : "trib.al/mIDtv4f"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315913681399586816",
  "text" : "RT @FastCoDesign: Kickstarters (@Kickstarter) now dwarf the budget of the National Endowment for the Arts (@NEAarts): http://t.co/vOtrDHsfxa",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kickstarter",
        "screen_name" : "kickstarter",
        "indices" : [ 14, 26 ],
        "id_str" : "16186995",
        "id" : 16186995
      }, {
        "name" : "Nat'l Endow f/t Arts",
        "screen_name" : "NEAarts",
        "indices" : [ 89, 97 ],
        "id_str" : "41655821",
        "id" : 41655821
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http://t.co/vOtrDHsfxa",
        "expanded_url" : "http://trib.al/mIDtv4f",
        "display_url" : "trib.al/mIDtv4f"
      } ]
    },
    "geo" : {
    },
    "id_str" : "315103687536177152",
    "text" : "Kickstarters (@Kickstarter) now dwarf the budget of the National Endowment for the Arts (@NEAarts): http://t.co/vOtrDHsfxa",
    "id" : 315103687536177152,
    "created_at" : "Fri Mar 22 14:12:28 +0000 2013",
    "user" : {
      "name" : "Co.Design",
      "screen_name" : "FastCoDesign",
      "protected" : false,
      "id_str" : "158865339",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1782675147/1214-co-design-twitter-logo_normal.gif",
      "id" : 158865339,
      "verified" : true
    }
  },
  "id" : 315913681399586816,
  "created_at" : "Sun Mar 24 19:51:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warby Parker",
      "screen_name" : "WarbyParker",
      "indices" : [ 21, 33 ],
      "id_str" : "77527412",
      "id" : 77527412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/L3W5o2pPGB",
      "expanded_url" : "http://4sq.com/ZZzZiE",
      "display_url" : "4sq.com/ZZzZiE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7248190553, -73.995700375 ]
  },
  "id_str" : "315911985806073857",
  "text" : "Sunday showroom. (at @WarbyParker - Puck Store w/ 10 others) [pic]: http://t.co/L3W5o2pPGB",
  "id" : 315911985806073857,
  "created_at" : "Sun Mar 24 19:44:21 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315889416935702528",
  "geo" : {
  },
  "id_str" : "315897434809192449",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive Dr. JD Robinson IV has a ring to it.",
  "id" : 315897434809192449,
  "in_reply_to_status_id" : 315889416935702528,
  "created_at" : "Sun Mar 24 18:46:32 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http://t.co/7T382mBjoj",
      "expanded_url" : "http://t.imehop.com/WOW2cN",
      "display_url" : "t.imehop.com/WOW2cN"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315873919066320896",
  "text" : "Still not useful. http://t.co/7T382mBjoj",
  "id" : 315873919066320896,
  "created_at" : "Sun Mar 24 17:13:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 0, 5 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315819256237395968",
  "geo" : {
  },
  "id_str" : "315856534766768128",
  "in_reply_to_user_id" : 1439921,
  "text" : "@kane $250 cash, open to negotiations.",
  "id" : 315856534766768128,
  "in_reply_to_status_id" : 315819256237395968,
  "created_at" : "Sun Mar 24 16:04:00 +0000 2013",
  "in_reply_to_screen_name" : "kane1735613",
  "in_reply_to_user_id_str" : "1439921",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 3, 9 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315706808759111680",
  "text" : "RT @jluan: Yo, k-means, imma let you finish, but you're the slowest algorithm of all time. ALL TIME. (close enough.)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "315669770060050432",
    "text" : "Yo, k-means, imma let you finish, but you're the slowest algorithm of all time. ALL TIME. (close enough.)",
    "id" : 315669770060050432,
    "created_at" : "Sun Mar 24 03:41:52 +0000 2013",
    "user" : {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "protected" : false,
      "id_str" : "27015881",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1366826138/72500_1527561949320_1242810207_31307527_6609490_n_1__normal.jpg",
      "id" : 27015881,
      "verified" : false
    }
  },
  "id" : 315706808759111680,
  "created_at" : "Sun Mar 24 06:09:03 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315666827143426049",
  "geo" : {
  },
  "id_str" : "315701997758197761",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo @kshsieh chyeahhh",
  "id" : 315701997758197761,
  "in_reply_to_status_id" : 315666827143426049,
  "created_at" : "Sun Mar 24 05:49:56 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "indices" : [ 0, 16 ],
      "id_str" : "353789193",
      "id" : 353789193
    }, {
      "name" : "Keith Rabois",
      "screen_name" : "rabois",
      "indices" : [ 17, 24 ],
      "id_str" : "20263710",
      "id" : 20263710
    }, {
      "name" : "Charlie Cheever",
      "screen_name" : "ccheever",
      "indices" : [ 25, 34 ],
      "id_str" : "4653371",
      "id" : 4653371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315309509855825920",
  "geo" : {
  },
  "id_str" : "315342830736400386",
  "in_reply_to_user_id" : 353789193,
  "text" : "@StartupLJackson @rabois @ccheever Sunrise is the only one that can manage multi-invite events bc they architected around iOS's crappy API.",
  "id" : 315342830736400386,
  "in_reply_to_status_id" : 315309509855825920,
  "created_at" : "Sat Mar 23 06:02:44 +0000 2013",
  "in_reply_to_screen_name" : "StartupLJackson",
  "in_reply_to_user_id_str" : "353789193",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315242415516700672",
  "text" : "Based on \"Olympus has Fallen\" and \"Red Dawn,\" Asians are the new Russians.",
  "id" : 315242415516700672,
  "created_at" : "Fri Mar 22 23:23:43 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Wegener",
      "screen_name" : "jwegener",
      "indices" : [ 14, 23 ],
      "id_str" : "3187821",
      "id" : 3187821
    }, {
      "name" : "AngelList",
      "screen_name" : "angellist",
      "indices" : [ 30, 40 ],
      "id_str" : "94682674",
      "id" : 94682674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/Lgo8n0y0Lr",
      "expanded_url" : "http://cl.ly/image/2h2W0u3v2a1v",
      "display_url" : "cl.ly/image/2h2W0u3v\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "315217948602150912",
  "geo" : {
  },
  "id_str" : "315229382375534593",
  "in_reply_to_user_id" : 3187821,
  "text" : "Great catch. \u201C@jwegener: ORLY @angellist... i beg to differ. http://t.co/Lgo8n0y0Lr\u201D",
  "id" : 315229382375534593,
  "in_reply_to_status_id" : 315217948602150912,
  "created_at" : "Fri Mar 22 22:31:56 +0000 2013",
  "in_reply_to_screen_name" : "jwegener",
  "in_reply_to_user_id_str" : "3187821",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315191677990084609",
  "geo" : {
  },
  "id_str" : "315228165586944000",
  "in_reply_to_user_id" : 111999960,
  "text" : "@kshsieh I only code in full kit.",
  "id" : 315228165586944000,
  "in_reply_to_status_id" : 315191677990084609,
  "created_at" : "Fri Mar 22 22:27:05 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315226548783423489",
  "text" : "Places with lines for men's bathrooms: the 4 PM showing of Olympus has Fallen.",
  "id" : 315226548783423489,
  "created_at" : "Fri Mar 22 22:20:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315189544205053953",
  "geo" : {
  },
  "id_str" : "315191443268444160",
  "in_reply_to_user_id" : 111999960,
  "text" : "@kshsieh more aggressive geometry plz",
  "id" : 315191443268444160,
  "in_reply_to_status_id" : 315189544205053953,
  "created_at" : "Fri Mar 22 20:01:10 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315188134688206848",
  "geo" : {
  },
  "id_str" : "315188703163211777",
  "in_reply_to_user_id" : 111999960,
  "text" : "@kshsieh the obvious solution is to start coding while riding a trainer.",
  "id" : 315188703163211777,
  "in_reply_to_status_id" : 315188134688206848,
  "created_at" : "Fri Mar 22 19:50:17 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 0, 5 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315188361528745984",
  "in_reply_to_user_id" : 1439921,
  "text" : "@kane willing to buy your username! Let me know if interested.",
  "id" : 315188361528745984,
  "created_at" : "Fri Mar 22 19:48:55 +0000 2013",
  "in_reply_to_screen_name" : "kane1735613",
  "in_reply_to_user_id_str" : "1439921",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/315164778110783489/photo/1",
      "indices" : [ 48, 70 ],
      "url" : "http://t.co/B8hiX3QIG9",
      "media_url" : "http://pbs.twimg.com/media/BF-wsiXCEAAvDe7.png",
      "id_str" : "315164778123366400",
      "id" : 315164778123366400,
      "media_url_https" : "https://pbs.twimg.com/media/BF-wsiXCEAAvDe7.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/B8hiX3QIG9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315164778110783489",
  "text" : "Great use of iPhone, or greatest use of iPhone? http://t.co/B8hiX3QIG9",
  "id" : 315164778110783489,
  "created_at" : "Fri Mar 22 18:15:13 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Fleishman",
      "screen_name" : "GlennF",
      "indices" : [ 3, 10 ],
      "id_str" : "8315692",
      "id" : 8315692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315156795473674240",
  "text" : "RT @GlennF: Jony Ives, in his office, seizes the speaking tube. \u201CRemove the stitching!\u201D His voice echoes down the vasty spaces of Apple\u2019 ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "314961372054163458",
    "text" : "Jony Ives, in his office, seizes the speaking tube. \u201CRemove the stitching!\u201D His voice echoes down the vasty spaces of Apple\u2019s skeu factories",
    "id" : 314961372054163458,
    "created_at" : "Fri Mar 22 04:46:57 +0000 2013",
    "user" : {
      "name" : "Glenn Fleishman",
      "screen_name" : "GlennF",
      "protected" : false,
      "id_str" : "8315692",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2942545630/2fe07637de189972ce58229c708f6e2a_normal.jpeg",
      "id" : 8315692,
      "verified" : false
    }
  },
  "id" : 315156795473674240,
  "created_at" : "Fri Mar 22 17:43:30 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Games",
      "screen_name" : "EpicGames",
      "indices" : [ 3, 13 ],
      "id_str" : "121258930",
      "id" : 121258930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http://t.co/6uFN1VKmTU",
      "expanded_url" : "http://venturebeat.com/2013/03/21/tencent-paid-330m-for-40-of-epic-games/",
      "display_url" : "venturebeat.com/2013/03/21/ten\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315152412669263872",
  "text" : "So @EpicGames is worth .85 Instagrams, and is 40% owned by a Chinese co. now. Weird. http://t.co/6uFN1VKmTU",
  "id" : 315152412669263872,
  "created_at" : "Fri Mar 22 17:26:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315148787700072448",
  "text" : "OH: \"AirBnB for botnets!\"",
  "id" : 315148787700072448,
  "created_at" : "Fri Mar 22 17:11:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ozaki",
      "screen_name" : "Ozakiverse",
      "indices" : [ 1, 12 ],
      "id_str" : "373063470",
      "id" : 373063470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315148262334152705",
  "geo" : {
  },
  "id_str" : "315148671916310529",
  "in_reply_to_user_id" : 373063470,
  "text" : ".@Ozakiverse is easily one of my favorite, small, off-the-cuff Apple accessory makers.",
  "id" : 315148671916310529,
  "in_reply_to_status_id" : 315148262334152705,
  "created_at" : "Fri Mar 22 17:11:13 +0000 2013",
  "in_reply_to_screen_name" : "Ozakiverse",
  "in_reply_to_user_id_str" : "373063470",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 6, 17 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Nikolay Bachiyski",
      "screen_name" : "nikolayb",
      "indices" : [ 27, 36 ],
      "id_str" : "7652262",
      "id" : 7652262
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/315148276729012224/photo/1",
      "indices" : [ 38, 60 ],
      "url" : "http://t.co/qb28qNasXR",
      "media_url" : "http://pbs.twimg.com/media/BF-hsB5CYAAIgNa.jpg",
      "id_str" : "315148276733206528",
      "id" : 315148276733206528,
      "media_url_https" : "https://pbs.twimg.com/media/BF-hsB5CYAAIgNa.jpg",
      "sizes" : [ {
        "h" : 329,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1058,
        "resize" : "fit",
        "w" : 1928
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com/qb28qNasXR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315148276729012224",
  "text" : "Great @techcrunch piece by @nikolayb! http://t.co/qb28qNasXR",
  "id" : 315148276729012224,
  "created_at" : "Fri Mar 22 17:09:39 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Lampoon",
      "screen_name" : "harvardlampoon",
      "indices" : [ 3, 18 ],
      "id_str" : "28849244",
      "id" : 28849244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315090879637491715",
  "text" : "RT @harvardlampoon: America, we are sorry for messing up your brackets and also your financial system and everything else.",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "314956099944071168",
    "text" : "America, we are sorry for messing up your brackets and also your financial system and everything else.",
    "id" : 314956099944071168,
    "created_at" : "Fri Mar 22 04:26:00 +0000 2013",
    "user" : {
      "name" : "Harvard Lampoon",
      "screen_name" : "harvardlampoon",
      "protected" : false,
      "id_str" : "28849244",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/121669309/LAMPY_JESTERLUTE_normal.jpg",
      "id" : 28849244,
      "verified" : false
    }
  },
  "id" : 315090879637491715,
  "created_at" : "Fri Mar 22 13:21:34 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Lin",
      "screen_name" : "JLin7",
      "indices" : [ 3, 9 ],
      "id_str" : "170424259",
      "id" : 170424259
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/JLin7/status/314955449734664192/photo/1",
      "indices" : [ 114, 136 ],
      "url" : "http://t.co/ZlpqTFCPtM",
      "media_url" : "http://pbs.twimg.com/media/BF7yUBYCEAABOM7.png",
      "id_str" : "314955449743052800",
      "id" : 314955449743052800,
      "media_url_https" : "https://pbs.twimg.com/media/BF7yUBYCEAABOM7.png",
      "sizes" : [ {
        "h" : 555,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/ZlpqTFCPtM"
    } ],
    "hashtags" : [ {
      "text" : "threepointgoggles",
      "indices" : [ 79, 97 ]
    }, {
      "text" : "bracketbusters",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314962403836170241",
  "text" : "RT @JLin7: YYYYYEEEEESSSSSSSSS!!! HARVARD winssss!!! hahahahhah i told you.... #threepointgoggles #bracketbusters http://t.co/ZlpqTFCPtM",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/JLin7/status/314955449734664192/photo/1",
        "indices" : [ 103, 125 ],
        "url" : "http://t.co/ZlpqTFCPtM",
        "media_url" : "http://pbs.twimg.com/media/BF7yUBYCEAABOM7.png",
        "id_str" : "314955449743052800",
        "id" : 314955449743052800,
        "media_url_https" : "https://pbs.twimg.com/media/BF7yUBYCEAABOM7.png",
        "sizes" : [ {
          "h" : 555,
          "resize" : "fit",
          "w" : 393
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 393
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 393
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/ZlpqTFCPtM"
      } ],
      "hashtags" : [ {
        "text" : "threepointgoggles",
        "indices" : [ 68, 86 ]
      }, {
        "text" : "bracketbusters",
        "indices" : [ 87, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "314955449734664192",
    "text" : "YYYYYEEEEESSSSSSSSS!!! HARVARD winssss!!! hahahahhah i told you.... #threepointgoggles #bracketbusters http://t.co/ZlpqTFCPtM",
    "id" : 314955449734664192,
    "created_at" : "Fri Mar 22 04:23:25 +0000 2013",
    "user" : {
      "name" : "Jeremy Lin",
      "screen_name" : "JLin7",
      "protected" : false,
      "id_str" : "170424259",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574394286/Screen_shot_2011-10-05_at_2.27.45_PM_normal.png",
      "id" : 170424259,
      "verified" : true
    }
  },
  "id" : 314962403836170241,
  "created_at" : "Fri Mar 22 04:51:03 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 3, 12 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314962070137348096",
  "text" : "RT @BuzzFeed: RIP my brackets",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "314956973860868096",
    "text" : "RIP my brackets",
    "id" : 314956973860868096,
    "created_at" : "Fri Mar 22 04:29:28 +0000 2013",
    "user" : {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "protected" : false,
      "id_str" : "5695632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2852410605/6e6da28a06cfd7aea20a3cc393ef1182_normal.png",
      "id" : 5695632,
      "verified" : true
    }
  },
  "id" : 314962070137348096,
  "created_at" : "Fri Mar 22 04:49:43 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kathleen french",
      "screen_name" : "frenchamnesty",
      "indices" : [ 3, 17 ],
      "id_str" : "253346218",
      "id" : 253346218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314962037698605057",
  "text" : "RT @frenchamnesty: DID NATE SILVER PREDICT THIS?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "314957085269970945",
    "text" : "DID NATE SILVER PREDICT THIS?",
    "id" : 314957085269970945,
    "created_at" : "Fri Mar 22 04:29:55 +0000 2013",
    "user" : {
      "name" : "kathleen french",
      "screen_name" : "frenchamnesty",
      "protected" : false,
      "id_str" : "253346218",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3412339139/6848e6ab77e0642f496fde5ab8b73da1_normal.jpeg",
      "id" : 253346218,
      "verified" : false
    }
  },
  "id" : 314962037698605057,
  "created_at" : "Fri Mar 22 04:49:36 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Basketball",
      "screen_name" : "hoopsatharvard",
      "indices" : [ 27, 42 ],
      "id_str" : "168667707",
      "id" : 168667707
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/314954950969024514/photo/1",
      "indices" : [ 69, 91 ],
      "url" : "http://t.co/WXYzKYY4fs",
      "media_url" : "http://pbs.twimg.com/media/BF7x2_VCYAAgEPs.jpg",
      "id_str" : "314954950977413120",
      "id" : 314954950977413120,
      "media_url_https" : "https://pbs.twimg.com/media/BF7x2_VCYAAgEPs.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/WXYzKYY4fs"
    } ],
    "hashtags" : [ {
      "text" : "GoCrimson",
      "indices" : [ 43, 53 ]
    }, {
      "text" : "MarchMadness",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314954950969024514",
  "text" : "And the crowd goes wild!!! @hoopsatharvard #GoCrimson #MarchMadness. http://t.co/WXYzKYY4fs",
  "id" : 314954950969024514,
  "created_at" : "Fri Mar 22 04:21:26 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314876705581961217",
  "text" : "'07 alumni: cell phones had become ubiquitous when he graduated. When I graduated '12, smart phones were ubiquitous. When '18 graduates??",
  "id" : 314876705581961217,
  "created_at" : "Thu Mar 21 23:10:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard GSD",
      "screen_name" : "HarvardGSD",
      "indices" : [ 1, 12 ],
      "id_str" : "19272669",
      "id" : 19272669
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/314854693757132800/photo/1",
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/uqtPpjfzDS",
      "media_url" : "http://pbs.twimg.com/media/BF6WrQHCIAI2pme.png",
      "id_str" : "314854693765521410",
      "id" : 314854693765521410,
      "media_url_https" : "https://pbs.twimg.com/media/BF6WrQHCIAI2pme.png",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com/uqtPpjfzDS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314854693757132800",
  "text" : ".@HarvardGSD, you're awesome, but the irony that your logo is distorted and pixelated on mobile is too much. Here: http://t.co/uqtPpjfzDS",
  "id" : 314854693757132800,
  "created_at" : "Thu Mar 21 21:43:03 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 51, 57 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314842075231318016",
  "text" : "To clarify, how do I delete old email address from @gmail contacts? Trying to update contacts with outdated emails saved.",
  "id" : 314842075231318016,
  "created_at" : "Thu Mar 21 20:52:54 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Walker",
      "screen_name" : "iamrlw",
      "indices" : [ 0, 7 ],
      "id_str" : "271778074",
      "id" : 271778074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314840399623630849",
  "geo" : {
  },
  "id_str" : "314840679173988352",
  "in_reply_to_user_id" : 271778074,
  "text" : "@iamrlw to be clear, I need to delete the email *addresses* from contact fields - not emails themselves!",
  "id" : 314840679173988352,
  "in_reply_to_status_id" : 314840399623630849,
  "created_at" : "Thu Mar 21 20:47:22 +0000 2013",
  "in_reply_to_screen_name" : "iamrlw",
  "in_reply_to_user_id_str" : "271778074",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 68, 74 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314839038592970752",
  "text" : "How do I bulk delete emails of a certain domain in bulk from all my @gmail contacts? Lots of my friends defunct school emails still default.",
  "id" : 314839038592970752,
  "created_at" : "Thu Mar 21 20:40:50 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314826783583252481",
  "geo" : {
  },
  "id_str" : "314831662364119040",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick darn, and I thought it was because you cared!",
  "id" : 314831662364119040,
  "in_reply_to_status_id" : 314826783583252481,
  "created_at" : "Thu Mar 21 20:11:32 +0000 2013",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Watson",
      "screen_name" : "bwats",
      "indices" : [ 0, 6 ],
      "id_str" : "18500786",
      "id" : 18500786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314781559561523200",
  "in_reply_to_user_id" : 18500786,
  "text" : "@bwats yea, in general I think people need to ctfd before posting stuff, esp in the world with a news-cycle of seconds.",
  "id" : 314781559561523200,
  "created_at" : "Thu Mar 21 16:52:26 +0000 2013",
  "in_reply_to_screen_name" : "bwats",
  "in_reply_to_user_id_str" : "18500786",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http://t.co/HLUuG35GdP",
      "expanded_url" : "http://www.nytimes.com/2013/03/21/us/politics/senate-panel-weighs-privacy-concerns-over-use-of-drones.html?_r=0",
      "display_url" : "nytimes.com/2013/03/21/us/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314781459217006592",
  "text" : "Oh look, more people that don't understand technology legislating about it. #drones http://t.co/HLUuG35GdP",
  "id" : 314781459217006592,
  "created_at" : "Thu Mar 21 16:52:02 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Watson",
      "screen_name" : "bwats",
      "indices" : [ 39, 45 ],
      "id_str" : "18500786",
      "id" : 18500786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https://t.co/g2AVUHN8VQ",
      "expanded_url" : "https://www.facebook.com/SendGrid/posts/10151502570463967",
      "display_url" : "facebook.com/SendGrid/posts\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "314776602766610433",
  "geo" : {
  },
  "id_str" : "314777837213216770",
  "in_reply_to_user_id" : 18500786,
  "text" : "Well that escalated rather quickly... \u201C@bwats: SendGrid, really? https://t.co/g2AVUHN8VQ\u201D",
  "id" : 314777837213216770,
  "in_reply_to_status_id" : 314776602766610433,
  "created_at" : "Thu Mar 21 16:37:39 +0000 2013",
  "in_reply_to_screen_name" : "bwats",
  "in_reply_to_user_id_str" : "18500786",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feedly",
      "screen_name" : "feedly",
      "indices" : [ 0, 7 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http://t.co/k0TLrekoeJ",
      "expanded_url" : "http://feedly.com",
      "display_url" : "feedly.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314759125861031937",
  "in_reply_to_user_id" : 14485018,
  "text" : "@feedly how in the world do I share an article via email while using http://t.co/k0TLrekoeJ??",
  "id" : 314759125861031937,
  "created_at" : "Thu Mar 21 15:23:18 +0000 2013",
  "in_reply_to_screen_name" : "feedly",
  "in_reply_to_user_id_str" : "14485018",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Watson",
      "screen_name" : "bwats",
      "indices" : [ 0, 6 ],
      "id_str" : "18500786",
      "id" : 18500786
    }, {
      "name" : "feedly",
      "screen_name" : "feedly",
      "indices" : [ 49, 56 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314592306655264768",
  "geo" : {
  },
  "id_str" : "314593853401362433",
  "in_reply_to_user_id" : 18500786,
  "text" : "@bwats must admit, after initial learning curve, @feedly is much better than Google + Reeder.",
  "id" : 314593853401362433,
  "in_reply_to_status_id" : 314592306655264768,
  "created_at" : "Thu Mar 21 04:26:34 +0000 2013",
  "in_reply_to_screen_name" : "bwats",
  "in_reply_to_user_id_str" : "18500786",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feedly",
      "screen_name" : "feedly",
      "indices" : [ 3, 10 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/314591659683893248/photo/1",
      "indices" : [ 26, 48 ],
      "url" : "http://t.co/P3yYMhdjWr",
      "media_url" : "http://pbs.twimg.com/media/BF2ncp0CUAAWJnJ.jpg",
      "id_str" : "314591659688087552",
      "id" : 314591659688087552,
      "media_url_https" : "https://pbs.twimg.com/media/BF2ncp0CUAAWJnJ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/P3yYMhdjWr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314591659683893248",
  "text" : "No @feedly! Not you too!! http://t.co/P3yYMhdjWr",
  "id" : 314591659683893248,
  "created_at" : "Thu Mar 21 04:17:51 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IA Ventures",
      "screen_name" : "iaventures",
      "indices" : [ 3, 14 ],
      "id_str" : "97359375",
      "id" : 97359375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http://t.co/CUgnPjC8E1",
      "expanded_url" : "http://bit.ly/ia_analyst",
      "display_url" : "bit.ly/ia_analyst"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314578721396891649",
  "text" : "RT @iaventures: we're looking for the next member of the IA investment team family. one more day to apply! http://t.co/CUgnPjC8E1",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http://t.co/CUgnPjC8E1",
        "expanded_url" : "http://bit.ly/ia_analyst",
        "display_url" : "bit.ly/ia_analyst"
      } ]
    },
    "geo" : {
    },
    "id_str" : "314363862105346048",
    "text" : "we're looking for the next member of the IA investment team family. one more day to apply! http://t.co/CUgnPjC8E1",
    "id" : 314363862105346048,
    "created_at" : "Wed Mar 20 13:12:39 +0000 2013",
    "user" : {
      "name" : "IA Ventures",
      "screen_name" : "iaventures",
      "protected" : false,
      "id_str" : "97359375",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1608283826/IA_avatar_normal.png",
      "id" : 97359375,
      "verified" : false
    }
  },
  "id" : 314578721396891649,
  "created_at" : "Thu Mar 21 03:26:26 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    }, {
      "name" : "Matt Shampine",
      "screen_name" : "ms",
      "indices" : [ 18, 21 ],
      "id_str" : "16312316",
      "id" : 16312316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314546893826961408",
  "geo" : {
  },
  "id_str" : "314547928452706304",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo I invited @ms to tomorrows Xian run but he made a lame excuse.",
  "id" : 314547928452706304,
  "in_reply_to_status_id" : 314546893826961408,
  "created_at" : "Thu Mar 21 01:24:04 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/314546382704893952/photo/1",
      "indices" : [ 103, 125 ],
      "url" : "http://t.co/FeFIo7tmwh",
      "media_url" : "http://pbs.twimg.com/media/BF1-RL9CYAAP2Qu.jpg",
      "id_str" : "314546382717476864",
      "id" : 314546382717476864,
      "media_url_https" : "https://pbs.twimg.com/media/BF1-RL9CYAAP2Qu.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/FeFIo7tmwh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314546382704893952",
  "text" : "Blue shirts rolled up and tucked into jeans with leather shoes. The Silicon Alley uniform, apparently. http://t.co/FeFIo7tmwh",
  "id" : 314546382704893952,
  "created_at" : "Thu Mar 21 01:17:56 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silicon Valley Bank",
      "screen_name" : "SVB_Financial",
      "indices" : [ 24, 38 ],
      "id_str" : "17396865",
      "id" : 17396865
    }, {
      "name" : "Dell ",
      "screen_name" : "Dell",
      "indices" : [ 43, 48 ],
      "id_str" : "58561993",
      "id" : 58561993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http://t.co/PGDZT8FPkb",
      "expanded_url" : "http://4sq.com/Y0jm8i",
      "display_url" : "4sq.com/Y0jm8i"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7404940183, -73.9871048927 ]
  },
  "id_str" : "314545298947063808",
  "text" : "Awesome event thanks to @SVB_financial and @Dell. (@ SPiN New York w/ 10 others) http://t.co/PGDZT8FPkb",
  "id" : 314545298947063808,
  "created_at" : "Thu Mar 21 01:13:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314506772725510145",
  "text" : "Calling it: iWatch shenanigans is a false flag op for an epic Apple TV. Wouldn't mind being proven wrong, I love watches.",
  "id" : 314506772725510145,
  "created_at" : "Wed Mar 20 22:40:32 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drunk Predator Drone",
      "screen_name" : "drunkenpredator",
      "indices" : [ 29, 45 ],
      "id_str" : "252787550",
      "id" : 252787550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/Y4565iaNV4",
      "expanded_url" : "http://theatlantic.com/technology/archive/2013/03/the-canonical-image-of-a-drone-is-a-rendering-dressed-up-in-photoshop/274177/",
      "display_url" : "theatlantic.com/technology/arc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "314497565955600384",
  "geo" : {
  },
  "id_str" : "314506028777627649",
  "in_reply_to_user_id" : 252787550,
  "text" : "Not even a convincing fake! \u201C@drunkenpredator: the ubiquitous stock image of a Reaper launching a Hellfire is fake http://t.co/Y4565iaNV4 \u2026\u201D",
  "id" : 314506028777627649,
  "in_reply_to_status_id" : 314497565955600384,
  "created_at" : "Wed Mar 20 22:37:35 +0000 2013",
  "in_reply_to_screen_name" : "drunkenpredator",
  "in_reply_to_user_id_str" : "252787550",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flint and Tinder ",
      "screen_name" : "Flint_TinderUSA",
      "indices" : [ 14, 30 ],
      "id_str" : "764110152",
      "id" : 764110152
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 53, 65 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http://t.co/AggNUWR5FE",
      "expanded_url" : "http://kck.st/12xr2Tp",
      "display_url" : "kck.st/12xr2Tp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314493178457772032",
  "text" : "I just backed @Flint_TinderUSA THE 10-YEAR HOODIE on @Kickstarter http://t.co/AggNUWR5FE",
  "id" : 314493178457772032,
  "created_at" : "Wed Mar 20 21:46:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "onlyhalfkidding",
      "indices" : [ 33, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314472479622045696",
  "geo" : {
  },
  "id_str" : "314485350393339904",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo hummus and lamb burgers? #onlyhalfkidding",
  "id" : 314485350393339904,
  "in_reply_to_status_id" : 314472479622045696,
  "created_at" : "Wed Mar 20 21:15:25 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Design Stats",
      "screen_name" : "DesignStats",
      "indices" : [ 3, 15 ],
      "id_str" : "995154116",
      "id" : 995154116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314372568171823104",
  "text" : "RT @DesignStats: 98% of the general public don't care about your parallax scrolling.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "314364841827651584",
    "text" : "98% of the general public don't care about your parallax scrolling.",
    "id" : 314364841827651584,
    "created_at" : "Wed Mar 20 13:16:33 +0000 2013",
    "user" : {
      "name" : "Design Stats",
      "screen_name" : "DesignStats",
      "protected" : false,
      "id_str" : "995154116",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2962703368/80bbe639783221647502cd1a5d07b510_normal.png",
      "id" : 995154116,
      "verified" : false
    }
  },
  "id" : 314372568171823104,
  "created_at" : "Wed Mar 20 13:47:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 34, 40 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http://t.co/zc9NMHMelg",
      "expanded_url" : "http://hvrd.me/ZHVOTI",
      "display_url" : "hvrd.me/ZHVOTI"
    } ]
  },
  "in_reply_to_status_id_str" : "314109785635184640",
  "geo" : {
  },
  "id_str" : "314230194900717568",
  "in_reply_to_user_id" : 236921052,
  "text" : "Make little 3D printers with it! \u201C@hseas: Our new 7-ton, custom-designed 3D printer arrives (photos) http://t.co/zc9NMHMelg\u201D",
  "id" : 314230194900717568,
  "in_reply_to_status_id" : 314109785635184640,
  "created_at" : "Wed Mar 20 04:21:31 +0000 2013",
  "in_reply_to_screen_name" : "hseas",
  "in_reply_to_user_id_str" : "236921052",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 3, 14 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314225515756154880",
  "text" : "RT @nickbilton: Success is 90% hard work, 90% luck, and 10% how good you are at math.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "314164657151688704",
    "text" : "Success is 90% hard work, 90% luck, and 10% how good you are at math.",
    "id" : 314164657151688704,
    "created_at" : "Wed Mar 20 00:01:05 +0000 2013",
    "user" : {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "protected" : false,
      "id_str" : "1586501",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3004953754/981f9dceb963d56f998e557e81e4115f_normal.jpeg",
      "id" : 1586501,
      "verified" : true
    }
  },
  "id" : 314225515756154880,
  "created_at" : "Wed Mar 20 04:02:55 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/kb281KdfAU",
      "expanded_url" : "http://4sq.com/Zcpjuv",
      "display_url" : "4sq.com/Zcpjuv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.773839, -73.87122 ]
  },
  "id_str" : "314222429666938880",
  "text" : "Nice instruments landing, Delta pilot. My roller coaster desires are fulfilled for the year. http://t.co/kb281KdfAU",
  "id" : 314222429666938880,
  "created_at" : "Wed Mar 20 03:50:39 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Tisch",
      "screen_name" : "davetisch",
      "indices" : [ 0, 10 ],
      "id_str" : "6475722",
      "id" : 6475722
    }, {
      "name" : "Tivli",
      "screen_name" : "Tivli",
      "indices" : [ 99, 105 ],
      "id_str" : "81766872",
      "id" : 81766872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314185112134766592",
  "geo" : {
  },
  "id_str" : "314192538804293632",
  "in_reply_to_user_id" : 6475722,
  "text" : "@davetisch Harvard never had cable. Went straight to digital streaming thanks to homegrown startup @Tivli",
  "id" : 314192538804293632,
  "in_reply_to_status_id" : 314185112134766592,
  "created_at" : "Wed Mar 20 01:51:53 +0000 2013",
  "in_reply_to_screen_name" : "davetisch",
  "in_reply_to_user_id_str" : "6475722",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 0, 12 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314186974703546368",
  "geo" : {
  },
  "id_str" : "314191916117925888",
  "in_reply_to_user_id" : 7782442,
  "text" : "@christinelu either that or Apple is running a brilliant false flag operation.",
  "id" : 314191916117925888,
  "in_reply_to_status_id" : 314186974703546368,
  "created_at" : "Wed Mar 20 01:49:24 +0000 2013",
  "in_reply_to_screen_name" : "christinelu",
  "in_reply_to_user_id_str" : "7782442",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    }, {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 33, 49 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314108412436815872",
  "geo" : {
  },
  "id_str" : "314109120590520320",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil are you just going to use @fivethirtyeight's brackets? Because I would.",
  "id" : 314109120590520320,
  "in_reply_to_status_id" : 314108412436815872,
  "created_at" : "Tue Mar 19 20:20:24 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314098402164088832",
  "text" : "It'd be like renting your cake and eating it too.",
  "id" : 314098402164088832,
  "created_at" : "Tue Mar 19 19:37:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314098110316032001",
  "text" : "Dear collaborative consumers: you can't argue that old regs are outdated and shouldn't apply while opposing updated taxes at the same time.",
  "id" : 314098110316032001,
  "created_at" : "Tue Mar 19 19:36:39 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 3, 14 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314081102501396480",
  "text" : "RT @tomloverro: Last Year's 10 Largest VC Exits - According to Pitchbook, last year\u2019s 10 largest exits were: Facebook\u2019s $16... http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http://t.co/Z0nsyteQKV",
        "expanded_url" : "http://tmblr.co/Z8IoCygdyPIj",
        "display_url" : "tmblr.co/Z8IoCygdyPIj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "314076789905432576",
    "text" : "Last Year's 10 Largest VC Exits - According to Pitchbook, last year\u2019s 10 largest exits were: Facebook\u2019s $16... http://t.co/Z0nsyteQKV",
    "id" : 314076789905432576,
    "created_at" : "Tue Mar 19 18:11:56 +0000 2013",
    "user" : {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "protected" : false,
      "id_str" : "21160381",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3612974456/a43e1395c940e9f29ce2ac27921b8628_normal.png",
      "id" : 21160381,
      "verified" : false
    }
  },
  "id" : 314081102501396480,
  "created_at" : "Tue Mar 19 18:29:04 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Zacharias",
      "screen_name" : "zacman85",
      "indices" : [ 0, 9 ],
      "id_str" : "7495722",
      "id" : 7495722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314055949453254657",
  "geo" : {
  },
  "id_str" : "314076407577841664",
  "in_reply_to_user_id" : 7495722,
  "text" : "@zacman85 \"solar color-way\"",
  "id" : 314076407577841664,
  "in_reply_to_status_id" : 314055949453254657,
  "created_at" : "Tue Mar 19 18:10:25 +0000 2013",
  "in_reply_to_screen_name" : "zacman85",
  "in_reply_to_user_id_str" : "7495722",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/feedly/id396069556?mt=8&uo=4\" rel=\"nofollow\">feedly on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http://t.co/7DVKZEMwLM",
      "expanded_url" : "http://feedly.com/k/16GN0CB",
      "display_url" : "feedly.com/k/16GN0CB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314033640998854656",
  "text" : "Shut up and take my money. \"iPhone App Contains Secret Game Boy Advance Emulator, Get It Before It's Gone\" http://t.co/7DVKZEMwLM",
  "id" : 314033640998854656,
  "created_at" : "Tue Mar 19 15:20:29 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Tang",
      "screen_name" : "tangaciousD",
      "indices" : [ 0, 12 ],
      "id_str" : "49705439",
      "id" : 49705439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314030579307925504",
  "geo" : {
  },
  "id_str" : "314031565825007616",
  "in_reply_to_user_id" : 49705439,
  "text" : "@tangaciousD yea, those satellites are so 1990s.",
  "id" : 314031565825007616,
  "in_reply_to_status_id" : 314030579307925504,
  "created_at" : "Tue Mar 19 15:12:14 +0000 2013",
  "in_reply_to_screen_name" : "tangaciousD",
  "in_reply_to_user_id_str" : "49705439",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazing",
      "indices" : [ 136, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314028708790947840",
  "text" : "Can we take a sec to appreciate that I'm using a satellite constellation &amp; supercomputers via a handheld glass slab to find coffee? #amazing",
  "id" : 314028708790947840,
  "created_at" : "Tue Mar 19 15:00:53 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James D Robinson III",
      "screen_name" : "JDRIII",
      "indices" : [ 33, 40 ],
      "id_str" : "57435311",
      "id" : 57435311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313986372560117762",
  "text" : "Interesting to see media habits. @JDRIII reading paper WSJ on morning commute, I'm reading Twitter next to him. What will my children do?",
  "id" : 313986372560117762,
  "created_at" : "Tue Mar 19 12:12:39 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 3, 12 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 14, 21 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313880389947125760",
  "text" : "RT @Romotive: @khsieh Yeah, looking at scifi and robot culture, Romo's hardly the most threatening robot around. I mean, he sneezes if y ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.zendesk.com\" rel=\"nofollow\">Zendesk</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 0, 7 ],
        "id_str" : "111999960",
        "id" : 111999960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "313876486761361408",
    "geo" : {
    },
    "id_str" : "313880178625503233",
    "in_reply_to_user_id" : 19380775,
    "text" : "@khsieh Yeah, looking at scifi and robot culture, Romo's hardly the most threatening robot around. I mean, he sneezes if you tickle his nose",
    "id" : 313880178625503233,
    "in_reply_to_status_id" : 313876486761361408,
    "created_at" : "Tue Mar 19 05:10:40 +0000 2013",
    "in_reply_to_screen_name" : "kane",
    "in_reply_to_user_id_str" : "19380775",
    "user" : {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "protected" : false,
      "id_str" : "340545195",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2180791949/romo_normal.jpg",
      "id" : 340545195,
      "verified" : false
    }
  },
  "id" : 313880389947125760,
  "created_at" : "Tue Mar 19 05:11:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313877116582244352",
  "geo" : {
  },
  "id_str" : "313878784162009088",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo funny, I'm stuck in a random place and just want to be back in NY!",
  "id" : 313878784162009088,
  "in_reply_to_status_id" : 313877116582244352,
  "created_at" : "Tue Mar 19 05:05:08 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 71, 84 ],
      "id_str" : "5988062",
      "id" : 5988062
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 122, 131 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http://t.co/40rMBWwLxE",
      "expanded_url" : "http://www.economist.com/news/technology-quarterly/21572916-robotics-remotely-controlled-telepresence-robots-let-people-be-two-places",
      "display_url" : "economist.com/news/technolog\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313876486761361408",
  "text" : "\"Thanks to scifi movies, people prefer robots they can overpower.\" via @TheEconomist http://t.co/40rMBWwLxE (shout out to @Romotive!)",
  "id" : 313876486761361408,
  "created_at" : "Tue Mar 19 04:56:00 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313874450439348224",
  "geo" : {
  },
  "id_str" : "313875002279723008",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive would def watch the original full length films (in Japanese w subtitles, English dub is terrible) - incredibly ahead of its time.",
  "id" : 313875002279723008,
  "in_reply_to_status_id" : 313874450439348224,
  "created_at" : "Tue Mar 19 04:50:06 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http://t.co/4VyGbdlFWW",
      "expanded_url" : "http://www.smbc-comics.com/index.php?db=comics&id=2917#comic",
      "display_url" : "smbc-comics.com/index.php?db=c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "313873397253808128",
  "geo" : {
  },
  "id_str" : "313874742069297152",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive singularity you say? http://t.co/4VyGbdlFWW",
  "id" : 313874742069297152,
  "in_reply_to_status_id" : 313873397253808128,
  "created_at" : "Tue Mar 19 04:49:04 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313873144580554754",
  "text" : "\"Do you even need ____?\" is a terrible question for judging new technologies. No one *needs* anything more than fire and a good rock.",
  "id" : 313873144580554754,
  "created_at" : "Tue Mar 19 04:42:43 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313870734164373506",
  "geo" : {
  },
  "id_str" : "313872679113469952",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive sounds like you've been watching Ghost in the Shell.",
  "id" : 313872679113469952,
  "in_reply_to_status_id" : 313870734164373506,
  "created_at" : "Tue Mar 19 04:40:52 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/feedly/id396069556?mt=8&uo=4\" rel=\"nofollow\">feedly on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http://t.co/HYKvBecPda",
      "expanded_url" : "http://feedly.com/k/144CBRB",
      "display_url" : "feedly.com/k/144CBRB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313867177952436225",
  "text" : "Oh the irony. \"US investigates Wall Street Journal for bribery claims in China\" http://t.co/HYKvBecPda",
  "id" : 313867177952436225,
  "created_at" : "Tue Mar 19 04:19:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 0, 6 ],
      "id_str" : "17856596",
      "id" : 17856596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313852964584431617",
  "geo" : {
  },
  "id_str" : "313864069054599169",
  "in_reply_to_user_id" : 17856596,
  "text" : "@Wayne you should read the book \"Longitude\" if you haven't yet - amazing ingenuity in figuring out core navigation technologies.",
  "id" : 313864069054599169,
  "in_reply_to_status_id" : 313852964584431617,
  "created_at" : "Tue Mar 19 04:06:40 +0000 2013",
  "in_reply_to_screen_name" : "Wayne",
  "in_reply_to_user_id_str" : "17856596",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitch Kapor",
      "screen_name" : "mkapor",
      "indices" : [ 0, 7 ],
      "id_str" : "2730791",
      "id" : 2730791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313847724590108673",
  "geo" : {
  },
  "id_str" : "313863669907849216",
  "in_reply_to_user_id" : 2730791,
  "text" : "@mkapor meritocracy bubbles up best candidates from an input pool; if the input pool is disproportionate that's a diff problem.",
  "id" : 313863669907849216,
  "in_reply_to_status_id" : 313847724590108673,
  "created_at" : "Tue Mar 19 04:05:04 +0000 2013",
  "in_reply_to_screen_name" : "mkapor",
  "in_reply_to_user_id_str" : "2730791",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313860927743197184",
  "geo" : {
  },
  "id_str" : "313861182698164225",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo I must have! Where to obtain such glorious nerd swag?",
  "id" : 313861182698164225,
  "in_reply_to_status_id" : 313860927743197184,
  "created_at" : "Tue Mar 19 03:55:11 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 0, 6 ],
      "id_str" : "14208617",
      "id" : 14208617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313856114515120128",
  "geo" : {
  },
  "id_str" : "313861056801951744",
  "in_reply_to_user_id" : 14208617,
  "text" : "@robgo oh I didn't mean that it was a problem. Meant it more along the vein of great-minds-think-alike ;)",
  "id" : 313861056801951744,
  "in_reply_to_status_id" : 313856114515120128,
  "created_at" : "Tue Mar 19 03:54:41 +0000 2013",
  "in_reply_to_screen_name" : "robgo",
  "in_reply_to_user_id_str" : "14208617",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 0, 6 ],
      "id_str" : "14208617",
      "id" : 14208617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313848586519597057",
  "geo" : {
  },
  "id_str" : "313852856690163713",
  "in_reply_to_user_id" : 14208617,
  "text" : "@robgo oh em gee we're like website twinsies now!",
  "id" : 313852856690163713,
  "in_reply_to_status_id" : 313848586519597057,
  "created_at" : "Tue Mar 19 03:22:06 +0000 2013",
  "in_reply_to_screen_name" : "robgo",
  "in_reply_to_user_id_str" : "14208617",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Wong",
      "screen_name" : "kwong47",
      "indices" : [ 0, 8 ],
      "id_str" : "21637787",
      "id" : 21637787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313813250842177536",
  "geo" : {
  },
  "id_str" : "313815221045186560",
  "in_reply_to_user_id" : 21637787,
  "text" : "@kwong47 come visit out offices!",
  "id" : 313815221045186560,
  "in_reply_to_status_id" : 313813250842177536,
  "created_at" : "Tue Mar 19 00:52:33 +0000 2013",
  "in_reply_to_screen_name" : "kwong47",
  "in_reply_to_user_id_str" : "21637787",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Wong",
      "screen_name" : "kwong47",
      "indices" : [ 0, 8 ],
      "id_str" : "21637787",
      "id" : 21637787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313811005425729536",
  "geo" : {
  },
  "id_str" : "313811975429836800",
  "in_reply_to_user_id" : 21637787,
  "text" : "@kwong47 will totally take one if you're ever visiting NY!",
  "id" : 313811975429836800,
  "in_reply_to_status_id" : 313811005425729536,
  "created_at" : "Tue Mar 19 00:39:39 +0000 2013",
  "in_reply_to_screen_name" : "kwong47",
  "in_reply_to_user_id_str" : "21637787",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 113, 120 ],
      "id_str" : "9544202",
      "id" : 9544202
    }, {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 121, 132 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313801160781877248",
  "text" : "According to the 5 Hour Energy commercial, it had sold 1.5B bottles, or about 855,597 years, worth of energy. cc @schlaf @tomloverro",
  "id" : 313801160781877248,
  "created_at" : "Mon Mar 18 23:56:41 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313784929060286464",
  "text" : "That is, societal ideals of \"success\" are borne of masculine institutions; female equality within it is flawed bc ideals are flawed.",
  "id" : 313784929060286464,
  "created_at" : "Mon Mar 18 22:52:11 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313784372455165954",
  "text" : "Sandberg's Lean In misses point. Shouldn't try to guarantee equality of outcome; should progressively redefine \"success\" on equal terms.",
  "id" : 313784372455165954,
  "created_at" : "Mon Mar 18 22:49:58 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Block",
      "screen_name" : "ryan",
      "indices" : [ 3, 8 ],
      "id_str" : "862681",
      "id" : 862681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/zrRs4bDRH3",
      "expanded_url" : "http://twitter.com/ryan/status/313755123295854592/photo/1",
      "display_url" : "pic.twitter.com/zrRs4bDRH3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313772137712340994",
  "text" : "RT @ryan: This is by far the best bit of user interface design I have ever seen. Ever. EVER. http://t.co/zrRs4bDRH3",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/ryan/status/313755123295854592/photo/1",
        "indices" : [ 83, 105 ],
        "url" : "http://t.co/zrRs4bDRH3",
        "media_url" : "http://pbs.twimg.com/media/BFqun08CIAEtcYC.png",
        "id_str" : "313755123304243201",
        "id" : 313755123304243201,
        "media_url_https" : "https://pbs.twimg.com/media/BFqun08CIAEtcYC.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 409
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 409
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 409
        }, {
          "h" : 130,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/zrRs4bDRH3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "313755123295854592",
    "text" : "This is by far the best bit of user interface design I have ever seen. Ever. EVER. http://t.co/zrRs4bDRH3",
    "id" : 313755123295854592,
    "created_at" : "Mon Mar 18 20:53:45 +0000 2013",
    "user" : {
      "name" : "Ryan Block",
      "screen_name" : "ryan",
      "protected" : false,
      "id_str" : "862681",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3279804601/dd6c3a124f4fbf8f88aaee46cea7e3ad_normal.jpeg",
      "id" : 862681,
      "verified" : true
    }
  },
  "id" : 313772137712340994,
  "created_at" : "Mon Mar 18 22:01:21 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http://t.co/kLK3P6Ao5x",
      "expanded_url" : "http://bgr.com/2013/03/18/google-keep-note-taking-rumor-383103/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+TheBoyGeniusReport+%28BGR+%7C+Boy+Genius+Report%29",
      "display_url" : "bgr.com/2013/03/18/goo\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313754686610087936",
  "text" : "Well, there goes Evernote. I tried so hard to use it too. http://t.co/kLK3P6Ao5x",
  "id" : 313754686610087936,
  "created_at" : "Mon Mar 18 20:52:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perry Hewitt",
      "screen_name" : "perryhewitt",
      "indices" : [ 0, 12 ],
      "id_str" : "1363481",
      "id" : 1363481
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 13, 25 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313729458249011201",
  "geo" : {
  },
  "id_str" : "313730163928096768",
  "in_reply_to_user_id" : 1363481,
  "text" : "@perryhewitt @badboyboyce and I came up with this in Mather. Roomies were always explaining things to each other. Wish we had made it!",
  "id" : 313730163928096768,
  "in_reply_to_status_id" : 313729458249011201,
  "created_at" : "Mon Mar 18 19:14:34 +0000 2013",
  "in_reply_to_screen_name" : "perryhewitt",
  "in_reply_to_user_id_str" : "1363481",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313728032517021696",
  "text" : "I just heard someone dead-seriously ask for a \"TPS report\" in conversation.",
  "id" : 313728032517021696,
  "created_at" : "Mon Mar 18 19:06:06 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/feedly/id396069556?mt=8&uo=4\" rel=\"nofollow\">feedly on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http://t.co/JbnhrqJvzx",
      "expanded_url" : "http://feedly.com/k/15gGlM2",
      "display_url" : "feedly.com/k/15gGlM2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313632907694583808",
  "text" : "Kaifu Lee tracks and analyzes how the CCP censors his Weibo posts. http://t.co/JbnhrqJvzx",
  "id" : 313632907694583808,
  "created_at" : "Mon Mar 18 12:48:06 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313628845578264576",
  "text" : "Startup units: 1 mailbox = 1 deciinstagram",
  "id" : 313628845578264576,
  "created_at" : "Mon Mar 18 12:31:58 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nabeel Hyatt",
      "screen_name" : "nabeel",
      "indices" : [ 8, 15 ],
      "id_str" : "2565",
      "id" : 2565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/FoEC4ZWVWe",
      "expanded_url" : "http://techcrunch.com/2013/03/17/hardware-startups/",
      "display_url" : "techcrunch.com/2013/03/17/har\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313613603951493120",
  "text" : "Agree w @nabeel on hardware startups, but ubiquitous connectivity and hosted computing unmentioned but necessary too. http://t.co/FoEC4ZWVWe",
  "id" : 313613603951493120,
  "created_at" : "Mon Mar 18 11:31:24 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Gage",
      "screen_name" : "helvetica",
      "indices" : [ 0, 10 ],
      "id_str" : "5603992",
      "id" : 5603992
    }, {
      "name" : "Vlambeer",
      "screen_name" : "Vlambeer",
      "indices" : [ 11, 20 ],
      "id_str" : "155844378",
      "id" : 155844378
    }, {
      "name" : "Greg Wohlwend",
      "screen_name" : "aeiowu",
      "indices" : [ 21, 28 ],
      "id_str" : "15418343",
      "id" : 15418343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313318279940829184",
  "in_reply_to_user_id" : 5603992,
  "text" : "@helvetica @vlambeer @aeiowu bug! If alarm goes off during game, drill, gun, and fish splat sounds disappear. Can't fish without the splats!",
  "id" : 313318279940829184,
  "created_at" : "Sun Mar 17 15:57:53 +0000 2013",
  "in_reply_to_screen_name" : "helvetica",
  "in_reply_to_user_id_str" : "5603992",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taiwanese American ",
      "screen_name" : "TaiwaneseAm_org",
      "indices" : [ 0, 16 ],
      "id_str" : "19437606",
      "id" : 19437606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313086960191299584",
  "geo" : {
  },
  "id_str" : "313090400376205312",
  "in_reply_to_user_id" : 19437606,
  "text" : "@TaiwaneseAm_org Mr. Donut &gt; Krispy Kreme, hands down.",
  "id" : 313090400376205312,
  "in_reply_to_status_id" : 313086960191299584,
  "created_at" : "Sun Mar 17 00:52:23 +0000 2013",
  "in_reply_to_screen_name" : "TaiwaneseAm_org",
  "in_reply_to_user_id_str" : "19437606",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312813666795917313",
  "geo" : {
  },
  "id_str" : "312930016004542464",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil if I get a (bad) cut-and-paste or BCC pitch, they'll get a cut-and-paste rejection. Why should I use more effort than they did?",
  "id" : 312930016004542464,
  "in_reply_to_status_id" : 312813666795917313,
  "created_at" : "Sat Mar 16 14:15:04 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "indices" : [ 3, 13 ],
      "id_str" : "13369702",
      "id" : 13369702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http://t.co/PRM43LGWwj",
      "expanded_url" : "http://www.foundersworkbench.com/",
      "display_url" : "foundersworkbench.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312928633171898369",
  "text" : "RT @NikhilKal: nice work Goodwin Procter! great startup resource well beyond document creation. http://t.co/PRM43LGWwj",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http://t.co/PRM43LGWwj",
        "expanded_url" : "http://www.foundersworkbench.com/",
        "display_url" : "foundersworkbench.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "312878716231487488",
    "text" : "nice work Goodwin Procter! great startup resource well beyond document creation. http://t.co/PRM43LGWwj",
    "id" : 312878716231487488,
    "created_at" : "Sat Mar 16 10:51:13 +0000 2013",
    "user" : {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "protected" : false,
      "id_str" : "13369702",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3437624104/ebd80fda5433a8aec0fee038589e7079_normal.jpeg",
      "id" : 13369702,
      "verified" : false
    }
  },
  "id" : 312928633171898369,
  "created_at" : "Sat Mar 16 14:09:34 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312609663294271490",
  "geo" : {
  },
  "id_str" : "312609775500267521",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo ew. ew.",
  "id" : 312609775500267521,
  "in_reply_to_status_id" : 312609663294271490,
  "created_at" : "Fri Mar 15 17:02:33 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312599629625700352",
  "geo" : {
  },
  "id_str" : "312600816819261441",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo pain is weakness leaving the body. Double down on Mac and cheese.",
  "id" : 312600816819261441,
  "in_reply_to_status_id" : 312599629625700352,
  "created_at" : "Fri Mar 15 16:26:57 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312592681484316672",
  "geo" : {
  },
  "id_str" : "312593348068245504",
  "in_reply_to_user_id" : 111999960,
  "text" : "@kshsieh karma will manifest next time someone thinks I'm 18 and gives me a student discount.",
  "id" : 312593348068245504,
  "in_reply_to_status_id" : 312592681484316672,
  "created_at" : "Fri Mar 15 15:57:16 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The 3Doodler",
      "screen_name" : "3Doodler",
      "indices" : [ 17, 26 ],
      "id_str" : "968836284",
      "id" : 968836284
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/312592269704327168/photo/1",
      "indices" : [ 66, 88 ],
      "url" : "http://t.co/RISNZPovnq",
      "media_url" : "http://pbs.twimg.com/media/BFaNA1uCcAALNTt.jpg",
      "id_str" : "312592269708521472",
      "id" : 312592269708521472,
      "media_url_https" : "https://pbs.twimg.com/media/BFaNA1uCcAALNTt.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/RISNZPovnq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "312592269704327168",
  "text" : "Playing with the @3Doodler 3D pen. Arts and crafts just got REAL. http://t.co/RISNZPovnq",
  "id" : 312592269704327168,
  "created_at" : "Fri Mar 15 15:52:59 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "312591778886868994",
  "text" : "I held a taxi door for an old lady that turned out to be a hipster with realllllly odd style.",
  "id" : 312591778886868994,
  "created_at" : "Fri Mar 15 15:51:02 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Heron",
      "screen_name" : "lheron",
      "indices" : [ 3, 10 ],
      "id_str" : "9692022",
      "id" : 9692022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/vioCK7Cimm",
      "expanded_url" : "http://bit.ly/YbAG9V",
      "display_url" : "bit.ly/YbAG9V"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312538984083513344",
  "text" : "RT @lheron: Wow, quite the chart: Doomed Google Reader still drives far more traffic than G+ http://t.co/vioCK7Cimm",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http://t.co/vioCK7Cimm",
        "expanded_url" : "http://bit.ly/YbAG9V",
        "display_url" : "bit.ly/YbAG9V"
      } ]
    },
    "geo" : {
    },
    "id_str" : "312260105754255360",
    "text" : "Wow, quite the chart: Doomed Google Reader still drives far more traffic than G+ http://t.co/vioCK7Cimm",
    "id" : 312260105754255360,
    "created_at" : "Thu Mar 14 17:53:05 +0000 2013",
    "user" : {
      "name" : "Liz Heron",
      "screen_name" : "lheron",
      "protected" : false,
      "id_str" : "9692022",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1261912324/eddie_pic_normal.jpeg",
      "id" : 9692022,
      "verified" : true
    }
  },
  "id" : 312538984083513344,
  "created_at" : "Fri Mar 15 12:21:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http://t.co/ozzI6IvgAC",
      "expanded_url" : "http://4sq.com/14068fm",
      "display_url" : "4sq.com/14068fm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.747748038, -74.0069652418 ]
  },
  "id_str" : "312530236019470337",
  "text" : "F.ounders START, bright and early. (@ Center 548 w/ 7 others) [pic]: http://t.co/ozzI6IvgAC",
  "id" : 312530236019470337,
  "created_at" : "Fri Mar 15 11:46:29 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Design Milk",
      "screen_name" : "designmilk",
      "indices" : [ 3, 14 ],
      "id_str" : "15446126",
      "id" : 15446126
    }, {
      "name" : "feedly",
      "screen_name" : "feedly",
      "indices" : [ 19, 26 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http://t.co/H4THQnwJxh",
      "expanded_url" : "http://www.replacereader.com",
      "display_url" : "replacereader.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312384801673990144",
  "text" : "RT @designmilk: RT @feedly: Enjoy feedly? Please help us spread the word: http://t.co/H4THQnwJxh Thanks! -Edwin",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "feedly",
        "screen_name" : "feedly",
        "indices" : [ 3, 10 ],
        "id_str" : "14485018",
        "id" : 14485018
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http://t.co/H4THQnwJxh",
        "expanded_url" : "http://www.replacereader.com",
        "display_url" : "replacereader.com"
      } ]
    },
    "in_reply_to_status_id_str" : "312365172842975233",
    "geo" : {
    },
    "id_str" : "312370852119334912",
    "in_reply_to_user_id" : 14485018,
    "text" : "RT @feedly: Enjoy feedly? Please help us spread the word: http://t.co/H4THQnwJxh Thanks! -Edwin",
    "id" : 312370852119334912,
    "in_reply_to_status_id" : 312365172842975233,
    "created_at" : "Fri Mar 15 01:13:09 +0000 2013",
    "in_reply_to_screen_name" : "feedly",
    "in_reply_to_user_id_str" : "14485018",
    "user" : {
      "name" : "Design Milk",
      "screen_name" : "designmilk",
      "protected" : false,
      "id_str" : "15446126",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1765276661/DMLogoTM-carton-icon-facebook-twitter_normal.jpg",
      "id" : 15446126,
      "verified" : false
    }
  },
  "id" : 312384801673990144,
  "created_at" : "Fri Mar 15 02:08:35 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "312380250896084992",
  "text" : "Samsung Galaxy S3S.",
  "id" : 312380250896084992,
  "created_at" : "Fri Mar 15 01:50:30 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eugenia Koo",
      "screen_name" : "itwentviral",
      "indices" : [ 94, 106 ],
      "id_str" : "261491851",
      "id" : 261491851
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "galaxyS4",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/KKFnSnWX6S",
      "expanded_url" : "http://4sq.com/XMrLvY",
      "display_url" : "4sq.com/XMrLvY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7599915373, -73.9801132528 ]
  },
  "id_str" : "312342652660117504",
  "text" : "Remember when cell phone launches weren't a huge thing? #galaxyS4 (@ Radio City Music Hall w/ @itwentviral) [pic]: http://t.co/KKFnSnWX6S",
  "id" : 312342652660117504,
  "created_at" : "Thu Mar 14 23:21:06 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feedly",
      "screen_name" : "feedly",
      "indices" : [ 69, 76 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "312235730246176768",
  "text" : "Now that I've gotten over whining about having to use a new product, @feedly is actually a much better experience that Google Reader.",
  "id" : 312235730246176768,
  "created_at" : "Thu Mar 14 16:16:13 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "appetite",
      "screen_name" : "appetite",
      "indices" : [ 34, 43 ],
      "id_str" : "1050161834",
      "id" : 1050161834
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 71, 83 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http://t.co/ksBigDGZCa",
      "expanded_url" : "http://appetite.io/a/c3fa5a45",
      "display_url" : "appetite.io/a/c3fa5a45"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312208252853178370",
  "text" : "My iPhone homescreen, courtesy of @appetite. http://t.co/ksBigDGZCa cc @badboyboyce",
  "id" : 312208252853178370,
  "created_at" : "Thu Mar 14 14:27:02 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Reader",
      "screen_name" : "googlereader",
      "indices" : [ 62, 75 ],
      "id_str" : "19002481",
      "id" : 19002481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "312040428729937922",
  "text" : "Wow, OldReader and Feedly are both buckling under the load of @GoogleReader refugees right now.",
  "id" : 312040428729937922,
  "created_at" : "Thu Mar 14 03:20:10 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 19, 31 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/alishalisha/status/312004111220482049/photo/1",
      "indices" : [ 97, 119 ],
      "url" : "http://t.co/AvhcKbVH1u",
      "media_url" : "http://pbs.twimg.com/media/BFR2FgpCIAAe0s0.png",
      "id_str" : "312004111228870656",
      "id" : 312004111228870656,
      "media_url_https" : "https://pbs.twimg.com/media/BFR2FgpCIAAe0s0.png",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 449
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 449
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 449
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/AvhcKbVH1u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312004111220482049",
  "geo" : {
  },
  "id_str" : "312029805031870465",
  "in_reply_to_user_id" : 15101900,
  "text" : "This made my day. \u201C@alishalisha: Just made this out of rage at Google. DON'T KILL GOOGLE READER. http://t.co/AvhcKbVH1u\u201D",
  "id" : 312029805031870465,
  "in_reply_to_status_id" : 312004111220482049,
  "created_at" : "Thu Mar 14 02:37:57 +0000 2013",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio",
      "screen_name" : "antrod",
      "indices" : [ 0, 7 ],
      "id_str" : "464493",
      "id" : 464493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311996547976024064",
  "geo" : {
  },
  "id_str" : "311997887242444800",
  "in_reply_to_user_id" : 464493,
  "text" : "@antrod ~75% of my Google Reader content is consumed through Reeder already. One click migration would be clutch.",
  "id" : 311997887242444800,
  "in_reply_to_status_id" : 311996547976024064,
  "created_at" : "Thu Mar 14 00:31:07 +0000 2013",
  "in_reply_to_screen_name" : "antrod",
  "in_reply_to_user_id_str" : "464493",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311990305769537538",
  "text" : "RT @parislemon: Look, the last PM of Google Reader, Jorge Mario Bergoglio, now has a new job, okay?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "311989529739423745",
    "text" : "Look, the last PM of Google Reader, Jorge Mario Bergoglio, now has a new job, okay?",
    "id" : 311989529739423745,
    "created_at" : "Wed Mar 13 23:57:55 +0000 2013",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3336694463/99718483afb19d6d441290afccb72772_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 311990305769537538,
  "created_at" : "Thu Mar 14 00:01:00 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311987694404251649",
  "text" : "ALL my reading apps use Google Reader as a backbone. What is this I don't even",
  "id" : 311987694404251649,
  "created_at" : "Wed Mar 13 23:50:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311984119150157827",
  "text" : "I spend more time in Google Reader than any other site. The shut down announcement sucks.",
  "id" : 311984119150157827,
  "created_at" : "Wed Mar 13 23:36:25 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Gallagher",
      "screen_name" : "davidfg",
      "indices" : [ 21, 29 ],
      "id_str" : "14763721",
      "id" : 14763721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http://t.co/2rjE5Jr7Ml",
      "expanded_url" : "http://googlereader.blogspot.com/2013/03/powering-down-google-reader.html",
      "display_url" : "googlereader.blogspot.com/2013/03/poweri\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311980215133945857",
  "geo" : {
  },
  "id_str" : "311983614755762176",
  "in_reply_to_user_id" : 14763721,
  "text" : "Oh god please no!!! \u201C@davidfg: Please, no! R.I.P. Google Reader. http://t.co/2rjE5Jr7Ml\u201D",
  "id" : 311983614755762176,
  "in_reply_to_status_id" : 311980215133945857,
  "created_at" : "Wed Mar 13 23:34:24 +0000 2013",
  "in_reply_to_screen_name" : "davidfg",
  "in_reply_to_user_id_str" : "14763721",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 60, 69 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311922995633455104",
  "geo" : {
  },
  "id_str" : "311924250405654528",
  "in_reply_to_user_id" : 500704345,
  "text" : "In my head this is old white people yelling at each other. \u201C@Pontifex: HABEMUS PAPAM FRANCISCUM\u201D",
  "id" : 311924250405654528,
  "in_reply_to_status_id" : 311922995633455104,
  "created_at" : "Wed Mar 13 19:38:31 +0000 2013",
  "in_reply_to_screen_name" : "Pontifex",
  "in_reply_to_user_id_str" : "500704345",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311923295203254272",
  "text" : "Line breaks in the web\nHaikus begin to take form\nRefrigerator",
  "id" : 311923295203254272,
  "created_at" : "Wed Mar 13 19:34:43 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311921396093702144",
  "text" : "If I were Pope I would name myself Pope Pourri the Fragrant.",
  "id" : 311921396093702144,
  "created_at" : "Wed Mar 13 19:27:10 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ramen",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "nofriends",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http://t.co/MFCZqfZkMs",
      "expanded_url" : "http://betabeat.com/2013/03/turns-out-being-a-chinese-hacker-is-boring-and-awful/",
      "display_url" : "betabeat.com/2013/03/turns-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311919452440629248",
  "text" : "Being a hacker in the elite Chinese PLA Unit 61398 sounds a lot like being a CS grad student. #ramen #nofriends http://t.co/MFCZqfZkMs",
  "id" : 311919452440629248,
  "created_at" : "Wed Mar 13 19:19:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pawe\u0142 Szymczykowski",
      "screen_name" : "makenai",
      "indices" : [ 3, 11 ],
      "id_str" : "4569381",
      "id" : 4569381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http://t.co/6JyqLVkRIT",
      "expanded_url" : "http://i.imgur.com/ljdpBFK.jpg",
      "display_url" : "i.imgur.com/ljdpBFK.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311916954980065281",
  "text" : "RT @makenai: http://t.co/6JyqLVkRIT",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http://t.co/6JyqLVkRIT",
        "expanded_url" : "http://i.imgur.com/ljdpBFK.jpg",
        "display_url" : "i.imgur.com/ljdpBFK.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "311915738900344832",
    "text" : "http://t.co/6JyqLVkRIT",
    "id" : 311915738900344832,
    "created_at" : "Wed Mar 13 19:04:41 +0000 2013",
    "user" : {
      "name" : "Pawe\u0142 Szymczykowski",
      "screen_name" : "makenai",
      "protected" : false,
      "id_str" : "4569381",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2419919807/ea5my0bt24zy65naioem_normal.jpeg",
      "id" : 4569381,
      "verified" : false
    }
  },
  "id" : 311916954980065281,
  "created_at" : "Wed Mar 13 19:09:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/311916644127617024/photo/1",
      "indices" : [ 34, 56 ],
      "url" : "http://t.co/Q7yBEHBLpK",
      "media_url" : "http://pbs.twimg.com/media/BFQmiQUCMAAtjMO.jpg",
      "id_str" : "311916644131811328",
      "id" : 311916644131811328,
      "media_url_https" : "https://pbs.twimg.com/media/BFQmiQUCMAAtjMO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/Q7yBEHBLpK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311916644127617024",
  "text" : "The *original* Twitter for music. http://t.co/Q7yBEHBLpK",
  "id" : 311916644127617024,
  "created_at" : "Wed Mar 13 19:08:17 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http://t.co/vUZDNuYPoK",
      "expanded_url" : "http://nyti.ms/VUxr79",
      "display_url" : "nyti.ms/VUxr79"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311611760274718720",
  "text" : "Completely agree with this epiphany. Spend $$ on experiences and friends, not stuff. \"Living With Less. A Lot Less. http://t.co/vUZDNuYPoK\"",
  "id" : 311611760274718720,
  "created_at" : "Tue Mar 12 22:56:47 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dedication",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311587052837818368",
  "text" : "The Sunrise calendar team uses iPhone 4 (not 4S) so they don't take the iPhone 5 speed for granted when developing. #dedication",
  "id" : 311587052837818368,
  "created_at" : "Tue Mar 12 21:18:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 13, 22 ],
      "id_str" : "20568189",
      "id" : 20568189
    }, {
      "name" : "Harvard Tech Review",
      "screen_name" : "harvardtech",
      "indices" : [ 27, 39 ],
      "id_str" : "348486463",
      "id" : 348486463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311473816406740992",
  "text" : "I always get @HODINKEE and @harvardtech confused because of their profile pics.",
  "id" : 311473816406740992,
  "created_at" : "Tue Mar 12 13:48:39 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 19, 28 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http://t.co/UMLy8HWzVv",
      "expanded_url" : "http://news.cnet.com/8301-1023_3-57573771-93/panic-over-as-eu-votes-to-reject-porn-ban-proposals/",
      "display_url" : "news.cnet.com/8301-1023_3-57\u2026"
    }, {
      "indices" : [ 107, 129 ],
      "url" : "http://t.co/sDpZlP4zeP",
      "expanded_url" : "http://www.techmeme.com/130312/p22#a130312p22",
      "display_url" : "techmeme.com/130312/p22#a13\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311468098886721536",
  "geo" : {
  },
  "id_str" : "311472567993106432",
  "in_reply_to_user_id" : 817386,
  "text" : "Society is saved! \u201C@Techmeme: Panic over as EU votes to reject 'porn ban' proposals http://t.co/UMLy8HWzVv http://t.co/sDpZlP4zeP\u201D",
  "id" : 311472567993106432,
  "in_reply_to_status_id" : 311468098886721536,
  "created_at" : "Tue Mar 12 13:43:41 +0000 2013",
  "in_reply_to_screen_name" : "Techmeme",
  "in_reply_to_user_id_str" : "817386",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugo Van Vuuren",
      "screen_name" : "hvgo",
      "indices" : [ 3, 8 ],
      "id_str" : "18413446",
      "id" : 18413446
    }, {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 13, 27 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311280482061012993",
  "text" : "RT @hvgo: MT @evgenymorozov: I wish more academic theory used Web 2.0 start-up shortcuts - e.g. \"It's like Zizek but for sport studies\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evgeny Morozov",
        "screen_name" : "evgenymorozov",
        "indices" : [ 3, 17 ],
        "id_str" : "30331417",
        "id" : 30331417
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "311226145989332992",
    "geo" : {
    },
    "id_str" : "311275079478681601",
    "in_reply_to_user_id" : 30331417,
    "text" : "MT @evgenymorozov: I wish more academic theory used Web 2.0 start-up shortcuts - e.g. \"It's like Zizek but for sport studies\"",
    "id" : 311275079478681601,
    "in_reply_to_status_id" : 311226145989332992,
    "created_at" : "Tue Mar 12 00:38:56 +0000 2013",
    "in_reply_to_screen_name" : "evgenymorozov",
    "in_reply_to_user_id_str" : "30331417",
    "user" : {
      "name" : "Hugo Van Vuuren",
      "screen_name" : "hvgo",
      "protected" : false,
      "id_str" : "18413446",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3363715470/f4303415b415b9f80a8081bb8d9ffcfd_normal.jpeg",
      "id" : 18413446,
      "verified" : false
    }
  },
  "id" : 311280482061012993,
  "created_at" : "Tue Mar 12 01:00:24 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Myles White",
      "screen_name" : "johnmyleswhite",
      "indices" : [ 3, 18 ],
      "id_str" : "15379361",
      "id" : 15379361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310780212117913601",
  "text" : "RT @johnmyleswhite: You call it procrastination. I call it JIT'ting my life.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "310754801564655616",
    "text" : "You call it procrastination. I call it JIT'ting my life.",
    "id" : 310754801564655616,
    "created_at" : "Sun Mar 10 14:11:32 +0000 2013",
    "user" : {
      "name" : "John Myles White",
      "screen_name" : "johnmyleswhite",
      "protected" : false,
      "id_str" : "15379361",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1986481191/jmw_normal.jpg",
      "id" : 15379361,
      "verified" : false
    }
  },
  "id" : 310780212117913601,
  "created_at" : "Sun Mar 10 15:52:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310551524537417728",
  "text" : "Wondering if I could ride a bike on a treadmill.",
  "id" : 310551524537417728,
  "created_at" : "Sun Mar 10 00:43:47 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Chou",
      "screen_name" : "markdchou",
      "indices" : [ 3, 13 ],
      "id_str" : "67686145",
      "id" : 67686145
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nofilter",
      "indices" : [ 15, 24 ]
    }, {
      "text" : "snow",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http://t.co/GW4fMfZ9Fi",
      "expanded_url" : "http://instagr.am/p/Wm8V4iNYXR/",
      "display_url" : "instagr.am/p/Wm8V4iNYXR/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310129602351751168",
  "text" : "RT @markdchou: #nofilter. It really is that black and white in NYC today! #snow @ Battery Park http://t.co/GW4fMfZ9Fi",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nofilter",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "snow",
        "indices" : [ 59, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http://t.co/GW4fMfZ9Fi",
        "expanded_url" : "http://instagr.am/p/Wm8V4iNYXR/",
        "display_url" : "instagr.am/p/Wm8V4iNYXR/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.7035783373, -74.0161800385 ]
    },
    "id_str" : "310111718498000896",
    "text" : "#nofilter. It really is that black and white in NYC today! #snow @ Battery Park http://t.co/GW4fMfZ9Fi",
    "id" : 310111718498000896,
    "created_at" : "Fri Mar 08 19:36:09 +0000 2013",
    "user" : {
      "name" : "Mark Chou",
      "screen_name" : "markdchou",
      "protected" : false,
      "id_str" : "67686145",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1774751274/image1327295547_normal.png",
      "id" : 67686145,
      "verified" : false
    }
  },
  "id" : 310129602351751168,
  "created_at" : "Fri Mar 08 20:47:13 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310077485297586179",
  "text" : "\"Your money XOR (your money ^ your life)!\" - information superhighway bandit.",
  "id" : 310077485297586179,
  "created_at" : "Fri Mar 08 17:20:08 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 53, 57 ],
      "id_str" : "19494411",
      "id" : 19494411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSW",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/gfdIJ6VvqH",
      "expanded_url" : "http://www.nytimes.com/2013/03/08/technology/its-the-hardwares-turn-in-the-spotlight.html",
      "display_url" : "nytimes.com/2013/03/08/tec\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "309796590439247873",
  "geo" : {
  },
  "id_str" : "309796776708288513",
  "in_reply_to_user_id" : 19494411,
  "text" : "Every good hardware co. is also a good software co. \u201C@RRE: It's hardware's turn in the spotlight at #SXSW this year! http://t.co/gfdIJ6VvqH\u201D",
  "id" : 309796776708288513,
  "in_reply_to_status_id" : 309796590439247873,
  "created_at" : "Thu Mar 07 22:44:41 +0000 2013",
  "in_reply_to_screen_name" : "RRE",
  "in_reply_to_user_id_str" : "19494411",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Alumni Assoc",
      "screen_name" : "HarvardAlumni",
      "indices" : [ 0, 14 ],
      "id_str" : "19304974",
      "id" : 19304974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digitalharvard",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https://t.co/4oW7L32xyM",
      "expanded_url" : "https://twitter.com/HarvardAlumni/digital-harvard-2013/",
      "display_url" : "twitter.com/HarvardAlumni/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "309749832673792000",
  "in_reply_to_user_id" : 19304974,
  "text" : "@HarvardAlumni the #digitalharvard list https://t.co/4oW7L32xyM is relevant to me - can I request an add? Thanks!",
  "id" : 309749832673792000,
  "created_at" : "Thu Mar 07 19:38:09 +0000 2013",
  "in_reply_to_screen_name" : "HarvardAlumni",
  "in_reply_to_user_id_str" : "19304974",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Carleton",
      "screen_name" : "ScotterC",
      "indices" : [ 0, 9 ],
      "id_str" : "90048571",
      "id" : 90048571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309726568744353792",
  "geo" : {
  },
  "id_str" : "309726805932253184",
  "in_reply_to_user_id" : 90048571,
  "text" : "@ScotterC granted this was over a year ago.",
  "id" : 309726805932253184,
  "in_reply_to_status_id" : 309726568744353792,
  "created_at" : "Thu Mar 07 18:06:39 +0000 2013",
  "in_reply_to_screen_name" : "ScotterC",
  "in_reply_to_user_id_str" : "90048571",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Carleton",
      "screen_name" : "ScotterC",
      "indices" : [ 0, 9 ],
      "id_str" : "90048571",
      "id" : 90048571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309716367085535232",
  "geo" : {
  },
  "id_str" : "309725395698200576",
  "in_reply_to_user_id" : 90048571,
  "text" : "@ScotterC HSBC's commercial banking web services.",
  "id" : 309725395698200576,
  "in_reply_to_status_id" : 309716367085535232,
  "created_at" : "Thu Mar 07 18:01:03 +0000 2013",
  "in_reply_to_screen_name" : "ScotterC",
  "in_reply_to_user_id_str" : "90048571",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 21, 25 ],
      "id_str" : "19494411",
      "id" : 19494411
    }, {
      "name" : "Stuart Ellman",
      "screen_name" : "bikenyc",
      "indices" : [ 30, 38 ],
      "id_str" : "4515021",
      "id" : 4515021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http://t.co/C5WhHAh4yU",
      "expanded_url" : "http://4sq.com/169Gwfm",
      "display_url" : "4sq.com/169Gwfm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7290858508, -73.9960221043 ]
  },
  "id_str" : "309458053525299201",
  "text" : "New Media panel with @RRE and @bikenyc! (@ NYU Stern School of Business w/ 24 others) http://t.co/C5WhHAh4yU",
  "id" : 309458053525299201,
  "created_at" : "Thu Mar 07 00:18:44 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "309061719785893888",
  "text" : "Friend on Bloomberg terminal: \"I'm four minutes faster than CNN.\"",
  "id" : 309061719785893888,
  "created_at" : "Tue Mar 05 22:03:50 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/dGLFYfqCmx",
      "expanded_url" : "http://blog.kanehsieh.com/2013/03/05/redesigning-1984/",
      "display_url" : "blog.kanehsieh.com/2013/03/05/red\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308990851948875777",
  "text" : "My cover design for Orwell's 1984: http://t.co/dGLFYfqCmx",
  "id" : 308990851948875777,
  "created_at" : "Tue Mar 05 17:22:14 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "indices" : [ 0, 16 ],
      "id_str" : "353789193",
      "id" : 353789193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308795445772156928",
  "geo" : {
  },
  "id_str" : "308827266798981121",
  "in_reply_to_user_id" : 353789193,
  "text" : "@StartupLJackson yea, member CLV is probably $hundreds as well as their soul.",
  "id" : 308827266798981121,
  "in_reply_to_status_id" : 308795445772156928,
  "created_at" : "Tue Mar 05 06:32:12 +0000 2013",
  "in_reply_to_screen_name" : "StartupLJackson",
  "in_reply_to_user_id_str" : "353789193",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 7, 16 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/308780973850497024/photo/1",
      "indices" : [ 47, 69 ],
      "url" : "http://t.co/mF0IpBVnRm",
      "media_url" : "http://pbs.twimg.com/media/BEkCqOQCEAA8_0G.jpg",
      "id_str" : "308780973854691328",
      "id" : 308780973854691328,
      "media_url_https" : "https://pbs.twimg.com/media/BEkCqOQCEAA8_0G.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/mF0IpBVnRm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "308780973850497024",
  "text" : "Got my @Romotive Romo in the mail today! &lt;3 http://t.co/mF0IpBVnRm",
  "id" : 308780973850497024,
  "created_at" : "Tue Mar 05 03:28:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/308304240269459456/photo/1",
      "indices" : [ 13, 35 ],
      "url" : "http://t.co/5iQ8dTVqPA",
      "media_url" : "http://pbs.twimg.com/media/BEdRErSCAAALGTr.jpg",
      "id_str" : "308304240277848064",
      "id" : 308304240277848064,
      "media_url_https" : "https://pbs.twimg.com/media/BEdRErSCAAALGTr.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com/5iQ8dTVqPA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "308304240269459456",
  "text" : "Boba down :( http://t.co/5iQ8dTVqPA",
  "id" : 308304240269459456,
  "created_at" : "Sun Mar 03 19:53:53 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialmedia",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "308088789203550208",
  "text" : "RT @jknapp45: CMOs spend 8.4% of their budgets on #socialmedia, but in the next 5 yrs. that figure will reach 21.6% http://t.co/9W5Sajp7 ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Social@Ogilvy",
        "screen_name" : "SocialOgilvy",
        "indices" : [ 125, 138 ],
        "id_str" : "376762488",
        "id" : 376762488
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialmedia",
        "indices" : [ 36, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http://t.co/9W5Sajp7TN",
        "expanded_url" : "http://www.fastcompany.com/node/3006310",
        "display_url" : "fastcompany.com/node/3006310"
      } ]
    },
    "geo" : {
    },
    "id_str" : "308050400718761984",
    "text" : "CMOs spend 8.4% of their budgets on #socialmedia, but in the next 5 yrs. that figure will reach 21.6% http://t.co/9W5Sajp7TN @SocialOgilvy",
    "id" : 308050400718761984,
    "created_at" : "Sun Mar 03 03:05:13 +0000 2013",
    "user" : {
      "name" : "Justin Knapp",
      "screen_name" : "goodallfocus",
      "protected" : false,
      "id_str" : "22448506",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3559043773/cd310343ecc329989c6ac0f5e607c347_normal.jpeg",
      "id" : 22448506,
      "verified" : false
    }
  },
  "id" : 308088789203550208,
  "created_at" : "Sun Mar 03 05:37:46 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evernote",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "307918949943742465",
  "text" : "Days without major consumer data hack: 0. #evernote",
  "id" : 307918949943742465,
  "created_at" : "Sat Mar 02 18:22:53 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "307880968168030208",
  "text" : "RT @hseas: Computer science alum Stephen Kaufer '84, president &amp; CEO of Trip Advisor, calls himself \"an average traveler\" http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http://t.co/SIwO4F7Ei8",
        "expanded_url" : "http://hvrd.me/12hlgoU",
        "display_url" : "hvrd.me/12hlgoU"
      } ]
    },
    "geo" : {
    },
    "id_str" : "307879290228318208",
    "text" : "Computer science alum Stephen Kaufer '84, president &amp; CEO of Trip Advisor, calls himself \"an average traveler\" http://t.co/SIwO4F7Ei8",
    "id" : 307879290228318208,
    "created_at" : "Sat Mar 02 15:45:17 +0000 2013",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 307880968168030208,
  "created_at" : "Sat Mar 02 15:51:57 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYC Turing Fellows",
      "screen_name" : "nycturing",
      "indices" : [ 15, 25 ],
      "id_str" : "242477165",
      "id" : 242477165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http://t.co/eeb1TrziE7",
      "expanded_url" : "http://4sq.com/ZUtO3E",
      "display_url" : "4sq.com/ZUtO3E"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.745884, -73.988116 ]
  },
  "id_str" : "307841384172371969",
  "text" : "Picking up the @nycTuring Fellows bright and early! (@ Ace Hotel Lobby &amp; Bar) http://t.co/eeb1TrziE7",
  "id" : 307841384172371969,
  "created_at" : "Sat Mar 02 13:14:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http://t.co/7y9M7A5hif",
      "expanded_url" : "http://t.imehop.com/WlZYnp",
      "display_url" : "t.imehop.com/WlZYnp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "307570733226270720",
  "text" : "Two years ago I hit inbox zero, and have never made it back since. http://t.co/7y9M7A5hif",
  "id" : 307570733226270720,
  "created_at" : "Fri Mar 01 19:19:11 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 3, 14 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "307528612238721025",
  "text" : "RT @tomloverro: Crunchbase is down. Well nothing left for me to do here. Going back to bed.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "307506171995103232",
    "text" : "Crunchbase is down. Well nothing left for me to do here. Going back to bed.",
    "id" : 307506171995103232,
    "created_at" : "Fri Mar 01 15:02:39 +0000 2013",
    "user" : {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "protected" : false,
      "id_str" : "21160381",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3612974456/a43e1395c940e9f29ce2ac27921b8628_normal.png",
      "id" : 21160381,
      "verified" : false
    }
  },
  "id" : 307528612238721025,
  "created_at" : "Fri Mar 01 16:31:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307527014175354880",
  "geo" : {
  },
  "id_str" : "307527103002320897",
  "in_reply_to_user_id" : 111999960,
  "text" : "@kshsieh one word: wax.",
  "id" : 307527103002320897,
  "in_reply_to_status_id" : 307527014175354880,
  "created_at" : "Fri Mar 01 16:25:49 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]