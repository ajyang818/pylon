Grailbird.data.tweets_2010_04 = 
 [ {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13163076541",
  "text" : "DJ-ing part of Abella!",
  "id" : 13163076541,
  "created_at" : "Sat May 01 01:52:26 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13160177044",
  "text" : "Setting up music for Winthrop formal!",
  "id" : 13160177044,
  "created_at" : "Sat May 01 00:51:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13147435072",
  "text" : "Harvard Student Art Show - where mediocre photography is sold for ridiculous prices.",
  "id" : 13147435072,
  "created_at" : "Fri Apr 30 19:54:05 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13084812400",
  "text" : "it's sad how much of my life depends on gmail",
  "id" : 13084812400,
  "created_at" : "Thu Apr 29 19:15:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13084727905",
  "text" : "don't die on me gmail!",
  "id" : 13084727905,
  "created_at" : "Thu Apr 29 19:13:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13051121909",
  "text" : "Currier formal DJ is incompetent",
  "id" : 13051121909,
  "created_at" : "Thu Apr 29 04:52:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 0, 6 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13021090655",
  "in_reply_to_user_id" : 15333079,
  "text" : "@cklee \"oh gosh kappa kappa girls in a CS engineering course\"",
  "id" : 13021090655,
  "created_at" : "Wed Apr 28 18:27:55 +0000 2010",
  "in_reply_to_screen_name" : "chriskelvinlee",
  "in_reply_to_user_id_str" : "15333079",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13012934668",
  "text" : "These two girls in math section ask the stupidest questions. \"I'm not sure what to say...\" -the prof",
  "id" : 13012934668,
  "created_at" : "Wed Apr 28 15:36:48 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12996538399",
  "text" : "Last day of class!",
  "id" : 12996538399,
  "created_at" : "Wed Apr 28 09:08:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 0, 7 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12972685691",
  "in_reply_to_user_id" : 19380775,
  "text" : "@khsieh has a follow cost of 71.64 milliscobles. http://followcost.com/khsieh",
  "id" : 12972685691,
  "created_at" : "Tue Apr 27 23:42:15 +0000 2010",
  "in_reply_to_screen_name" : "kane",
  "in_reply_to_user_id_str" : "19380775",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12966765312",
  "text" : "QuadBikes is building me an amazing wheel!  Just in time for summer.",
  "id" : 12966765312,
  "created_at" : "Tue Apr 27 21:43:19 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12955567910",
  "text" : "Some of the VES theses sound like utter BS...",
  "id" : 12955567910,
  "created_at" : "Tue Apr 27 17:19:04 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12933996400",
  "text" : "cleaned out my gmail, / letters responded, archived. / Inbox is at peace. #haiku",
  "id" : 12933996400,
  "created_at" : "Tue Apr 27 08:20:23 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12897347815",
  "geo" : {
  },
  "id_str" : "12911699216",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern I need one too!  Group rate?",
  "id" : 12911699216,
  "in_reply_to_status_id" : 12897347815,
  "created_at" : "Mon Apr 26 23:32:26 +0000 2010",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12811761571",
  "text" : "Back to haiku tweets.  / need to contain frustration / within syllables",
  "id" : 12811761571,
  "created_at" : "Sun Apr 25 08:27:40 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12707483024",
  "text" : "If you walk into class late, fine, but don't ask questions about goddamn everything already covered.",
  "id" : 12707483024,
  "created_at" : "Fri Apr 23 15:13:22 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 0, 13 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allnighter",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12684015623",
  "geo" : {
  },
  "id_str" : "12685072229",
  "in_reply_to_user_id" : 112919587,
  "text" : "@vcruzcontrol #allnighter!",
  "id" : 12685072229,
  "in_reply_to_status_id" : 12684015623,
  "created_at" : "Fri Apr 23 05:16:49 +0000 2010",
  "in_reply_to_screen_name" : "vcruzcontrol",
  "in_reply_to_user_id_str" : "112919587",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12678115417",
  "text" : "Black Surly disc rim + black Swiss DT rim + black spokes = awesome",
  "id" : 12678115417,
  "created_at" : "Fri Apr 23 02:42:12 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12658547114",
  "text" : "It's earth day.  Embrace nuclear power, buy used cars instead of hybrids, and don't buy organic foods.  Think, people.",
  "id" : 12658547114,
  "created_at" : "Thu Apr 22 20:09:45 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12613176481",
  "geo" : {
  },
  "id_str" : "12615006962",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin get some Tosti Asti!",
  "id" : 12615006962,
  "in_reply_to_status_id" : 12613176481,
  "created_at" : "Thu Apr 22 02:47:44 +0000 2010",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12612871877",
  "text" : "Modified my Pilot G2's to take Montblanc ink.  pretty sweet",
  "id" : 12612871877,
  "created_at" : "Thu Apr 22 02:08:06 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12590351141",
  "text" : "\"The good stuff is when we start changing it with explosions\" - CS171 professor on virtual environments",
  "id" : 12590351141,
  "created_at" : "Wed Apr 21 18:11:37 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "militarytime",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12583331131",
  "text" : "I woke up at 7 to streaming sunlight and thought it was PM. Flipped out. Changed everything to #militarytime",
  "id" : 12583331131,
  "created_at" : "Wed Apr 21 15:44:29 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 46, 52 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12564061647",
  "text" : "\"vegetarians are like force colorblindness\" - @cklee",
  "id" : 12564061647,
  "created_at" : "Wed Apr 21 07:29:55 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12532059097",
  "text" : "I just want to ride my bike today. Final projects dragging me down.",
  "id" : 12532059097,
  "created_at" : "Tue Apr 20 19:01:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OLD BOY JON",
      "screen_name" : "dumbfoundead",
      "indices" : [ 22, 35 ],
      "id_str" : "20646945",
      "id" : 20646945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12483455345",
  "text" : "Botching up sound for @dumbfoundead - oops!",
  "id" : 12483455345,
  "created_at" : "Mon Apr 19 23:52:56 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12468385032",
  "text" : "Fleshmap - from CS171 class http://www.fleshmap.com/listen/music.html",
  "id" : 12468385032,
  "created_at" : "Mon Apr 19 18:04:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12462703706",
  "text" : "\"Nonlinear and quantum optics in photonic nanostructures\" - my advisors emails waaaaay overestimates my interests...",
  "id" : 12462703706,
  "created_at" : "Mon Apr 19 15:56:45 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12461500668",
  "text" : "People in my math section ask the stupidest questions.",
  "id" : 12461500668,
  "created_at" : "Mon Apr 19 15:31:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kpop",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12439095978",
  "text" : "Cannot stop listening to SHINee.  They all look like girls though... #kpop",
  "id" : 12439095978,
  "created_at" : "Mon Apr 19 04:57:06 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12413305328",
  "text" : "Me neitherrr RT @themonkeychow: idont wanna workkkkkkk but ugh midterm!!!",
  "id" : 12413305328,
  "created_at" : "Sun Apr 18 19:22:02 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12377770178",
  "text" : "Fire alarm at mather lather!!",
  "id" : 12377770178,
  "created_at" : "Sun Apr 18 03:41:45 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12348521274",
  "text" : "Meeting someone in the Garage for a craigslist sale. I always forget how awkward these meetings are.",
  "id" : 12348521274,
  "created_at" : "Sat Apr 17 16:06:31 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celena Chan",
      "screen_name" : "celenachan",
      "indices" : [ 0, 11 ],
      "id_str" : "18780101",
      "id" : 18780101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12300037973",
  "in_reply_to_user_id" : 18780101,
  "text" : "@celenachan geeky AND preppy!",
  "id" : 12300037973,
  "created_at" : "Fri Apr 16 19:20:35 +0000 2010",
  "in_reply_to_screen_name" : "celenachan",
  "in_reply_to_user_id_str" : "18780101",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12290357014",
  "text" : "Nullclines are back to haunt me nooooo",
  "id" : 12290357014,
  "created_at" : "Fri Apr 16 15:56:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12272327575",
  "text" : "The Mather birds are at it again.",
  "id" : 12272327575,
  "created_at" : "Fri Apr 16 08:39:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12235563494",
  "text" : "\"For every runtime exception you declare you will spend a millenia or two in PURGATORY\" - guest lecturer",
  "id" : 12235563494,
  "created_at" : "Thu Apr 15 17:44:31 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12183405524",
  "text" : "I really want a KFC doubledown. Yum.",
  "id" : 12183405524,
  "created_at" : "Wed Apr 14 20:51:57 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12151638336",
  "text" : "Someone else stabbed by the station/Dunster St. Why can't I get a CC permit in this town??",
  "id" : 12151638336,
  "created_at" : "Wed Apr 14 07:49:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Square Now!",
      "screen_name" : "02138now",
      "indices" : [ 3, 12 ],
      "id_str" : "15089620",
      "id" : 15089620
    }, {
      "name" : "Cambridge Chronicle",
      "screen_name" : "cambridgechron",
      "indices" : [ 17, 32 ],
      "id_str" : "14278568",
      "id" : 14278568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12151611822",
  "text" : "RT @02138now: by @cambridgechron: NEWS: Cambridge man stabbed near Harvard Square http://bit.ly/cOxmrJ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hoodlenow.com\" rel=\"nofollow\">HoodleNow</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge Chronicle",
        "screen_name" : "cambridgechron",
        "indices" : [ 3, 18 ],
        "id_str" : "14278568",
        "id" : 14278568
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "12150541411",
    "text" : "by @cambridgechron: NEWS: Cambridge man stabbed near Harvard Square http://bit.ly/cOxmrJ",
    "id" : 12150541411,
    "created_at" : "Wed Apr 14 07:10:02 +0000 2010",
    "user" : {
      "name" : "Harvard Square Now!",
      "screen_name" : "02138now",
      "protected" : false,
      "id_str" : "15089620",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/55341027/zipup_harvardsq_normal.png",
      "id" : 15089620,
      "verified" : false
    }
  },
  "id" : 12151611822,
  "created_at" : "Wed Apr 14 07:48:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12146517960",
  "text" : "I just walked in on a room full of Koreans playing starcraft at Lamont!",
  "id" : 12146517960,
  "created_at" : "Wed Apr 14 05:01:57 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12038193969",
  "text" : "Laundry day from helllll",
  "id" : 12038193969,
  "created_at" : "Mon Apr 12 09:53:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12030143519",
  "text" : "I have no dellte key!! i mean delete key",
  "id" : 12030143519,
  "created_at" : "Mon Apr 12 04:54:23 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11981742475",
  "text" : "AADT threw down a great after-afterparty.  Sleep then wakeup to teach ESL!",
  "id" : 11981742475,
  "created_at" : "Sun Apr 11 08:17:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 0, 13 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11908695725",
  "geo" : {
  },
  "id_str" : "11911015785",
  "in_reply_to_user_id" : 112919587,
  "text" : "@vcruzcontrol try for yourself!  I &lt;3 it",
  "id" : 11911015785,
  "in_reply_to_status_id" : 11908695725,
  "created_at" : "Sat Apr 10 00:55:13 +0000 2010",
  "in_reply_to_screen_name" : "vcruzcontrol",
  "in_reply_to_user_id_str" : "112919587",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11906959939",
  "text" : "Tweeting from the new Blackberry twitter app!  So much better than Openbeak and Ubertwitter.",
  "id" : 11906959939,
  "created_at" : "Fri Apr 09 23:21:31 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11890120748",
  "text" : "Haven't been to the range in forevvaaahhh",
  "id" : 11890120748,
  "created_at" : "Fri Apr 09 16:50:52 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11834141730",
  "text" : "Good job Obama.  Hope and change my ass.  Facepalm http://nyti.ms/ascx3v",
  "id" : 11834141730,
  "created_at" : "Thu Apr 08 17:22:08 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 23, 30 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11827204430",
  "text" : "To shoot it down?! RT: @cnnbrk NORAD scrambles 2 F-16s to intercept United flight bound for Denver, CO, after disturbance onboar",
  "id" : 11827204430,
  "created_at" : "Thu Apr 08 14:51:41 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immature",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11766513755",
  "text" : "Bang Wong of the Broad Institute is lecturing.  GIggling at the name.  #immature",
  "id" : 11766513755,
  "created_at" : "Wed Apr 07 17:13:08 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11745066840",
  "text" : "The Mather bird begins singing really early!",
  "id" : 11745066840,
  "created_at" : "Wed Apr 07 07:39:32 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11718285246",
  "text" : "Weather, make up your mind!!",
  "id" : 11718285246,
  "created_at" : "Tue Apr 06 20:58:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11668499570",
  "in_reply_to_user_id" : 62603505,
  "text" : "@lightbrightlayy - Butttweet!",
  "id" : 11668499570,
  "created_at" : "Tue Apr 06 00:04:21 +0000 2010",
  "in_reply_to_screen_name" : "Halle_lujahh",
  "in_reply_to_user_id_str" : "62603505",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11598924726",
  "geo" : {
  },
  "id_str" : "11634180104",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow Cambridge iced tea + my inability to remember rules = bad news for me",
  "id" : 11634180104,
  "in_reply_to_status_id" : 11598924726,
  "created_at" : "Mon Apr 05 10:01:25 +0000 2010",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11497908637",
  "text" : "Some scary smelling old guy ranted at me for 10 minutes in the Science Center!  AhhH!",
  "id" : 11497908637,
  "created_at" : "Fri Apr 02 19:56:22 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 17, 30 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whoami",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11486193382",
  "text" : "Hahaha yes!  RT: @vcruzcontrol LOVE ASIAN POP SONGS!!!! OMG, #whoami??",
  "id" : 11486193382,
  "created_at" : "Fri Apr 02 15:36:41 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11442181674",
  "geo" : {
  },
  "id_str" : "11442568144",
  "in_reply_to_user_id" : 118781125,
  "text" : "@thinkpinkxx  Coop gifts?  So tacky!",
  "id" : 11442568144,
  "in_reply_to_status_id" : 11442181674,
  "created_at" : "Thu Apr 01 20:13:20 +0000 2010",
  "in_reply_to_screen_name" : "missxlena",
  "in_reply_to_user_id_str" : "118781125",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11439483235",
  "text" : "The Yard smells like animal poo. Spring is here!",
  "id" : 11439483235,
  "created_at" : "Thu Apr 01 18:55:48 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11435654745",
  "text" : "Tweeting from a freshly installed 10.6.3 on an Intel X25 disk.  Mac may have redeemed itself!  For now.",
  "id" : 11435654745,
  "created_at" : "Thu Apr 01 17:26:55 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11435451312",
  "text" : "I made a formspring in class! http://www.formspring.me/kilohotel",
  "id" : 11435451312,
  "created_at" : "Thu Apr 01 17:22:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]