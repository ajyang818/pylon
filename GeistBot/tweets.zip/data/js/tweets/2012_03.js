Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/F5kDLLq7",
      "expanded_url" : "http://ow.ly/9Z73k",
      "display_url" : "ow.ly/9Z73k"
    } ]
  },
  "geo" : {
  },
  "id_str" : "186180012477661184",
  "text" : "RT @medialab: The Camera That Can See Around Walls http://t.co/F5kDLLq7",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http://t.co/F5kDLLq7",
        "expanded_url" : "http://ow.ly/9Z73k",
        "display_url" : "ow.ly/9Z73k"
      } ]
    },
    "geo" : {
    },
    "id_str" : "186155976150355968",
    "text" : "The Camera That Can See Around Walls http://t.co/F5kDLLq7",
    "id" : 186155976150355968,
    "created_at" : "Sat Mar 31 18:20:17 +0000 2012",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 186180012477661184,
  "created_at" : "Sat Mar 31 19:55:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186157178288222209",
  "text" : "Looks like Anonymous failed to shut down the Internet today as promised",
  "id" : 186157178288222209,
  "created_at" : "Sat Mar 31 18:25:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "irony",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185561057039876097",
  "text" : "Chrome crashes during bulk photo uploads in Google+. Firefox does not. #irony",
  "id" : 185561057039876097,
  "created_at" : "Fri Mar 30 02:56:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185519448826970113",
  "text" : "Tweeting from a new Galaxy Nexus. iOS was too static, boring.",
  "id" : 185519448826970113,
  "created_at" : "Fri Mar 30 00:10:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 13, 20 ],
      "id_str" : "224321197",
      "id" : 224321197
    }, {
      "name" : "Devon Ray",
      "screen_name" : "DevonRay",
      "indices" : [ 21, 30 ],
      "id_str" : "245281190",
      "id" : 245281190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185252362661801985",
  "geo" : {
  },
  "id_str" : "185252591612084224",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce @zhamed @devonray forget hipsters, firearms are a $4B dollar industry. Just sayin'",
  "id" : 185252591612084224,
  "in_reply_to_status_id" : 185252362661801985,
  "created_at" : "Thu Mar 29 06:30:34 +0000 2012",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185071698050154496",
  "text" : "Has any product dubbed \"the ____ killer\" actually ever taken significant market share from ____?",
  "id" : 185071698050154496,
  "created_at" : "Wed Mar 28 18:31:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skillshare",
      "screen_name" : "skillshare",
      "indices" : [ 18, 29 ],
      "id_str" : "171613435",
      "id" : 171613435
    }, {
      "name" : "Harvard i-lab",
      "screen_name" : "innovationlab",
      "indices" : [ 51, 65 ],
      "id_str" : "246493616",
      "id" : 246493616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/ClijVEHZ",
      "expanded_url" : "http://instagr.am/p/IsOufNvA_a/",
      "display_url" : "instagr.am/p/IsOufNvA_a/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184755202371489792",
  "text" : "Teaching my first @skillshare class at the Harvard @innovationlab http://t.co/ClijVEHZ",
  "id" : 184755202371489792,
  "created_at" : "Tue Mar 27 21:34:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 3, 15 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 54, 62 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "Jeff Bussgang",
      "screen_name" : "bussgang",
      "indices" : [ 79, 88 ],
      "id_str" : "18691131",
      "id" : 18691131
    }, {
      "name" : "Vinay Trivedi",
      "screen_name" : "trivinay",
      "indices" : [ 92, 101 ],
      "id_str" : "236627145",
      "id" : 236627145
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 102, 109 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "Carl Kangming Gao",
      "screen_name" : "carl_gao",
      "indices" : [ 110, 119 ],
      "id_str" : "394931772",
      "id" : 394931772
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 120, 127 ],
      "id_str" : "224321197",
      "id" : 224321197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HBS",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182967398633189377",
  "text" : "RT @badboyboyce: Talking entrepreneurship and VC with @Harvard &amp; #HBS alum @bussgang cc @trivinay @khsieh @carl_gao @zhamed http://t ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 37, 45 ],
        "id_str" : "39585367",
        "id" : 39585367
      }, {
        "name" : "Jeff Bussgang",
        "screen_name" : "bussgang",
        "indices" : [ 62, 71 ],
        "id_str" : "18691131",
        "id" : 18691131
      }, {
        "name" : "Vinay Trivedi",
        "screen_name" : "trivinay",
        "indices" : [ 75, 84 ],
        "id_str" : "236627145",
        "id" : 236627145
      }, {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 85, 92 ],
        "id_str" : "111999960",
        "id" : 111999960
      }, {
        "name" : "Carl Kangming Gao",
        "screen_name" : "carl_gao",
        "indices" : [ 93, 102 ],
        "id_str" : "394931772",
        "id" : 394931772
      }, {
        "name" : "Zach Hamed",
        "screen_name" : "zhamed",
        "indices" : [ 103, 110 ],
        "id_str" : "224321197",
        "id" : 224321197
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/badboyboyce/status/182964392776839169/photo/1",
        "indices" : [ 111, 131 ],
        "url" : "http://t.co/OnwDTzSU",
        "media_url" : "http://pbs.twimg.com/media/AooFJVaCMAALeR3.jpg",
        "id_str" : "182964392785227776",
        "id" : 182964392785227776,
        "media_url_https" : "https://pbs.twimg.com/media/AooFJVaCMAALeR3.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1023,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1023,
          "resize" : "fit",
          "w" : 1023
        } ],
        "display_url" : "pic.twitter.com/OnwDTzSU"
      } ],
      "hashtags" : [ {
        "text" : "HBS",
        "indices" : [ 52, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "182964392776839169",
    "text" : "Talking entrepreneurship and VC with @Harvard &amp; #HBS alum @bussgang cc @trivinay @khsieh @carl_gao @zhamed http://t.co/OnwDTzSU",
    "id" : 182964392776839169,
    "created_at" : "Thu Mar 22 22:58:05 +0000 2012",
    "user" : {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "protected" : false,
      "id_str" : "110823121",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1736585624/HaLongBay_Profile_Thumbnail_normal.jpg",
      "id" : 110823121,
      "verified" : false
    }
  },
  "id" : 182967398633189377,
  "created_at" : "Thu Mar 22 23:10:01 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/PFGL2pNH",
      "expanded_url" : "http://dvice.com/archives/2012/03/china-is-now-th.php",
      "display_url" : "dvice.com/archives/2012/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3760599643, -71.1154940353 ]
  },
  "id_str" : "182837490435108865",
  "text" : "China is #1 for smart phone activations. Popular apps are still for US audience. When will people start cashing in? http://t.co/PFGL2pNH",
  "id" : 182837490435108865,
  "created_at" : "Thu Mar 22 14:33:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3750982667, -71.1144462974 ]
  },
  "id_str" : "182195305280835584",
  "text" : "Saw two kids in the back of a Fiat 500. Didn't know the Geneva Convention allowed that.",
  "id" : 182195305280835584,
  "created_at" : "Tue Mar 20 20:02:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/dA0hCLUn",
      "expanded_url" : "http://www.thefancy.com/things/294042907/Diesel-x-Ducati-Monster-Motorcycle",
      "display_url" : "thefancy.com/things/2940429\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "181190397345800192",
  "text" : "Diesel X Ducati Monster? Shut up and take my money. http://t.co/dA0hCLUn",
  "id" : 181190397345800192,
  "created_at" : "Sun Mar 18 01:28:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MBTA",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3616580248, -71.0189148588 ]
  },
  "id_str" : "180656254778212352",
  "text" : "It should not take longer to get from Boston-Logan to Cambridge than Dulles to Boston-Logan. Wtf #MBTA",
  "id" : 180656254778212352,
  "created_at" : "Fri Mar 16 14:06:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Bates",
      "screen_name" : "batess",
      "indices" : [ 0, 7 ],
      "id_str" : "13833982",
      "id" : 13833982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180628062449319937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8561404124, -77.0417224523 ]
  },
  "id_str" : "180628276094574594",
  "in_reply_to_user_id" : 13833982,
  "text" : "@batess understated is underrated.",
  "id" : 180628276094574594,
  "in_reply_to_status_id" : 180628062449319937,
  "created_at" : "Fri Mar 16 12:15:11 +0000 2012",
  "in_reply_to_screen_name" : "batess",
  "in_reply_to_user_id_str" : "13833982",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8562205434, -77.0417058562 ]
  },
  "id_str" : "180627620776513536",
  "text" : "Seated next to some Chinese princelings on this flight. I can tell from the excessive luxury brands and complete lack of style and tact.",
  "id" : 180627620776513536,
  "created_at" : "Fri Mar 16 12:12:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8561060885, -77.0416694787 ]
  },
  "id_str" : "180626940695289856",
  "text" : "Spent my last spring break building robots with Romotive. Totally worth it. Now back to Cambridge for school.",
  "id" : 180626940695289856,
  "created_at" : "Fri Mar 16 12:09:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/180417977986981888/photo/1",
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/DTe5DdnR",
      "media_url" : "http://pbs.twimg.com/media/AoD5MfFCIAEKKU3.jpg",
      "id_str" : "180417977991176193",
      "id" : 180417977991176193,
      "media_url_https" : "https://pbs.twimg.com/media/AoD5MfFCIAEKKU3.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com/DTe5DdnR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180417977986981888",
  "text" : "Testing the new Romotive firmware. I think he likes it. http://t.co/DTe5DdnR",
  "id" : 180417977986981888,
  "created_at" : "Thu Mar 15 22:19:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 22, 31 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/180151559236239360/photo/1",
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/lE38zh49",
      "media_url" : "http://pbs.twimg.com/media/AoAG436CQAA85Yv.jpg",
      "id_str" : "180151559244627968",
      "id" : 180151559244627968,
      "media_url_https" : "https://pbs.twimg.com/media/AoAG436CQAA85Yv.jpg",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com/lE38zh49"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180151559236239360",
  "text" : "Community dinner with @Romotive team. http://t.co/lE38zh49",
  "id" : 180151559236239360,
  "created_at" : "Thu Mar 15 04:40:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180141203063455744",
  "text" : "TIL Apple pays $11 for the MagSafe cable, Foxconn is the only one that makes it, and its based on a rice cooker.",
  "id" : 180141203063455744,
  "created_at" : "Thu Mar 15 03:59:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 34, 43 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/179854968168251392/photo/1",
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/qngKpPEu",
      "media_url" : "http://pbs.twimg.com/media/An75JAECAAATU_i.jpg",
      "id_str" : "179854968172445696",
      "id" : 179854968172445696,
      "media_url_https" : "https://pbs.twimg.com/media/An75JAECAAATU_i.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com/qngKpPEu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179854968168251392",
  "text" : "Super productive day hacking with @Romotive. New product pics. http://t.co/qngKpPEu",
  "id" : 179854968168251392,
  "created_at" : "Wed Mar 14 09:02:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 79, 88 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179634603911430144",
  "text" : "Just ordered some old stock Palm inductive charging parts. Wirelessly charging @Romotive imminent.",
  "id" : 179634603911430144,
  "created_at" : "Tue Mar 13 18:26:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 0, 14 ],
      "id_str" : "128968036",
      "id" : 128968036
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/179619957401853954/photo/1",
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/Z19Omt7k",
      "media_url" : "http://pbs.twimg.com/media/An4jZkwCIAA6x9v.jpg",
      "id_str" : "179619957410242560",
      "id" : 179619957410242560,
      "media_url_https" : "https://pbs.twimg.com/media/An4jZkwCIAA6x9v.jpg",
      "sizes" : [ {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com/Z19Omt7k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179619957401853954",
  "in_reply_to_user_id" : 128968036,
  "text" : "@KellerRinaudo in the zone for Romo brainstorming. http://t.co/Z19Omt7k",
  "id" : 179619957401853954,
  "created_at" : "Tue Mar 13 17:28:30 +0000 2012",
  "in_reply_to_screen_name" : "KellerRinaudo",
  "in_reply_to_user_id_str" : "128968036",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No Startups ",
      "screen_name" : "nostartups",
      "indices" : [ 20, 31 ],
      "id_str" : "482388526",
      "id" : 482388526
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 49, 61 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179618031805272064",
  "text" : "Curious to see what @nostartups is all about. cc @badboyboyce",
  "id" : 179618031805272064,
  "created_at" : "Tue Mar 13 17:20:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179093609902129152",
  "text" : "So I just bought Civilization V. Uh oh.",
  "id" : 179093609902129152,
  "created_at" : "Mon Mar 12 06:36:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 25, 34 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/179038891012128768/photo/1",
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/pYwYkmSF",
      "media_url" : "http://pbs.twimg.com/media/AnwS7DwCAAEPYKa.jpg",
      "id_str" : "179038891016323073",
      "id" : 179038891016323073,
      "media_url_https" : "https://pbs.twimg.com/media/AnwS7DwCAAEPYKa.jpg",
      "sizes" : [ {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com/pYwYkmSF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.170328, -115.133466 ]
  },
  "id_str" : "179038891012128768",
  "text" : "Robot building race with @Romotive at the Las Vegas HQ http://t.co/pYwYkmSF",
  "id" : 179038891012128768,
  "created_at" : "Mon Mar 12 02:59:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 32, 41 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.0841734941, -115.1356654802 ]
  },
  "id_str" : "178994604740321280",
  "text" : "In Vegas, thanks to the awesome @Romotive team. Can't wait to start building some robots.",
  "id" : 178994604740321280,
  "created_at" : "Mon Mar 12 00:03:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TSAfail",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3677013029, -71.0142822173 ]
  },
  "id_str" : "178877486778691584",
  "text" : "Boston airport X-ray scanners transmit images for screening via exposed Ethernet cable. Man-in-the-middle attack opportunity. #TSAfail",
  "id" : 178877486778691584,
  "created_at" : "Sun Mar 11 16:18:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devon Ray",
      "screen_name" : "DevonRay",
      "indices" : [ 0, 9 ],
      "id_str" : "245281190",
      "id" : 245281190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "178696901858828288",
  "in_reply_to_user_id" : 245281190,
  "text" : "@DevonRay unfortunately I can't update iOS from my jailbroken phone!",
  "id" : 178696901858828288,
  "created_at" : "Sun Mar 11 04:20:36 +0000 2012",
  "in_reply_to_screen_name" : "DevonRay",
  "in_reply_to_user_id_str" : "245281190",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 9, 24 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3727867473, -71.1171218008 ]
  },
  "id_str" : "177786666252124161",
  "text" : "Spotted: @NaveenSrivatsa walking across Harvard yard in camo and war paint",
  "id" : 177786666252124161,
  "created_at" : "Thu Mar 08 16:03:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177665614494695425",
  "text" : "The iPad site's CSS is all borked right now. Someone's going to lose their job over that.",
  "id" : 177665614494695425,
  "created_at" : "Thu Mar 08 08:02:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmexWholeFoods",
      "indices" : [ 59, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177494147631026177",
  "text" : "Amex giving out discounts for tweeting? You sly dogs, you. #AmexWholeFoods",
  "id" : 177494147631026177,
  "created_at" : "Wed Mar 07 20:41:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177491011000467456",
  "text" : "Forget the new iPad... Rolex announces SkyDweller as a COSC, dual timezone, annual calendar in a reasonable size!",
  "id" : 177491011000467456,
  "created_at" : "Wed Mar 07 20:28:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 6, 12 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177264223825559552",
  "text" : "A new @gmail loading screen!",
  "id" : 177264223825559552,
  "created_at" : "Wed Mar 07 05:27:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3726471886, -71.1145342235 ]
  },
  "id_str" : "177154065275424768",
  "text" : "I just used a 3-hole punch for the first time in years. Paper notes are so alien to me now.",
  "id" : 177154065275424768,
  "created_at" : "Tue Mar 06 22:09:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 3, 19 ],
      "id_str" : "228489296",
      "id" : 228489296
    }, {
      "name" : "Ray Kwong",
      "screen_name" : "raykwong",
      "indices" : [ 25, 34 ],
      "id_str" : "14926475",
      "id" : 14926475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177102637936820224",
  "text" : "RT @GlobalAsianista: Via @raykwong 50 Best Chinese Restaurants stateside. Missing on NY list is Nan Xiang Dumpling House in Flushing. ht ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ray Kwong",
        "screen_name" : "raykwong",
        "indices" : [ 4, 13 ],
        "id_str" : "14926475",
        "id" : 14926475
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http://t.co/IcPHRD9N",
        "expanded_url" : "http://bit.ly/zQbrDJ",
        "display_url" : "bit.ly/zQbrDJ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "176896573610000384",
    "text" : "Via @raykwong 50 Best Chinese Restaurants stateside. Missing on NY list is Nan Xiang Dumpling House in Flushing. http://t.co/IcPHRD9N",
    "id" : 176896573610000384,
    "created_at" : "Tue Mar 06 05:06:44 +0000 2012",
    "user" : {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "protected" : false,
      "id_str" : "228489296",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1479092871/Twitter4_normal.jpg",
      "id" : 228489296,
      "verified" : false
    }
  },
  "id" : 177102637936820224,
  "created_at" : "Tue Mar 06 18:45:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JasonCross00",
      "screen_name" : "JasonCross00",
      "indices" : [ 3, 16 ],
      "id_str" : "14334870",
      "id" : 14334870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177101902155227136",
  "text" : "RT @JasonCross00: Love it when 20-something tech writers claim Windows 95 wasn't great. Bitch, please. You were 9. You don't even know.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "176851506216177664",
    "text" : "Love it when 20-something tech writers claim Windows 95 wasn't great. Bitch, please. You were 9. You don't even know.",
    "id" : 176851506216177664,
    "created_at" : "Tue Mar 06 02:07:39 +0000 2012",
    "user" : {
      "name" : "JasonCross00",
      "screen_name" : "JasonCross00",
      "protected" : false,
      "id_str" : "14334870",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1963679460/jcross_normal.jpg",
      "id" : 14334870,
      "verified" : false
    }
  },
  "id" : 177101902155227136,
  "created_at" : "Tue Mar 06 18:42:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "176882836601700352",
  "text" : "Trying to motivate myself to use Pinterest.",
  "id" : 176882836601700352,
  "created_at" : "Tue Mar 06 04:12:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "176732989563207680",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha hopefully I'll have the product in my hands this week!",
  "id" : 176732989563207680,
  "created_at" : "Mon Mar 05 18:16:42 +0000 2012",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3681743956, -71.1154182628 ]
  },
  "id_str" : "176602629739257856",
  "text" : "Working with Chinese prototypers is really wrecking my sleep schedule. On the plus side, Chinese skills improving.",
  "id" : 176602629739257856,
  "created_at" : "Mon Mar 05 09:38:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "fangjon",
      "indices" : [ 0, 8 ],
      "id_str" : "46477577",
      "id" : 46477577
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 16, 28 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175454871649132545",
  "geo" : {
  },
  "id_str" : "176243411932819456",
  "in_reply_to_user_id" : 46477577,
  "text" : "@fangjon me and @badboyboyce are once again the reigning champions of the Mather Chicken Wing Eating contest :)",
  "id" : 176243411932819456,
  "in_reply_to_status_id" : 175454871649132545,
  "created_at" : "Sun Mar 04 09:51:18 +0000 2012",
  "in_reply_to_screen_name" : "fangjon",
  "in_reply_to_user_id_str" : "46477577",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "176176147602743298",
  "text" : "Writing applications and doing HW on a Saturday night. Clearly the coolest senior.",
  "id" : 176176147602743298,
  "created_at" : "Sun Mar 04 05:24:01 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Krasney",
      "screen_name" : "nickkrasney",
      "indices" : [ 3, 15 ],
      "id_str" : "22696850",
      "id" : 22696850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175425811095093250",
  "text" : "RT @nickkrasney: I want to write a Python NLP script that responds to inquiries with simulated Republic outrage. I bet it could pass the ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "175344622753685504",
    "text" : "I want to write a Python NLP script that responds to inquiries with simulated Republic outrage. I bet it could pass the Turing test.",
    "id" : 175344622753685504,
    "created_at" : "Thu Mar 01 22:19:50 +0000 2012",
    "user" : {
      "name" : "Nick Krasney",
      "screen_name" : "nickkrasney",
      "protected" : false,
      "id_str" : "22696850",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/435128958/nbk_normal.jpg",
      "id" : 22696850,
      "verified" : false
    }
  },
  "id" : 175425811095093250,
  "created_at" : "Fri Mar 02 03:42:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/2M3dTccY",
      "expanded_url" : "http://www.brothers-brick.com/2012/02/29/lego-iss-built-aboard-international-space-station-inside-zero-g-build-bubble/",
      "display_url" : "brothers-brick.com/2012/02/29/leg\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "175131442135830529",
  "text" : "Yo dawg, I heard you liked International Space Stations: http://t.co/2M3dTccY",
  "id" : 175131442135830529,
  "created_at" : "Thu Mar 01 08:12:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]