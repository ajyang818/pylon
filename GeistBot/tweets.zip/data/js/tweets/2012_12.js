Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TWC",
      "screen_name" : "twcable_nyc",
      "indices" : [ 10, 22 ],
      "id_str" : "1225944228",
      "id" : 1225944228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7417099983, -73.9859142912 ]
  },
  "id_str" : "285828071653781504",
  "text" : "One thing @TWcable_NYC does really fast is replace remotes. But only bc they have a literal bucket of them bc they're expected to break.",
  "id" : 285828071653781504,
  "created_at" : "Mon Dec 31 19:21:37 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TWC",
      "screen_name" : "twcable_nyc",
      "indices" : [ 5, 17 ],
      "id_str" : "1225944228",
      "id" : 1225944228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7407513204, -73.986993787 ]
  },
  "id_str" : "285827654224052226",
  "text" : "More @TWcable_NYC brilliance: the people that opt for self-setup wait in line with everyone else waiting for full service.",
  "id" : 285827654224052226,
  "created_at" : "Mon Dec 31 19:19:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TWC",
      "screen_name" : "twcable_nyc",
      "indices" : [ 16, 28 ],
      "id_str" : "1225944228",
      "id" : 1225944228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7420394639, -73.9854082708 ]
  },
  "id_str" : "285827002852851712",
  "text" : "Another amazing @TWcable_NYC service: couple wanted to sign up for service. Sales rep is AWOL. They wait in line w us support plebes.",
  "id" : 285827002852851712,
  "created_at" : "Mon Dec 31 19:17:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TWC",
      "screen_name" : "twcable_nyc",
      "indices" : [ 3, 15 ],
      "id_str" : "1225944228",
      "id" : 1225944228
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genius",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7411147197, -73.9860129307 ]
  },
  "id_str" : "285826386302742528",
  "text" : "So @TWcable_NYC rep just told a senior citizen in a wheelchair to call support... He came in because his phone's not working. #genius",
  "id" : 285826386302742528,
  "created_at" : "Mon Dec 31 19:14:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Fiber",
      "screen_name" : "googlefiber",
      "indices" : [ 15, 27 ],
      "id_str" : "300378623",
      "id" : 300378623
    }, {
      "name" : "TWC",
      "screen_name" : "twcable_nyc",
      "indices" : [ 44, 56 ],
      "id_str" : "1225944228",
      "id" : 1225944228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "285573053965029376",
  "text" : "Can't wait for @GoogleFiber to free us from @TWCable_NYC (not sure if this tweet is even going to make it thru our terrible wifi).",
  "id" : 285573053965029376,
  "created_at" : "Mon Dec 31 02:28:16 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TWC",
      "screen_name" : "twcable_nyc",
      "indices" : [ 26, 38 ],
      "id_str" : "1225944228",
      "id" : 1225944228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7096654, -74.01210703 ]
  },
  "id_str" : "285272202805407745",
  "text" : "My favorite part of using @TWCable_NYC is when their crappy modem reboots under heavy load without fail.",
  "id" : 285272202805407745,
  "created_at" : "Sun Dec 30 06:32:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Anderson",
      "screen_name" : "chr1sa",
      "indices" : [ 1, 8 ],
      "id_str" : "17595439",
      "id" : 17595439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285205634016763904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7291824779, -73.9888952591 ]
  },
  "id_str" : "285207436695072769",
  "in_reply_to_user_id" : 17595439,
  "text" : ".@chr1sa the app 123D Catch by Autodesk allows you to do 3D capture with a smart phone assuming pretty even lighting.",
  "id" : 285207436695072769,
  "in_reply_to_status_id" : 285205634016763904,
  "created_at" : "Sun Dec 30 02:15:26 +0000 2012",
  "in_reply_to_screen_name" : "chr1sa",
  "in_reply_to_user_id_str" : "17595439",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284811943225729026",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7624650246, -73.9766677455 ]
  },
  "id_str" : "284813469449068545",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil FB's half assed foray into hardware with HTC last year was dead-on-arrival.",
  "id" : 284813469449068545,
  "in_reply_to_status_id" : 284811943225729026,
  "created_at" : "Sat Dec 29 00:09:57 +0000 2012",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FacebookRevenueIdeas",
      "indices" : [ 63, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7632690575, -73.9704939724 ]
  },
  "id_str" : "284811268118949888",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil make it a hashtag. Ex: Ghostwriters to message crushes. #FacebookRevenueIdeas",
  "id" : 284811268118949888,
  "created_at" : "Sat Dec 29 00:01:12 +0000 2012",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gadget Lab",
      "screen_name" : "gadgetlab",
      "indices" : [ 36, 46 ],
      "id_str" : "11518842",
      "id" : 11518842
    }, {
      "name" : "Maybe Mat Honan",
      "screen_name" : "mat",
      "indices" : [ 119, 123 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/mDKqk8gO",
      "expanded_url" : "http://www.wired.com/gadgetlab/2012/12/internet-tv-sucks/",
      "display_url" : "wired.com/gadgetlab/2012\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621053997, -73.9685557412 ]
  },
  "id_str" : "284800908221612032",
  "text" : "Apple, deliver us from mediocrity. \u201C@gadgetlab: No One Uses Smart TV Internet Because It Sucks http://t.co/mDKqk8gO by @mat\u201D",
  "id" : 284800908221612032,
  "created_at" : "Fri Dec 28 23:20:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284788694630690817",
  "text" : "I see tweets from friends in the Adirondacks now. I remember having to get satellite phones and dedicated GPS to camp there 10 years ago.",
  "id" : 284788694630690817,
  "created_at" : "Fri Dec 28 22:31:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ministry of Supply",
      "screen_name" : "MinistrySupply",
      "indices" : [ 11, 26 ],
      "id_str" : "462236193",
      "id" : 462236193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284773229770440705",
  "text" : "Ordered my @MinistrySupply shirts. If all goes well, I'm going to donate most of my wardrobe and just have a few of these shirts.",
  "id" : 284773229770440705,
  "created_at" : "Fri Dec 28 21:30:03 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the reddit alien",
      "screen_name" : "reddit",
      "indices" : [ 93, 100 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/284704494657347585/photo/1",
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/JheyTsQH",
      "media_url" : "http://pbs.twimg.com/media/A_N5Or5CIAAzYjQ.jpg",
      "id_str" : "284704494661541888",
      "id" : 284704494661541888,
      "media_url_https" : "https://pbs.twimg.com/media/A_N5Or5CIAAzYjQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com/JheyTsQH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "284704494657347585",
  "text" : "Great picture showing how different generations play. I straddle both sides of this gap. via @reddit http://t.co/JheyTsQH",
  "id" : 284704494657347585,
  "created_at" : "Fri Dec 28 16:56:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/DPzNqYdE",
      "expanded_url" : "http://shanghaiist.com/2012/12/27/xinhua_photoshops_li_keqiang_is_emb.php",
      "display_url" : "shanghaiist.com/2012/12/27/xin\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "284391414387843072",
  "text" : "For a government that has the most sophisticated digital censorship in the world, China still can't photoshop. http://t.co/DPzNqYdE",
  "id" : 284391414387843072,
  "created_at" : "Thu Dec 27 20:12:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/283650625252761600/photo/1",
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/ljzAXN3R",
      "media_url" : "http://pbs.twimg.com/media/A--6vacCIAEDSsS.jpg",
      "id_str" : "283650625261150209",
      "id" : 283650625261150209,
      "media_url_https" : "https://pbs.twimg.com/media/A--6vacCIAEDSsS.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/ljzAXN3R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104697789, -74.0053565546 ]
  },
  "id_str" : "283650625252761600",
  "text" : "For Christmas, my cat threw up in my shoes. http://t.co/ljzAXN3R",
  "id" : 283650625252761600,
  "created_at" : "Tue Dec 25 19:09:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Jackson",
      "screen_name" : "zenazn",
      "indices" : [ 0, 7 ],
      "id_str" : "13982702",
      "id" : 13982702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283117998858977280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104399125, -74.0064055079 ]
  },
  "id_str" : "283129711993970688",
  "in_reply_to_user_id" : 13982702,
  "text" : "@zenazn I used to think that too. Now that I know people who aren't always glued to a laptop, I realized it's pretty popular.",
  "id" : 283129711993970688,
  "in_reply_to_status_id" : 283117998858977280,
  "created_at" : "Mon Dec 24 08:39:18 +0000 2012",
  "in_reply_to_screen_name" : "zenazn",
  "in_reply_to_user_id_str" : "13982702",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AircraftTalking",
      "screen_name" : "AircraftTalking",
      "indices" : [ 63, 79 ],
      "id_str" : "827765124",
      "id" : 827765124
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/AircraftTalking/status/282899205071175680/photo/1",
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/vskrSiAi",
      "media_url" : "http://pbs.twimg.com/media/A-0PVAHCAAA7mJf.jpg",
      "id_str" : "282899205075369984",
      "id" : 282899205075369984,
      "media_url_https" : "https://pbs.twimg.com/media/A-0PVAHCAAA7mJf.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/vskrSiAi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7350598487, -73.9183347004 ]
  },
  "id_str" : "283002444475158528",
  "text" : "It never ceases to amaze me how over-engineered aircraft are. \u201C@AircraftTalking: Su 25 hard damage. Still flew home. http://t.co/vskrSiAi\u201D",
  "id" : 283002444475158528,
  "created_at" : "Mon Dec 24 00:13:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Jackson",
      "screen_name" : "zenazn",
      "indices" : [ 0, 7 ],
      "id_str" : "13982702",
      "id" : 13982702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282996579168817152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7668545423, -73.8877510932 ]
  },
  "id_str" : "283001213564358656",
  "in_reply_to_user_id" : 13982702,
  "text" : "@zenazn by \"desktop\" I assume you mean iMac. They don't even have Mac Pros in stores anymore.",
  "id" : 283001213564358656,
  "in_reply_to_status_id" : 282996579168817152,
  "created_at" : "Mon Dec 24 00:08:41 +0000 2012",
  "in_reply_to_screen_name" : "zenazn",
  "in_reply_to_user_id_str" : "13982702",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U-Turn Audio",
      "screen_name" : "uturnaudio",
      "indices" : [ 0, 11 ],
      "id_str" : "542727065",
      "id" : 542727065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282951033439789056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9361994965, -78.7299773733 ]
  },
  "id_str" : "282960679797944322",
  "in_reply_to_user_id" : 542727065,
  "text" : "@uturnaudio congrats on funding! Can't wait to get my hands on the Orbit.",
  "id" : 282960679797944322,
  "in_reply_to_status_id" : 282951033439789056,
  "created_at" : "Sun Dec 23 21:27:37 +0000 2012",
  "in_reply_to_screen_name" : "uturnaudio",
  "in_reply_to_user_id_str" : "542727065",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/282943753356976128/photo/1",
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/PckFgcur",
      "media_url" : "http://pbs.twimg.com/media/A-032DbCIAEYy3q.jpg",
      "id_str" : "282943753365364737",
      "id" : 282943753365364737,
      "media_url_https" : "https://pbs.twimg.com/media/A-032DbCIAEYy3q.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/PckFgcur"
    } ],
    "hashtags" : [ {
      "text" : "mightymightymighty",
      "indices" : [ 73, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0238508666, -78.6975167972 ]
  },
  "id_str" : "282943753356976128",
  "text" : "No matter classy my taste gets, I am always in the mood for MIGHTY TACO. #mightymightymighty http://t.co/PckFgcur",
  "id" : 282943753356976128,
  "created_at" : "Sun Dec 23 20:20:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 0, 9 ],
      "id_str" : "20568189",
      "id" : 20568189
    }, {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 16, 24 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282860004808224768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0068275147, -78.699979568 ]
  },
  "id_str" : "282904055741812736",
  "in_reply_to_user_id" : 20568189,
  "text" : "@HODINKEE which @wegmans?",
  "id" : 282904055741812736,
  "in_reply_to_status_id" : 282860004808224768,
  "created_at" : "Sun Dec 23 17:42:37 +0000 2012",
  "in_reply_to_screen_name" : "HODINKEE",
  "in_reply_to_user_id_str" : "20568189",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "indices" : [ 57, 64 ],
      "id_str" : "24206345",
      "id" : 24206345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282721787211558912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0067847174, -78.6997616293 ]
  },
  "id_str" : "282722080519254016",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce iPhone-flip-hanger-upper sounds more like a @quirky project to me.",
  "id" : 282722080519254016,
  "in_reply_to_status_id" : 282721787211558912,
  "created_at" : "Sun Dec 23 05:39:31 +0000 2012",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "282720332220096513",
  "text" : "I want to design an iPhone accessory that lets me flip-to-hang-up with the authority of an old flip phone.",
  "id" : 282720332220096513,
  "created_at" : "Sun Dec 23 05:32:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U-Turn Audio",
      "screen_name" : "uturnaudio",
      "indices" : [ 37, 48 ],
      "id_str" : "542727065",
      "id" : 542727065
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 52, 64 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/QJzPQWqc",
      "expanded_url" : "http://www.kickstarter.com/projects/uturnaudio/the-orbit-turntable-0",
      "display_url" : "kickstarter.com/projects/uturn\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "282717907450986498",
  "text" : "I just backed The Orbit Turntable by @UTurnAudio on @Kickstarter! http://t.co/QJzPQWqc",
  "id" : 282717907450986498,
  "created_at" : "Sun Dec 23 05:22:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Constine",
      "screen_name" : "JoshConstine",
      "indices" : [ 3, 16 ],
      "id_str" : "19563366",
      "id" : 19563366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lol",
      "indices" : [ 78, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "282691880679002112",
  "text" : "RT @JoshConstine: OH about the future of Snapchat: \"They should make it B2B.\" #lol",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lol",
        "indices" : [ 60, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "282687169154387968",
    "text" : "OH about the future of Snapchat: \"They should make it B2B.\" #lol",
    "id" : 282687169154387968,
    "created_at" : "Sun Dec 23 03:20:47 +0000 2012",
    "user" : {
      "name" : "Josh Constine",
      "screen_name" : "JoshConstine",
      "protected" : false,
      "id_str" : "19563366",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1954609932/Josh_Constine_Headshot_Middle_3_25_done_normal.jpg",
      "id" : 19563366,
      "verified" : false
    }
  },
  "id" : 282691880679002112,
  "created_at" : "Sun Dec 23 03:39:31 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.967785406, -78.6949324888 ]
  },
  "id_str" : "282570513132433408",
  "text" : "Mom, sis and I wandered around Best Buy and could not figure out a compelling way to spend $50 gift card. Their biz model is toast.",
  "id" : 282570513132433408,
  "created_at" : "Sat Dec 22 19:37:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9365398163, -78.7450842675 ]
  },
  "id_str" : "282356490793275392",
  "text" : "Passengers gave the pilot a round of applause for textbook landing on an ice-covered tarmac. Yep, I'm definitely back in Buffalo.",
  "id" : 282356490793275392,
  "created_at" : "Sat Dec 22 05:26:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Design Stats",
      "screen_name" : "DesignStats",
      "indices" : [ 3, 15 ],
      "id_str" : "995154116",
      "id" : 995154116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "282180448275279874",
  "text" : "RT @DesignStats: 57% of designers will drink a beer they hate if the label is properly typeset.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "281363302565691392",
    "text" : "57% of designers will drink a beer they hate if the label is properly typeset.",
    "id" : 281363302565691392,
    "created_at" : "Wed Dec 19 11:40:13 +0000 2012",
    "user" : {
      "name" : "Design Stats",
      "screen_name" : "DesignStats",
      "protected" : false,
      "id_str" : "995154116",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2962703368/80bbe639783221647502cd1a5d07b510_normal.png",
      "id" : 995154116,
      "verified" : false
    }
  },
  "id" : 282180448275279874,
  "created_at" : "Fri Dec 21 17:47:16 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby McKenna",
      "screen_name" : "bobby",
      "indices" : [ 0, 6 ],
      "id_str" : "17983820",
      "id" : 17983820
    }, {
      "name" : "Andrew Cornett",
      "screen_name" : "amotion",
      "indices" : [ 7, 15 ],
      "id_str" : "10920012",
      "id" : 10920012
    }, {
      "name" : "Eli",
      "screen_name" : "elirousso",
      "indices" : [ 16, 26 ],
      "id_str" : "14298904",
      "id" : 14298904
    }, {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 27, 38 ],
      "id_str" : "6568422",
      "id" : 6568422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282165725727174656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7620898033, -73.9685031285 ]
  },
  "id_str" : "282174502572539904",
  "in_reply_to_user_id" : 17983820,
  "text" : "@bobby @amotion @elirousso @adamludwin hearing a DJ's OSX system sounds is always a facepalm.",
  "id" : 282174502572539904,
  "in_reply_to_status_id" : 282165725727174656,
  "created_at" : "Fri Dec 21 17:23:38 +0000 2012",
  "in_reply_to_screen_name" : "bobby",
  "in_reply_to_user_id_str" : "17983820",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/282168519544680449/photo/1",
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/IDbtRa24",
      "media_url" : "http://pbs.twimg.com/media/A-p2xgbCMAAeka7.jpg",
      "id_str" : "282168519553069056",
      "id" : 282168519553069056,
      "media_url_https" : "https://pbs.twimg.com/media/A-p2xgbCMAAeka7.jpg",
      "sizes" : [ {
        "h" : 75,
        "resize" : "fit",
        "w" : 187
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 187
      }, {
        "h" : 75,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 187
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 187
      } ],
      "display_url" : "pic.twitter.com/IDbtRa24"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "282168519544680449",
  "text" : "Youtube adds some flair to Gangnam Style's 1 billion views. Can. Not. Stop. Watching. http://t.co/IDbtRa24",
  "id" : 282168519544680449,
  "created_at" : "Fri Dec 21 16:59:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThatAwkwardMoment",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.762091936, -73.9685034876 ]
  },
  "id_str" : "282133623346458624",
  "text" : "#ThatAwkwardMoment when your headphones leak sound and everyone on the rush hour train hears you rocking out to the Pokemon theme.",
  "id" : 282133623346458624,
  "created_at" : "Fri Dec 21 14:41:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 25, 32 ],
      "id_str" : "15137329",
      "id" : 15137329
    }, {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 60, 64 ],
      "id_str" : "19494411",
      "id" : 19494411
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/281856669925904384/photo/1",
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/UbRaSUCA",
      "media_url" : "http://pbs.twimg.com/media/A-lbJeECEAECqHf.jpg",
      "id_str" : "281856669934292993",
      "id" : 281856669934292993,
      "media_url_https" : "https://pbs.twimg.com/media/A-lbJeECEAECqHf.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/UbRaSUCA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281856669925904384",
  "text" : "My secret Santa gift for @jdrive: .177 cal. desktop cannon. @RRE cubicle wars just got serious. http://t.co/UbRaSUCA",
  "id" : 281856669925904384,
  "created_at" : "Thu Dec 20 20:20:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281834725482590210",
  "text" : "The world hasn't ended yet. Good to know that the universe works on Eastern Standard Time.",
  "id" : 281834725482590210,
  "created_at" : "Thu Dec 20 18:53:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/2TjGad4v",
      "expanded_url" : "http://lego.cuusoo.com/",
      "display_url" : "lego.cuusoo.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281832609368141824",
  "text" : "LEGO has stayed above water because they embrace new technologies. Check out their awesome crowdsourced design site. http://t.co/2TjGad4v",
  "id" : 281832609368141824,
  "created_at" : "Thu Dec 20 18:45:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily C&H Quote",
      "screen_name" : "CalvinandHobb3s",
      "indices" : [ 3, 19 ],
      "id_str" : "166613829",
      "id" : 166613829
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "calvinandhobbes",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281807303181746176",
  "text" : "RT @CalvinandHobb3s: I'm not dumb. I just have a command of thoroughly useless information. #calvinandhobbes Calvin and Hobbes",
  "retweeted_status" : {
    "source" : "<a href=\"http://calvinandhobbes.me\" rel=\"nofollow\">Calvin and Hobbes Daily Quotes</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "calvinandhobbes",
        "indices" : [ 71, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "281051218426601472",
    "text" : "I'm not dumb. I just have a command of thoroughly useless information. #calvinandhobbes Calvin and Hobbes",
    "id" : 281051218426601472,
    "created_at" : "Tue Dec 18 15:00:06 +0000 2012",
    "user" : {
      "name" : "Daily C&H Quote",
      "screen_name" : "CalvinandHobb3s",
      "protected" : false,
      "id_str" : "166613829",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2956934884/e2f76c349d2bf274526dbb49facfd6c8_normal.jpeg",
      "id" : 166613829,
      "verified" : false
    }
  },
  "id" : 281807303181746176,
  "created_at" : "Thu Dec 20 17:04:31 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281786019769110528",
  "text" : "The new merger of GETCO and Knight should be Get Knight Cap.",
  "id" : 281786019769110528,
  "created_at" : "Thu Dec 20 15:39:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maker",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/o7fG4CnS",
      "expanded_url" : "http://www.boeing.com/Features/2012/12/corp_wifi_12_18_12.html",
      "display_url" : "boeing.com/Features/2012/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281537083095543808",
  "text" : "Boeing uses 10 tons of potatoes to simulate people in wifi tests. Love seeing the #maker spirit solving hard problems. http://t.co/o7fG4CnS",
  "id" : 281537083095543808,
  "created_at" : "Wed Dec 19 23:10:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Sinofsky",
      "screen_name" : "stevesi",
      "indices" : [ 3, 11 ],
      "id_str" : "13418072",
      "id" : 13418072
    }, {
      "name" : "Harvard Business",
      "screen_name" : "HarvardHBS",
      "indices" : [ 34, 45 ],
      "id_str" : "19606528",
      "id" : 19606528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sabba",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281472451207110656",
  "text" : "RT @stevesi: Excited to return to @HarvardHBS to teach again this spring!  New perspectives, recharge, share experiences, write.  #sabba ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard Business",
        "screen_name" : "HarvardHBS",
        "indices" : [ 21, 32 ],
        "id_str" : "19606528",
        "id" : 19606528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sabbatical",
        "indices" : [ 117, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "281439841483362306",
    "text" : "Excited to return to @HarvardHBS to teach again this spring!  New perspectives, recharge, share experiences, write.  #sabbatical",
    "id" : 281439841483362306,
    "created_at" : "Wed Dec 19 16:44:21 +0000 2012",
    "user" : {
      "name" : "Steven Sinofsky",
      "screen_name" : "stevesi",
      "protected" : false,
      "id_str" : "13418072",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2581758774/OM_normal.jpg",
      "id" : 13418072,
      "verified" : false
    }
  },
  "id" : 281472451207110656,
  "created_at" : "Wed Dec 19 18:53:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Friends of Ai Weiwei",
      "screen_name" : "FriendsofAiWW",
      "indices" : [ 90, 104 ],
      "id_str" : "862974031",
      "id" : 862974031
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/281263063905206273/photo/1",
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/vTsqi2XK",
      "media_url" : "http://pbs.twimg.com/media/A-c_RDTCAAEEVAP.jpg",
      "id_str" : "281263063909400577",
      "id" : 281263063909400577,
      "media_url_https" : "https://pbs.twimg.com/media/A-c_RDTCAAEEVAP.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/vTsqi2XK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104020046, -74.0063493321 ]
  },
  "id_str" : "281263063905206273",
  "text" : "It's like a book of fortune cookie fortunes, if fortune cookies were super insightful. cc @FriendsofAiWW http://t.co/vTsqi2XK",
  "id" : 281263063905206273,
  "created_at" : "Wed Dec 19 05:01:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281086862028857347",
  "text" : "RT @parislemon: Last year, we quit Facebook. 6 months ago, we quit Twitter. Today, we quit Instagram. Oh, by \"quit\" you mean stop using  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "281082733294387200",
    "text" : "Last year, we quit Facebook. 6 months ago, we quit Twitter. Today, we quit Instagram. Oh, by \"quit\" you mean stop using them? Then no.",
    "id" : 281082733294387200,
    "created_at" : "Tue Dec 18 17:05:20 +0000 2012",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3336694463/99718483afb19d6d441290afccb72772_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 281086862028857347,
  "created_at" : "Tue Dec 18 17:21:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houston Rockets",
      "screen_name" : "HoustonRockets",
      "indices" : [ 3, 18 ],
      "id_str" : "19077044",
      "id" : 19077044
    }, {
      "name" : "Jeremy Lin",
      "screen_name" : "JLin7",
      "indices" : [ 60, 66 ],
      "id_str" : "170424259",
      "id" : 170424259
    }, {
      "name" : "NBA All-Star",
      "screen_name" : "NBAAllStar",
      "indices" : [ 76, 87 ],
      "id_str" : "214537859",
      "id" : 214537859
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RepRed",
      "indices" : [ 94, 101 ]
    }, {
      "text" : "NBABallo",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280890104426397696",
  "text" : "RT @HoustonRockets: After tonight's performance, Jeremy Lin @JLin7 gets our @NBAAllStar vote. #RepRed Vote Rockets, Vote Often #NBABallo ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy Lin",
        "screen_name" : "JLin7",
        "indices" : [ 40, 46 ],
        "id_str" : "170424259",
        "id" : 170424259
      }, {
        "name" : "NBA All-Star",
        "screen_name" : "NBAAllStar",
        "indices" : [ 56, 67 ],
        "id_str" : "214537859",
        "id" : 214537859
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/HoustonRockets/status/280873269995913216/photo/1",
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/K84TlCEP",
        "media_url" : "http://pbs.twimg.com/media/A-XcwD1CQAEFQpZ.jpg",
        "id_str" : "280873270000107521",
        "id" : 280873270000107521,
        "media_url_https" : "https://pbs.twimg.com/media/A-XcwD1CQAEFQpZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1800,
          "resize" : "fit",
          "w" : 1277
        }, {
          "h" : 1443,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/K84TlCEP"
      } ],
      "hashtags" : [ {
        "text" : "RepRed",
        "indices" : [ 74, 81 ]
      }, {
        "text" : "NBABallot",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "280873269995913216",
    "text" : "After tonight's performance, Jeremy Lin @JLin7 gets our @NBAAllStar vote. #RepRed Vote Rockets, Vote Often #NBABallot http://t.co/K84TlCEP",
    "id" : 280873269995913216,
    "created_at" : "Tue Dec 18 03:13:01 +0000 2012",
    "user" : {
      "name" : "Houston Rockets",
      "screen_name" : "HoustonRockets",
      "protected" : false,
      "id_str" : "19077044",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2811341729/a8fed7c74952fe45fe13c23ad269bf9e_normal.png",
      "id" : 19077044,
      "verified" : true
    }
  },
  "id" : 280890104426397696,
  "created_at" : "Tue Dec 18 04:19:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Blitzstein Tho",
      "screen_name" : "Stat110Tho",
      "indices" : [ 3, 14 ],
      "id_str" : "983366707",
      "id" : 983366707
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notrealscientists",
      "indices" : [ 108, 126 ]
    }, {
      "text" : "STATSORDIE",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279982007080087552",
  "text" : "RT @Stat110Tho: off by one errors is common in programming - dats becuz computer scientists is str8 stoopid #notrealscientists #STATSORDIE",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "notrealscientists",
        "indices" : [ 92, 110 ]
      }, {
        "text" : "STATSORDIE",
        "indices" : [ 111, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "278306631190712321",
    "text" : "off by one errors is common in programming - dats becuz computer scientists is str8 stoopid #notrealscientists #STATSORDIE",
    "id" : 278306631190712321,
    "created_at" : "Tue Dec 11 01:14:06 +0000 2012",
    "user" : {
      "name" : "Joe Blitzstein Tho",
      "screen_name" : "Stat110Tho",
      "protected" : false,
      "id_str" : "983366707",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2926518637/06ac278f280ae3208fa1cbd2f8e02f8b_normal.png",
      "id" : 983366707,
      "verified" : false
    }
  },
  "id" : 279982007080087552,
  "created_at" : "Sat Dec 15 16:11:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Davidson",
      "screen_name" : "tdavidson",
      "indices" : [ 3, 13 ],
      "id_str" : "8466962",
      "id" : 8466962
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 23, 32 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 36, 50 ],
      "id_str" : "128968036",
      "id" : 128968036
    }, {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 82, 89 ],
      "id_str" : "9544202",
      "id" : 9544202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcweek",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "vegastech",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/przmfqch",
      "expanded_url" : "http://instagr.am/p/TO6l_3ocYR/",
      "display_url" : "instagr.am/p/TO6l_3ocYR/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279710769560580096",
  "text" : "RT @tdavidson: Demo of @romotive by @KellerRinaudo for #tcweek tour #vegastech cc @schlaf  @ Romotive HQ http://t.co/przmfqch",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Romotive",
        "screen_name" : "Romotive",
        "indices" : [ 8, 17 ],
        "id_str" : "340545195",
        "id" : 340545195
      }, {
        "name" : "Keller Rinaudo",
        "screen_name" : "KellerRinaudo",
        "indices" : [ 21, 35 ],
        "id_str" : "128968036",
        "id" : 128968036
      }, {
        "name" : "Steve Schlafman",
        "screen_name" : "schlaf",
        "indices" : [ 67, 74 ],
        "id_str" : "9544202",
        "id" : 9544202
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcweek",
        "indices" : [ 40, 47 ]
      }, {
        "text" : "vegastech",
        "indices" : [ 53, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/przmfqch",
        "expanded_url" : "http://instagr.am/p/TO6l_3ocYR/",
        "display_url" : "instagr.am/p/TO6l_3ocYR/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 36.1700045235, -115.139547065 ]
    },
    "id_str" : "279709191692771330",
    "text" : "Demo of @romotive by @KellerRinaudo for #tcweek tour #vegastech cc @schlaf  @ Romotive HQ http://t.co/przmfqch",
    "id" : 279709191692771330,
    "created_at" : "Fri Dec 14 22:07:22 +0000 2012",
    "user" : {
      "name" : "Taylor Davidson",
      "screen_name" : "tdavidson",
      "protected" : false,
      "id_str" : "8466962",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1281157967/tdavidson2_normal.jpg",
      "id" : 8466962,
      "verified" : false
    }
  },
  "id" : 279710769560580096,
  "created_at" : "Fri Dec 14 22:13:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/h9hSb8Q1",
      "expanded_url" : "http://www.eurogamer.net/articles/2012-12-13-why-xbox-failed-in-japan",
      "display_url" : "eurogamer.net/articles/2012-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279651931348140032",
  "text" : "Designing across cultures: why the Xbox failed in Japan. http://t.co/h9hSb8Q1",
  "id" : 279651931348140032,
  "created_at" : "Fri Dec 14 18:19:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/8FK5USta",
      "expanded_url" : "http://t.imehop.com/UWir6E",
      "display_url" : "t.imehop.com/UWir6E"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279321937757478912",
  "text" : "State of the art, circa 2010. http://t.co/8FK5USta",
  "id" : 279321937757478912,
  "created_at" : "Thu Dec 13 20:28:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Colbert Report",
      "screen_name" : "ColbertReport",
      "indices" : [ 16, 30 ],
      "id_str" : "158412741",
      "id" : 158412741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.76215054, -73.9685514636 ]
  },
  "id_str" : "279262442037592064",
  "text" : "Holy crap I got @ColbertReport tickets. Pinch me.",
  "id" : 279262442037592064,
  "created_at" : "Thu Dec 13 16:32:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinicius Vacanti",
      "screen_name" : "vacanti",
      "indices" : [ 41, 49 ],
      "id_str" : "14424445",
      "id" : 14424445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621281862, -73.968532454 ]
  },
  "id_str" : "279256279371874304",
  "text" : "You can almost hear everyone reloading. \u201C@vacanti: Feel like Google Maps on the iPhone is a temp ceasefire in the tech platform wars\u201D",
  "id" : 279256279371874304,
  "created_at" : "Thu Dec 13 16:07:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "indices" : [ 12, 20 ],
      "id_str" : "184543773",
      "id" : 184543773
    }, {
      "name" : "Joe Blitzstein Tho",
      "screen_name" : "Stat110Tho",
      "indices" : [ 33, 44 ],
      "id_str" : "983366707",
      "id" : 983366707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278972997572915201",
  "text" : "I wonder if @stat110 knows about @stat110tho.",
  "id" : 278972997572915201,
  "created_at" : "Wed Dec 12 21:22:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Jones",
      "screen_name" : "rjonesy",
      "indices" : [ 0, 8 ],
      "id_str" : "14710664",
      "id" : 14710664
    }, {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 9, 15 ],
      "id_str" : "15227849",
      "id" : 15227849
    }, {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 16, 26 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278893037634084866",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.716641536, -74.0127096792 ]
  },
  "id_str" : "278963015678844929",
  "in_reply_to_user_id" : 14710664,
  "text" : "@rjonesy @semil @besvinick curious to see how many of Facebooks messages from mobile go through Facebook app versus Messenger",
  "id" : 278963015678844929,
  "in_reply_to_status_id" : 278893037634084866,
  "created_at" : "Wed Dec 12 20:42:20 +0000 2012",
  "in_reply_to_screen_name" : "rjonesy",
  "in_reply_to_user_id_str" : "14710664",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 9, 21 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 26, 33 ],
      "id_str" : "224321197",
      "id" : 224321197
    }, {
      "name" : "Rough Draft Ventures",
      "screen_name" : "roughdraftvc",
      "indices" : [ 45, 58 ],
      "id_str" : "924613568",
      "id" : 924613568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/9MvwMhGz",
      "expanded_url" : "http://tcrn.ch/T8X28n",
      "display_url" : "tcrn.ch/T8X28n"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621420995, -73.9685477128 ]
  },
  "id_str" : "278916569453715456",
  "text" : "Congrats @badboyboyce and @zhamed on leading @roughdraftVC: http://t.co/9MvwMhGz",
  "id" : 278916569453715456,
  "created_at" : "Wed Dec 12 17:37:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    }, {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 7, 17 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278885892825964544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621347969, -73.9685287902 ]
  },
  "id_str" : "278886207096766465",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil @besvinick one goes to Facebook to do those things, but we don't think of \"going to google\" - we go to gmail, reader, cal, etc.",
  "id" : 278886207096766465,
  "in_reply_to_status_id" : 278885892825964544,
  "created_at" : "Wed Dec 12 15:37:07 +0000 2012",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/pnp3qaUH",
      "expanded_url" : "http://www.google.com/zeitgeist/2012/",
      "display_url" : "google.com/zeitgeist/2012/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278884813618941952",
  "text" : "The Google Year in Review for 2012 is out. I always tear up watching these. http://t.co/pnp3qaUH",
  "id" : 278884813618941952,
  "created_at" : "Wed Dec 12 15:31:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    }, {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 7, 17 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278884321157337088",
  "geo" : {
  },
  "id_str" : "278884650468921344",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil @Besvinick too many offers, which would be included in app?",
  "id" : 278884650468921344,
  "in_reply_to_status_id" : 278884321157337088,
  "created_at" : "Wed Dec 12 15:30:56 +0000 2012",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xinhua News Agency",
      "screen_name" : "XHNews",
      "indices" : [ 93, 100 ],
      "id_str" : "487118986",
      "id" : 487118986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104355872, -74.0063796991 ]
  },
  "id_str" : "278719933356068864",
  "text" : "So it turns out Xinhua, the Chinese news agency, has a completely un-ironic twitter account: @XHNews",
  "id" : 278719933356068864,
  "created_at" : "Wed Dec 12 04:36:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 3, 9 ],
      "id_str" : "17856596",
      "id" : 17856596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278673183631089665",
  "text" : "RT @Wayne: Now that CPU speed is topped out, I'm glad all industry innovation is happening to get us what truly matters: photo filters.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "278667589952102400",
    "text" : "Now that CPU speed is topped out, I'm glad all industry innovation is happening to get us what truly matters: photo filters.",
    "id" : 278667589952102400,
    "created_at" : "Wed Dec 12 01:08:25 +0000 2012",
    "user" : {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "protected" : false,
      "id_str" : "17856596",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3472053434/8cecfad95a11c1f1ede129b33c0b4fef_normal.jpeg",
      "id" : 17856596,
      "verified" : false
    }
  },
  "id" : 278673183631089665,
  "created_at" : "Wed Dec 12 01:30:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tap tap tap",
      "screen_name" : "taptaptap",
      "indices" : [ 9, 19 ],
      "id_str" : "15027362",
      "id" : 15027362
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 21, 31 ],
      "id_str" : "180505807",
      "id" : 180505807
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 37, 45 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/278640617440026624/photo/1",
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/JdVu3Wuj",
      "media_url" : "http://pbs.twimg.com/media/A93uKk7CIAI1kbQ.jpg",
      "id_str" : "278640617444220930",
      "id" : 278640617444220930,
      "media_url_https" : "https://pbs.twimg.com/media/A93uKk7CIAI1kbQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/JdVu3Wuj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7527239322, -73.9798442853 ]
  },
  "id_str" : "278640617440026624",
  "text" : "Stacking @taptaptap, @instagram, and @twitter filters on top of each other. http://t.co/JdVu3Wuj",
  "id" : 278640617440026624,
  "created_at" : "Tue Dec 11 23:21:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 21, 26 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/278526701699489794/photo/1",
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/6A0Pejk9",
      "media_url" : "http://pbs.twimg.com/media/A92GjzvCYAALFr7.jpg",
      "id_str" : "278526701707878400",
      "id" : 278526701707878400,
      "media_url_https" : "https://pbs.twimg.com/media/A92GjzvCYAALFr7.jpg",
      "sizes" : [ {
        "h" : 329,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 754,
        "resize" : "fit",
        "w" : 1374
      } ],
      "display_url" : "pic.twitter.com/6A0Pejk9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278526701699489794",
  "text" : "Good email design by @uber: content is still legible and beautiful even when images are being blocked. http://t.co/6A0Pejk9",
  "id" : 278526701699489794,
  "created_at" : "Tue Dec 11 15:48:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621440656, -73.9685491695 ]
  },
  "id_str" : "278283261946494976",
  "text" : "I can't wait to Twitter filter my Instagram filtered pic that Camera+ had filtered for me.",
  "id" : 278283261946494976,
  "created_at" : "Mon Dec 10 23:41:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinicius Vacanti",
      "screen_name" : "vacanti",
      "indices" : [ 3, 11 ],
      "id_str" : "14424445",
      "id" : 14424445
    }, {
      "name" : "Aviary",
      "screen_name" : "Aviary",
      "indices" : [ 24, 31 ],
      "id_str" : "78803",
      "id" : 78803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/G1KAhXTJ",
      "expanded_url" : "http://blog.twitter.com/2012/12/twitter-photos-put-filter-on-it.html",
      "display_url" : "blog.twitter.com/2012/12/twitte\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278282242478981120",
  "text" : "RT @vacanti: Wow. NYC's @aviary powering Twitter's new filters. Awesome! http://t.co/G1KAhXTJ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aviary",
        "screen_name" : "Aviary",
        "indices" : [ 11, 18 ],
        "id_str" : "78803",
        "id" : 78803
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http://t.co/G1KAhXTJ",
        "expanded_url" : "http://blog.twitter.com/2012/12/twitter-photos-put-filter-on-it.html",
        "display_url" : "blog.twitter.com/2012/12/twitte\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "278278028092665856",
    "text" : "Wow. NYC's @aviary powering Twitter's new filters. Awesome! http://t.co/G1KAhXTJ",
    "id" : 278278028092665856,
    "created_at" : "Mon Dec 10 23:20:26 +0000 2012",
    "user" : {
      "name" : "Vinicius Vacanti",
      "screen_name" : "vacanti",
      "protected" : false,
      "id_str" : "14424445",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1711083032/image_normal.jpg",
      "id" : 14424445,
      "verified" : false
    }
  },
  "id" : 278282242478981120,
  "created_at" : "Mon Dec 10 23:37:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Friends of Ai Weiwei",
      "screen_name" : "FriendsofAiWW",
      "indices" : [ 20, 34 ],
      "id_str" : "862974031",
      "id" : 862974031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/u0NQH5eQ",
      "expanded_url" : "http://www.friendsofaiweiwei.com/products/weiwei-isms",
      "display_url" : "friendsofaiweiwei.com/products/weiwe\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278207998537637888",
  "text" : "Placed my order for @FriendsofAiWW's new book. Makes a great stocking stuffer! http://t.co/u0NQH5eQ",
  "id" : 278207998537637888,
  "created_at" : "Mon Dec 10 18:42:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 10, 18 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/llMZNd2M",
      "expanded_url" : "http://www.wired.com/design/2012/12/harvard-3d-printing-archaelogy/",
      "display_url" : "wired.com/design/2012/12\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278205406214504449",
  "text" : "Love that @Harvard's Archaeology Dept. is using 3D printers to restore artifacts. http://t.co/llMZNd2M",
  "id" : 278205406214504449,
  "created_at" : "Mon Dec 10 18:31:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perry Hewitt",
      "screen_name" : "perryhewitt",
      "indices" : [ 0, 12 ],
      "id_str" : "1363481",
      "id" : 1363481
    }, {
      "name" : "Sailthru",
      "screen_name" : "sailthru",
      "indices" : [ 49, 58 ],
      "id_str" : "14328850",
      "id" : 14328850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277974909366460416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104585684, -74.0063643696 ]
  },
  "id_str" : "278023392177831936",
  "in_reply_to_user_id" : 1363481,
  "text" : "@perryhewitt whoever you choose, I hope they use @Sailthru!",
  "id" : 278023392177831936,
  "in_reply_to_status_id" : 277974909366460416,
  "created_at" : "Mon Dec 10 06:28:36 +0000 2012",
  "in_reply_to_screen_name" : "perryhewitt",
  "in_reply_to_user_id_str" : "1363481",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linux Mint",
      "screen_name" : "Linux_Mint",
      "indices" : [ 31, 42 ],
      "id_str" : "20664366",
      "id" : 20664366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104988049, -74.0064506717 ]
  },
  "id_str" : "277674221696589824",
  "text" : "After half a decade of Ubuntu, @Linux_Mint is a refreshing change. Really a beautiful OS.",
  "id" : 277674221696589824,
  "created_at" : "Sun Dec 09 07:21:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 3, 9 ],
      "id_str" : "17856596",
      "id" : 17856596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277511926626537473",
  "text" : "RT @Wayne: The new phrase for \"that's a Kodak moment\" is \"wait let me Instagram that.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "277503487535894528",
    "text" : "The new phrase for \"that's a Kodak moment\" is \"wait let me Instagram that.\"",
    "id" : 277503487535894528,
    "created_at" : "Sat Dec 08 20:02:41 +0000 2012",
    "user" : {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "protected" : false,
      "id_str" : "17856596",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3472053434/8cecfad95a11c1f1ede129b33c0b4fef_normal.jpeg",
      "id" : 17856596,
      "verified" : false
    }
  },
  "id" : 277511926626537473,
  "created_at" : "Sat Dec 08 20:36:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277264701946228736",
  "text" : "Conclusion from late night convos with old friends: happiness causes success, not vice versa.",
  "id" : 277264701946228736,
  "created_at" : "Sat Dec 08 04:13:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 45, 52 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6154514403, -122.384596523 ]
  },
  "id_str" : "277196616589508610",
  "text" : "I just let my Palo Alto cab driver borrow my @square reader so I could pay him with card. Boom.",
  "id" : 277196616589508610,
  "created_at" : "Fri Dec 07 23:43:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roland Meneghetti",
      "screen_name" : "Roghetti",
      "indices" : [ 3, 12 ],
      "id_str" : "25564640",
      "id" : 25564640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276848234670997504",
  "text" : "RT @Roghetti: 8 Hobbit = 1 Hobbyte?",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276463576372350976",
    "text" : "8 Hobbit = 1 Hobbyte?",
    "id" : 276463576372350976,
    "created_at" : "Wed Dec 05 23:10:27 +0000 2012",
    "user" : {
      "name" : "Roland Meneghetti",
      "screen_name" : "Roghetti",
      "protected" : false,
      "id_str" : "25564640",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533868118/e3ca4cb35fdd3117601e65e7cc2a161b_normal.jpeg",
      "id" : 25564640,
      "verified" : false
    }
  },
  "id" : 276848234670997504,
  "created_at" : "Fri Dec 07 00:38:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 3, 7 ],
      "id_str" : "19494411",
      "id" : 19494411
    }, {
      "name" : "Lemnos Labs Inc",
      "screen_name" : "lemnoslabs",
      "indices" : [ 39, 50 ],
      "id_str" : "266116717",
      "id" : 266116717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hardware20",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276828068587393025",
  "text" : "RT @RRE: Lessons from Kiva Systems and @lemnoslabs: patents aren't worth the paper they're printed on if you don't execute. #Hardware20",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lemnos Labs Inc",
        "screen_name" : "lemnoslabs",
        "indices" : [ 30, 41 ],
        "id_str" : "266116717",
        "id" : 266116717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hardware20",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276826322028863489",
    "text" : "Lessons from Kiva Systems and @lemnoslabs: patents aren't worth the paper they're printed on if you don't execute. #Hardware20",
    "id" : 276826322028863489,
    "created_at" : "Thu Dec 06 23:11:53 +0000 2012",
    "user" : {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "protected" : false,
      "id_str" : "19494411",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2781036073/47c8a2806a89312e9882b4aa968aead4_normal.png",
      "id" : 19494411,
      "verified" : false
    }
  },
  "id" : 276828068587393025,
  "created_at" : "Thu Dec 06 23:18:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lemnos Labs Inc",
      "screen_name" : "lemnoslabs",
      "indices" : [ 67, 78 ],
      "id_str" : "266116717",
      "id" : 266116717
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/276805218405064704/photo/1",
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/JSQLNqaz",
      "media_url" : "http://pbs.twimg.com/media/A9do4StCIAItcHc.jpg",
      "id_str" : "276805218409259010",
      "id" : 276805218409259010,
      "media_url_https" : "https://pbs.twimg.com/media/A9do4StCIAItcHc.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com/JSQLNqaz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.775965, -122.397917 ]
  },
  "id_str" : "276805218405064704",
  "text" : "Momentum Machines' burger robot is exactly what it sounds like. cc @lemnoslabs http://t.co/JSQLNqaz",
  "id" : 276805218405064704,
  "created_at" : "Thu Dec 06 21:48:01 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lemnos Labs Inc",
      "screen_name" : "lemnoslabs",
      "indices" : [ 15, 26 ],
      "id_str" : "266116717",
      "id" : 266116717
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/276805134539968512/photo/1",
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/JGft8mHN",
      "media_url" : "http://pbs.twimg.com/media/A9dozaTCUAATvNI.jpg",
      "id_str" : "276805134548357120",
      "id" : 276805134548357120,
      "media_url_https" : "https://pbs.twimg.com/media/A9dozaTCUAATvNI.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com/JGft8mHN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77618, -122.397525 ]
  },
  "id_str" : "276805134539968512",
  "text" : "Previewing the @lemnoslabs companies. Unmanned Innovations makes extensible autopilots. http://t.co/JGft8mHN",
  "id" : 276805134539968512,
  "created_at" : "Thu Dec 06 21:47:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timbuk2",
      "screen_name" : "timbuk2",
      "indices" : [ 0, 8 ],
      "id_str" : "14995801",
      "id" : 14995801
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/276784971421720577/photo/1",
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/ZvXjxlUY",
      "media_url" : "http://pbs.twimg.com/media/A9dWdw1CIAAADn6.jpg",
      "id_str" : "276784971430109184",
      "id" : 276784971430109184,
      "media_url_https" : "https://pbs.twimg.com/media/A9dWdw1CIAAADn6.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/ZvXjxlUY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7882829217, -122.4160690154 ]
  },
  "id_str" : "276784971421720577",
  "in_reply_to_user_id" : 14995801,
  "text" : "@timbuk2 I was hoping to grow old w my timbuk2, alas my faithful bag is falling apart after 2 years! http://t.co/ZvXjxlUY",
  "id" : 276784971421720577,
  "created_at" : "Thu Dec 06 20:27:34 +0000 2012",
  "in_reply_to_screen_name" : "timbuk2",
  "in_reply_to_user_id_str" : "14995801",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276783115777765378",
  "text" : "Publishing an article in a slideshow format should be the eighth cardinal sin.",
  "id" : 276783115777765378,
  "created_at" : "Thu Dec 06 20:20:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276760752818356224",
  "text" : "Love the idea of online ed, but Coursera and edX are flawed; can't just digitize stuff and call it innovative. Need to leverage the medium.",
  "id" : 276760752818356224,
  "created_at" : "Thu Dec 06 18:51:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gogo",
      "screen_name" : "GogoInflight",
      "indices" : [ 22, 35 ],
      "id_str" : "144885144",
      "id" : 144885144
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/276538837046542336/photo/1",
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/WIf0XN2T",
      "media_url" : "http://pbs.twimg.com/media/A9Z2m20CQAAlod7.png",
      "id_str" : "276538837050736640",
      "id" : 276538837050736640,
      "media_url_https" : "https://pbs.twimg.com/media/A9Z2m20CQAAlod7.png",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/WIf0XN2T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276538837046542336",
  "text" : "Oops, I think I broke @GogoInflight. http://t.co/WIf0XN2T",
  "id" : 276538837046542336,
  "created_at" : "Thu Dec 06 04:09:31 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Series A Crunch",
      "screen_name" : "SeriesACrunch",
      "indices" : [ 3, 17 ],
      "id_str" : "983070782",
      "id" : 983070782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276517999555530752",
  "text" : "RT @SeriesACrunch: Employee: Hey can I get a copy of Photoshop? Me: Yes just use our corporate account on The Pirate Bay.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "274944088355258368",
    "text" : "Employee: Hey can I get a copy of Photoshop? Me: Yes just use our corporate account on The Pirate Bay.",
    "id" : 274944088355258368,
    "created_at" : "Sat Dec 01 18:32:33 +0000 2012",
    "user" : {
      "name" : "Series A Crunch",
      "screen_name" : "SeriesACrunch",
      "protected" : false,
      "id_str" : "983070782",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2919748222/193af07952fca7f5247da6cc1fe84a6d_normal.jpeg",
      "id" : 983070782,
      "verified" : false
    }
  },
  "id" : 276517999555530752,
  "created_at" : "Thu Dec 06 02:46:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/hdVWgyeY",
      "expanded_url" : "http://t.imehop.com/SyLRWA",
      "display_url" : "t.imehop.com/SyLRWA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276467331352371201",
  "text" : "I miss computational theory in a masochistic way. http://t.co/hdVWgyeY",
  "id" : 276467331352371201,
  "created_at" : "Wed Dec 05 23:25:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 0, 7 ],
      "id_str" : "9544202",
      "id" : 9544202
    }, {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 18, 29 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276421891487592449",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.6850816482, -73.9741983839 ]
  },
  "id_str" : "276425754034700289",
  "in_reply_to_user_id" : 9544202,
  "text" : "@schlaf disregard @tomloverro, he is rabidly anti-anything-not-Apple.",
  "id" : 276425754034700289,
  "in_reply_to_status_id" : 276421891487592449,
  "created_at" : "Wed Dec 05 20:40:10 +0000 2012",
  "in_reply_to_screen_name" : "schlaf",
  "in_reply_to_user_id_str" : "9544202",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 0, 7 ],
      "id_str" : "9544202",
      "id" : 9544202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276421891487592449",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.68514874, -73.9742122782 ]
  },
  "id_str" : "276425265196982273",
  "in_reply_to_user_id" : 9544202,
  "text" : "@schlaf a Nexus phone will get you bleeding edge UXUI features faster. If you prefer to wait for kinks to be hammered out, go iOS.",
  "id" : 276425265196982273,
  "in_reply_to_status_id" : 276421891487592449,
  "created_at" : "Wed Dec 05 20:38:13 +0000 2012",
  "in_reply_to_screen_name" : "schlaf",
  "in_reply_to_user_id_str" : "9544202",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104033938, -74.0063558191 ]
  },
  "id_str" : "276188803394306048",
  "text" : "It seems that Weibo has made my account inaccessible to everyone but me. Damn you CCP!",
  "id" : 276188803394306048,
  "created_at" : "Wed Dec 05 04:58:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 3, 15 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 41, 48 ],
      "id_str" : "224321197",
      "id" : 224321197
    }, {
      "name" : "Y Combinator",
      "screen_name" : "ycombinator",
      "indices" : [ 98, 110 ],
      "id_str" : "113130846",
      "id" : 113130846
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackHarvard",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276177766196600833",
  "text" : "RT @badboyboyce: #HackHarvard intro from @zhamed &amp; congrats to our @pollvaultr team going  to @ycombinator! (@ Maxwell Dworkin) [pic ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zach Hamed",
        "screen_name" : "zhamed",
        "indices" : [ 24, 31 ],
        "id_str" : "224321197",
        "id" : 224321197
      }, {
        "name" : "Y Combinator",
        "screen_name" : "ycombinator",
        "indices" : [ 81, 93 ],
        "id_str" : "113130846",
        "id" : 113130846
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HackHarvard",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http://t.co/kBUv3Jho",
        "expanded_url" : "http://4sq.com/VzR94v",
        "display_url" : "4sq.com/VzR94v"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.3786190682, -71.1171073214 ]
    },
    "id_str" : "276164909916631041",
    "text" : "#HackHarvard intro from @zhamed &amp; congrats to our @pollvaultr team going  to @ycombinator! (@ Maxwell Dworkin) [pic]: http://t.co/kBUv3Jho",
    "id" : 276164909916631041,
    "created_at" : "Wed Dec 05 03:23:40 +0000 2012",
    "user" : {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "protected" : false,
      "id_str" : "110823121",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1736585624/HaLongBay_Profile_Thumbnail_normal.jpg",
      "id" : 110823121,
      "verified" : false
    }
  },
  "id" : 276177766196600833,
  "created_at" : "Wed Dec 05 04:14:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/F8ltdXHW",
      "expanded_url" : "http://instagr.am/p/S1oHtKPA0R/",
      "display_url" : "instagr.am/p/S1oHtKPA0R/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276149529131229184",
  "text" : "Last nytm event of 2012. http://t.co/F8ltdXHW",
  "id" : 276149529131229184,
  "created_at" : "Wed Dec 05 02:22:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Business",
      "screen_name" : "nytimesbusiness",
      "indices" : [ 40, 56 ],
      "id_str" : "1754641",
      "id" : 1754641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/eaKcYfUT",
      "expanded_url" : "http://nyti.ms/QFQbET",
      "display_url" : "nyti.ms/QFQbET"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7298628661, -73.9975793461 ]
  },
  "id_str" : "276129056418824193",
  "text" : "Wow, the 787 just can't catch a break. \u201C@nytimesbusiness: United 787 Loses Power and Lands Early http://t.co/eaKcYfUT\u201D",
  "id" : 276129056418824193,
  "created_at" : "Wed Dec 05 01:01:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Gregory",
      "screen_name" : "Tmac721",
      "indices" : [ 0, 8 ],
      "id_str" : "1262251880",
      "id" : 1262251880
    }, {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 9, 23 ],
      "id_str" : "15593773",
      "id" : 15593773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276096373391233024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7298878209, -73.9975351186 ]
  },
  "id_str" : "276123649377984512",
  "in_reply_to_user_id" : 15186728,
  "text" : "@tmac721 @lexiberylross loving the typography in the new Gmail app, for sure.",
  "id" : 276123649377984512,
  "in_reply_to_status_id" : 276096373391233024,
  "created_at" : "Wed Dec 05 00:39:42 +0000 2012",
  "in_reply_to_screen_name" : "tmacwill",
  "in_reply_to_user_id_str" : "15186728",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621313627, -73.9685223971 ]
  },
  "id_str" : "276113256404377600",
  "text" : "Finally got Weibo accnt registered after last months lockdown for the 18th Congress. Over-under on how long it takes me to get banned?",
  "id" : 276113256404377600,
  "created_at" : "Tue Dec 04 23:58:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Gregory",
      "screen_name" : "Tmac721",
      "indices" : [ 0, 8 ],
      "id_str" : "1262251880",
      "id" : 1262251880
    }, {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 9, 23 ],
      "id_str" : "15593773",
      "id" : 15593773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276067377689534464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621891611, -73.968609875 ]
  },
  "id_str" : "276073659582541824",
  "in_reply_to_user_id" : 15186728,
  "text" : "@tmac721 @lexiberylross better than sparrow?",
  "id" : 276073659582541824,
  "in_reply_to_status_id" : 276067377689534464,
  "created_at" : "Tue Dec 04 21:21:04 +0000 2012",
  "in_reply_to_screen_name" : "tmacwill",
  "in_reply_to_user_id_str" : "15186728",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621240161, -73.9685241739 ]
  },
  "id_str" : "276048608925728768",
  "text" : "OH: \"Windows 8 is growing on me. Like a fungus.\"",
  "id" : 276048608925728768,
  "created_at" : "Tue Dec 04 19:41:31 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/ZQpSzAxG",
      "expanded_url" : "http://consumerist.com/2012/12/03/lego-finds-spare-discontinued-set-so-boy-who-saved-up-for-2-years-wouldnt-be-disappointed/",
      "display_url" : "consumerist.com/2012/12/03/leg\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276001254231126017",
  "text" : "If it wasn't obvious already, LEGO is one of the awesomest products and companies ever. http://t.co/ZQpSzAxG",
  "id" : 276001254231126017,
  "created_at" : "Tue Dec 04 16:33:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 21, 26 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/AZgOgdvf",
      "expanded_url" : "http://instagr.am/p/Sy0NlyPA_U/",
      "display_url" : "instagr.am/p/Sy0NlyPA_U/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275753986416574464",
  "text" : "Leather press at the @etsy pop up shop. http://t.co/AZgOgdvf",
  "id" : 275753986416574464,
  "created_at" : "Tue Dec 04 00:10:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7694599135, -73.9929968837 ]
  },
  "id_str" : "275632842418036737",
  "text" : "Apple's 6 laptops generate more profit than Dell and HPs combined 89.",
  "id" : 275632842418036737,
  "created_at" : "Mon Dec 03 16:09:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Segall",
      "screen_name" : "ksegall",
      "indices" : [ 92, 100 ],
      "id_str" : "19170871",
      "id" : 19170871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEDxSiliconAlley",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7695503878, -73.9929252839 ]
  },
  "id_str" : "275631747876679681",
  "text" : "Dell has 42 laptops. HP has 49. Apple has 6, if you count the retina as independent models. @ksegall #TEDxSiliconAlley",
  "id" : 275631747876679681,
  "created_at" : "Mon Dec 03 16:05:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Segall",
      "screen_name" : "ksegall",
      "indices" : [ 9, 17 ],
      "id_str" : "19170871",
      "id" : 19170871
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/275629159483588611/photo/1",
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/icdofJA5",
      "media_url" : "http://pbs.twimg.com/media/A9M7Qp0CQAAeWci.jpg",
      "id_str" : "275629159487782912",
      "id" : 275629159487782912,
      "media_url_https" : "https://pbs.twimg.com/media/A9M7Qp0CQAAeWci.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/icdofJA5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7695384953, -73.9929297466 ]
  },
  "id_str" : "275629159483588611",
  "text" : "TEDx and @ksegall, namer of iMac: \"Steve wanted to call it MacMan...\" http://t.co/icdofJA5",
  "id" : 275629159483588611,
  "created_at" : "Mon Dec 03 15:54:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]