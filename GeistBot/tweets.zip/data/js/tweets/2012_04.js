Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 0, 5 ],
      "id_str" : "132319630",
      "id" : 132319630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197123191460728832",
  "geo" : {
  },
  "id_str" : "197124881740087297",
  "in_reply_to_user_id" : 132319630,
  "text" : "@sidd I might be missing a few filters - I *think* there are a few iPhone-exclusive ones.",
  "id" : 197124881740087297,
  "in_reply_to_status_id" : 197123191460728832,
  "created_at" : "Tue May 01 00:46:48 +0000 2012",
  "in_reply_to_screen_name" : "sidd",
  "in_reply_to_user_id_str" : "132319630",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 10, 20 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/jZpxJWrv",
      "expanded_url" : "http://blog.kanehsieh.com/2012/04/30/instagranalysis/",
      "display_url" : "blog.kanehsieh.com/2012/04/30/ins\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "197120240507822082",
  "text" : "What does @instagram actually do? http://t.co/jZpxJWrv",
  "id" : 197120240507822082,
  "created_at" : "Tue May 01 00:28:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 47, 55 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197081969404809216",
  "text" : "I think 400 may be the upper bound of updating @twitter accounts that one can reasonably keep up with.",
  "id" : 197081969404809216,
  "created_at" : "Mon Apr 30 21:56:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ROFLCon",
      "screen_name" : "roflcon",
      "indices" : [ 21, 29 ],
      "id_str" : "14427911",
      "id" : 14427911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerd",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197059227854966784",
  "text" : "Just volunteered for @ROFLcon at MIT this weekend. Should be a good time. #nerd",
  "id" : 197059227854966784,
  "created_at" : "Mon Apr 30 20:25:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 23, 35 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "CrunchBase",
      "screen_name" : "crunchbase",
      "indices" : [ 65, 76 ],
      "id_str" : "14279577",
      "id" : 14279577
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 90, 98 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "196849332094373889",
  "text" : "who's your adviser? RT @badboyboyce: Tonight, it's just me &amp; @crunchbase\u2026 Starting my @Harvard thesis on VC &amp; startup network phenomena.",
  "id" : 196849332094373889,
  "created_at" : "Mon Apr 30 06:31:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 1, 17 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196807470612619264",
  "geo" : {
  },
  "id_str" : "196836582764974080",
  "in_reply_to_user_id" : 228489296,
  "text" : ".@GlobalAsianista Mr. Bo has been mysteriously absent from the Harvard scene in light of recent events.",
  "id" : 196836582764974080,
  "in_reply_to_status_id" : 196807470612619264,
  "created_at" : "Mon Apr 30 05:41:13 +0000 2012",
  "in_reply_to_screen_name" : "GlobalAsianista",
  "in_reply_to_user_id_str" : "228489296",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Pinkston",
      "screen_name" : "NickPinkston",
      "indices" : [ 3, 16 ],
      "id_str" : "17973378",
      "id" : 17973378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "196416085120131072",
  "text" : "RT @NickPinkston: Glad to see another article bemoaning the lack of true innovation in the majority of internet startups: http://t.co/Sk ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http://t.co/Skruuzl4",
        "expanded_url" : "http://www.wired.com/opinion/2012/04/opinion-fox-net-innovation",
        "display_url" : "wired.com/opinion/2012/0\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "196401521708122112",
    "text" : "Glad to see another article bemoaning the lack of true innovation in the majority of internet startups: http://t.co/Skruuzl4",
    "id" : 196401521708122112,
    "created_at" : "Sun Apr 29 00:52:26 +0000 2012",
    "user" : {
      "name" : "Nick Pinkston",
      "screen_name" : "NickPinkston",
      "protected" : false,
      "id_str" : "17973378",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2159529252/NickPicSmile_normal.jpg",
      "id" : 17973378,
      "verified" : false
    }
  },
  "id" : 196416085120131072,
  "created_at" : "Sun Apr 29 01:50:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3613364808, -71.1304318439 ]
  },
  "id_str" : "196364254188806144",
  "text" : "BMW ActiveE 1-series spotted driving in Cambridge! Anyone know what it was doing?",
  "id" : 196364254188806144,
  "created_at" : "Sat Apr 28 22:24:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 0, 10 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195730748785958912",
  "geo" : {
  },
  "id_str" : "195731047479119873",
  "in_reply_to_user_id" : 14326765,
  "text" : "@johnhcook under manage labels you can have gmail always display those folders.",
  "id" : 195731047479119873,
  "in_reply_to_status_id" : 195730748785958912,
  "created_at" : "Fri Apr 27 04:28:12 +0000 2012",
  "in_reply_to_screen_name" : "johnhcook",
  "in_reply_to_user_id_str" : "14326765",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195730792368979969",
  "text" : "Samsung overtakes Nokia to be world's largest mobile manufacturer.",
  "id" : 195730792368979969,
  "created_at" : "Fri Apr 27 04:27:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Gregory",
      "screen_name" : "Tmac721",
      "indices" : [ 3, 11 ],
      "id_str" : "1262251880",
      "id" : 1262251880
    }, {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 13, 27 ],
      "id_str" : "15593773",
      "id" : 15593773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195727583122427904",
  "text" : "RT @tmac721: @lexiberylross first reaction: reddit's backend is written in .NET? and then, I was amazed.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lexi Ross",
        "screen_name" : "lexiberylross",
        "indices" : [ 0, 14 ],
        "id_str" : "15593773",
        "id" : 15593773
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "195667754513219584",
    "geo" : {
    },
    "id_str" : "195678406355070977",
    "in_reply_to_user_id" : 15593773,
    "text" : "@lexiberylross first reaction: reddit's backend is written in .NET? and then, I was amazed.",
    "id" : 195678406355070977,
    "in_reply_to_status_id" : 195667754513219584,
    "created_at" : "Fri Apr 27 00:59:02 +0000 2012",
    "in_reply_to_screen_name" : "lexiberylross",
    "in_reply_to_user_id_str" : "15593773",
    "user" : {
      "name" : "Tommy MacWilliam",
      "screen_name" : "tmacwill",
      "protected" : false,
      "id_str" : "15186728",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1824170075/44703_462871062888_545482888_6383039_115727_n_normal.jpg",
      "id" : 15186728,
      "verified" : false
    }
  },
  "id" : 195727583122427904,
  "created_at" : "Fri Apr 27 04:14:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life should bcalm\u2122",
      "screen_name" : "bcalm",
      "indices" : [ 14, 20 ],
      "id_str" : "449232786",
      "id" : 449232786
    }, {
      "name" : "Fab",
      "screen_name" : "Fab",
      "indices" : [ 91, 95 ],
      "id_str" : "188844665",
      "id" : 188844665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/wh2t4oZw",
      "expanded_url" : "http://fab.com/sale/5436/",
      "display_url" : "fab.com/sale/5436/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "195727319124541441",
  "text" : "Awesome news! @bcalm: we are happy to announce that on Friday at 7pm we launch a sale with @fab http://t.co/wh2t4oZw",
  "id" : 195727319124541441,
  "created_at" : "Fri Apr 27 04:13:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Text-Only Instagram",
      "screen_name" : "textinstagram",
      "indices" : [ 10, 24 ],
      "id_str" : "604322629",
      "id" : 604322629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195596267299151873",
  "text" : "Holy crap @textinstagram really exploded overnight.",
  "id" : 195596267299151873,
  "created_at" : "Thu Apr 26 19:32:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 3, 13 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195070793573609472",
  "text" : "RT @jenny8lee: Oddly. American Express thinks my posting an ad on Github is fraud. Rejected and emailed me.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "195035285397061632",
    "text" : "Oddly. American Express thinks my posting an ad on Github is fraud. Rejected and emailed me.",
    "id" : 195035285397061632,
    "created_at" : "Wed Apr 25 06:23:30 +0000 2012",
    "user" : {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "protected" : false,
      "id_str" : "1976841",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1842465869/jenny_baby_graduation_cap_cropped_normal.jpg",
      "id" : 1976841,
      "verified" : true
    }
  },
  "id" : 195070793573609472,
  "created_at" : "Wed Apr 25 08:44:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 3, 10 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/0mbjElGi",
      "expanded_url" : "http://Wired.com",
      "display_url" : "Wired.com"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/w8kdP0Yy",
      "expanded_url" : "http://www.wired.com/design/2012/04/10-things-3d-printers-can-do-now/",
      "display_url" : "wired.com/design/2012/04\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "195012068842274817",
  "text" : "RT @jdrive: Look Ma, I Made It Myself! 10 Amazing Things 3-D Printers Can Do Now | http://t.co/0mbjElGi http://t.co/w8kdP0Yy",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/0mbjElGi",
        "expanded_url" : "http://Wired.com",
        "display_url" : "Wired.com"
      }, {
        "indices" : [ 92, 112 ],
        "url" : "http://t.co/w8kdP0Yy",
        "expanded_url" : "http://www.wired.com/design/2012/04/10-things-3d-printers-can-do-now/",
        "display_url" : "wired.com/design/2012/04\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "195000897150005250",
    "text" : "Look Ma, I Made It Myself! 10 Amazing Things 3-D Printers Can Do Now | http://t.co/0mbjElGi http://t.co/w8kdP0Yy",
    "id" : 195000897150005250,
    "created_at" : "Wed Apr 25 04:06:51 +0000 2012",
    "user" : {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "protected" : false,
      "id_str" : "15137329",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3458237744/7f6dc83d6d93ff6347730211a9e34430_normal.jpeg",
      "id" : 15137329,
      "verified" : false
    }
  },
  "id" : 195012068842274817,
  "created_at" : "Wed Apr 25 04:51:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/PDks3Wkq",
      "expanded_url" : "http://instagr.am/p/J0-rChPAxL/",
      "display_url" : "instagr.am/p/J0-rChPAxL/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "194993719739555840",
  "text" : "Uses for robots #64: impressing VCs in bars. http://t.co/PDks3Wkq",
  "id" : 194993719739555840,
  "created_at" : "Wed Apr 25 03:38:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 1, 10 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/194933930829426688/photo/1",
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/KmBlpOm4",
      "media_url" : "http://pbs.twimg.com/media/ArSLYJYCMAAi-E3.jpg",
      "id_str" : "194933930833620992",
      "id" : 194933930833620992,
      "media_url_https" : "https://pbs.twimg.com/media/ArSLYJYCMAAi-E3.jpg",
      "sizes" : [ {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/KmBlpOm4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7577064, -73.8459886 ]
  },
  "id_str" : "194933930829426688",
  "text" : ".@Romotive invading Citi Stadium for the Mets game. http://t.co/KmBlpOm4",
  "id" : 194933930829426688,
  "created_at" : "Tue Apr 24 23:40:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hippeau",
      "screen_name" : "erichippeau",
      "indices" : [ 3, 15 ],
      "id_str" : "29795220",
      "id" : 29795220
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 40, 49 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/4r5hNvPs",
      "expanded_url" : "http://romotive.com/",
      "display_url" : "romotive.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "194911624530894849",
  "text" : "RT @erichippeau: Robots are the new PC \"@Romotive: Getting a lot of kudos from #lerersummit. Check out http://t.co/4r5hNvPs to get your  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Romotive",
        "screen_name" : "Romotive",
        "indices" : [ 23, 32 ],
        "id_str" : "340545195",
        "id" : 340545195
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lerersummit",
        "indices" : [ 62, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http://t.co/4r5hNvPs",
        "expanded_url" : "http://romotive.com/",
        "display_url" : "romotive.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "194909297279373312",
    "text" : "Robots are the new PC \"@Romotive: Getting a lot of kudos from #lerersummit. Check out http://t.co/4r5hNvPs to get your own :)\"",
    "id" : 194909297279373312,
    "created_at" : "Tue Apr 24 22:02:52 +0000 2012",
    "user" : {
      "name" : "Eric Hippeau",
      "screen_name" : "erichippeau",
      "protected" : false,
      "id_str" : "29795220",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3282921430/02ffc094bd7d42c5b9b9afc5357da710_normal.jpeg",
      "id" : 29795220,
      "verified" : true
    }
  },
  "id" : 194911624530894849,
  "created_at" : "Tue Apr 24 22:12:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7527342, -73.8498336 ]
  },
  "id_str" : "194909774217883648",
  "text" : "All I want is a blackberry with a really good camera and stable OS. Photo, email, twitter, and Facebook are all I really do on smartphone.",
  "id" : 194909774217883648,
  "created_at" : "Tue Apr 24 22:04:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kai macmahon",
      "screen_name" : "kaimac",
      "indices" : [ 3, 10 ],
      "id_str" : "43693",
      "id" : 43693
    }, {
      "name" : "Megan Berry",
      "screen_name" : "meganberry",
      "indices" : [ 43, 54 ],
      "id_str" : "15814841",
      "id" : 15814841
    }, {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 97, 111 ],
      "id_str" : "128968036",
      "id" : 128968036
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194907100906930176",
  "text" : "RT @kaimac: You had me at robots. Sold. RT @meganberry: Awesome preso about smartphone robots by @KellerRinaudo. I want one! #lerersummit",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Megan Berry",
        "screen_name" : "meganberry",
        "indices" : [ 31, 42 ],
        "id_str" : "15814841",
        "id" : 15814841
      }, {
        "name" : "Keller Rinaudo",
        "screen_name" : "KellerRinaudo",
        "indices" : [ 85, 99 ],
        "id_str" : "128968036",
        "id" : 128968036
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lerersummit",
        "indices" : [ 113, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "194899528120406017",
    "text" : "You had me at robots. Sold. RT @meganberry: Awesome preso about smartphone robots by @KellerRinaudo. I want one! #lerersummit",
    "id" : 194899528120406017,
    "created_at" : "Tue Apr 24 21:24:03 +0000 2012",
    "user" : {
      "name" : "kai macmahon",
      "screen_name" : "kaimac",
      "protected" : false,
      "id_str" : "43693",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3562491146/7677f29b73d917852ad6fca1f79ae1a3_normal.jpeg",
      "id" : 43693,
      "verified" : false
    }
  },
  "id" : 194907100906930176,
  "created_at" : "Tue Apr 24 21:54:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 1, 15 ],
      "id_str" : "128968036",
      "id" : 128968036
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 72, 81 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/194897345245220865/photo/1",
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/zgSwhU4P",
      "media_url" : "http://pbs.twimg.com/media/ArRqGldCEAExzrd.jpg",
      "id_str" : "194897345249415169",
      "id" : 194897345249415169,
      "media_url_https" : "https://pbs.twimg.com/media/ArRqGldCEAExzrd.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/zgSwhU4P"
    } ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194897345245220865",
  "text" : ".@KellerRinaudo ending #lerersummit presentations with a robotic twist: @Romotive http://t.co/zgSwhU4P",
  "id" : 194897345245220865,
  "created_at" : "Tue Apr 24 21:15:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 34, 39 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194885907336278016",
  "text" : "RT @elonmusk: Just confirmed with @NASA that May 7th is go for launch of Falcon 9 &amp; Dragon to the Space Station",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 20, 25 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "194882663599968256",
    "text" : "Just confirmed with @NASA that May 7th is go for launch of Falcon 9 &amp; Dragon to the Space Station",
    "id" : 194882663599968256,
    "created_at" : "Tue Apr 24 20:17:02 +0000 2012",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3467595996/f82c4a3235eb180360d9ff670e092e02_normal.jpeg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 194885907336278016,
  "created_at" : "Tue Apr 24 20:29:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moot",
      "screen_name" : "moot",
      "indices" : [ 57, 62 ],
      "id_str" : "36994785",
      "id" : 36994785
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/194867195086516225/photo/1",
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/WyLku2TF",
      "media_url" : "http://pbs.twimg.com/media/ArROrnXCMAEahpb.jpg",
      "id_str" : "194867195090710529",
      "id" : 194867195090710529,
      "media_url_https" : "https://pbs.twimg.com/media/ArROrnXCMAEahpb.jpg",
      "sizes" : [ {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/WyLku2TF"
    } ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194867195086516225",
  "text" : "\"How do you place 4chan in society?\" funny questions for @moot at #lerersummit http://t.co/WyLku2TF",
  "id" : 194867195086516225,
  "created_at" : "Tue Apr 24 19:15:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenden Mulligan",
      "screen_name" : "mulligan",
      "indices" : [ 1, 10 ],
      "id_str" : "14323985",
      "id" : 14323985
    }, {
      "name" : "David Lee",
      "screen_name" : "davidlee",
      "indices" : [ 11, 20 ],
      "id_str" : "5965332",
      "id" : 5965332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194836072755249152",
  "geo" : {
  },
  "id_str" : "194866579144581120",
  "in_reply_to_user_id" : 14323985,
  "text" : ".@mulligan @davidlee CyberDuck lets you access your Google Docs like a file system.",
  "id" : 194866579144581120,
  "in_reply_to_status_id" : 194836072755249152,
  "created_at" : "Tue Apr 24 19:13:07 +0000 2012",
  "in_reply_to_screen_name" : "mulligan",
  "in_reply_to_user_id_str" : "14323985",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 1, 15 ],
      "id_str" : "128968036",
      "id" : 128968036
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 25, 34 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/194862892611416064/photo/1",
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/iKYgt14e",
      "media_url" : "http://pbs.twimg.com/media/ArRKxLZCMAIqWPM.jpg",
      "id_str" : "194862892615610370",
      "id" : 194862892615610370,
      "media_url_https" : "https://pbs.twimg.com/media/ArRKxLZCMAIqWPM.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/iKYgt14e"
    } ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 55, 67 ]
    }, {
      "text" : "Profectionist",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194862892611416064",
  "text" : ".@KellerRinaudo tweaking @Romotive deck last minute at #lerersummit. Procrastination + Perfectionist = #Profectionist. http://t.co/iKYgt14e",
  "id" : 194862892611416064,
  "created_at" : "Tue Apr 24 18:58:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Franzosa",
      "screen_name" : "zosa",
      "indices" : [ 3, 8 ],
      "id_str" : "6601052",
      "id" : 6601052
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MediaLabIO",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194861371043753984",
  "text" : "RT @zosa: Everything boils down to design. #MediaLabIO",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MediaLabIO",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "194859705456263168",
    "text" : "Everything boils down to design. #MediaLabIO",
    "id" : 194859705456263168,
    "created_at" : "Tue Apr 24 18:45:48 +0000 2012",
    "user" : {
      "name" : "Paul Franzosa",
      "screen_name" : "zosa",
      "protected" : false,
      "id_str" : "6601052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/57668949/DSCN3085_normal.JPG",
      "id" : 6601052,
      "verified" : false
    }
  },
  "id" : 194861371043753984,
  "created_at" : "Tue Apr 24 18:52:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 59, 73 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194859333891276801",
  "text" : "Tough questions about decaying American infrastructure for @MikeBloomberg at #lerersummit.",
  "id" : 194859333891276801,
  "created_at" : "Tue Apr 24 18:44:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Hoffman",
      "screen_name" : "leemhoffman",
      "indices" : [ 3, 15 ],
      "id_str" : "16176467",
      "id" : 16176467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194858239987425280",
  "text" : "RT @leemhoffman: Bloomberg: solution to urban sprawl, offer educated foreigners citizenship if they move to & stay in those cities for 7 ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Lerersummit",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "194857946079965186",
    "text" : "Bloomberg: solution to urban sprawl, offer educated foreigners citizenship if they move to & stay in those cities for 7 years. #Lerersummit",
    "id" : 194857946079965186,
    "created_at" : "Tue Apr 24 18:38:49 +0000 2012",
    "user" : {
      "name" : "Lee Hoffman",
      "screen_name" : "leemhoffman",
      "protected" : false,
      "id_str" : "16176467",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1431142810/headshot_icon_normal.jpg",
      "id" : 16176467,
      "verified" : false
    }
  },
  "id" : 194858239987425280,
  "created_at" : "Tue Apr 24 18:39:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 1, 15 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/194853511979216896/photo/1",
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/ZDo7MW9K",
      "media_url" : "http://pbs.twimg.com/media/ArRCPJ0CMAE0Snt.jpg",
      "id_str" : "194853511983411201",
      "id" : 194853511983411201,
      "media_url_https" : "https://pbs.twimg.com/media/ArRCPJ0CMAE0Snt.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/ZDo7MW9K"
    } ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194853511979216896",
  "text" : ".@MikeBloomberg pitching NYC as a tech hub at #lerersummit. \"NY has more students than Boston has people.\" http://t.co/ZDo7MW9K",
  "id" : 194853511979216896,
  "created_at" : "Tue Apr 24 18:21:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 3, 17 ],
      "id_str" : "128968036",
      "id" : 128968036
    }, {
      "name" : "Bre Pettis",
      "screen_name" : "bre",
      "indices" : [ 98, 102 ],
      "id_str" : "11900",
      "id" : 11900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194852134867574784",
  "text" : "RT @KellerRinaudo: Getting' ready to drive robots around at #lerersummit . Welcome change though, @bre just arrived so we aren't the onl ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bre Pettis",
        "screen_name" : "bre",
        "indices" : [ 79, 83 ],
        "id_str" : "11900",
        "id" : 11900
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lerersummit",
        "indices" : [ 41, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "194851426558676992",
    "text" : "Getting' ready to drive robots around at #lerersummit . Welcome change though, @bre just arrived so we aren't the only HW company here",
    "id" : 194851426558676992,
    "created_at" : "Tue Apr 24 18:12:54 +0000 2012",
    "user" : {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "protected" : false,
      "id_str" : "128968036",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/802626909/profile_pic_normal.jpg",
      "id" : 128968036,
      "verified" : false
    }
  },
  "id" : 194852134867574784,
  "created_at" : "Tue Apr 24 18:15:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 8, 17 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Lerer Ventures",
      "screen_name" : "lererventures",
      "indices" : [ 21, 35 ],
      "id_str" : "147666931",
      "id" : 147666931
    }, {
      "name" : "David Lee",
      "screen_name" : "davidlee",
      "indices" : [ 63, 72 ],
      "id_str" : "5965332",
      "id" : 5965332
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/194850576268406784/photo/1",
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/UxZr8avw",
      "media_url" : "http://pbs.twimg.com/media/ArQ_kRcCMAEIPkx.jpg",
      "id_str" : "194850576272601089",
      "id" : 194850576272601089,
      "media_url_https" : "https://pbs.twimg.com/media/ArQ_kRcCMAEIPkx.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/UxZr8avw"
    } ],
    "hashtags" : [ {
      "text" : "lerersummit",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194850576268406784",
  "text" : "Repping @Romotive at @lererventures summit. Solid photobomb by @davidlee. #lerersummit http://t.co/UxZr8avw",
  "id" : 194850576268406784,
  "created_at" : "Tue Apr 24 18:09:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7608798379, -73.9907186665 ]
  },
  "id_str" : "194821378011176962",
  "text" : "Kid in front of me on megabus to NY is yelling out the name of every store we pass.",
  "id" : 194821378011176962,
  "created_at" : "Tue Apr 24 16:13:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/X1jV63aW",
      "expanded_url" : "http://hvrd.me/JAJMVQ",
      "display_url" : "hvrd.me/JAJMVQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "194758798940979200",
  "text" : "RT @hseas: Loncar wins 2012 Levenson Prize for Excellence in Undergraduate Teaching http://t.co/X1jV63aW",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/X1jV63aW",
        "expanded_url" : "http://hvrd.me/JAJMVQ",
        "display_url" : "hvrd.me/JAJMVQ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "194752527835738113",
    "text" : "Loncar wins 2012 Levenson Prize for Excellence in Undergraduate Teaching http://t.co/X1jV63aW",
    "id" : 194752527835738113,
    "created_at" : "Tue Apr 24 11:39:55 +0000 2012",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 194758798940979200,
  "created_at" : "Tue Apr 24 12:04:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194570083580915712",
  "text" : "DNS PROPAGATION Y U NO GO??",
  "id" : 194570083580915712,
  "created_at" : "Mon Apr 23 23:34:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Rumennik",
      "screen_name" : "djdan85",
      "indices" : [ 1, 9 ],
      "id_str" : "22803575",
      "id" : 22803575
    }, {
      "name" : "Life should bcalm\u2122",
      "screen_name" : "bcalm",
      "indices" : [ 80, 86 ],
      "id_str" : "449232786",
      "id" : 449232786
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/194558983992909824/photo/1",
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/87kBt2lC",
      "media_url" : "http://pbs.twimg.com/media/ArM2XXlCIAEyRAd.jpg",
      "id_str" : "194558984001298433",
      "id" : 194558984001298433,
      "media_url_https" : "https://pbs.twimg.com/media/ArM2XXlCIAEyRAd.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/87kBt2lC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3718592059, -71.1168130953 ]
  },
  "id_str" : "194558983992909824",
  "text" : ".@djdan85 dropping some entrepreneurial knowledge in Adams House about founding @bcalm http://t.co/87kBt2lC",
  "id" : 194558983992909824,
  "created_at" : "Mon Apr 23 22:50:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 1, 13 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194544045580759040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3682438815, -71.1158140562 ]
  },
  "id_str" : "194544363953602561",
  "in_reply_to_user_id" : 7782442,
  "text" : ".@christinelu Ten Ren is the best! Still absent from Boston :(",
  "id" : 194544363953602561,
  "in_reply_to_status_id" : 194544045580759040,
  "created_at" : "Mon Apr 23 21:52:45 +0000 2012",
  "in_reply_to_screen_name" : "christinelu",
  "in_reply_to_user_id_str" : "7782442",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/194507238403080193/photo/1",
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/nfBlvGEB",
      "media_url" : "http://pbs.twimg.com/media/ArMHTYOCAAIa-uM.jpg",
      "id_str" : "194507238407274498",
      "id" : 194507238407274498,
      "media_url_https" : "https://pbs.twimg.com/media/ArMHTYOCAAIa-uM.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/nfBlvGEB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194507238403080193",
  "text" : "Found in basement of Harvard Science Center. Wait what? http://t.co/nfBlvGEB",
  "id" : 194507238403080193,
  "created_at" : "Mon Apr 23 19:25:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 19, 28 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3777090199, -71.1163476482 ]
  },
  "id_str" : "194490050120134656",
  "text" : "This is news..? RT @Techmeme: Apple May Add Secure Password Suggestions to Safari with OS X Mountain Lion",
  "id" : 194490050120134656,
  "created_at" : "Mon Apr 23 18:16:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 36, 46 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194489671672270849",
  "text" : "Why was six afraid of jenny? 'cause @jenny8lee",
  "id" : 194489671672270849,
  "created_at" : "Mon Apr 23 18:15:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Computer Science ",
      "screen_name" : "CompSciFact",
      "indices" : [ 3, 15 ],
      "id_str" : "220145170",
      "id" : 220145170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194481441671872513",
  "text" : "RT @CompSciFact: 'A big computer, a complex algorithm and a long time does not equal science.' -- Robert Gentleman",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "194451962123657216",
    "text" : "'A big computer, a complex algorithm and a long time does not equal science.' -- Robert Gentleman",
    "id" : 194451962123657216,
    "created_at" : "Mon Apr 23 15:45:35 +0000 2012",
    "user" : {
      "name" : "Computer Science ",
      "screen_name" : "CompSciFact",
      "protected" : false,
      "id_str" : "220145170",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1178298385/CompSci_normal.png",
      "id" : 220145170,
      "verified" : false
    }
  },
  "id" : 194481441671872513,
  "created_at" : "Mon Apr 23 17:42:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3683088832, -71.1155157443 ]
  },
  "id_str" : "194352862980091904",
  "text" : "Anyone else get an AmazonSupply email?",
  "id" : 194352862980091904,
  "created_at" : "Mon Apr 23 09:11:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pebble",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3681511357, -71.1152573302 ]
  },
  "id_str" : "194254642656452609",
  "text" : "A well-funded mediocre smart watch is still a mediocre smart watch. #pebble",
  "id" : 194254642656452609,
  "created_at" : "Mon Apr 23 02:41:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 12, 18 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/2bMGjxNV",
      "expanded_url" : "http://hvrd.me/I4qI0l",
      "display_url" : "hvrd.me/I4qI0l"
    } ]
  },
  "geo" : {
  },
  "id_str" : "193916973950832640",
  "text" : "Noooooo. RT @hseas: It's coming, it's coming! COMMENCEMENT details, schedule, tickets, regalia, excitement http://t.co/2bMGjxNV",
  "id" : 193916973950832640,
  "created_at" : "Sun Apr 22 04:19:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/Z9GrxTSZ",
      "expanded_url" : "http://instagr.am/p/JtUmn_PA41/",
      "display_url" : "instagr.am/p/JtUmn_PA41/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "193916030727368704",
  "text" : "When the laptop fails... DJ from a smartphone. http://t.co/Z9GrxTSZ",
  "id" : 193916030727368704,
  "created_at" : "Sun Apr 22 04:15:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Rumennik",
      "screen_name" : "djdan85",
      "indices" : [ 15, 23 ],
      "id_str" : "22803575",
      "id" : 22803575
    }, {
      "name" : "Life should bcalm\u2122",
      "screen_name" : "bcalm",
      "indices" : [ 93, 99 ],
      "id_str" : "449232786",
      "id" : 449232786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/qyfJ37IF",
      "expanded_url" : "http://drinkbcalm.com",
      "display_url" : "drinkbcalm.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "193782414156374016",
  "text" : "Excited to see @djdan85 starting to ship his product! HBS rooms make for cramped warehouses. @bcalm wellness drink http://t.co/qyfJ37IF",
  "id" : 193782414156374016,
  "created_at" : "Sat Apr 21 19:25:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 27, 37 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193770811650351104",
  "text" : "Serendipitous meeting with @jenny8lee on the sunny streets of Cambridge!",
  "id" : 193770811650351104,
  "created_at" : "Sat Apr 21 18:38:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Artsy",
      "screen_name" : "artsy",
      "indices" : [ 3, 9 ],
      "id_str" : "81783051",
      "id" : 81783051
    }, {
      "name" : "Phaidon",
      "screen_name" : "Phaidon",
      "indices" : [ 75, 83 ],
      "id_str" : "187869078",
      "id" : 187869078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/Tv4EVnrW",
      "expanded_url" : "http://ow.ly/apOL7",
      "display_url" : "ow.ly/apOL7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "193408690068520960",
  "text" : "RT @artsy: Ai Weiwei: Never Sorry. (Film, teaser) http://t.co/Tv4EVnrW via @phaidon",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phaidon",
        "screen_name" : "Phaidon",
        "indices" : [ 64, 72 ],
        "id_str" : "187869078",
        "id" : 187869078
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http://t.co/Tv4EVnrW",
        "expanded_url" : "http://ow.ly/apOL7",
        "display_url" : "ow.ly/apOL7"
      } ]
    },
    "geo" : {
    },
    "id_str" : "193386752684195842",
    "text" : "Ai Weiwei: Never Sorry. (Film, teaser) http://t.co/Tv4EVnrW via @phaidon",
    "id" : 193386752684195842,
    "created_at" : "Fri Apr 20 17:12:49 +0000 2012",
    "user" : {
      "name" : "Artsy",
      "screen_name" : "artsy",
      "protected" : false,
      "id_str" : "81783051",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1541269347/Artsy_normal.png",
      "id" : 81783051,
      "verified" : false
    }
  },
  "id" : 193408690068520960,
  "created_at" : "Fri Apr 20 18:39:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193362692591984641",
  "text" : "Paul Salopek on human curiosity: \"when [our ancestors] finally made it to Patagonia and land's end, we created Patagonias in our minds.\"",
  "id" : 193362692591984641,
  "created_at" : "Fri Apr 20 15:37:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/XlYRaJKj",
      "expanded_url" : "http://instagr.am/p/JpQGBBvA0l/",
      "display_url" : "instagr.am/p/JpQGBBvA0l/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "193343234884382721",
  "text" : "Basketball at the Harvard Graduate School of Design. http://t.co/XlYRaJKj",
  "id" : 193343234884382721,
  "created_at" : "Fri Apr 20 14:19:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zipcar",
      "screen_name" : "Zipcar",
      "indices" : [ 6, 13 ],
      "id_str" : "19364978",
      "id" : 19364978
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/193223861830029315/photo/1",
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/TzSDQuGE",
      "media_url" : "http://pbs.twimg.com/media/Aq54FB7CEAA_MTa.jpg",
      "id_str" : "193223861834223616",
      "id" : 193223861834223616,
      "media_url_https" : "https://pbs.twimg.com/media/Aq54FB7CEAA_MTa.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/TzSDQuGE"
    } ],
    "hashtags" : [ {
      "text" : "lame",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193223861830029315",
  "text" : "So... @zipcar doesn't unlock, but it's parked underground so we can't call support. #lame http://t.co/TzSDQuGE",
  "id" : 193223861830029315,
  "created_at" : "Fri Apr 20 06:25:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193180291563663361",
  "text" : "Take it from an anodizer: LiquidMetal is nifty but by no means amazing. iPhone RDF already hard at work.",
  "id" : 193180291563663361,
  "created_at" : "Fri Apr 20 03:32:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193153572173643776",
  "text" : "I find it amusing that Panera, staple of my podunk upstate NY hometown, is suddenly the place to be in Harvard Sq.",
  "id" : 193153572173643776,
  "created_at" : "Fri Apr 20 01:46:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 3, 9 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193132478217728000",
  "text" : "RT @jluan: Dogs are so smart. Robots are not.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "193112178730074113",
    "text" : "Dogs are so smart. Robots are not.",
    "id" : 193112178730074113,
    "created_at" : "Thu Apr 19 23:01:45 +0000 2012",
    "user" : {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "protected" : false,
      "id_str" : "27015881",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1366826138/72500_1527561949320_1242810207_31307527_6609490_n_1__normal.jpg",
      "id" : 27015881,
      "verified" : false
    }
  },
  "id" : 193132478217728000,
  "created_at" : "Fri Apr 20 00:22:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "indices" : [ 0, 10 ],
      "id_str" : "13369702",
      "id" : 13369702
    }, {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 11, 25 ],
      "id_str" : "128968036",
      "id" : 128968036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193042968947589120",
  "geo" : {
  },
  "id_str" : "193043220664565760",
  "in_reply_to_user_id" : 13369702,
  "text" : "@NikhilKal @KellerRinaudo should be able to stay for Wednesday. Looking forward to it!",
  "id" : 193043220664565760,
  "in_reply_to_status_id" : 193042968947589120,
  "created_at" : "Thu Apr 19 18:27:45 +0000 2012",
  "in_reply_to_screen_name" : "NikhilKal",
  "in_reply_to_user_id_str" : "13369702",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gitrdun",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192875271492341760",
  "text" : "Last algorithms-related all-nighter in the foreseeable future. #gitrdun",
  "id" : 192875271492341760,
  "created_at" : "Thu Apr 19 07:20:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192833633218871296",
  "text" : "Ray Dalio's 2011 salary was 3 Instagrams.",
  "id" : 192833633218871296,
  "created_at" : "Thu Apr 19 04:34:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192833443816669184",
  "text" : "Luxembourg's GDP is 43 Instagrams.",
  "id" : 192833443816669184,
  "created_at" : "Thu Apr 19 04:34:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192833088269729792",
  "text" : "If everyone in the world gave me a nickel, I'd have a third of an Instagram.",
  "id" : 192833088269729792,
  "created_at" : "Thu Apr 19 04:32:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 95, 107 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "indices" : [ 108, 118 ],
      "id_str" : "13369702",
      "id" : 13369702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192832570650664960",
  "text" : "Also, prestige is big w luxe auto. Why else own ANY super car brand? Profit is drop in bucket. @badboyboyce @NikhilKal",
  "id" : 192832570650664960,
  "created_at" : "Thu Apr 19 04:30:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 111, 123 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "indices" : [ 124, 134 ],
      "id_str" : "13369702",
      "id" : 13369702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192830801619062785",
  "geo" : {
  },
  "id_str" : "192832277879848961",
  "in_reply_to_user_id" : 110823121,
  "text" : "Credit Suisse: \"...[Ducati buy] driven by VW's passion for nameplates rather than industrial/financial logic.\" @badboyboyce @NikhilKal",
  "id" : 192832277879848961,
  "in_reply_to_status_id" : 192830801619062785,
  "created_at" : "Thu Apr 19 04:29:32 +0000 2012",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192726978409938945",
  "text" : "College startup idea: subscription service for Solo cups and 30 racks.",
  "id" : 192726978409938945,
  "created_at" : "Wed Apr 18 21:31:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 1, 11 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192692629832597504",
  "geo" : {
  },
  "id_str" : "192694578913087488",
  "in_reply_to_user_id" : 22745680,
  "text" : ".@Besvinick when you said \"big dog\" I thought you meant the Boston Dynamics robot.",
  "id" : 192694578913087488,
  "in_reply_to_status_id" : 192692629832597504,
  "created_at" : "Wed Apr 18 19:22:22 +0000 2012",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 3, 13 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/vKKEIOpY",
      "expanded_url" : "http://www.geekwire.com/2012/stat-day-internet-users-visit-site-amazons-infrastructure/",
      "display_url" : "geekwire.com/2012/stat-day-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "192681734523994112",
  "text" : "RT @johnhcook: Whoa, crazy stat: A third of all Internet users visit a site that uses Amazon's infrastructure: http://t.co/vKKEIOpY",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http://t.co/vKKEIOpY",
        "expanded_url" : "http://www.geekwire.com/2012/stat-day-internet-users-visit-site-amazons-infrastructure/",
        "display_url" : "geekwire.com/2012/stat-day-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "192677635497791488",
    "text" : "Whoa, crazy stat: A third of all Internet users visit a site that uses Amazon's infrastructure: http://t.co/vKKEIOpY",
    "id" : 192677635497791488,
    "created_at" : "Wed Apr 18 18:15:02 +0000 2012",
    "user" : {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "protected" : false,
      "id_str" : "14326765",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/403089484/john-headshot_normal.jpg",
      "id" : 14326765,
      "verified" : false
    }
  },
  "id" : 192681734523994112,
  "created_at" : "Wed Apr 18 18:31:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3602664052, -71.1156825442 ]
  },
  "id_str" : "192680602699436032",
  "text" : "Hell is trying to change the lead in a drafting pencil with the eraser worn all the way down.",
  "id" : 192680602699436032,
  "created_at" : "Wed Apr 18 18:26:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192478830210977792",
  "text" : "Microsoft acquired 800 AOL patents for 1 Instagram.",
  "id" : 192478830210977792,
  "created_at" : "Wed Apr 18 05:05:03 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192478673033625601",
  "text" : "Everything sounds strange when you use 1 Instagram (IG) = $1B. \"Audi is bidding 1 Instagram for Ducati.\"",
  "id" : 192478673033625601,
  "created_at" : "Wed Apr 18 05:04:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192458675099668481",
  "text" : "\"I'm pretty sure finding a time that 6 harvard students are free to meet is NP-complete.\"",
  "id" : 192458675099668481,
  "created_at" : "Wed Apr 18 03:44:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 3, 17 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/lvX37K7I",
      "expanded_url" : "http://bit.ly/yRV0Ei",
      "display_url" : "bit.ly/yRV0Ei"
    } ]
  },
  "geo" : {
  },
  "id_str" : "192371383215472641",
  "text" : "RT @MikeBloomberg: More than 40% of Fortune 500 companies were founded by an immigrant or child of an immigrant: http://t.co/lvX37K7I",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http://t.co/lvX37K7I",
        "expanded_url" : "http://bit.ly/yRV0Ei",
        "display_url" : "bit.ly/yRV0Ei"
      } ]
    },
    "geo" : {
    },
    "id_str" : "174210957126541313",
    "text" : "More than 40% of Fortune 500 companies were founded by an immigrant or child of an immigrant: http://t.co/lvX37K7I",
    "id" : 174210957126541313,
    "created_at" : "Mon Feb 27 19:15:03 +0000 2012",
    "user" : {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "protected" : false,
      "id_str" : "16581604",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3374841513/ccdffb7ce6910ac43568ae2f7c68fe2b_normal.jpeg",
      "id" : 16581604,
      "verified" : true
    }
  },
  "id" : 192371383215472641,
  "created_at" : "Tue Apr 17 21:58:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 3, 12 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/kdOFTYtJ",
      "expanded_url" : "http://itunes.apple.com/us/app/romocontroller/id517163794?mt=12",
      "display_url" : "itunes.apple.com/us/app/romocon\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "192370699061575680",
  "text" : "RT @Romotive: Have a Mac? Control your Romo with our newly launched Mac App! http://t.co/kdOFTYtJ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http://t.co/kdOFTYtJ",
        "expanded_url" : "http://itunes.apple.com/us/app/romocontroller/id517163794?mt=12",
        "display_url" : "itunes.apple.com/us/app/romocon\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "192341115947585536",
    "text" : "Have a Mac? Control your Romo with our newly launched Mac App! http://t.co/kdOFTYtJ",
    "id" : 192341115947585536,
    "created_at" : "Tue Apr 17 19:57:50 +0000 2012",
    "user" : {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "protected" : false,
      "id_str" : "340545195",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2180791949/romo_normal.jpg",
      "id" : 340545195,
      "verified" : false
    }
  },
  "id" : 192370699061575680,
  "created_at" : "Tue Apr 17 21:55:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192361562105839616",
  "text" : "About 30% of audience has been genotyped, maybe 5% full sequenced. 20% would want full sequence if cheaper.",
  "id" : 192361562105839616,
  "created_at" : "Tue Apr 17 21:19:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/192359962482188288/photo/1",
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/djGsQ3ps",
      "media_url" : "http://pbs.twimg.com/media/AqtmXeECIAAPrFH.jpg",
      "id_str" : "192359962486382592",
      "id" : 192359962486382592,
      "media_url_https" : "https://pbs.twimg.com/media/AqtmXeECIAAPrFH.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/djGsQ3ps"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192359962482188288",
  "text" : "Anne Wojcicki about to speak on 23andme at Harvard. http://t.co/djGsQ3ps",
  "id" : 192359962482188288,
  "created_at" : "Tue Apr 17 21:12:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/7KHqrkSp",
      "expanded_url" : "http://www.friatider.se/shocking-photos-shows-swedish-minister-of-culture-celebrating-with-niger-cake#.T413VM2wzf1.facebook",
      "display_url" : "friatider.se/shocking-photo\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "192339792380444672",
  "text" : "Annnnd the WTF-of-the-day goes to... Sweden! (potentially nsfw) http://t.co/7KHqrkSp",
  "id" : 192339792380444672,
  "created_at" : "Tue Apr 17 19:52:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenden Mulligan",
      "screen_name" : "mulligan",
      "indices" : [ 3, 12 ],
      "id_str" : "14323985",
      "id" : 14323985
    }, {
      "name" : "@username",
      "screen_name" : "username",
      "indices" : [ 63, 72 ],
      "id_str" : "318686216",
      "id" : 318686216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192337472447979520",
  "text" : "RT @mulligan: It's amazing how many people start tweets with a @username and think all their followers will see it. Quick refresher: htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "@username",
        "screen_name" : "username",
        "indices" : [ 49, 58 ],
        "id_str" : "318686216",
        "id" : 318686216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/h57nZ6dv",
        "expanded_url" : "http://bit.ly/at-reply-rules",
        "display_url" : "bit.ly/at-reply-rules"
      } ]
    },
    "geo" : {
    },
    "id_str" : "192310260806062080",
    "text" : "It's amazing how many people start tweets with a @username and think all their followers will see it. Quick refresher: http://t.co/h57nZ6dv",
    "id" : 192310260806062080,
    "created_at" : "Tue Apr 17 17:55:13 +0000 2012",
    "user" : {
      "name" : "Brenden Mulligan",
      "screen_name" : "mulligan",
      "protected" : false,
      "id_str" : "14323985",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3439412048/db113407176337dc7fb87be66af000c7_normal.jpeg",
      "id" : 14323985,
      "verified" : false
    }
  },
  "id" : 192337472447979520,
  "created_at" : "Tue Apr 17 19:43:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Ko",
      "screen_name" : "ryanko",
      "indices" : [ 0, 7 ],
      "id_str" : "15951349",
      "id" : 15951349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3735370534, -71.1148228962 ]
  },
  "id_str" : "192326450609786881",
  "in_reply_to_user_id" : 15951349,
  "text" : "@ryanko I've tweeted an order of magnitude more pictures than I've instagram'd",
  "id" : 192326450609786881,
  "created_at" : "Tue Apr 17 18:59:33 +0000 2012",
  "in_reply_to_screen_name" : "ryanko",
  "in_reply_to_user_id_str" : "15951349",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 0, 8 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3787935544, -71.116984589 ]
  },
  "id_str" : "192324584203223041",
  "in_reply_to_user_id" : 783214,
  "text" : "@twitter shakes up tech IP by letting inventors control patents. Far cry from my work at Msoft where I was paid to file for the company.",
  "id" : 192324584203223041,
  "created_at" : "Tue Apr 17 18:52:08 +0000 2012",
  "in_reply_to_screen_name" : "twitter",
  "in_reply_to_user_id_str" : "783214",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192317395703037952",
  "text" : "RT @hseas: Prof. Parkes joins Nanigans (Facebook advertising tech co.) as technical adviser on automated bidding algorithms http://t.co/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http://t.co/CwCEkodf",
        "expanded_url" : "http://hvrd.me/IuTO8P",
        "display_url" : "hvrd.me/IuTO8P"
      } ]
    },
    "geo" : {
    },
    "id_str" : "192311197905862657",
    "text" : "Prof. Parkes joins Nanigans (Facebook advertising tech co.) as technical adviser on automated bidding algorithms http://t.co/CwCEkodf",
    "id" : 192311197905862657,
    "created_at" : "Tue Apr 17 17:58:57 +0000 2012",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 192317395703037952,
  "created_at" : "Tue Apr 17 18:23:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AFFINITY CHINA",
      "screen_name" : "AffinityChina",
      "indices" : [ 10, 24 ],
      "id_str" : "65585297",
      "id" : 65585297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/QlQr9JBc",
      "expanded_url" : "http://ow.ly/ajS6h",
      "display_url" : "ow.ly/ajS6h"
    } ]
  },
  "geo" : {
  },
  "id_str" : "192012557349961729",
  "text" : "Crazy. RT @AffinityChina: \"...in Europe, Chinese tourists made up 62% of the continent\u2019s luxury good consumers\" http://t.co/QlQr9JBc",
  "id" : 192012557349961729,
  "created_at" : "Mon Apr 16 22:12:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/gC52dlyg",
      "expanded_url" : "http://instagr.am/p/Jfl4rhPA4B/",
      "display_url" : "instagr.am/p/Jfl4rhPA4B/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "191983703726104576",
  "text" : "Spotted: Beautiful 528 SE parked on Dunster St.  http://t.co/gC52dlyg",
  "id" : 191983703726104576,
  "created_at" : "Mon Apr 16 20:17:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191974724060975105",
  "text" : "RT @NASA: NASA confirms April 30 launch target for SpaceX demonstration flight.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "191973952682340352",
    "text" : "NASA confirms April 30 launch target for SpaceX demonstration flight.",
    "id" : 191973952682340352,
    "created_at" : "Mon Apr 16 19:38:51 +0000 2012",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/188302352/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 191974724060975105,
  "created_at" : "Mon Apr 16 19:41:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191951278312652803",
  "geo" : {
  },
  "id_str" : "191973684590821376",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick \"my textbook ran out of batteries.\"",
  "id" : 191973684590821376,
  "in_reply_to_status_id" : 191951278312652803,
  "created_at" : "Mon Apr 16 19:37:47 +0000 2012",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Niu",
      "screen_name" : "sleepypotamus",
      "indices" : [ 55, 69 ],
      "id_str" : "339513400",
      "id" : 339513400
    }, {
      "name" : "Terence Gregory",
      "screen_name" : "Tmac721",
      "indices" : [ 70, 78 ],
      "id_str" : "1262251880",
      "id" : 1262251880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3679770436, -71.1155610904 ]
  },
  "id_str" : "191949765443993600",
  "text" : "\"Before I name my kid I'm going to buy his domain.\" cc @sleepypotamus @tmac721",
  "id" : 191949765443993600,
  "created_at" : "Mon Apr 16 18:02:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/w9PVju34",
      "expanded_url" : "http://instagr.am/p/JcqwXAvA-Q/",
      "display_url" : "instagr.am/p/JcqwXAvA-Q/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3661747249, -71.0905608907 ]
  },
  "id_str" : "191572770415583233",
  "text" : "At the MIT flea market! http://t.co/w9PVju34",
  "id" : 191572770415583233,
  "created_at" : "Sun Apr 15 17:04:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 43, 49 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191397625277321216",
  "text" : "They do implicitly w recommended items. RT @koush: Why doesn't Amazon start an ad network?",
  "id" : 191397625277321216,
  "created_at" : "Sun Apr 15 05:28:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191272480374128640",
  "text" : "Busker playing Star Wars music on an according in Boston metro making my day.",
  "id" : 191272480374128640,
  "created_at" : "Sat Apr 14 21:11:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191246331602411521",
  "text" : "I have never seen an operation as inefficient as the MBTA Green Line.",
  "id" : 191246331602411521,
  "created_at" : "Sat Apr 14 19:27:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 43, 55 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191065670656598016",
  "text" : "Not sure what the big deal about Pebble on @kickstarter is. Sony literally released the same thing today. For sale now.",
  "id" : 191065670656598016,
  "created_at" : "Sat Apr 14 07:29:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/JO5uleMO",
      "expanded_url" : "http://thedoghousediaries.com/3535",
      "display_url" : "thedoghousediaries.com/3535"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190860036774428672",
  "text" : "How design works. http://t.co/JO5uleMO",
  "id" : 190860036774428672,
  "created_at" : "Fri Apr 13 17:52:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190841751974580225",
  "text" : "Comment on Chinese website: \"given the capabilities of S Korean, American, and Japanese boats, N Korea was really just launching a target.\"",
  "id" : 190841751974580225,
  "created_at" : "Fri Apr 13 16:39:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BostInnovation",
      "screen_name" : "BostInnovation",
      "indices" : [ 0, 15 ],
      "id_str" : "1056260852",
      "id" : 1056260852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190830669482565632",
  "geo" : {
  },
  "id_str" : "190835658472951808",
  "in_reply_to_user_id" : 16877220,
  "text" : "@BostInnovation for what it's worth, Bostonians think Japanese food is to be dipped in wasabi and soy sauce all the time for some reason.",
  "id" : 190835658472951808,
  "in_reply_to_status_id" : 190830669482565632,
  "created_at" : "Fri Apr 13 16:15:41 +0000 2012",
  "in_reply_to_screen_name" : "BostInno",
  "in_reply_to_user_id_str" : "16877220",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BostInnovation",
      "screen_name" : "BostInnovation",
      "indices" : [ 0, 15 ],
      "id_str" : "1056260852",
      "id" : 1056260852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190830669482565632",
  "geo" : {
  },
  "id_str" : "190834151086227457",
  "in_reply_to_user_id" : 16877220,
  "text" : "@BostInnovation I don't think you've had Mister Donut. That stuff is like crack.",
  "id" : 190834151086227457,
  "in_reply_to_status_id" : 190830669482565632,
  "created_at" : "Fri Apr 13 16:09:41 +0000 2012",
  "in_reply_to_screen_name" : "BostInno",
  "in_reply_to_user_id_str" : "16877220",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AW Asia",
      "screen_name" : "AWASIA",
      "indices" : [ 3, 10 ],
      "id_str" : "22698057",
      "id" : 22698057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/KJXxHr6q",
      "expanded_url" : "http://stream.aljazeera.com/story/china-censorship-mother-creativity-0022167?utm_content=automate&utm_campaign=Trial6&utm_source=NewSocialFlow&utm_term=plustweets&utm_medium=MasterAccount",
      "display_url" : "stream.aljazeera.com/story/china-ce\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190833247184363520",
  "text" : "RT @AWASIA: In China, is censorship the mother of creativity? Ai Weiwei interview on Aljazeera\nhttp://t.co/KJXxHr6q",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http://t.co/KJXxHr6q",
        "expanded_url" : "http://stream.aljazeera.com/story/china-censorship-mother-creativity-0022167?utm_content=automate&utm_campaign=Trial6&utm_source=NewSocialFlow&utm_term=plustweets&utm_medium=MasterAccount",
        "display_url" : "stream.aljazeera.com/story/china-ce\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "190820844010876928",
    "text" : "In China, is censorship the mother of creativity? Ai Weiwei interview on Aljazeera\nhttp://t.co/KJXxHr6q",
    "id" : 190820844010876928,
    "created_at" : "Fri Apr 13 15:16:49 +0000 2012",
    "user" : {
      "name" : "AW Asia",
      "screen_name" : "AWASIA",
      "protected" : false,
      "id_str" : "22698057",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535668456/QZL_OilPainting_2009_YoungIntellectualsNo1_220x180cm_AW6_lowres_normal.jpg",
      "id" : 22698057,
      "verified" : false
    }
  },
  "id" : 190833247184363520,
  "created_at" : "Fri Apr 13 16:06:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Ko",
      "screen_name" : "ryanko",
      "indices" : [ 0, 7 ],
      "id_str" : "15951349",
      "id" : 15951349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190672459807207424",
  "geo" : {
  },
  "id_str" : "190681347491237888",
  "in_reply_to_user_id" : 15951349,
  "text" : "@ryanko browser or client?",
  "id" : 190681347491237888,
  "in_reply_to_status_id" : 190672459807207424,
  "created_at" : "Fri Apr 13 06:02:30 +0000 2012",
  "in_reply_to_screen_name" : "ryanko",
  "in_reply_to_user_id_str" : "15951349",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 0, 6 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190674411093889025",
  "in_reply_to_user_id" : 586,
  "text" : "@sacca Did you attend GMP at the University of Buffalo by any chance?",
  "id" : 190674411093889025,
  "created_at" : "Fri Apr 13 05:34:56 +0000 2012",
  "in_reply_to_screen_name" : "sacca",
  "in_reply_to_user_id_str" : "586",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 3, 10 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190672189983432705",
  "text" : "RT @jdrive: Don't overthink this, future robots wanting to kill me. A hot female Terminator handing out free tacos will easily suffice.  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://stone.com/Twittelator\" rel=\"nofollow\">Twittelator</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Siedell",
        "screen_name" : "badbanana",
        "indices" : [ 129, 139 ],
        "id_str" : "809760",
        "id" : 809760
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "190616044094750722",
    "text" : "Don't overthink this, future robots wanting to kill me. A hot female Terminator handing out free tacos will easily suffice. /via @badbanana",
    "id" : 190616044094750722,
    "created_at" : "Fri Apr 13 01:43:01 +0000 2012",
    "user" : {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "protected" : false,
      "id_str" : "15137329",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3458237744/7f6dc83d6d93ff6347730211a9e34430_normal.jpeg",
      "id" : 15137329,
      "verified" : false
    }
  },
  "id" : 190672189983432705,
  "created_at" : "Fri Apr 13 05:26:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190671472027635712",
  "text" : "I wonder if anyone tweets from computers anymore (besides the Hootsuite crowd).",
  "id" : 190671472027635712,
  "created_at" : "Fri Apr 13 05:23:16 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "niniane",
      "screen_name" : "niniane",
      "indices" : [ 3, 11 ],
      "id_str" : "9239622",
      "id" : 9239622
    }, {
      "name" : "E! Online",
      "screen_name" : "eonline",
      "indices" : [ 67, 75 ],
      "id_str" : "2883841",
      "id" : 2883841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190660303346860032",
  "text" : "RT @niniane: I always think it's movie about a python framework RT @eonline: poster for Quentin Tarantino\u2019s movie \"Django Unchained\" htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "E! Online",
        "screen_name" : "eonline",
        "indices" : [ 54, 62 ],
        "id_str" : "2883841",
        "id" : 2883841
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/eonline/status/190488151146512385/photo/1",
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/mRfP3vRs",
        "media_url" : "http://pbs.twimg.com/media/AqS_9tdCQAA5Enz.jpg",
        "id_str" : "190488151150706688",
        "id" : 190488151150706688,
        "media_url_https" : "https://pbs.twimg.com/media/AqS_9tdCQAA5Enz.jpg",
        "sizes" : [ {
          "h" : 889,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1517,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1926,
          "resize" : "fit",
          "w" : 1300
        } ],
        "display_url" : "pic.twitter.com/mRfP3vRs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "190638455619981313",
    "text" : "I always think it's movie about a python framework RT @eonline: poster for Quentin Tarantino\u2019s movie \"Django Unchained\" http://t.co/mRfP3vRs",
    "id" : 190638455619981313,
    "created_at" : "Fri Apr 13 03:12:04 +0000 2012",
    "user" : {
      "name" : "niniane",
      "screen_name" : "niniane",
      "protected" : false,
      "id_str" : "9239622",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/428496371/DSCF1415_2_2_normal.JPG",
      "id" : 9239622,
      "verified" : false
    }
  },
  "id" : 190660303346860032,
  "created_at" : "Fri Apr 13 04:38:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tucker Martin",
      "screen_name" : "jtuckermartin",
      "indices" : [ 3, 17 ],
      "id_str" : "473537910",
      "id" : 473537910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190587432146710528",
  "text" : "RT @jtuckermartin: Um, what rocket fail? My North Korean PR says it circled the globe 10 times before showering the motherland with resp ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "190581136798384128",
    "text" : "Um, what rocket fail? My North Korean PR says it circled the globe 10 times before showering the motherland with resplendent golden chips",
    "id" : 190581136798384128,
    "created_at" : "Thu Apr 12 23:24:18 +0000 2012",
    "user" : {
      "name" : "Tucker Martin",
      "screen_name" : "jtuckermartin",
      "protected" : false,
      "id_str" : "473537910",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3569836642/c23cddd2d1856017615626f380eac3fb_normal.jpeg",
      "id" : 473537910,
      "verified" : false
    }
  },
  "id" : 190587432146710528,
  "created_at" : "Thu Apr 12 23:49:19 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3684532614, -71.1154947057 ]
  },
  "id_str" : "190582728759050243",
  "text" : "DPRK rocket news trickling in. Apparently it failed at stage 3?",
  "id" : 190582728759050243,
  "created_at" : "Thu Apr 12 23:30:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190577466673336321",
  "geo" : {
  },
  "id_str" : "190580236256149505",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive dim sum for dinner is a little strange, no?",
  "id" : 190580236256149505,
  "in_reply_to_status_id" : 190577466673336321,
  "created_at" : "Thu Apr 12 23:20:43 +0000 2012",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Chun",
      "screen_name" : "chun",
      "indices" : [ 3, 8 ],
      "id_str" : "21935284",
      "id" : 21935284
    }, {
      "name" : "VentureBeat",
      "screen_name" : "VentureBeat",
      "indices" : [ 112, 124 ],
      "id_str" : "60642052",
      "id" : 60642052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190515706532610048",
  "text" : "RT @chun: Call of Duty MW3 is a social SaaS game with a killer business model + engagement to be envious of via @VentureBeat http://t.co ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VentureBeat",
        "screen_name" : "VentureBeat",
        "indices" : [ 102, 114 ],
        "id_str" : "60642052",
        "id" : 60642052
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/gMBvPsjV",
        "expanded_url" : "http://eepurl.com/kTb5L",
        "display_url" : "eepurl.com/kTb5L"
      } ]
    },
    "geo" : {
    },
    "id_str" : "190493658200539137",
    "text" : "Call of Duty MW3 is a social SaaS game with a killer business model + engagement to be envious of via @VentureBeat http://t.co/gMBvPsjV",
    "id" : 190493658200539137,
    "created_at" : "Thu Apr 12 17:36:41 +0000 2012",
    "user" : {
      "name" : "Patrick Chun",
      "screen_name" : "chun",
      "protected" : false,
      "id_str" : "21935284",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1468120405/Thumbnail__-_Twitter_normal.jpg",
      "id" : 21935284,
      "verified" : false
    }
  },
  "id" : 190515706532610048,
  "created_at" : "Thu Apr 12 19:04:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3689464107, -71.1152423266 ]
  },
  "id_str" : "190488861581910016",
  "text" : "Anyone know a good handbag repairman in Cambridge? Custom Longchamp project as a gift.",
  "id" : 190488861581910016,
  "created_at" : "Thu Apr 12 17:17:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/zMPfOpEn",
      "expanded_url" : "http://instagr.am/p/JPPvNuvAyT/",
      "display_url" : "instagr.am/p/JPPvNuvAyT/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "189683242050404352",
  "text" : "The drab drab line for the morning Delta shuttle.  http://t.co/zMPfOpEn",
  "id" : 189683242050404352,
  "created_at" : "Tue Apr 10 11:56:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3727429099, -71.1174407322 ]
  },
  "id_str" : "189489423107371008",
  "text" : "I can't tell if iOS is better at switching between wifi and 3G or if Android is just more verbose about its confusion.",
  "id" : 189489423107371008,
  "created_at" : "Mon Apr 09 23:06:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cenciotti",
      "screen_name" : "cencio4",
      "indices" : [ 50, 58 ],
      "id_str" : "53138772",
      "id" : 53138772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/MKFng6EA",
      "expanded_url" : "http://wp.me/pEfC-2vH",
      "display_url" : "wp.me/pEfC-2vH"
    } ]
  },
  "geo" : {
  },
  "id_str" : "189444620495749120",
  "text" : "Instagram news is big, but this is significant RT @cencio4: First images of Mig-21s in Free Libya Air Force markings http://t.co/MKFng6EA",
  "id" : 189444620495749120,
  "created_at" : "Mon Apr 09 20:08:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189441638806994944",
  "text" : "RT @bznotes: Now that euphoria is over...lets get back to building businesses. Facebook likely ain't coming for you and ebitda matters t ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "189425559221186560",
    "text" : "Now that euphoria is over...lets get back to building businesses. Facebook likely ain't coming for you and ebitda matters to most others.",
    "id" : 189425559221186560,
    "created_at" : "Mon Apr 09 18:52:27 +0000 2012",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 189441638806994944,
  "created_at" : "Mon Apr 09 19:56:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189441294878261249",
  "text" : "RT @medialab: Want to win some MIT Media Lab swag? We\u2019re kicking off a contest tomorrow \u2013 check out our blog for details! http://t.co/h9 ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/h9fsUaN0",
        "expanded_url" : "http://ow.ly/aadLE",
        "display_url" : "ow.ly/aadLE"
      } ]
    },
    "geo" : {
    },
    "id_str" : "189417409537519616",
    "text" : "Want to win some MIT Media Lab swag? We\u2019re kicking off a contest tomorrow \u2013 check out our blog for details! http://t.co/h9fsUaN0",
    "id" : 189417409537519616,
    "created_at" : "Mon Apr 09 18:20:04 +0000 2012",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 189441294878261249,
  "created_at" : "Mon Apr 09 19:54:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Snyder",
      "screen_name" : "briansny",
      "indices" : [ 3, 12 ],
      "id_str" : "239024528",
      "id" : 239024528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189413521451261953",
  "text" : "RT @briansny: Are folks tending toward InstaFace or FaceGram?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "189408138733158400",
    "text" : "Are folks tending toward InstaFace or FaceGram?",
    "id" : 189408138733158400,
    "created_at" : "Mon Apr 09 17:43:13 +0000 2012",
    "user" : {
      "name" : "Brian Snyder",
      "screen_name" : "briansny",
      "protected" : false,
      "id_str" : "239024528",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3158309606/fe7c325924e2d06810aab40b37d49d02_normal.png",
      "id" : 239024528,
      "verified" : false
    }
  },
  "id" : 189413521451261953,
  "created_at" : "Mon Apr 09 18:04:37 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189413298108768257",
  "text" : "Facebook bought instagram??",
  "id" : 189413298108768257,
  "created_at" : "Mon Apr 09 18:03:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 9, 23 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/yx3njJey",
      "expanded_url" : "http://techcrunch.com/2012/04/09/aol-sells-800-patents-for-1-billion-to-microsoft-memo-to-staff/",
      "display_url" : "techcrunch.com/2012/04/09/aol\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "189404011223461888",
  "text" : "Damn. RT @hackernewsbot: AOL Sells 800 Patents For $1 Billion To Microsoft http://t.co/yx3njJey",
  "id" : 189404011223461888,
  "created_at" : "Mon Apr 09 17:26:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 14, 20 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189261140809879552",
  "text" : "I really need @gmail to allow reverse chronological inbox. Sorry to everyone I still owe an email.",
  "id" : 189261140809879552,
  "created_at" : "Mon Apr 09 07:59:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Krasney",
      "screen_name" : "nickkrasney",
      "indices" : [ 0, 12 ],
      "id_str" : "22696850",
      "id" : 22696850
    }, {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 13, 23 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189156564861583360",
  "geo" : {
  },
  "id_str" : "189217533147086848",
  "in_reply_to_user_id" : 22696850,
  "text" : "@nickkrasney @jenny8lee my inner monologue is dominated by corgis",
  "id" : 189217533147086848,
  "in_reply_to_status_id" : 189156564861583360,
  "created_at" : "Mon Apr 09 05:05:50 +0000 2012",
  "in_reply_to_screen_name" : "nickkrasney",
  "in_reply_to_user_id_str" : "22696850",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 3, 9 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189217188043948034",
  "text" : "RT @sacca: If you show kids any mercy during a snowball fight, you're doing their futures a disservice. Or, so I like to convince myself.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "189154680096563203",
    "text" : "If you show kids any mercy during a snowball fight, you're doing their futures a disservice. Or, so I like to convince myself.",
    "id" : 189154680096563203,
    "created_at" : "Mon Apr 09 00:56:04 +0000 2012",
    "user" : {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "protected" : false,
      "id_str" : "586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1771648774/Sacca_profile_normal.jpg",
      "id" : 586,
      "verified" : true
    }
  },
  "id" : 189217188043948034,
  "created_at" : "Mon Apr 09 05:04:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 0, 6 ],
      "id_str" : "14208617",
      "id" : 14208617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188091967165562881",
  "in_reply_to_user_id" : 14208617,
  "text" : "@robgo you'd have to fly a damn lot around CA to justify $9600/yr",
  "id" : 188091967165562881,
  "created_at" : "Fri Apr 06 02:33:14 +0000 2012",
  "in_reply_to_screen_name" : "robgo",
  "in_reply_to_user_id_str" : "14208617",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 8, 14 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/187987670364991489/photo/1",
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/38xwVJ5Z",
      "media_url" : "http://pbs.twimg.com/media/ApvdykrCMAABSpL.jpg",
      "id_str" : "187987670373380096",
      "id" : 187987670373380096,
      "media_url_https" : "https://pbs.twimg.com/media/ApvdykrCMAABSpL.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/38xwVJ5Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187987670364991489",
  "text" : "Awesome @hseas senior thesis: automatic peanut butter and jelly machine! http://t.co/38xwVJ5Z",
  "id" : 187987670364991489,
  "created_at" : "Thu Apr 05 19:38:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MinnCAN",
      "screen_name" : "MinnCAN",
      "indices" : [ 3, 11 ],
      "id_str" : "183073365",
      "id" : 183073365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 106 ],
      "url" : "https://t.co/lLNwf9lo",
      "expanded_url" : "https://rkmc.tmfportal.org/Repository/RKMC/Scoreboard_JapanMN.pdf",
      "display_url" : "rkmc.tmfportal.org/Repository/RKM\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187961686949502976",
  "text" : "RT @MinnCAN: Japanese students spend 243 days a yr in school. MN students spend 172. https://t.co/lLNwf9lo",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 93 ],
        "url" : "https://t.co/lLNwf9lo",
        "expanded_url" : "https://rkmc.tmfportal.org/Repository/RKMC/Scoreboard_JapanMN.pdf",
        "display_url" : "rkmc.tmfportal.org/Repository/RKM\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "187953785484746752",
    "text" : "Japanese students spend 243 days a yr in school. MN students spend 172. https://t.co/lLNwf9lo",
    "id" : 187953785484746752,
    "created_at" : "Thu Apr 05 17:24:09 +0000 2012",
    "user" : {
      "name" : "MinnCAN",
      "screen_name" : "MinnCAN",
      "protected" : false,
      "id_str" : "183073365",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2189927744/Twitter-MinnCAN_normal.gif",
      "id" : 183073365,
      "verified" : false
    }
  },
  "id" : 187961686949502976,
  "created_at" : "Thu Apr 05 17:55:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Tseng",
      "screen_name" : "BenjaminTseng",
      "indices" : [ 3, 17 ],
      "id_str" : "15876871",
      "id" : 15876871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/YrNPlBNN",
      "expanded_url" : "http://lnkd.in/8N6EuM",
      "display_url" : "lnkd.in/8N6EuM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187696223963185154",
  "text" : "RT @BenjaminTseng: Interesting profile of the CEO heir apparent at Microsoft: Steve Sinofsky http://t.co/YrNPlBNN",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.linkedin.com/\" rel=\"nofollow\">LinkedIn</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http://t.co/YrNPlBNN",
        "expanded_url" : "http://lnkd.in/8N6EuM",
        "display_url" : "lnkd.in/8N6EuM"
      } ]
    },
    "geo" : {
    },
    "id_str" : "187693894278975488",
    "text" : "Interesting profile of the CEO heir apparent at Microsoft: Steve Sinofsky http://t.co/YrNPlBNN",
    "id" : 187693894278975488,
    "created_at" : "Thu Apr 05 00:11:26 +0000 2012",
    "user" : {
      "name" : "Benjamin Tseng",
      "screen_name" : "BenjaminTseng",
      "protected" : false,
      "id_str" : "15876871",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2355557182/n0mQ0SQp_normal",
      "id" : 15876871,
      "verified" : false
    }
  },
  "id" : 187696223963185154,
  "created_at" : "Thu Apr 05 00:20:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 0, 7 ],
      "id_str" : "224321197",
      "id" : 224321197
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 8, 20 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187622998033969154",
  "geo" : {
  },
  "id_str" : "187626519005376512",
  "in_reply_to_user_id" : 224321197,
  "text" : "@zhamed @badboyboyce JNJ is my pick right now.",
  "id" : 187626519005376512,
  "in_reply_to_status_id" : 187622998033969154,
  "created_at" : "Wed Apr 04 19:43:42 +0000 2012",
  "in_reply_to_screen_name" : "zhamed",
  "in_reply_to_user_id_str" : "224321197",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Stempeck",
      "screen_name" : "mstem",
      "indices" : [ 3, 9 ],
      "id_str" : "1637181",
      "id" : 1637181
    }, {
      "name" : "Joi Ito",
      "screen_name" : "Joi",
      "indices" : [ 37, 41 ],
      "id_str" : "691353",
      "id" : 691353
    }, {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 76, 85 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187626019090481152",
  "text" : "RT @mstem: So fresh there's no name: @joi announces startup launchtrack for @medialab students with Google, Greylock, and Matrix as part ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joi Ito",
        "screen_name" : "Joi",
        "indices" : [ 26, 30 ],
        "id_str" : "691353",
        "id" : 691353
      }, {
        "name" : "MIT Media Lab",
        "screen_name" : "medialab",
        "indices" : [ 65, 74 ],
        "id_str" : "13982132",
        "id" : 13982132
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLTalks",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "187625810310606848",
    "text" : "So fresh there's no name: @joi announces startup launchtrack for @medialab students with Google, Greylock, and Matrix as partners #MLTalks",
    "id" : 187625810310606848,
    "created_at" : "Wed Apr 04 19:40:53 +0000 2012",
    "user" : {
      "name" : "Matt Stempeck",
      "screen_name" : "mstem",
      "protected" : false,
      "id_str" : "1637181",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3496141147/c164f945b9ca37b9b170c348240f0fc5_normal.jpeg",
      "id" : 1637181,
      "verified" : false
    }
  },
  "id" : 187626019090481152,
  "created_at" : "Wed Apr 04 19:41:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/9mKAEI5c",
      "expanded_url" : "http://www.flickr.com/photos/maoby/sets/72157627624479529/with/6198771927/",
      "display_url" : "flickr.com/photos/maoby/s\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187621037192658944",
  "text" : "Self portraits with digital cameras over the past decade! http://t.co/9mKAEI5c",
  "id" : 187621037192658944,
  "created_at" : "Wed Apr 04 19:21:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/187619721900855298/photo/1",
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/MT0F7Tfu",
      "media_url" : "http://pbs.twimg.com/media/ApqPJJ0CEAICl8L.jpg",
      "id_str" : "187619721905049602",
      "id" : 187619721905049602,
      "media_url_https" : "https://pbs.twimg.com/media/ApqPJJ0CEAICl8L.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 820
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 820
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/MT0F7Tfu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187619721900855298",
  "text" : "Google News, always showing me important stuff. http://t.co/MT0F7Tfu",
  "id" : 187619721900855298,
  "created_at" : "Wed Apr 04 19:16:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/GEQoyIDh",
      "expanded_url" : "http://blog.caranddriver.com/jaguar-announces-new-f-type-will-go-on-sale-in-2013-new-york-auto-show",
      "display_url" : "blog.caranddriver.com/jaguar-announc\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187614858194321408",
  "text" : "The new Jaguar F-type looks like an Aston Martin did the dirty with a Mazda Miata. http://t.co/GEQoyIDh",
  "id" : 187614858194321408,
  "created_at" : "Wed Apr 04 18:57:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187614119661285377",
  "text" : "Note to future-dictator-self: SOPA protests were probably successful because the acronym is easy to remember and chant.",
  "id" : 187614119661285377,
  "created_at" : "Wed Apr 04 18:54:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 47, 57 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/S4Rl9Rdk",
      "expanded_url" : "http://www.buzzfeed.com/katienotopoulos/iphone-users-disgusted-by-android-instagram",
      "display_url" : "buzzfeed.com/katienotopoulo\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187609167316520960",
  "text" : "iPhone users complaining about Android getting @Instagram http://t.co/S4Rl9Rdk HATERS GONNA HATE",
  "id" : 187609167316520960,
  "created_at" : "Wed Apr 04 18:34:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 3, 13 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "Zak Stone",
      "screen_name" : "zakstone",
      "indices" : [ 91, 100 ],
      "id_str" : "18138715",
      "id" : 18138715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187416411814100992",
  "text" : "RT @jenny8lee: Facebook inspired facial recognition. Presentation by Harvard PhD candidate @zakstone. Defense in a month! http://t.co/QO ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zak Stone",
        "screen_name" : "zakstone",
        "indices" : [ 76, 85 ],
        "id_str" : "18138715",
        "id" : 18138715
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/jenny8lee/status/187374149805686784/photo/1",
        "indices" : [ 107, 127 ],
        "url" : "http://t.co/QODjqiqL",
        "media_url" : "http://pbs.twimg.com/media/Apmvy-eCQAEZJmz.jpg",
        "id_str" : "187374149809881089",
        "id" : 187374149809881089,
        "media_url_https" : "https://pbs.twimg.com/media/Apmvy-eCQAEZJmz.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com/QODjqiqL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "187374149805686784",
    "text" : "Facebook inspired facial recognition. Presentation by Harvard PhD candidate @zakstone. Defense in a month! http://t.co/QODjqiqL",
    "id" : 187374149805686784,
    "created_at" : "Wed Apr 04 03:00:54 +0000 2012",
    "user" : {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "protected" : false,
      "id_str" : "1976841",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1842465869/jenny_baby_graduation_cap_cropped_normal.jpg",
      "id" : 1976841,
      "verified" : true
    }
  },
  "id" : 187416411814100992,
  "created_at" : "Wed Apr 04 05:48:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Sacca",
      "screen_name" : "SaccaSacca",
      "indices" : [ 3, 14 ],
      "id_str" : "6095",
      "id" : 6095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sabres",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187356499629182978",
  "text" : "RT @SaccaSacca: If I ever have a heart attack, it will be the result of supporting Buffalo sports franchises. #Sabres",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sabres",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "187355131262668801",
    "text" : "If I ever have a heart attack, it will be the result of supporting Buffalo sports franchises. #Sabres",
    "id" : 187355131262668801,
    "created_at" : "Wed Apr 04 01:45:18 +0000 2012",
    "user" : {
      "name" : "Brian Sacca",
      "screen_name" : "SaccaSacca",
      "protected" : false,
      "id_str" : "6095",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3158149084/ae7bf7e325f2b4c5e6e269f6546d2a27_normal.jpeg",
      "id" : 6095,
      "verified" : false
    }
  },
  "id" : 187356499629182978,
  "created_at" : "Wed Apr 04 01:50:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 47, 56 ],
      "id_str" : "18008249",
      "id" : 18008249
    }, {
      "name" : "danger!awesome",
      "screen_name" : "danger_awesome",
      "indices" : [ 98, 113 ],
      "id_str" : "303407546",
      "id" : 303407546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187223037618307072",
  "text" : "$400+ for a Class Ring is ridiculous, Harvard. @thepunit and I will make our own with the help of @danger_awesome's lasers and some...",
  "id" : 187223037618307072,
  "created_at" : "Tue Apr 03 17:00:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Tseng",
      "screen_name" : "BenjaminTseng",
      "indices" : [ 0, 14 ],
      "id_str" : "15876871",
      "id" : 15876871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187069770611429376",
  "geo" : {
  },
  "id_str" : "187078941985615872",
  "in_reply_to_user_id" : 15876871,
  "text" : "@BenjaminTseng my last four professional email addresses have been based on Google Apps",
  "id" : 187078941985615872,
  "in_reply_to_status_id" : 187069770611429376,
  "created_at" : "Tue Apr 03 07:27:50 +0000 2012",
  "in_reply_to_screen_name" : "BenjaminTseng",
  "in_reply_to_user_id_str" : "15876871",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187055892297035777",
  "text" : "Day 3 with Ice Cream Sandwich and I can't imagine going back to iOS. So many little interface nuances that are a joy to use.",
  "id" : 187055892297035777,
  "created_at" : "Tue Apr 03 05:56:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 33, 42 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/186309575551627264/photo/1",
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/zW1guaKA",
      "media_url" : "http://pbs.twimg.com/media/ApXnkmUCMAEvCjh.jpg",
      "id_str" : "186309575551627265",
      "id" : 186309575551627265,
      "media_url_https" : "https://pbs.twimg.com/media/ApXnkmUCMAEvCjh.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/zW1guaKA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186309575551627264",
  "text" : "Breadboarding on a Saturday with @thepunit. Nothings working. http://t.co/zW1guaKA",
  "id" : 186309575551627264,
  "created_at" : "Sun Apr 01 04:30:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]