Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 119, 133 ],
      "id_str" : "16005250",
      "id" : 16005250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/ui03TGPY",
      "expanded_url" : "http://www.xojane.com/it-happened-to-me/asian-woman-dating-asian-men-jenny-an",
      "display_url" : "xojane.com/it-happened-to\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241629527674064896",
  "text" : "There are many clever, insightful pieces written about Asian dating. This is not one of them. http://t.co/ui03TGPY via @angryasianman",
  "id" : 241629527674064896,
  "created_at" : "Fri Aug 31 20:12:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    }, {
      "name" : "Patrick Thibodeau",
      "screen_name" : "DCgov",
      "indices" : [ 110, 116 ],
      "id_str" : "18024105",
      "id" : 18024105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovation",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "tech",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241580933734608896",
  "text" : "RT @medialab: \u201CThe iPad is about as innovative as a toaster.\u201D - Are we abusing the word #innovation in #tech? @DCgov weighs in  http://t ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patrick Thibodeau",
        "screen_name" : "DCgov",
        "indices" : [ 96, 102 ],
        "id_str" : "18024105",
        "id" : 18024105
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "innovation",
        "indices" : [ 74, 85 ]
      }, {
        "text" : "tech",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http://t.co/mLRQG5IA",
        "expanded_url" : "http://bit.ly/SRXtWu",
        "display_url" : "bit.ly/SRXtWu"
      } ]
    },
    "geo" : {
    },
    "id_str" : "241571188009226243",
    "text" : "\u201CThe iPad is about as innovative as a toaster.\u201D - Are we abusing the word #innovation in #tech? @DCgov weighs in  http://t.co/mLRQG5IA",
    "id" : 241571188009226243,
    "created_at" : "Fri Aug 31 16:20:34 +0000 2012",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 241580933734608896,
  "created_at" : "Fri Aug 31 16:59:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/241308493825589248/photo/1",
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/C3Jey906",
      "media_url" : "http://pbs.twimg.com/media/A1lMy_ACQAA2CLu.jpg",
      "id_str" : "241308493829783552",
      "id" : 241308493829783552,
      "media_url_https" : "https://pbs.twimg.com/media/A1lMy_ACQAA2CLu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com/C3Jey906"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241308493825589248",
  "text" : "Looks like someone on the Nexus 7 team didn't do their job. http://t.co/C3Jey906",
  "id" : 241308493825589248,
  "created_at" : "Thu Aug 30 22:56:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/i0pMcXU9",
      "expanded_url" : "http://www.engadget.com/2012/08/29/google-plus-business/",
      "display_url" : "engadget.com/2012/08/29/goo\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241291035760799744",
  "text" : "Called it. Google+ can be the SharePoint of the Google Docs suite. http://t.co/i0pMcXU9",
  "id" : 241291035760799744,
  "created_at" : "Thu Aug 30 21:47:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241001390510571520",
  "text" : "I'm playing Adobe Illustrator in hard mode: full screen, no menus, no toolbars. Keystrokes and mouse only.",
  "id" : 241001390510571520,
  "created_at" : "Thu Aug 30 02:36:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/Bdfx0bDQ",
      "expanded_url" : "http://dealbreaker.com/2012/08/d-e-shaw-geniuses-build-their-greatest-model-yet/",
      "display_url" : "dealbreaker.com/2012/08/d-e-sh\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240993634739179520",
  "text" : "DE Shaw quants model the line at Chipotle, \"are really excited about how accurate it is.\" http://t.co/Bdfx0bDQ",
  "id" : 240993634739179520,
  "created_at" : "Thu Aug 30 02:05:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/240987646392930304/photo/1",
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/mFRR0CFy",
      "media_url" : "http://pbs.twimg.com/media/A1go_NLCEAEeUwp.jpg",
      "id_str" : "240987646397124609",
      "id" : 240987646397124609,
      "media_url_https" : "https://pbs.twimg.com/media/A1go_NLCEAEeUwp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com/mFRR0CFy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240987646392930304",
  "text" : "Watch restoration project: an all original, 70's Seiko 'Pogue' 6139 chronograph - the humblest space watch. http://t.co/mFRR0CFy",
  "id" : 240987646392930304,
  "created_at" : "Thu Aug 30 01:41:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 105, 114 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/Zn9Af51L",
      "expanded_url" : "http://www.citrix.com/English/NE/news/news.asp?newsID=2328309",
      "display_url" : "citrix.com/English/NE/new\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240921242788564993",
  "text" : "51% think weather affects cloud computing; 17% pretend to understand it on first date. No, it's not from @TheOnion. http://t.co/Zn9Af51L",
  "id" : 240921242788564993,
  "created_at" : "Wed Aug 29 21:17:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 8, 20 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/apHSbACH",
      "expanded_url" : "http://www.reddit.com/r/IAmA/comments/z1c9z/i_am_barack_obama_president_of_the_united_states/",
      "display_url" : "reddit.com/r/IAmA/comment\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240913774616399872",
  "text" : "I think @BarackObama overloaded Reddit's servers with his AMA... http://t.co/apHSbACH",
  "id" : 240913774616399872,
  "created_at" : "Wed Aug 29 20:48:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/zDlyHfdk",
      "expanded_url" : "http://www.theverge.com/2012/8/29/3276302/samsung-galaxy-camera-announcement",
      "display_url" : "theverge.com/2012/8/29/3276\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240888466253168640",
  "text" : "Hot on Nikon's heels, Samsung to release Android powered camera. http://t.co/zDlyHfdk",
  "id" : 240888466253168640,
  "created_at" : "Wed Aug 29 19:07:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aziz Ansari",
      "screen_name" : "azizansari",
      "indices" : [ 3, 14 ],
      "id_str" : "6480682",
      "id" : 6480682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240692253570527232",
  "text" : "RT @azizansari: Let's have a moment of silence for all the chubby Asian dudes that are getting 'Gangnam style!' yelled at them by bros a ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240192682130038784",
    "text" : "Let's have a moment of silence for all the chubby Asian dudes that are getting 'Gangnam style!' yelled at them by bros around the world.",
    "id" : 240192682130038784,
    "created_at" : "Mon Aug 27 21:02:52 +0000 2012",
    "user" : {
      "name" : "Aziz Ansari",
      "screen_name" : "azizansari",
      "protected" : false,
      "id_str" : "6480682",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/421377161/azizlittletwitter_normal.jpg",
      "id" : 6480682,
      "verified" : true
    }
  },
  "id" : 240692253570527232,
  "created_at" : "Wed Aug 29 06:07:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Levitan",
      "screen_name" : "SteveLevitan",
      "indices" : [ 3, 16 ],
      "id_str" : "13190642",
      "id" : 13190642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240659025333739521",
  "text" : "RT @SteveLevitan: Thrilled Ann Romney says ModFam is her favorite show. We'll offer her the role of officiant at Mitch &amp; Cam's weddi ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240514395938111488",
    "text" : "Thrilled Ann Romney says ModFam is her favorite show. We'll offer her the role of officiant at Mitch &amp; Cam's wedding. As soon as it's legal.",
    "id" : 240514395938111488,
    "created_at" : "Tue Aug 28 18:21:15 +0000 2012",
    "user" : {
      "name" : "Steve Levitan",
      "screen_name" : "SteveLevitan",
      "protected" : false,
      "id_str" : "13190642",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/424603402/sltwitter_normal.jpg",
      "id" : 13190642,
      "verified" : true
    }
  },
  "id" : 240659025333739521,
  "created_at" : "Wed Aug 29 03:55:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Relevant Organs",
      "screen_name" : "relevantorgans",
      "indices" : [ 3, 18 ],
      "id_str" : "86975611",
      "id" : 86975611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240648796567109633",
  "text" : "RT @relevantorgans: And Americans have to endure this twice every four years? How have your people not insisted on single party government?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240639784677150721",
    "text" : "And Americans have to endure this twice every four years? How have your people not insisted on single party government?",
    "id" : 240639784677150721,
    "created_at" : "Wed Aug 29 02:39:30 +0000 2012",
    "user" : {
      "name" : "The Relevant Organs",
      "screen_name" : "relevantorgans",
      "protected" : false,
      "id_str" : "86975611",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1069675605/TRO_normal.jpg",
      "id" : 86975611,
      "verified" : false
    }
  },
  "id" : 240648796567109633,
  "created_at" : "Wed Aug 29 03:15:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cenciotti",
      "screen_name" : "cencio4",
      "indices" : [ 3, 11 ],
      "id_str" : "53138772",
      "id" : 53138772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240549794840444930",
  "text" : "RT @cencio4: Drone Revolution has just begun: Poland to replace Su-22 Fitter strike fighters with Unmanned Combat Aerial Vehicles http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://publicize.wp.com/\" rel=\"nofollow\">WordPress.com</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/pzF7UTxO",
        "expanded_url" : "http://wp.me/pEfC-3t1",
        "display_url" : "wp.me/pEfC-3t1"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240537866210521088",
    "text" : "Drone Revolution has just begun: Poland to replace Su-22 Fitter strike fighters with Unmanned Combat Aerial Vehicles http://t.co/pzF7UTxO",
    "id" : 240537866210521088,
    "created_at" : "Tue Aug 28 19:54:30 +0000 2012",
    "user" : {
      "name" : "David Cenciotti",
      "screen_name" : "cencio4",
      "protected" : false,
      "id_str" : "53138772",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611341129/qe0q5pulni76vevrxjww_normal.jpeg",
      "id" : 53138772,
      "verified" : false
    }
  },
  "id" : 240549794840444930,
  "created_at" : "Tue Aug 28 20:41:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BostInnovation",
      "screen_name" : "BostInnovation",
      "indices" : [ 38, 53 ],
      "id_str" : "1056260852",
      "id" : 1056260852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/0ufkib8z",
      "expanded_url" : "http://bit.ly/Ppffv8",
      "display_url" : "bit.ly/Ppffv8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240549119087751168",
  "text" : "Carpe Diem for dumb people. And no. RT@BostInnovation: What is YOLO? Do we need to analyze the phrase? http://t.co/0ufkib8z",
  "id" : 240549119087751168,
  "created_at" : "Tue Aug 28 20:39:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/c8u0WvIx",
      "expanded_url" : "http://blogs.wsj.com/speakeasy/2012/08/28/gangnam-style-viral-popularity-in-u-s-has-koreans-puzzled-gratified/",
      "display_url" : "blogs.wsj.com/speakeasy/2012\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240493444001300481",
  "text" : "Korean bewilderment at the overseas popularity of Gangam Style. http://t.co/c8u0WvIx",
  "id" : 240493444001300481,
  "created_at" : "Tue Aug 28 16:57:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "indices" : [ 3, 19 ],
      "id_str" : "353789193",
      "id" : 353789193
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 30, 38 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240352285237080064",
  "text" : "RT @StartupLJackson: All this @twitter angst is such inside baseball. They need a monopoly on the UX  for $$ and the 99% doesn't care. D ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 9, 17 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240282413710860288",
    "text" : "All this @twitter angst is such inside baseball. They need a monopoly on the UX  for $$ and the 99% doesn't care. Deal bitches.",
    "id" : 240282413710860288,
    "created_at" : "Tue Aug 28 02:59:26 +0000 2012",
    "user" : {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "protected" : false,
      "id_str" : "353789193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1491792938/Screen_shot_2011-08-12_at_9.54.22_AM_normal.png",
      "id" : 353789193,
      "verified" : false
    }
  },
  "id" : 240352285237080064,
  "created_at" : "Tue Aug 28 07:37:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240244691113766914",
  "text" : "Who thought that Motorola Droid RAZR M 4G LTE would be a good name for a phone? Protip: if you can't say it in one breath, it's a bad name.",
  "id" : 240244691113766914,
  "created_at" : "Tue Aug 28 00:29:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/240230379062177792/photo/1",
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/3vL93SXH",
      "media_url" : "http://pbs.twimg.com/media/A1V4QciCMAE-YmZ.jpg",
      "id_str" : "240230379066372097",
      "id" : 240230379066372097,
      "media_url_https" : "https://pbs.twimg.com/media/A1V4QciCMAE-YmZ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com/3vL93SXH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240230379062177792",
  "text" : "It seems Apple chose a Mondaine dial for the clocks in iOS6. http://t.co/3vL93SXH",
  "id" : 240230379062177792,
  "created_at" : "Mon Aug 27 23:32:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "indices" : [ 3, 13 ],
      "id_str" : "5668942",
      "id" : 5668942
    }, {
      "name" : "PandoDaily",
      "screen_name" : "PandoDaily",
      "indices" : [ 113, 124 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/9NPhL4Yl",
      "expanded_url" : "http://pandodaily.com/2012/08/27/with-40m-series-b-momo-proves-huge-market-for-casual-hook-ups-in-china/",
      "display_url" : "pandodaily.com/2012/08/27/wit\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240172444680335360",
  "text" : "RT @sarahcuda: With $40m Series B, Momo Proves Huge Market for Casual Hook-ups in China http://t.co/9NPhL4Yl via @pandodaily",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PandoDaily",
        "screen_name" : "PandoDaily",
        "indices" : [ 98, 109 ],
        "id_str" : "419710142",
        "id" : 419710142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/9NPhL4Yl",
        "expanded_url" : "http://pandodaily.com/2012/08/27/with-40m-series-b-momo-proves-huge-market-for-casual-hook-ups-in-china/",
        "display_url" : "pandodaily.com/2012/08/27/wit\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240170508895780864",
    "text" : "With $40m Series B, Momo Proves Huge Market for Casual Hook-ups in China http://t.co/9NPhL4Yl via @pandodaily",
    "id" : 240170508895780864,
    "created_at" : "Mon Aug 27 19:34:46 +0000 2012",
    "user" : {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "protected" : false,
      "id_str" : "5668942",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1763460129/lacy_normal.jpg",
      "id" : 5668942,
      "verified" : false
    }
  },
  "id" : 240172444680335360,
  "created_at" : "Mon Aug 27 19:42:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Howard Getson",
      "screen_name" : "hgetson",
      "indices" : [ 54, 62 ],
      "id_str" : "14136886",
      "id" : 14136886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/D72DeVSk",
      "expanded_url" : "http://bit.ly/QHjNfl",
      "display_url" : "bit.ly/QHjNfl"
    } ]
  },
  "in_reply_to_status_id_str" : "239861771270250496",
  "geo" : {
  },
  "id_str" : "239869363950329858",
  "in_reply_to_user_id" : 14136886,
  "text" : "Misleading. All stocks down 8/11 bc budget crisis. RT @hgetson: Apple Stock Rose 77% First Year Under CEO Tim Cook. http://t.co/D72DeVSk",
  "id" : 239869363950329858,
  "in_reply_to_status_id" : 239861771270250496,
  "created_at" : "Sun Aug 26 23:38:07 +0000 2012",
  "in_reply_to_screen_name" : "hgetson",
  "in_reply_to_user_id_str" : "14136886",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239866238044631041",
  "text" : "Discovered the app ChineseFoodMap - much better than Yelp for Chinese food!",
  "id" : 239866238044631041,
  "created_at" : "Sun Aug 26 23:25:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/mpUfbxy9",
      "expanded_url" : "http://www.androidpolice.com/2012/08/21/samsung-galaxy-note-10-1-review-an-embarrassing-lazy-arrogant-money-grab/",
      "display_url" : "androidpolice.com/2012/08/21/sam\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239853787613908992",
  "text" : "Despite some slick multitasking enhancements, Samsung totally drops the ball with build quality with the Note 10.1. http://t.co/mpUfbxy9",
  "id" : 239853787613908992,
  "created_at" : "Sun Aug 26 22:36:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239545398170103808",
  "text" : "Does anyone know a good watch restorer in NY or Boston?",
  "id" : 239545398170103808,
  "created_at" : "Sun Aug 26 02:10:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 0, 6 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239525236150779904",
  "geo" : {
  },
  "id_str" : "239527408129171456",
  "in_reply_to_user_id" : 586,
  "text" : "@sacca I think your nephew solved the sorites paradox.",
  "id" : 239527408129171456,
  "in_reply_to_status_id" : 239525236150779904,
  "created_at" : "Sun Aug 26 00:59:18 +0000 2012",
  "in_reply_to_screen_name" : "sacca",
  "in_reply_to_user_id_str" : "586",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/HlaooRaz",
      "expanded_url" : "http://www.lettersofnote.com/2010/11/in-event-of-moon-disaster.html",
      "display_url" : "lettersofnote.com/2010/11/in-eve\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239506558768263169",
  "text" : "If Neil hadn't made it, \"...[all] will know that there is some corner of another world that is forever mankind.\" RIP. http://t.co/HlaooRaz",
  "id" : 239506558768263169,
  "created_at" : "Sat Aug 25 23:36:28 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239441309558001665",
  "text" : "This has been a roller coaster year for space exploration. RIP, Neil Armstrong.",
  "id" : 239441309558001665,
  "created_at" : "Sat Aug 25 19:17:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GQ Magazine",
      "screen_name" : "GQMagazine",
      "indices" : [ 53, 64 ],
      "id_str" : "21701757",
      "id" : 21701757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/S515LYOs",
      "expanded_url" : "http://gqm.ag/OAkUji",
      "display_url" : "gqm.ag/OAkUji"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239427035682967552",
  "text" : "Relevant to some followers. You know who you are. RT @GQMagazine: Stop. Instagramming. Food. http://t.co/S515LYOs",
  "id" : 239427035682967552,
  "created_at" : "Sat Aug 25 18:20:28 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smart",
      "indices" : [ 62, 68 ]
    }, {
      "text" : "poor",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239284738479751168",
  "text" : "Kindle for Nexus 7 has made books a Friday night impulse buy. #smart #poor",
  "id" : 239284738479751168,
  "created_at" : "Sat Aug 25 08:55:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 3, 12 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239246781215559680",
  "text" : "RT @Romotive: Wanted: Killer marcomm engineer. Experienced. All channels (social, print, web). Nice salary, unlimited robots as perks... ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "239202446486929408",
    "text" : "Wanted: Killer marcomm engineer. Experienced. All channels (social, print, web). Nice salary, unlimited robots as perks...Holler!",
    "id" : 239202446486929408,
    "created_at" : "Sat Aug 25 03:28:02 +0000 2012",
    "user" : {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "protected" : false,
      "id_str" : "340545195",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2180791949/romo_normal.jpg",
      "id" : 340545195,
      "verified" : false
    }
  },
  "id" : 239246781215559680,
  "created_at" : "Sat Aug 25 06:24:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erick Erickson",
      "screen_name" : "EWErickson",
      "indices" : [ 3, 14 ],
      "id_str" : "640893",
      "id" : 640893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239133277368233985",
  "text" : "RT @EWErickson: Obama camp says Romney is a felon then denies saying it.  Romney gets to joke about Obama's birth certificate.  Everybod ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "239055445854154752",
    "text" : "Obama camp says Romney is a felon then denies saying it.  Romney gets to joke about Obama's birth certificate.  Everybody grow up now.",
    "id" : 239055445854154752,
    "created_at" : "Fri Aug 24 17:43:54 +0000 2012",
    "user" : {
      "name" : "Erick Erickson",
      "screen_name" : "EWErickson",
      "protected" : false,
      "id_str" : "640893",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1603497376/image_normal.jpg",
      "id" : 640893,
      "verified" : true
    }
  },
  "id" : 239133277368233985,
  "created_at" : "Fri Aug 24 22:53:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakerBot",
      "screen_name" : "makerbot",
      "indices" : [ 39, 48 ],
      "id_str" : "22021097",
      "id" : 22021097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/yLMhyKLk",
      "expanded_url" : "http://www.wired.com/design/tag/tangibot/",
      "display_url" : "wired.com/design/tag/tan\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238793481160630272",
  "text" : "TangiBot is a clone of the open source @MakerBot Replicator. Legal, but is it right? http://t.co/yLMhyKLk",
  "id" : 238793481160630272,
  "created_at" : "Fri Aug 24 00:22:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hippeau",
      "screen_name" : "erichippeau",
      "indices" : [ 13, 25 ],
      "id_str" : "29795220",
      "id" : 29795220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238756238656143360",
  "text" : "Air Race. RT @erichippeau: No amateur can drive F1. Re: I wonder what sport has greatest difference bt world's elite &amp; median amateur.",
  "id" : 238756238656143360,
  "created_at" : "Thu Aug 23 21:54:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238724450646896640",
  "text" : "I'm going to open Boba Fret, a Star Wars themed bubble tea jazz bar. Who wants to back me?",
  "id" : 238724450646896640,
  "created_at" : "Thu Aug 23 19:48:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Stempeck",
      "screen_name" : "mstem",
      "indices" : [ 0, 6 ],
      "id_str" : "1637181",
      "id" : 1637181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238352935858356225",
  "geo" : {
  },
  "id_str" : "238399791216869376",
  "in_reply_to_user_id" : 1637181,
  "text" : "@mstem after working at big tech companies I'm amazed at how much of our digital world is held together by spit, duct tape, and prayers.",
  "id" : 238399791216869376,
  "in_reply_to_status_id" : 238352935858356225,
  "created_at" : "Wed Aug 22 22:18:34 +0000 2012",
  "in_reply_to_screen_name" : "mstem",
  "in_reply_to_user_id_str" : "1637181",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/238351421496520704/photo/1",
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/eDrbHgAW",
      "media_url" : "http://pbs.twimg.com/media/A07LWuJCcAA0w4G.jpg",
      "id_str" : "238351421500715008",
      "id" : 238351421500715008,
      "media_url_https" : "https://pbs.twimg.com/media/A07LWuJCcAA0w4G.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com/eDrbHgAW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238351421496520704",
  "text" : "Did you know the iPhone App Store is just a webview? I didn't until I broke its CSS. http://t.co/eDrbHgAW",
  "id" : 238351421496520704,
  "created_at" : "Wed Aug 22 19:06:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McDowall",
      "screen_name" : "fogonwater",
      "indices" : [ 13, 24 ],
      "id_str" : "20462308",
      "id" : 20462308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/B41YHZAy",
      "expanded_url" : "http://rainbow.aws.af.cm/",
      "display_url" : "rainbow.aws.af.cm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238349495442763777",
  "text" : "Playing with @fogonwater's Uncertain Rainbow project. \"Twitter Sans Ego.\" http://t.co/B41YHZAy",
  "id" : 238349495442763777,
  "created_at" : "Wed Aug 22 18:58:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/238346564643471360/photo/1",
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/dNyNrDwf",
      "media_url" : "http://pbs.twimg.com/media/A07G8A9CQAEx3Ai.jpg",
      "id_str" : "238346564647665665",
      "id" : 238346564647665665,
      "media_url_https" : "https://pbs.twimg.com/media/A07G8A9CQAEx3Ai.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/dNyNrDwf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238346564643471360",
  "text" : "Made my own bubble tea for the first time. I have opened pandoras box. http://t.co/dNyNrDwf",
  "id" : 238346564643471360,
  "created_at" : "Wed Aug 22 18:47:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 0, 12 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238057741434896384",
  "geo" : {
  },
  "id_str" : "238089264842285056",
  "in_reply_to_user_id" : 7782442,
  "text" : "@christinelu Uh oh, he now knows it's profitable to extort you. It's why the US doesn't negotiate with terrorists!",
  "id" : 238089264842285056,
  "in_reply_to_status_id" : 238057741434896384,
  "created_at" : "Wed Aug 22 01:44:38 +0000 2012",
  "in_reply_to_screen_name" : "christinelu",
  "in_reply_to_user_id_str" : "7782442",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 36, 44 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237984253164519425",
  "text" : "A significant number of my friends' @twitter accounts were hijacked today for malicious DMs. Anyone know the root cause?",
  "id" : 237984253164519425,
  "created_at" : "Tue Aug 21 18:47:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/CtuANIM4",
      "expanded_url" : "http://bikeexif.com",
      "display_url" : "bikeexif.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237955462203580417",
  "text" : "Fantastic cafe racers I've been browsing all day. Gearhead porn at its finest. http://t.co/CtuANIM4",
  "id" : 237955462203580417,
  "created_at" : "Tue Aug 21 16:52:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "damien katz",
      "screen_name" : "damienkatz",
      "indices" : [ 3, 14 ],
      "id_str" : "77827772",
      "id" : 77827772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237951983754022914",
  "text" : "RT @damienkatz: A machine dispensing udp packets had a sign saying \"Out of Order\" (the great thing about udp jokes is I don't care if yo ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "236325271567994880",
    "text" : "A machine dispensing udp packets had a sign saying \"Out of Order\" (the great thing about udp jokes is I don't care if you get them)",
    "id" : 236325271567994880,
    "created_at" : "Fri Aug 17 04:55:10 +0000 2012",
    "user" : {
      "name" : "damien katz",
      "screen_name" : "damienkatz",
      "protected" : false,
      "id_str" : "77827772",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2722425409/769c7995ead332b48e3a6c8adead191c_normal.jpeg",
      "id" : 77827772,
      "verified" : false
    }
  },
  "id" : 237951983754022914,
  "created_at" : "Tue Aug 21 16:39:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237708532026327041",
  "text" : "RT @parislemon: In terms of market cap, Apple is now worth a Google more than Exxon.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "237703331169042432",
    "text" : "In terms of market cap, Apple is now worth a Google more than Exxon.",
    "id" : 237703331169042432,
    "created_at" : "Tue Aug 21 00:11:05 +0000 2012",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3336694463/99718483afb19d6d441290afccb72772_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 237708532026327041,
  "created_at" : "Tue Aug 21 00:31:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/aUwifbTJ",
      "expanded_url" : "http://blog.kanehsieh.com/2012/08/20/making-the-ideal-wedding-gift/",
      "display_url" : "blog.kanehsieh.com/2012/08/20/mak\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237684009583382529",
  "text" : "My thoughts on making a wedding gift. http://t.co/aUwifbTJ",
  "id" : 237684009583382529,
  "created_at" : "Mon Aug 20 22:54:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kiwiana Restaurant",
      "screen_name" : "KiwianaNYC",
      "indices" : [ 28, 39 ],
      "id_str" : "311728535",
      "id" : 311728535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237681849579741184",
  "text" : "Happy one year anniversary, @KiwianaNYC! Sorry to miss the dinner.",
  "id" : 237681849579741184,
  "created_at" : "Mon Aug 20 22:45:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Walnes",
      "screen_name" : "joewalnes",
      "indices" : [ 3, 13 ],
      "id_str" : "14770578",
      "id" : 14770578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237343095967059971",
  "text" : "RT @joewalnes: Lego Duplo + Brio track + 3D printed Duplo/Brio adapters = Bigger bridges. Ewan is building faster than I can print. http ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/joewalnes/status/237284322724433920/photo/1",
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/KUGcP7h9",
        "media_url" : "http://pbs.twimg.com/media/A0sA1ZpCUAAeSEL.jpg",
        "id_str" : "237284322783154176",
        "id" : 237284322783154176,
        "media_url_https" : "https://pbs.twimg.com/media/A0sA1ZpCUAAeSEL.jpg",
        "sizes" : [ {
          "h" : 484,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 648
        } ],
        "display_url" : "pic.twitter.com/KUGcP7h9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "237284322724433920",
    "text" : "Lego Duplo + Brio track + 3D printed Duplo/Brio adapters = Bigger bridges. Ewan is building faster than I can print. http://t.co/KUGcP7h9",
    "id" : 237284322724433920,
    "created_at" : "Sun Aug 19 20:26:06 +0000 2012",
    "user" : {
      "name" : "Joe Walnes",
      "screen_name" : "joewalnes",
      "protected" : false,
      "id_str" : "14770578",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1947402120/joewalnes-photo_normal.jpg",
      "id" : 14770578,
      "verified" : false
    }
  },
  "id" : 237343095967059971,
  "created_at" : "Mon Aug 20 00:19:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakerBot",
      "screen_name" : "makerbot",
      "indices" : [ 26, 35 ],
      "id_str" : "22021097",
      "id" : 22021097
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/236187493710585856/photo/1",
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/OeYDj1WA",
      "media_url" : "http://pbs.twimg.com/media/A0cbRi9CYAAGHlo.jpg",
      "id_str" : "236187493714780160",
      "id" : 236187493714780160,
      "media_url_https" : "https://pbs.twimg.com/media/A0cbRi9CYAAGHlo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/OeYDj1WA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236187493710585856",
  "text" : "Printed a shot glass with @MakerBot. Does anyone know if ethanol leaches ABS plastic? http://t.co/OeYDj1WA",
  "id" : 236187493710585856,
  "created_at" : "Thu Aug 16 19:47:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/28iES9AG",
      "expanded_url" : "http://www.engadget.com/2012/08/16/xiaomi-phone-2-quad-core/",
      "display_url" : "engadget.com/2012/08/16/xia\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236151769909055488",
  "text" : "Made in Japan and Switzerland used be signs of poor quality. Xiaomi's phones might be changing Made in China. http://t.co/28iES9AG",
  "id" : 236151769909055488,
  "created_at" : "Thu Aug 16 17:25:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perspective",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236146380513628160",
  "text" : "I have access to more computing power while I poop than all of NASA in the 60s. #perspective",
  "id" : 236146380513628160,
  "created_at" : "Thu Aug 16 17:04:19 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 3, 9 ],
      "id_str" : "17856596",
      "id" : 17856596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235601276874919937",
  "text" : "RT @Wayne: The PR value of Uber getting served in Cambridge is phenomenal. Community rallies, revenue soars, more happy riders. Go Uber!",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235597715214569472",
    "text" : "The PR value of Uber getting served in Cambridge is phenomenal. Community rallies, revenue soars, more happy riders. Go Uber!",
    "id" : 235597715214569472,
    "created_at" : "Wed Aug 15 04:44:07 +0000 2012",
    "user" : {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "protected" : false,
      "id_str" : "17856596",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3472053434/8cecfad95a11c1f1ede129b33c0b4fef_normal.jpeg",
      "id" : 17856596,
      "verified" : false
    }
  },
  "id" : 235601276874919937,
  "created_at" : "Wed Aug 15 04:58:16 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1698202775, -115.1398724144 ]
  },
  "id_str" : "235521073221873664",
  "text" : "Idea: Tvmblr.co - a subscription-based social-shopping and blogging platform for online-only curated cat fashion accessory packs monthly.",
  "id" : 235521073221873664,
  "created_at" : "Tue Aug 14 23:39:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1696130437, -115.139968909 ]
  },
  "id_str" : "235413652201689089",
  "text" : "I don't mean just those cruddy little lenses for iPhone; I mean a real set of optics &amp; large sensor, like a Ricoh GXR module for iPhone.",
  "id" : 235413652201689089,
  "created_at" : "Tue Aug 14 16:32:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1698846502, -115.1397957542 ]
  },
  "id_str" : "235413249363935234",
  "text" : "Imagine: a sensor and lens mount that your iPhone docks into to function as screen &amp; image processor. BAM instant high end camera.",
  "id" : 235413249363935234,
  "created_at" : "Tue Aug 14 16:31:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1258609314, -115.2036764939 ]
  },
  "id_str" : "235154327185022976",
  "text" : "Why are there no make-your-own pizza restaurants?",
  "id" : 235154327185022976,
  "created_at" : "Mon Aug 13 23:22:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Liang",
      "screen_name" : "daveliang",
      "indices" : [ 98, 108 ],
      "id_str" : "20615976",
      "id" : 20615976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.108901349, -115.1743462159 ]
  },
  "id_str" : "234737020692463616",
  "text" : "Shanghai Restoration Project playing on repeat in China Poblano at the Cosmo LV. They really like @daveliang here.",
  "id" : 234737020692463616,
  "created_at" : "Sun Aug 12 19:44:01 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233645541349806081",
  "text" : "Chick-Fil-A doesn't support gay rights. Papa John's doesn't support universal health care. Apparently fast food is how you engage Americans.",
  "id" : 233645541349806081,
  "created_at" : "Thu Aug 09 19:26:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ramesh Raskar",
      "screen_name" : "raskarmit",
      "indices" : [ 9, 19 ],
      "id_str" : "47768825",
      "id" : 47768825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/lx1FitSX",
      "expanded_url" : "http://www.engadget.com/2012/08/09/mit-media-labs-tensor-displays-hands-on/",
      "display_url" : "engadget.com/2012/08/09/mit\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233637592128712704",
  "text" : "Congrats @raskarmit and the Camera Culture Lab for an awesome demo at SIGGRAPH! http://t.co/lx1FitSX",
  "id" : 233637592128712704,
  "created_at" : "Thu Aug 09 18:55:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1696232377, -115.1393538316 ]
  },
  "id_str" : "233598420445704192",
  "text" : "Starbucks adopting Square shows that sexy counts. Intuit has the same product but with better hardware and software integration.",
  "id" : 233598420445704192,
  "created_at" : "Thu Aug 09 16:19:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/U9HzSFUV",
      "expanded_url" : "http://www.wired.com/gadgetlab/2012/08/if-theres-a-screw-theres-a-way-custom-screws-wont-stop-the-diy-community/",
      "display_url" : "wired.com/gadgetlab/2012\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233450647817711616",
  "text" : "\"Why Apple\u2019s Custom iPhone Screws Can\u2019t Stop the DIY Community\" - or really, anyone with a steady hand and dremel. http://t.co/U9HzSFUV",
  "id" : 233450647817711616,
  "created_at" : "Thu Aug 09 06:32:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travelocity",
      "screen_name" : "travelocity",
      "indices" : [ 1, 13 ],
      "id_str" : "18819574",
      "id" : 18819574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232896682415751169",
  "text" : ".@travelocity can't do anything right - cancelled flight without confirmation, credit disappeared, customer service can't find my email.",
  "id" : 232896682415751169,
  "created_at" : "Tue Aug 07 17:51:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Rogers",
      "screen_name" : "jetjocko",
      "indices" : [ 3, 12 ],
      "id_str" : "18955413",
      "id" : 18955413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232887508583727104",
  "text" : "RT @jetjocko: Hey, Zombie Neuroscience Writer! What's your story about this week? \"Braaiiinnns.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232884783489896448",
    "text" : "Hey, Zombie Neuroscience Writer! What's your story about this week? \"Braaiiinnns.\"",
    "id" : 232884783489896448,
    "created_at" : "Tue Aug 07 17:03:53 +0000 2012",
    "user" : {
      "name" : "Adam Rogers",
      "screen_name" : "jetjocko",
      "protected" : false,
      "id_str" : "18955413",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1283210272/Snapshot_2_normal.jpg",
      "id" : 18955413,
      "verified" : false
    }
  },
  "id" : 232887508583727104,
  "created_at" : "Tue Aug 07 17:14:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BAE Systems, Inc.",
      "screen_name" : "BAESystemsInc",
      "indices" : [ 1, 15 ],
      "id_str" : "50446312",
      "id" : 50446312
    }, {
      "name" : "Lockheed Martin",
      "screen_name" : "LockheedMartin",
      "indices" : [ 47, 62 ],
      "id_str" : "42871498",
      "id" : 42871498
    }, {
      "name" : "The Boeing Company",
      "screen_name" : "Boeing",
      "indices" : [ 66, 73 ],
      "id_str" : "25103967",
      "id" : 25103967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1696318818, -115.1399004269 ]
  },
  "id_str" : "232728309849542656",
  "text" : ".@BAESystemsInc's website is a LOT sexier than @LockheedMartin's, @Boeing's, and Northrup's.",
  "id" : 232728309849542656,
  "created_at" : "Tue Aug 07 06:42:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1701825157, -115.1395438669 ]
  },
  "id_str" : "232506618187751425",
  "text" : "Putting a robot on Mars via skycrane from a mach 4 approach, and getting AT&amp;T service in my bathroom. One of these is a solved problem.",
  "id" : 232506618187751425,
  "created_at" : "Mon Aug 06 16:01:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 4, 13 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/232344671215562752/photo/1",
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/XWvs6q7M",
      "media_url" : "http://pbs.twimg.com/media/Azl0P1nCMAEomp9.jpg",
      "id_str" : "232344671223951361",
      "id" : 232344671223951361,
      "media_url_https" : "https://pbs.twimg.com/media/Azl0P1nCMAEomp9.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com/XWvs6q7M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232344671215562752",
  "text" : "The @Romotive team watching the Curiosity rover landing with pizza and beer. You know, living the Vegas life. http://t.co/XWvs6q7M",
  "id" : 232344671215562752,
  "created_at" : "Mon Aug 06 05:17:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "addict",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232223426163666944",
  "text" : "I had a dream that someone stole my iphone, and it was the most distressing thing to happen to me in recent memory. #addict",
  "id" : 232223426163666944,
  "created_at" : "Sun Aug 05 21:15:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 3, 15 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 22, 29 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "Yangbo Du",
      "screen_name" : "mitgc_cm",
      "indices" : [ 39, 48 ],
      "id_str" : "423888869",
      "id" : 423888869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SBNY12",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "passion",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "MadeinBuffalo",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232222769117536256",
  "text" : "RT @badboyboyce: Like @khsieh &gt;&gt; @mitgc_cm: #SBNY12 People in Buffalo have #passion for their city. #MadeinBuffalo channels that p ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 5, 12 ],
        "id_str" : "111999960",
        "id" : 111999960
      }, {
        "name" : "Yangbo Du",
        "screen_name" : "mitgc_cm",
        "indices" : [ 22, 31 ],
        "id_str" : "423888869",
        "id" : 423888869
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SBNY12",
        "indices" : [ 33, 40 ]
      }, {
        "text" : "passion",
        "indices" : [ 64, 72 ]
      }, {
        "text" : "MadeinBuffalo",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232204078736879616",
    "text" : "Like @khsieh &gt;&gt; @mitgc_cm: #SBNY12 People in Buffalo have #passion for their city. #MadeinBuffalo channels that pride towards action",
    "id" : 232204078736879616,
    "created_at" : "Sun Aug 05 19:59:01 +0000 2012",
    "user" : {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "protected" : false,
      "id_str" : "110823121",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1736585624/HaLongBay_Profile_Thumbnail_normal.jpg",
      "id" : 110823121,
      "verified" : false
    }
  },
  "id" : 232222769117536256,
  "created_at" : "Sun Aug 05 21:13:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1697672228, -115.1391589668 ]
  },
  "id_str" : "231961570723393536",
  "text" : "The Apple MagSafe 2's magnet is a little to strong for me to be comfortable around it with a mechanical watch.",
  "id" : 231961570723393536,
  "created_at" : "Sun Aug 05 03:55:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conan O'Brien",
      "screen_name" : "ConanOBrien",
      "indices" : [ 3, 15 ],
      "id_str" : "115485051",
      "id" : 115485051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231858278861254656",
  "text" : "RT @ConanOBrien: This Chick-fil-A scandal has got me worried. I want to go to Arby\u2019s but I don\u2019t know where they stand on the unrest in  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "231854696728522752",
    "text" : "This Chick-fil-A scandal has got me worried. I want to go to Arby\u2019s but I don\u2019t know where they stand on the unrest in Syria.",
    "id" : 231854696728522752,
    "created_at" : "Sat Aug 04 20:50:42 +0000 2012",
    "user" : {
      "name" : "Conan O'Brien",
      "screen_name" : "ConanOBrien",
      "protected" : false,
      "id_str" : "115485051",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/728337241/conan_4cred_normal.jpg",
      "id" : 115485051,
      "verified" : true
    }
  },
  "id" : 231858278861254656,
  "created_at" : "Sat Aug 04 21:04:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Downtown Project",
      "screen_name" : "DowntownProjLV",
      "indices" : [ 66, 81 ],
      "id_str" : "490968947",
      "id" : 490968947
    }, {
      "name" : "Dave Liang",
      "screen_name" : "daveliang",
      "indices" : [ 86, 96 ],
      "id_str" : "20615976",
      "id" : 20615976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1687253975, -115.1406706498 ]
  },
  "id_str" : "231639879317061633",
  "text" : "Overheard: Shanghai Restoration Project playing in Vegas lounge w @DowntownProjLV. cc @daveliang",
  "id" : 231639879317061633,
  "created_at" : "Sat Aug 04 06:37:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/UaNXxaxa",
      "expanded_url" : "http://en.wikipedia.org/wiki/Interrobang",
      "display_url" : "en.wikipedia.org/wiki/Interroba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "231480644407025664",
  "geo" : {
  },
  "id_str" : "231481158028910593",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin check out the interrobang. http://t.co/UaNXxaxa",
  "id" : 231481158028910593,
  "in_reply_to_status_id" : 231480644407025664,
  "created_at" : "Fri Aug 03 20:06:23 +0000 2012",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 16, 21 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.169691227, -115.1398015169 ]
  },
  "id_str" : "231454522231386112",
  "text" : "Dear NYC taxis: @uber is not a competitor, because it takes me where I want to go. Fundamentally different than \"if I feel like it\" service.",
  "id" : 231454522231386112,
  "created_at" : "Fri Aug 03 18:20:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231436931882446848",
  "text" : "With a little tweaking, Google+ could be the Google App equivalent of Microsoft SharePoint.",
  "id" : 231436931882446848,
  "created_at" : "Fri Aug 03 17:10:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kim",
      "screen_name" : "pushingatoms",
      "indices" : [ 41, 54 ],
      "id_str" : "19954028",
      "id" : 19954028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/kUR1Nmh1",
      "expanded_url" : "http://cdn0.sbnation.com/entry_photo_images/4869867/apple-iphone-prototype-30-verge-1020_gallery_post.jpg",
      "display_url" : "cdn0.sbnation.com/entry_photo_im\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "230796968950112256",
  "geo" : {
  },
  "id_str" : "230799763547750400",
  "in_reply_to_user_id" : 19954028,
  "text" : "Nokia Lumia 800 has the same profile. RT @pushingatoms: This is ridiculously handsome. http://t.co/kUR1Nmh1",
  "id" : 230799763547750400,
  "in_reply_to_status_id" : 230796968950112256,
  "created_at" : "Wed Aug 01 22:58:46 +0000 2012",
  "in_reply_to_screen_name" : "pushingatoms",
  "in_reply_to_user_id_str" : "19954028",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMEGA Watches",
      "screen_name" : "omegawatches",
      "indices" : [ 61, 74 ],
      "id_str" : "284578421",
      "id" : 284578421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/eKYQ2ClG",
      "expanded_url" : "http://theatlantic.com/technology/archive/12/07/the-speed-of-sound-is-too-slow-for-olympic-athletes/260413/",
      "display_url" : "theatlantic.com/technology/arc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1698665895, -115.1397318407 ]
  },
  "id_str" : "230722960258904064",
  "text" : "Amazing. Olympic performance bottlenecked by speed of sound; @omegawatches engineers solution. http://t.co/eKYQ2ClG",
  "id" : 230722960258904064,
  "created_at" : "Wed Aug 01 17:53:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/tC5vANmI",
      "expanded_url" : "http://www.kickstarter.com/projects/1523379957/oculus-rift-step-into-the-game?ref=live",
      "display_url" : "kickstarter.com/projects/15233\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230706453021863936",
  "text" : "The most well-endorsed Kickstarter video I've ever seen. Over $100K raised in first day. http://t.co/tC5vANmI",
  "id" : 230706453021863936,
  "created_at" : "Wed Aug 01 16:47:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]