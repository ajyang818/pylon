Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mae",
      "screen_name" : "mxhuo",
      "indices" : [ 0, 6 ],
      "id_str" : "21170404",
      "id" : 21170404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9824271719202816",
  "geo" : {
  },
  "id_str" : "9828381487013888",
  "in_reply_to_user_id" : 21170404,
  "text" : "@mxhuo BMW 135. Do it.",
  "id" : 9828381487013888,
  "in_reply_to_status_id" : 9824271719202816,
  "created_at" : "Wed Dec 01 04:37:23 +0000 2010",
  "in_reply_to_screen_name" : "mxhuo",
  "in_reply_to_user_id_str" : "21170404",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9804790699659264",
  "text" : "Bubble tea at Leisure Station!",
  "id" : 9804790699659264,
  "created_at" : "Wed Dec 01 03:03:38 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 1, 15 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9802438731104258",
  "text" : "\"@hackernewsbot: WikiLeaks Founder Added To The Interpol wanted list\" - this is straight up James Bond stuff",
  "id" : 9802438731104258,
  "created_at" : "Wed Dec 01 02:54:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "medialab",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9793173031227392",
  "text" : "Standing next to Chad Hurley at the MIT #medialab",
  "id" : 9793173031227392,
  "created_at" : "Wed Dec 01 02:17:29 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lego",
      "indices" : [ 9, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9378396756774912",
  "text" : "When did #lego become so crappy?",
  "id" : 9378396756774912,
  "created_at" : "Mon Nov 29 22:49:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "medialab",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9368062889304065",
  "text" : "Mobius strip photograph at the #medialab http://twitpic.com/3bfk0a",
  "id" : 9368062889304065,
  "created_at" : "Mon Nov 29 22:08:14 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9334047134195712",
  "text" : "The PA announcements in #mbta stations remind me of Big Brother or City 17",
  "id" : 9334047134195712,
  "created_at" : "Mon Nov 29 19:53:04 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9149164189388800",
  "text" : "RT @hackernewsbot: Google Buys Groupon for $2.5 Billion... http://vator.tv/news/2010-11-28-google-buys-groupon-for-25-billion",
  "retweeted_status" : {
    "source" : "<a href=\"http://news.ycombinator.com/\" rel=\"nofollow\">Hacker News Bot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "9134985193717760",
    "text" : "Google Buys Groupon for $2.5 Billion... http://vator.tv/news/2010-11-28-google-buys-groupon-for-25-billion",
    "id" : 9134985193717760,
    "created_at" : "Mon Nov 29 06:42:04 +0000 2010",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/73596050/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 9149164189388800,
  "created_at" : "Mon Nov 29 07:38:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leica Camera AG",
      "screen_name" : "leica_camera",
      "indices" : [ 37, 50 ],
      "id_str" : "24884768",
      "id" : 24884768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9061980522414080",
  "text" : "Considering selling the 5D for an M7 @leica_camera. If only film wasn't so expensive!",
  "id" : 9061980522414080,
  "created_at" : "Mon Nov 29 01:51:59 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Price",
      "screen_name" : "iambrettprice",
      "indices" : [ 1, 15 ],
      "id_str" : "26945738",
      "id" : 26945738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8830574600921088",
  "text" : "\"@iambrettprice: one day i want to buy a leica and a noctilux f1.0 lens and shoot pictures of corgis\" we are so alike it's scary",
  "id" : 8830574600921088,
  "created_at" : "Sun Nov 28 10:32:27 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8823382514597888",
  "text" : "There needs to be a wireless protocol bt cars which recommends the same optimal routing to all cars in an area, rather than free-for-all",
  "id" : 8823382514597888,
  "created_at" : "Sun Nov 28 10:03:52 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "indices" : [ 1, 9 ],
      "id_str" : "184543773",
      "id" : 184543773
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 11, 18 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8747802922328064",
  "text" : "\"@stat110: @khsieh Or, I just thought you had some cool tweets.\" Nicest thing anyone's said to me all week :P",
  "id" : 8747802922328064,
  "created_at" : "Sun Nov 28 05:03:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 0, 8 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "indices" : [ 80, 88 ],
      "id_str" : "184543773",
      "id" : 184543773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8743106249752576",
  "in_reply_to_user_id" : 39585367,
  "text" : "@harvard is really cranking up its social media presence!  Just got followed by @stat110",
  "id" : 8743106249752576,
  "created_at" : "Sun Nov 28 04:44:53 +0000 2010",
  "in_reply_to_screen_name" : "Harvard",
  "in_reply_to_user_id_str" : "39585367",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8647766322450432",
  "text" : "Trying to make the most of the tiny space I have in Mather House http://twitpic.com/3at91c",
  "id" : 8647766322450432,
  "created_at" : "Sat Nov 27 22:26:02 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8647071330476032",
  "text" : "Rearranged the bedroom to optimize space and layout for the inevitable post Thanksgiving work!",
  "id" : 8647071330476032,
  "created_at" : "Sat Nov 27 22:23:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8470569741717506",
  "text" : "RT @bznotes: \"How a U Mass Entrepreneur Accidentally won the Harvard Elevator Pitch Competition\": http://bit.ly/i6sIKn",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "8444850789687296",
    "text" : "\"How a U Mass Entrepreneur Accidentally won the Harvard Elevator Pitch Competition\": http://bit.ly/i6sIKn",
    "id" : 8444850789687296,
    "created_at" : "Sat Nov 27 08:59:43 +0000 2010",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 8470569741717506,
  "created_at" : "Sat Nov 27 10:41:55 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 3, 18 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "8277843679121408",
  "text" : "RT @NaveenSrivatsa: I feel less like an individual using a Macbook.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "8269627666735104",
    "text" : "I feel less like an individual using a Macbook.",
    "id" : 8269627666735104,
    "created_at" : "Fri Nov 26 21:23:27 +0000 2010",
    "user" : {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "protected" : true,
      "id_str" : "18107808",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1745313225/IMG_0625edited2_normal.jpg",
      "id" : 18107808,
      "verified" : false
    }
  },
  "id" : 8277843679121408,
  "created_at" : "Fri Nov 26 21:56:06 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Lee",
      "screen_name" : "kevineriklee",
      "indices" : [ 28, 41 ],
      "id_str" : "38612181",
      "id" : 38612181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7996253497466880",
  "text" : "Driving to outlet mall with @kevineriklee blasting NSYNC",
  "id" : 7996253497466880,
  "created_at" : "Fri Nov 26 03:17:10 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7924186173411328",
  "text" : "Thankful for family and friends. All else is trivial.",
  "id" : 7924186173411328,
  "created_at" : "Thu Nov 25 22:30:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7629589555712000",
  "text" : "RT @hackernewsbot: ScribTeX online LaTeX editor (with git interface)... http://scribtex.com/",
  "retweeted_status" : {
    "source" : "<a href=\"http://news.ycombinator.com/\" rel=\"nofollow\">Hacker News Bot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "7625027914567680",
    "text" : "ScribTeX online LaTeX editor (with git interface)... http://scribtex.com/",
    "id" : 7625027914567680,
    "created_at" : "Thu Nov 25 02:42:02 +0000 2010",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/73596050/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 7629589555712000,
  "created_at" : "Thu Nov 25 03:00:10 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 25, 33 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7503646551973888",
  "text" : "Hordes of people leaving @harvard for break! Looking forward to a quiet campus",
  "id" : 7503646551973888,
  "created_at" : "Wed Nov 24 18:39:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Leica",
      "indices" : [ 41, 47 ]
    }, {
      "text" : "bdaywish",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7371735858941952",
  "text" : "Words cannot describe how badly I want a #Leica #bdaywish",
  "id" : 7371735858941952,
  "created_at" : "Wed Nov 24 09:55:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7139828005081088",
  "text" : "RT @nytimes: DealBook: It's Official: J. Crew to Sell Itself for $3 Billion http://nyti.ms/hA2azT",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.nytimes.com/twitter\" rel=\"nofollow\">The New York Times</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "7125814814445568",
    "text" : "DealBook: It's Official: J. Crew to Sell Itself for $3 Billion http://nyti.ms/hA2azT",
    "id" : 7125814814445568,
    "created_at" : "Tue Nov 23 17:38:21 +0000 2010",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2044921128/finals_normal.png",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 7139828005081088,
  "created_at" : "Tue Nov 23 18:34:02 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "indices" : [ 3, 17 ],
      "id_str" : "2172",
      "id" : 2172
    }, {
      "name" : "Duncan Jones",
      "screen_name" : "ManMadeMoon",
      "indices" : [ 65, 77 ],
      "id_str" : "20690398",
      "id" : 20690398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "7126113285312512",
  "text" : "RT @laughingsquid: trailer for \"Source Code\", the latest film by @ManMadeMoon, who directed the amazing film \"Moon\" http://bit.ly/fUS71T",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Duncan Jones",
        "screen_name" : "ManMadeMoon",
        "indices" : [ 46, 58 ],
        "id_str" : "20690398",
        "id" : 20690398
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "7117435517804545",
    "text" : "trailer for \"Source Code\", the latest film by @ManMadeMoon, who directed the amazing film \"Moon\" http://bit.ly/fUS71T",
    "id" : 7117435517804545,
    "created_at" : "Tue Nov 23 17:05:03 +0000 2010",
    "user" : {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "protected" : false,
      "id_str" : "2172",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/340068086/laughing_squid_logo_normal.jpg",
      "id" : 2172,
      "verified" : true
    }
  },
  "id" : 7126113285312512,
  "created_at" : "Tue Nov 23 17:39:32 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6872642225184768",
  "text" : "RT @hackernewsbot: SR-71 Blackbird Communication to Tower... http://www.econrates.com/reality/schul.html",
  "retweeted_status" : {
    "source" : "<a href=\"http://news.ycombinator.com/\" rel=\"nofollow\">Hacker News Bot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6809660258516993",
    "text" : "SR-71 Blackbird Communication to Tower... http://www.econrates.com/reality/schul.html",
    "id" : 6809660258516993,
    "created_at" : "Mon Nov 22 20:42:04 +0000 2010",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/73596050/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 6872642225184768,
  "created_at" : "Tue Nov 23 00:52:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6854282431168512",
  "geo" : {
  },
  "id_str" : "6871728504446976",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil kayne is my rapper name",
  "id" : 6871728504446976,
  "in_reply_to_status_id" : 6854282431168512,
  "created_at" : "Tue Nov 23 00:48:42 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6780507190730752",
  "text" : "My last day as a teenager.  I guess this means no more angsty teen music?",
  "id" : 6780507190730752,
  "created_at" : "Mon Nov 22 18:46:13 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 56, 64 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6632059883757568",
  "text" : "Reading the Legges translation of the Tao Te Ching with @digitil for some inspiration",
  "id" : 6632059883757568,
  "created_at" : "Mon Nov 22 08:56:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6523441511399426",
  "geo" : {
  },
  "id_str" : "6536530415853568",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha Droid X if you're on verizon, hands down",
  "id" : 6536530415853568,
  "in_reply_to_status_id" : 6523441511399426,
  "created_at" : "Mon Nov 22 02:36:44 +0000 2010",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robarnold",
      "screen_name" : "robarnold",
      "indices" : [ 3, 13 ],
      "id_str" : "15464170",
      "id" : 15464170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6510379102371840",
  "text" : "RT @robarnold: Adobe's license agreement for downloading Acrobat Reader is a PDF. Well done Adobe. Well done.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "5753460003704833",
    "text" : "Adobe's license agreement for downloading Acrobat Reader is a PDF. Well done Adobe. Well done.",
    "id" : 5753460003704833,
    "created_at" : "Fri Nov 19 22:45:06 +0000 2010",
    "user" : {
      "name" : "robarnold",
      "screen_name" : "robarnold",
      "protected" : false,
      "id_str" : "15464170",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/913506344/5079_565833163689_4808309_33323141_3020627_n_normal.jpg",
      "id" : 15464170,
      "verified" : false
    }
  },
  "id" : 6510379102371840,
  "created_at" : "Mon Nov 22 00:52:49 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6441989327290368",
  "text" : "I've resorted to energy drinks to stay awake during computational theory lectures",
  "id" : 6441989327290368,
  "created_at" : "Sun Nov 21 20:21:04 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "6420368742944768",
  "text" : "I finally realized how massive the 5D + grip combination is when I held a 1Ds Mark III and thought \"not bad\"",
  "id" : 6420368742944768,
  "created_at" : "Sun Nov 21 18:55:09 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5908469412528128",
  "text" : "Harvard-Yale weekend has begun",
  "id" : 5908469412528128,
  "created_at" : "Sat Nov 20 09:01:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5710395943686145",
  "text" : "Photons, bits, electrons, and neurons.",
  "id" : 5710395943686145,
  "created_at" : "Fri Nov 19 19:53:59 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 40, 48 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swype",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5698028576968704",
  "text" : "I've become much better at #swype input @digitil",
  "id" : 5698028576968704,
  "created_at" : "Fri Nov 19 19:04:50 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mit",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5697715996463104",
  "text" : "\"if I had a camera with infinite resolution and frame rate and 32 channels then computer vision becomes really easy.\" - #mit prof",
  "id" : 5697715996463104,
  "created_at" : "Fri Nov 19 19:03:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5689155803676672",
  "text" : "I have two weeks to implement an HDR video camera for this class.  Uh oh.",
  "id" : 5689155803676672,
  "created_at" : "Fri Nov 19 18:29:35 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DISCOVER Magazine",
      "screen_name" : "DiscoverMag",
      "indices" : [ 3, 15 ],
      "id_str" : "23962323",
      "id" : 23962323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5681731411640321",
  "text" : "RT @DiscoverMag: Why is FDA cracking down on caffeinated booze 4 Loko? Could it be *too perfect* a cognitive enhancer? http://bit.ly/a58 ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kyle Munkittrick",
        "screen_name" : "PopBioethics",
        "indices" : [ 126, 139 ],
        "id_str" : "95661007",
        "id" : 95661007
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "5662070183829505",
    "text" : "Why is FDA cracking down on caffeinated booze 4 Loko? Could it be *too perfect* a cognitive enhancer? http://bit.ly/a58AVU by @PopBioethics",
    "id" : 5662070183829505,
    "created_at" : "Fri Nov 19 16:41:57 +0000 2010",
    "user" : {
      "name" : "DISCOVER Magazine",
      "screen_name" : "DiscoverMag",
      "protected" : false,
      "id_str" : "23962323",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2911404161/b46d30d6e8cd6980ed9c954de026a52e_normal.png",
      "id" : 23962323,
      "verified" : true
    }
  },
  "id" : 5681731411640321,
  "created_at" : "Fri Nov 19 18:00:04 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xbox",
      "indices" : [ 26, 31 ]
    }, {
      "text" : "kinect",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "mit",
      "indices" : [ 48, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5674210974240768",
  "text" : "Prof demonstrating hacked #xbox #kinect.  &lt;3 #mit.",
  "id" : 5674210974240768,
  "created_at" : "Fri Nov 19 17:30:11 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashwin Rao",
      "screen_name" : "ashwinny",
      "indices" : [ 32, 41 ],
      "id_str" : "24392794",
      "id" : 24392794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5496903588380672",
  "text" : "Haha I use to help him in CS RT @ashwinny: Fresh from the suburbs of East Amherst NY. I'm not sure what to think. http://tiny.cc/ge3dz",
  "id" : 5496903588380672,
  "created_at" : "Fri Nov 19 05:45:38 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 17, 24 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5305343022202880",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil got his @square today.crap, now I cant use the no cash excuse to not pay him... http://twitpic.com/37y6i3",
  "id" : 5305343022202880,
  "created_at" : "Thu Nov 18 17:04:27 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "starbucks",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5225885489692672",
  "text" : "Today is buy one get one free at #starbucks between 2 and 5!",
  "id" : 5225885489692672,
  "created_at" : "Thu Nov 18 11:48:42 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 13, 21 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tsa",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5089751308701696",
  "text" : "comment on a @gizmodo #tsa post: \"You know what I just ordered? A kilt. I will now fly again, and have my revenge, one hairy leg at a time.\"",
  "id" : 5089751308701696,
  "created_at" : "Thu Nov 18 02:47:45 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 0, 11 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5083748429201408",
  "geo" : {
  },
  "id_str" : "5085488813707265",
  "in_reply_to_user_id" : 96501375,
  "text" : "@droid_life too bad Pro is an awful phone... traded for an X earlier this week",
  "id" : 5085488813707265,
  "in_reply_to_status_id" : 5083748429201408,
  "created_at" : "Thu Nov 18 02:30:49 +0000 2010",
  "in_reply_to_screen_name" : "droid_life",
  "in_reply_to_user_id_str" : "96501375",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Harvard",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "Tumblr",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "5075239050416129",
  "text" : "#Harvard engineering school has a #Tumblr?! http://harvardseas.tumblr.com/",
  "id" : 5075239050416129,
  "created_at" : "Thu Nov 18 01:50:05 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    }, {
      "name" : "Antonio Gregori_",
      "screen_name" : "a_gre",
      "indices" : [ 130, 136 ],
      "id_str" : "70694088",
      "id" : 70694088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4970286352961536",
  "text" : "RT @ForbesTech: How is the TSA dealing with angry travelers online? By censoring its blog comments. http://bit.ly/9NpoVU [post by @a_gre ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Greenberg",
        "screen_name" : "a_greenberg",
        "indices" : [ 114, 126 ],
        "id_str" : "4255361",
        "id" : 4255361
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "4930206397636609",
    "text" : "How is the TSA dealing with angry travelers online? By censoring its blog comments. http://bit.ly/9NpoVU [post by @a_greenberg]",
    "id" : 4930206397636609,
    "created_at" : "Wed Nov 17 16:13:47 +0000 2010",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 4970286352961536,
  "created_at" : "Wed Nov 17 18:53:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Value Fool",
      "screen_name" : "TMFInsideValue",
      "indices" : [ 3, 18 ],
      "id_str" : "15945181",
      "id" : 15945181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4947943907917824",
  "text" : "RT @TMFInsideValue: Apple ($AAPL) names a former Northrop CEO as a director, fueling rumors that the next iPad will feature heat-seeking ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "4936969347923969",
    "text" : "Apple ($AAPL) names a former Northrop CEO as a director, fueling rumors that the next iPad will feature heat-seeking missiles.",
    "id" : 4936969347923969,
    "created_at" : "Wed Nov 17 16:40:39 +0000 2010",
    "user" : {
      "name" : "A Value Fool",
      "screen_name" : "TMFInsideValue",
      "protected" : false,
      "id_str" : "15945181",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2898906271/689f32243d5977a280d3aa5179067e1f_normal.jpeg",
      "id" : 15945181,
      "verified" : false
    }
  },
  "id" : 4947943907917824,
  "created_at" : "Wed Nov 17 17:24:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 56, 64 ]
    }, {
      "text" : "google",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "cs",
      "indices" : [ 73, 76 ]
    }, {
      "text" : "whyamiawake",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4825834187657216",
  "text" : "Mitzenmacher posts on Welsh's blog http://bit.ly/9nLdoO #harvard #google #cs #whyamiawake",
  "id" : 4825834187657216,
  "created_at" : "Wed Nov 17 09:19:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ DIGITAL",
      "screen_name" : "digital",
      "indices" : [ 45, 53 ],
      "id_str" : "217765325",
      "id" : 217765325
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4670869477531648",
  "text" : "7 of 9 people using android in cs121 section @digital #harvard",
  "id" : 4670869477531648,
  "created_at" : "Tue Nov 16 23:03:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iphone",
      "indices" : [ 72, 79 ]
    }, {
      "text" : "apple",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4664958709145601",
  "text" : "Kid sells white iPhones on his own.  What a boss http://gizmo.do/c5tnOw #iphone #apple",
  "id" : 4664958709145601,
  "created_at" : "Tue Nov 16 22:39:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 3, 14 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4636350141693952",
  "text" : "RT @droid_life: Samsung Announces Galaxy S Giorgio Armani Edition - http://droid.co/9r #android",
  "retweeted_status" : {
    "source" : "<a href=\"http://an.droid-life.com\" rel=\"nofollow\">WP plugin android life</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "android",
        "indices" : [ 71, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "4617223914131456",
    "text" : "Samsung Announces Galaxy S Giorgio Armani Edition - http://droid.co/9r #android",
    "id" : 4617223914131456,
    "created_at" : "Tue Nov 16 19:30:06 +0000 2010",
    "user" : {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "protected" : false,
      "id_str" : "96501375",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1639322866/dl_square_normal.jpg",
      "id" : 96501375,
      "verified" : true
    }
  },
  "id" : 4636350141693952,
  "created_at" : "Tue Nov 16 20:46:06 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4250826734305281",
  "text" : "\"Get in a golf cart, it's about the same feeling.\" - Dad, on Tesla cars.",
  "id" : 4250826734305281,
  "created_at" : "Mon Nov 15 19:14:10 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 18, 26 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 31, 38 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cs",
      "indices" : [ 61, 64 ]
    }, {
      "text" : "harvard",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "google",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "wtf",
      "indices" : [ 82, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4247867774468096",
  "text" : "Matt Welsh leaves @Harvard for @Google! http://bit.ly/9k3y66 #cs #harvard #google #wtf",
  "id" : 4247867774468096,
  "created_at" : "Mon Nov 15 19:02:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 65, 70 ],
      "id_str" : "132319630",
      "id" : 132319630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4244074873749504",
  "text" : "\"if don't trust your browser you're all dead\" - cs prof #harvard @sidd",
  "id" : 4244074873749504,
  "created_at" : "Mon Nov 15 18:47:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4242195229966336",
  "text" : "\"if verisign gets compromised, it'll be the end of the world!!\" - cs prof",
  "id" : 4242195229966336,
  "created_at" : "Mon Nov 15 18:39:52 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vzw",
      "indices" : [ 7, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4214738246443008",
  "text" : "At the #vzw store trying to get an exchange. A deluge of old people taking foreverrrrr",
  "id" : 4214738246443008,
  "created_at" : "Mon Nov 15 16:50:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 34, 40 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 42, 49 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vzw",
      "indices" : [ 26, 30 ]
    }, {
      "text" : "WindowsPhone7",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4129162113585152",
  "text" : "I wish. Alas no option on #vzw RT @cklee: @khsieh I'm glad you're tasting phones like wine but let's get #WindowsPhone7",
  "id" : 4129162113585152,
  "created_at" : "Mon Nov 15 11:10:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "adams",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4054031563489280",
  "text" : "Pretty people in pretty settings makes photography easy: http://onesixtieth.net/ #harvard #adams",
  "id" : 4054031563489280,
  "created_at" : "Mon Nov 15 06:12:11 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4049532794970112",
  "text" : "RT @bznotes: So, a non-Harvard guy walks randomly into a Harvard Elevator Pitch Contest, pitches his idea, and walks away with $500 in c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "3939331286769664",
    "text" : "So, a non-Harvard guy walks randomly into a Harvard Elevator Pitch Contest, pitches his idea, and walks away with $500 in cash!!!",
    "id" : 3939331286769664,
    "created_at" : "Sun Nov 14 22:36:24 +0000 2010",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 4049532794970112,
  "created_at" : "Mon Nov 15 05:54:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3994286672576513",
  "text" : "trading the Droid pro for a Droid X or Blackberry Storm 2 tmrw. The keyboard and screen are garbage.",
  "id" : 3994286672576513,
  "created_at" : "Mon Nov 15 02:14:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 26, 32 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3908425423523840",
  "text" : "Elevator pitch event with @cklee",
  "id" : 3908425423523840,
  "created_at" : "Sun Nov 14 20:33:35 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3620804570906625",
  "text" : "Only Harvard students would put a subprime mortgage joke into an adaptation of Hamlet",
  "id" : 3620804570906625,
  "created_at" : "Sun Nov 14 01:30:41 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3611848758796289",
  "text" : "Thank goodness for Google, because Verizons sync software is godawful",
  "id" : 3611848758796289,
  "created_at" : "Sun Nov 14 00:55:06 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 3, 9 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3523667954765824",
  "text" : "RT @koush: God, Windows Phone 7 isolated storage is abysmally slow.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "3519218507059200",
    "text" : "God, Windows Phone 7 isolated storage is abysmally slow.",
    "id" : 3519218507059200,
    "created_at" : "Sat Nov 13 18:47:01 +0000 2010",
    "user" : {
      "name" : "koush",
      "screen_name" : "koush",
      "protected" : false,
      "id_str" : "18918415",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1577420755/img-18_normal.jpg",
      "id" : 18918415,
      "verified" : false
    }
  },
  "id" : 3523667954765824,
  "created_at" : "Sat Nov 13 19:04:42 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 87, 98 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3278188746645504",
  "text" : "Rocking the Droid Pro!  A few concerns: the buttons are unevenly lit, and it runs HOT. @droid_life",
  "id" : 3278188746645504,
  "created_at" : "Sat Nov 13 02:49:15 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3218153437921280",
  "text" : "Droid Pro in hand! http://yfrog.com/epl41hj",
  "id" : 3218153437921280,
  "created_at" : "Fri Nov 12 22:50:42 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIT",
      "indices" : [ 118, 122 ]
    }, {
      "text" : "medialab",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3166482477359104",
  "text" : "\"When you're shooting full color at 10,000 frames per second, the cost of the vehicle you're destroying is nothing\" - #MIT prof, #medialab",
  "id" : 3166482477359104,
  "created_at" : "Fri Nov 12 19:25:22 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3143911761514496",
  "text" : "Roast pork rice bowl from the momogoose food truck near MIT. It's like a last meal before my death at the hands of this midterm.",
  "id" : 3143911761514496,
  "created_at" : "Fri Nov 12 17:55:41 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Droid",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2927955504271360",
  "text" : "#Droid Pro is only 10 miles away in a FedEx facility!",
  "id" : 2927955504271360,
  "created_at" : "Fri Nov 12 03:37:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2841647154991104",
  "text" : "Galaxy Tab - I love getting real time data to the home screen. Smaller than expected though. http://yfrog.com/6esbsmj",
  "id" : 2841647154991104,
  "created_at" : "Thu Nov 11 21:54:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 51, 59 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vzw",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2840904062734336",
  "text" : "Tweeting from Samsung Galaxy Tab @ #vzw store with @digitil - nice size, but damn pricey",
  "id" : 2840904062734336,
  "created_at" : "Thu Nov 11 21:51:38 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 3, 16 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2637715082317824",
  "text" : "RT @sunilnagaraj: The \"Downloads\" folder seems like a security risk -- lots of old files stack up there",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "2552954888392704",
    "text" : "The \"Downloads\" folder seems like a security risk -- lots of old files stack up there",
    "id" : 2552954888392704,
    "created_at" : "Thu Nov 11 02:47:26 +0000 2010",
    "user" : {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "protected" : false,
      "id_str" : "14877810",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/285143601/sunil_march_normal.jpg",
      "id" : 14877810,
      "verified" : false
    }
  },
  "id" : 2637715082317824,
  "created_at" : "Thu Nov 11 08:24:14 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2612943048941568",
  "text" : "Verizon's online account services are broken.  Fantastic.",
  "id" : 2612943048941568,
  "created_at" : "Thu Nov 11 06:45:48 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2157995446243328",
  "geo" : {
  },
  "id_str" : "2162870028599296",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee no such thing as too much edamame",
  "id" : 2162870028599296,
  "in_reply_to_status_id" : 2157995446243328,
  "created_at" : "Wed Nov 10 00:57:23 +0000 2010",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Droid",
      "indices" : [ 11, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2162687295365121",
  "text" : "Preordered #Droid Pro. Droid 2 Global's keyboard was unusable",
  "id" : 2162687295365121,
  "created_at" : "Wed Nov 10 00:56:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tesla",
      "indices" : [ 17, 23 ]
    }, {
      "text" : "Harvard",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2071321223630848",
  "text" : "Photoshoot for a #Tesla Roadster at #Harvard. Sharp looking machine.",
  "id" : 2071321223630848,
  "created_at" : "Tue Nov 09 18:53:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 3, 9 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2043424916115458",
  "text" : "RT @koush: G2 got S-OFF. ClockworkMod recovery and ROM Manager are being ported now.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "2040835608682496",
    "text" : "G2 got S-OFF. ClockworkMod recovery and ROM Manager are being ported now.",
    "id" : 2040835608682496,
    "created_at" : "Tue Nov 09 16:52:27 +0000 2010",
    "user" : {
      "name" : "koush",
      "screen_name" : "koush",
      "protected" : false,
      "id_str" : "18918415",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1577420755/img-18_normal.jpg",
      "id" : 18918415,
      "verified" : false
    }
  },
  "id" : 2043424916115458,
  "created_at" : "Tue Nov 09 17:02:45 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vzw",
      "indices" : [ 39, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1923168419708929",
  "text" : "The lack of Windows Phone 7 options on #vzw makes deciding easier.",
  "id" : 1923168419708929,
  "created_at" : "Tue Nov 09 09:04:53 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fingerscrossed",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "harvard",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "cs",
      "indices" : [ 97, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1921716762705920",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil are going to class tomorrow morning like good proper students. #fingerscrossed #harvard #cs",
  "id" : 1921716762705920,
  "created_at" : "Tue Nov 09 08:59:07 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Droid",
      "indices" : [ 7, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1917363683328000",
  "text" : "Global #Droid 2 or Droid Pro?  Decisions decisions....",
  "id" : 1917363683328000,
  "created_at" : "Tue Nov 09 08:41:49 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard UC",
      "screen_name" : "HarvardUC",
      "indices" : [ 0, 10 ],
      "id_str" : "62927392",
      "id" : 62927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1520042038525953",
  "in_reply_to_user_id" : 62927392,
  "text" : "@harvarduc campaigning has started.  Best ticket so far: http://bit.ly/cj5DmY (love the original soundtrack)",
  "id" : 1520042038525953,
  "created_at" : "Mon Nov 08 06:23:00 +0000 2010",
  "in_reply_to_screen_name" : "HarvardUC",
  "in_reply_to_user_id_str" : "62927392",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Steam",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1459269727682560",
  "text" : "Downloaded Orange Box for Mac #Steam. Looking forward to catching up with Half Life canon during Thanksgiving break!",
  "id" : 1459269727682560,
  "created_at" : "Mon Nov 08 02:21:31 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 16, 27 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1416914609905664",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce RT @droid_life: Think you have 4G? Think again - http://bit.ly/9y4KZQ  #android",
  "id" : 1416914609905664,
  "created_at" : "Sun Nov 07 23:33:13 +0000 2010",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Droid",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "cantwait",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1172255014916096",
  "text" : "D-Day is Nov 18.   That is, #Droid Pro launch.  #cantwait",
  "id" : 1172255014916096,
  "created_at" : "Sun Nov 07 07:21:02 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mit",
      "indices" : [ 48, 52 ]
    }, {
      "text" : "medialab",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "643767568699392",
  "text" : "Words do not adequately express how much I love #mit #medialab",
  "id" : 643767568699392,
  "created_at" : "Fri Nov 05 20:21:00 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mit",
      "indices" : [ 99, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "635663485501440",
  "text" : "\"You want the raw image? Too bad. There is no raw image. it's all interpolated anyways.\" -MAS prof #mit",
  "id" : 635663485501440,
  "created_at" : "Fri Nov 05 19:48:48 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Canon",
      "indices" : [ 56, 62 ]
    }, {
      "text" : "mit",
      "indices" : [ 103, 107 ]
    }, {
      "text" : "medialabs",
      "indices" : [ 108, 118 ]
    }, {
      "text" : "photo",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "595011687161857",
  "text" : "\"I shouldn't say this, they gave me a ton of money, but #Canon will be out in three years.\" - MAS prof #mit #medialabs #photo",
  "id" : 595011687161857,
  "created_at" : "Fri Nov 05 17:07:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mit",
      "indices" : [ 62, 66 ]
    }, {
      "text" : "medialabs",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "591096413421568",
  "text" : "My coughs echo embarrassingly loud in the beautiful atrium of #mit #medialabs",
  "id" : 591096413421568,
  "created_at" : "Fri Nov 05 16:51:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 72, 82 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webOS",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "WP7",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "Android",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "578069966360576",
  "text" : "The death throes of #webOS... Maybe its time for #WP7 or #Android :) RT @jenny8lee: Think my Palm Pre hard drive or something failed.",
  "id" : 578069966360576,
  "created_at" : "Fri Nov 05 15:59:57 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etrade",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "thinkorswim",
      "indices" : [ 9, 21 ]
    }, {
      "text" : "optionshouse",
      "indices" : [ 23, 36 ]
    }, {
      "text" : "help",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "577639404277761",
  "text" : "#etrade, #thinkorswim, #optionshouse, or something else? #help",
  "id" : 577639404277761,
  "created_at" : "Fri Nov 05 15:58:14 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "562119338622976",
  "text" : "Nice breakfast with BarCap. Eggs with a side of crash-course in trading.",
  "id" : 562119338622976,
  "created_at" : "Fri Nov 05 14:56:34 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29695664234",
  "text" : "Amazon customer service is absolutely horrendous.",
  "id" : 29695664234,
  "created_at" : "Thu Nov 04 19:46:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "droid",
      "indices" : [ 37, 43 ]
    }, {
      "text" : "pro",
      "indices" : [ 44, 48 ]
    }, {
      "text" : "vzw",
      "indices" : [ 49, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29693900693",
  "text" : "WP7, your move http://bit.ly/aEfiAd  #droid #pro #vzw",
  "id" : 29693900693,
  "created_at" : "Thu Nov 04 19:20:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 20, 30 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29618299214",
  "text" : "Every time I tech a @jenny8lee event, something breaks...",
  "id" : 29618299214,
  "created_at" : "Wed Nov 03 23:40:10 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 3, 14 ],
      "id_str" : "21061803",
      "id" : 21061803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29612779922",
  "text" : "RT @_Eric_Chen: People here are so selfish, but you don't necessarily have to be self-centered and selfish",
  "id" : 29612779922,
  "created_at" : "Wed Nov 03 22:33:51 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29548497152",
  "text" : "Windows Phone 7 and Droid Pro will be competing for my love in Q4.",
  "id" : 29548497152,
  "created_at" : "Wed Nov 03 06:56:11 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 40, 46 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    }, {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 47, 59 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialnetwork",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29505974145",
  "text" : "I haven't seen it either #socialnetwork @cklee @alishalisha",
  "id" : 29505974145,
  "created_at" : "Tue Nov 02 21:15:07 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]