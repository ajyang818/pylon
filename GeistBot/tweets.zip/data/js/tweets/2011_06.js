Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Uttley",
      "screen_name" : "22u",
      "indices" : [ 0, 4 ],
      "id_str" : "24180129",
      "id" : 24180129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86557074657513474",
  "geo" : {
  },
  "id_str" : "86560325410885633",
  "in_reply_to_user_id" : 24180129,
  "text" : "@22u added a little tweak. Fits the theme well.",
  "id" : 86560325410885633,
  "in_reply_to_status_id" : 86557074657513474,
  "created_at" : "Thu Jun 30 22:22:44 +0000 2011",
  "in_reply_to_screen_name" : "22u",
  "in_reply_to_user_id_str" : "24180129",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Uttley",
      "screen_name" : "22u",
      "indices" : [ 0, 4 ],
      "id_str" : "24180129",
      "id" : 24180129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86551582027681792",
  "geo" : {
  },
  "id_str" : "86556776069206016",
  "in_reply_to_user_id" : 24180129,
  "text" : "@22u yep going for optimal readability. Too stark maybe?",
  "id" : 86556776069206016,
  "in_reply_to_status_id" : 86551582027681792,
  "created_at" : "Thu Jun 30 22:08:38 +0000 2011",
  "in_reply_to_screen_name" : "22u",
  "in_reply_to_user_id_str" : "24180129",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86551395704115201",
  "text" : "Trimmed fluff and polished the personal site: http://j.mp/looJeT",
  "id" : 86551395704115201,
  "created_at" : "Thu Jun 30 21:47:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86551057207013376",
  "text" : "RT @hotdogsladies: Google's new interface for iOS is super-pretty. \n\nPlus, I've managed to hit my intended button almost twice now.",
  "retweeted_status" : {
    "source" : "<a href=\"http://birdhouseapp.com\" rel=\"nofollow\">Birdhouse</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "86545706655027200",
    "text" : "Google's new interface for iOS is super-pretty. \n\nPlus, I've managed to hit my intended button almost twice now.",
    "id" : 86545706655027200,
    "created_at" : "Thu Jun 30 21:24:39 +0000 2011",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/51857279/merlin_icon_184-1_normal.png",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 86551057207013376,
  "created_at" : "Thu Jun 30 21:45:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Barnes",
      "screen_name" : "billba",
      "indices" : [ 0, 7 ],
      "id_str" : "9832392",
      "id" : 9832392
    }, {
      "name" : "Southworth",
      "screen_name" : "southworth",
      "indices" : [ 8, 19 ],
      "id_str" : "755990",
      "id" : 755990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86540694369476608",
  "in_reply_to_user_id" : 9832392,
  "text" : "@billba @southworth my roommates and I are PMs and we love NIH. Any way to snag a signed book for a Win8 PM's birthday in late July?",
  "id" : 86540694369476608,
  "created_at" : "Thu Jun 30 21:04:44 +0000 2011",
  "in_reply_to_screen_name" : "billba",
  "in_reply_to_user_id_str" : "9832392",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Tech Bubble",
      "screen_name" : "the_tech_bubble",
      "indices" : [ 21, 37 ],
      "id_str" : "221239966",
      "id" : 221239966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86466034420285440",
  "text" : "We've missed you. RT @the_tech_bubble: Sorry for radio silence. Finished raising round for my real startup!",
  "id" : 86466034420285440,
  "created_at" : "Thu Jun 30 16:08:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86227739245428736",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee short lived glory; Google+ email invites working now!",
  "id" : 86227739245428736,
  "created_at" : "Thu Jun 30 00:21:09 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86201436320436225",
  "text" : "Anyone want to buy a canon 5D and canon 35 1.4L?",
  "id" : 86201436320436225,
  "created_at" : "Wed Jun 29 22:36:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86190472518836225",
  "text" : "Trying to hack together a standing desk at work.",
  "id" : 86190472518836225,
  "created_at" : "Wed Jun 29 21:53:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HSBC",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86179268429746176",
  "text" : "#HSBC phishing attempt via phone call. Stay on guard.",
  "id" : 86179268429746176,
  "created_at" : "Wed Jun 29 21:08:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 13, 19 ],
      "id_str" : "15134782",
      "id" : 15134782
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 21, 28 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http://t.co/AYt5OLc",
      "expanded_url" : "http://klout.com/khsieh/score-analysis?n=tw&v=klout_score",
      "display_url" : "klout.com/khsieh/score-a\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "86171179706089472",
  "text" : "According to @Klout, @khsieh's Klout score is 34.  How influential are you? http://t.co/AYt5OLc",
  "id" : 86171179706089472,
  "created_at" : "Wed Jun 29 20:36:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Core77",
      "screen_name" : "core77",
      "indices" : [ 3, 10 ],
      "id_str" : "20236725",
      "id" : 20236725
    }, {
      "name" : "U.S. Postal Service",
      "screen_name" : "USPSConnect",
      "indices" : [ 47, 59 ],
      "id_str" : "164665456",
      "id" : 164665456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86107118842818560",
  "text" : "RT @core77: Happy World Industrial Design Day! @USPSConnect Pioneers of American Industrial Design Stamps released today!:  http://bit.l ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Postal Service",
        "screen_name" : "USPSConnect",
        "indices" : [ 35, 47 ],
        "id_str" : "164665456",
        "id" : 164665456
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "86063195739004928",
    "text" : "Happy World Industrial Design Day! @USPSConnect Pioneers of American Industrial Design Stamps released today!:  http://bit.ly/iSVUxP",
    "id" : 86063195739004928,
    "created_at" : "Wed Jun 29 13:27:19 +0000 2011",
    "user" : {
      "name" : "Core77",
      "screen_name" : "core77",
      "protected" : false,
      "id_str" : "20236725",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2706662093/6d6e3a2ac48b0d4a077a39bba1f03fc5_normal.jpeg",
      "id" : 20236725,
      "verified" : false
    }
  },
  "id" : 86107118842818560,
  "created_at" : "Wed Jun 29 16:21:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Bateman",
      "screen_name" : "pbateman",
      "indices" : [ 0, 9 ],
      "id_str" : "5760962",
      "id" : 5760962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86105837680082944",
  "in_reply_to_user_id" : 5760962,
  "text" : "@pbateman is tweeting again. Nice.",
  "id" : 86105837680082944,
  "created_at" : "Wed Jun 29 16:16:46 +0000 2011",
  "in_reply_to_screen_name" : "pbateman",
  "in_reply_to_user_id_str" : "5760962",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 89, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85870707749298177",
  "text" : "The single bus came today instead of the extended so I have to commute home standing up. #firstworldproblems",
  "id" : 85870707749298177,
  "created_at" : "Wed Jun 29 00:42:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio",
      "screen_name" : "antrod",
      "indices" : [ 0, 7 ],
      "id_str" : "464493",
      "id" : 464493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85825409018642432",
  "geo" : {
  },
  "id_str" : "85848802438823936",
  "in_reply_to_user_id" : 464493,
  "text" : "@antrod interesting, my navbar with google+ is still white in Gmail, maybe because of the minimalist light theme",
  "id" : 85848802438823936,
  "in_reply_to_status_id" : 85825409018642432,
  "created_at" : "Tue Jun 28 23:15:24 +0000 2011",
  "in_reply_to_screen_name" : "antrod",
  "in_reply_to_user_id_str" : "464493",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "citizen lab",
      "screen_name" : "citizenlab",
      "indices" : [ 3, 14 ],
      "id_str" : "35341530",
      "id" : 35341530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85848211578830849",
  "text" : "RT @citizenlab: Interesting. After India's ntl security establishment exploited by china-based nets, they turn to Huawei for security ht ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "85823837454860288",
    "text" : "Interesting. After India's ntl security establishment exploited by china-based nets, they turn to Huawei for security http://bit.ly/lU26GO",
    "id" : 85823837454860288,
    "created_at" : "Tue Jun 28 21:36:12 +0000 2011",
    "user" : {
      "name" : "citizen lab",
      "screen_name" : "citizenlab",
      "protected" : false,
      "id_str" : "35341530",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857394514/14876528995faf3261e633473ea53e19_normal.png",
      "id" : 35341530,
      "verified" : false
    }
  },
  "id" : 85848211578830849,
  "created_at" : "Tue Jun 28 23:13:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "impatient",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85814139104149504",
  "text" : "A supersonic airliner could do SeaTac to JFK in 3ish hours. Come on, I thought we were living in the future? #impatient",
  "id" : 85814139104149504,
  "created_at" : "Tue Jun 28 20:57:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan O\u2019Tierney",
      "screen_name" : "tristan",
      "indices" : [ 0, 8 ],
      "id_str" : "712733",
      "id" : 712733
    }, {
      "name" : "Chris Stewart",
      "screen_name" : "socialtopher",
      "indices" : [ 9, 22 ],
      "id_str" : "7870892",
      "id" : 7870892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85762735069081601",
  "geo" : {
  },
  "id_str" : "85798560158842880",
  "in_reply_to_user_id" : 712733,
  "text" : "@tristan @socialtopher thanks for the heads up re: square. Losing it was not worth the iOS beta upgrade...",
  "id" : 85798560158842880,
  "in_reply_to_status_id" : 85762735069081601,
  "created_at" : "Tue Jun 28 19:55:45 +0000 2011",
  "in_reply_to_screen_name" : "tristan",
  "in_reply_to_user_id_str" : "712733",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 31, 40 ],
      "id_str" : "18008249",
      "id" : 18008249
    }, {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 73, 78 ],
      "id_str" : "132319630",
      "id" : 132319630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdfriends",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85786161796231168",
  "text" : "Playing with Google+ thanks to @thepunit and tweeting about it thanks to @sidd. #nerdfriends",
  "id" : 85786161796231168,
  "created_at" : "Tue Jun 28 19:06:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square Support",
      "screen_name" : "SqSupport",
      "indices" : [ 0, 10 ],
      "id_str" : "135221095",
      "id" : 135221095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85763028041203712",
  "geo" : {
  },
  "id_str" : "85781060134244354",
  "in_reply_to_user_id" : 135221095,
  "text" : "@SqSupport thanks! Now I have to consider a kludge-y downgrade since square is so convenient...",
  "id" : 85781060134244354,
  "in_reply_to_status_id" : 85763028041203712,
  "created_at" : "Tue Jun 28 18:46:13 +0000 2011",
  "in_reply_to_screen_name" : "SqSupport",
  "in_reply_to_user_id_str" : "135221095",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http://t.co/TRgwL4Q",
      "expanded_url" : "http://tedxboston.org/",
      "display_url" : "tedxboston.org"
    } ]
  },
  "geo" : {
  },
  "id_str" : "85779216829915136",
  "text" : "RT @medialab: Watch Ramesh Raskar's talk @ TEDxBoston ~2:45pm ET: http://t.co/TRgwL4Q",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 71 ],
        "url" : "http://t.co/TRgwL4Q",
        "expanded_url" : "http://tedxboston.org/",
        "display_url" : "tedxboston.org"
      } ]
    },
    "geo" : {
    },
    "id_str" : "85774586582532096",
    "text" : "Watch Ramesh Raskar's talk @ TEDxBoston ~2:45pm ET: http://t.co/TRgwL4Q",
    "id" : 85774586582532096,
    "created_at" : "Tue Jun 28 18:20:29 +0000 2011",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 85779216829915136,
  "created_at" : "Tue Jun 28 18:38:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Firespotter",
      "screen_name" : "firespotter",
      "indices" : [ 55, 67 ],
      "id_str" : "25011562",
      "id" : 25011562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackbookpro",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85771700406456320",
  "text" : "#blackbookpro project moving forward thanks to josh at @firespotter helping with anodizing!",
  "id" : 85771700406456320,
  "created_at" : "Tue Jun 28 18:09:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 10, 17 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85561855887671296",
  "text" : "Chase and @square breaking on me in iOS 5 beta 2 for CDMA. Anyone else experience this issue?",
  "id" : 85561855887671296,
  "created_at" : "Tue Jun 28 04:15:10 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joanne chang-myers",
      "screen_name" : "jbchang",
      "indices" : [ 3, 11 ],
      "id_str" : "31391307",
      "id" : 31391307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85437246286741505",
  "text" : "RT @jbchang: Designing cake for Harvard's 375th anniversary in October. 50 sheetcakes assembled to make one huge H. Red velvet (go crimson!)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "85393942916505601",
    "text" : "Designing cake for Harvard's 375th anniversary in October. 50 sheetcakes assembled to make one huge H. Red velvet (go crimson!)",
    "id" : 85393942916505601,
    "created_at" : "Mon Jun 27 17:07:57 +0000 2011",
    "user" : {
      "name" : "joanne chang-myers",
      "screen_name" : "jbchang",
      "protected" : false,
      "id_str" : "31391307",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3341897826/134730ca9f787c65b4b6cd1c7a78fd8b_normal.jpeg",
      "id" : 31391307,
      "verified" : false
    }
  },
  "id" : 85437246286741505,
  "created_at" : "Mon Jun 27 20:00:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 0, 5 ],
      "id_str" : "132319630",
      "id" : 132319630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85366403896586241",
  "geo" : {
  },
  "id_str" : "85435379842424832",
  "in_reply_to_user_id" : 132319630,
  "text" : "@sidd nah, was home for sisters graduation, back in Seattle now!",
  "id" : 85435379842424832,
  "in_reply_to_status_id" : 85366403896586241,
  "created_at" : "Mon Jun 27 19:52:36 +0000 2011",
  "in_reply_to_screen_name" : "sidd",
  "in_reply_to_user_id_str" : "132319630",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facepalm",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85313945828737024",
  "text" : "Watching CNN morning segment on whether American students have too much homework. Let me save you an hour of banter CNN: NO. #facepalm",
  "id" : 85313945828737024,
  "created_at" : "Mon Jun 27 11:50:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "home",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85265269034983424",
  "text" : "Listening to jazz and driving lonely NY country roads in the predawn twilight. #home",
  "id" : 85265269034983424,
  "created_at" : "Mon Jun 27 08:36:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "indices" : [ 3, 17 ],
      "id_str" : "2172",
      "id" : 2172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85136170597629953",
  "text" : "RT @laughingsquid: Doonesbury takes a look at how search engines impact the life of a college student http://owl.li/5qJot",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "85135497315356674",
    "text" : "Doonesbury takes a look at how search engines impact the life of a college student http://owl.li/5qJot",
    "id" : 85135497315356674,
    "created_at" : "Mon Jun 27 00:00:58 +0000 2011",
    "user" : {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "protected" : false,
      "id_str" : "2172",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/340068086/laughing_squid_logo_normal.jpg",
      "id" : 2172,
      "verified" : true
    }
  },
  "id" : 85136170597629953,
  "created_at" : "Mon Jun 27 00:03:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85098752699928577",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee there are strong female characters in Neal stephensons novels, but mostly as supporting characters",
  "id" : 85098752699928577,
  "created_at" : "Sun Jun 26 21:34:58 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84674198798209024",
  "geo" : {
  },
  "id_str" : "84674688969740288",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee is the sky blue?",
  "id" : 84674688969740288,
  "in_reply_to_status_id" : 84674198798209024,
  "created_at" : "Sat Jun 25 17:29:53 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84672909989261312",
  "text" : "United pilot working the customer service desk and passing out food after late London flight chaos overwhelms staff. Faith in humanity +1",
  "id" : 84672909989261312,
  "created_at" : "Sat Jun 25 17:22:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 47, 61 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84663778465161217",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee's graduation story was picked up by @hackernewsbot!",
  "id" : 84663778465161217,
  "created_at" : "Sat Jun 25 16:46:32 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84595053930098688",
  "text" : "At a TSA checkpoint with their PSAs playing on loop makes me feel like I'm in City 17",
  "id" : 84595053930098688,
  "created_at" : "Sat Jun 25 12:13:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 0, 8 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84402955884838912",
  "geo" : {
  },
  "id_str" : "84428791639842816",
  "in_reply_to_user_id" : 38399009,
  "text" : "@bznotes that's good news. Cleantech is a lot more interesting than the deluge of group-buying-checkin-based-social-network startups.",
  "id" : 84428791639842816,
  "in_reply_to_status_id" : 84402955884838912,
  "created_at" : "Sat Jun 25 01:12:47 +0000 2011",
  "in_reply_to_screen_name" : "bznotes",
  "in_reply_to_user_id_str" : "38399009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http://t.co/CoNqr8b",
      "expanded_url" : "http://hvrd.me/jHRc2g",
      "display_url" : "hvrd.me/jHRc2g"
    } ]
  },
  "geo" : {
  },
  "id_str" : "84425251764707328",
  "text" : "RT @hseas: SEAS to offer graduate secondary field in Computational Science and Engineering http://t.co/CoNqr8b",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 99 ],
        "url" : "http://t.co/CoNqr8b",
        "expanded_url" : "http://hvrd.me/jHRc2g",
        "display_url" : "hvrd.me/jHRc2g"
      } ]
    },
    "geo" : {
    },
    "id_str" : "84336996327235584",
    "text" : "SEAS to offer graduate secondary field in Computational Science and Engineering http://t.co/CoNqr8b",
    "id" : 84336996327235584,
    "created_at" : "Fri Jun 24 19:08:01 +0000 2011",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 84425251764707328,
  "created_at" : "Sat Jun 25 00:58:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Lulz Boat",
      "screen_name" : "LulzSec",
      "indices" : [ 3, 11 ],
      "id_str" : "294325981",
      "id" : 294325981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84347627650555904",
  "text" : "RT @LulzSec: If you use the same password for your PayPal and Neopets accounts, welcome to the 10% of that 62K that's being laughed at b ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "84314135696900096",
    "text" : "If you use the same password for your PayPal and Neopets accounts, welcome to the 10% of that 62K that's being laughed at by the other 90%.",
    "id" : 84314135696900096,
    "created_at" : "Fri Jun 24 17:37:11 +0000 2011",
    "user" : {
      "name" : "The Lulz Boat",
      "screen_name" : "LulzSec",
      "protected" : false,
      "id_str" : "294325981",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1341989664/somehwat-mad-completely-mad-u-mad-MADAD_normal.jpg",
      "id" : 294325981,
      "verified" : false
    }
  },
  "id" : 84347627650555904,
  "created_at" : "Fri Jun 24 19:50:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Ramsey",
      "screen_name" : "willdanieley",
      "indices" : [ 0, 13 ],
      "id_str" : "141380372",
      "id" : 141380372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84246495657865217",
  "geo" : {
  },
  "id_str" : "84293866269847552",
  "in_reply_to_user_id" : 141380372,
  "text" : "@willdanieley you would love seattle! More oysters than I know what to do with.",
  "id" : 84293866269847552,
  "in_reply_to_status_id" : 84246495657865217,
  "created_at" : "Fri Jun 24 16:16:38 +0000 2011",
  "in_reply_to_screen_name" : "willdanieley",
  "in_reply_to_user_id_str" : "141380372",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Ramsey",
      "screen_name" : "willdanieley",
      "indices" : [ 3, 16 ],
      "id_str" : "141380372",
      "id" : 141380372
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 18, 25 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84293754252562432",
  "text" : "RT @willdanieley: @khsieh just found two receipts and a postcard from Russell House Tavern in my suit pocket. Think that qualifies as an ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 0, 7 ],
        "id_str" : "111999960",
        "id" : 111999960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "84246495657865217",
    "in_reply_to_user_id" : 19380775,
    "text" : "@khsieh just found two receipts and a postcard from Russell House Tavern in my suit pocket. Think that qualifies as an obsession",
    "id" : 84246495657865217,
    "created_at" : "Fri Jun 24 13:08:24 +0000 2011",
    "in_reply_to_screen_name" : "kane",
    "in_reply_to_user_id_str" : "19380775",
    "user" : {
      "name" : "Will Ramsey",
      "screen_name" : "willdanieley",
      "protected" : false,
      "id_str" : "141380372",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1147740798/n1393531007_30207792_3591_normal.jpg",
      "id" : 141380372,
      "verified" : false
    }
  },
  "id" : 84293754252562432,
  "created_at" : "Fri Jun 24 16:16:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cult of Mac",
      "screen_name" : "cultofmac",
      "indices" : [ 3, 13 ],
      "id_str" : "9688342",
      "id" : 9688342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84290964960706560",
  "text" : "RT @cultofmac: Chinese Report Suggests iPhone 5 Will Come To America As Early As August http://j.mp/lT5Azp\u201D",
  "id" : 84290964960706560,
  "created_at" : "Fri Jun 24 16:05:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 29, 38 ],
      "id_str" : "13982132",
      "id" : 13982132
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 43, 54 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84059622100566016",
  "text" : "The prototype is still up at @medialab! RT @TechCrunch: Oblong Has Built The Future Of Computing. It's Beautiful. http://j.mp/iEtXnf",
  "id" : 84059622100566016,
  "created_at" : "Fri Jun 24 00:45:50 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83910905594777600",
  "geo" : {
  },
  "id_str" : "83927946577985536",
  "in_reply_to_user_id" : 13334072,
  "text" : "@qichenz Lenovo ideapads are pretty decent!",
  "id" : 83927946577985536,
  "in_reply_to_status_id" : 83910905594777600,
  "created_at" : "Thu Jun 23 16:02:36 +0000 2011",
  "in_reply_to_screen_name" : "qichenzhang",
  "in_reply_to_user_id_str" : "13334072",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 0, 10 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geekwire",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83801136565460992",
  "geo" : {
  },
  "id_str" : "83805570594902017",
  "in_reply_to_user_id" : 14326765,
  "text" : "@johnhcook I'm really sad I missed the #geekwire launch! Any cool seattle events coming up?",
  "id" : 83805570594902017,
  "in_reply_to_status_id" : 83801136565460992,
  "created_at" : "Thu Jun 23 07:56:19 +0000 2011",
  "in_reply_to_screen_name" : "johnhcook",
  "in_reply_to_user_id_str" : "14326765",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 111 ],
      "url" : "http://t.co/pnJKEm0",
      "expanded_url" : "http://nizoapp.com/",
      "display_url" : "nizoapp.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "83736316721889280",
  "text" : "The most beautiful website I've seen in a while. I don't even know what it is but I want it http://t.co/pnJKEm0",
  "id" : 83736316721889280,
  "created_at" : "Thu Jun 23 03:21:08 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83699556625301507",
  "text" : "Late iPhone product cycle set to steal the thunder from Nokia+Mango this fall. I wonder of it was intentional?",
  "id" : 83699556625301507,
  "created_at" : "Thu Jun 23 00:55:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 8, 13 ],
      "id_str" : "12",
      "id" : 12
    }, {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 70, 77 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83579751767355392",
  "text" : "Whoa RT @jack: Thrilled to announce that Larry Summers is joining the @Square board: http://j.mp/lUWNwB",
  "id" : 83579751767355392,
  "created_at" : "Wed Jun 22 16:59:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Core77",
      "screen_name" : "core77",
      "indices" : [ 3, 10 ],
      "id_str" : "20236725",
      "id" : 20236725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83571913187794945",
  "text" : "RT @core77: TEDx Boston Adventure 2011: MIT Media Lab and How to Innovate:  http://bit.ly/kLqXRW",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "83570706058723328",
    "text" : "TEDx Boston Adventure 2011: MIT Media Lab and How to Innovate:  http://bit.ly/kLqXRW",
    "id" : 83570706058723328,
    "created_at" : "Wed Jun 22 16:23:03 +0000 2011",
    "user" : {
      "name" : "Core77",
      "screen_name" : "core77",
      "protected" : false,
      "id_str" : "20236725",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2706662093/6d6e3a2ac48b0d4a077a39bba1f03fc5_normal.jpeg",
      "id" : 20236725,
      "verified" : false
    }
  },
  "id" : 83571913187794945,
  "created_at" : "Wed Jun 22 16:27:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinay Trivedi",
      "screen_name" : "trivinay",
      "indices" : [ 0, 9 ],
      "id_str" : "236627145",
      "id" : 236627145
    }, {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 86, 95 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83520105916547072",
  "geo" : {
  },
  "id_str" : "83569199812849664",
  "in_reply_to_user_id" : 236627145,
  "text" : "@trivinay that camera tech is 19 yrs old.  We'll see if they can nail implementation. @medialab has had prototypes kicking around for years.",
  "id" : 83569199812849664,
  "in_reply_to_status_id" : 83520105916547072,
  "created_at" : "Wed Jun 22 16:17:04 +0000 2011",
  "in_reply_to_screen_name" : "trivinay",
  "in_reply_to_user_id_str" : "236627145",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackbookpro",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83567325097365506",
  "text" : "Removing adhesive gunk from the anodizing! #blackbookpro http://twitpic.com/5f8xre",
  "id" : 83567325097365506,
  "created_at" : "Wed Jun 22 16:09:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83339732645453827",
  "geo" : {
  },
  "id_str" : "83440323208032256",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin ah, but the key difference is that it's a timeless leica and not an apple widget with a 10 month product cycle ;)",
  "id" : 83440323208032256,
  "in_reply_to_status_id" : 83339732645453827,
  "created_at" : "Wed Jun 22 07:44:57 +0000 2011",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackbookpro",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83439767655682048",
  "text" : "Apples not making black MacBook Air so i disassembled MBP to the aluminum to anodize. Updates soon. #blackbookpro http://twitpic.com/5f337c",
  "id" : 83439767655682048,
  "created_at" : "Wed Jun 22 07:42:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Lulz Boat",
      "screen_name" : "LulzSec",
      "indices" : [ 0, 8 ],
      "id_str" : "294325981",
      "id" : 294325981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83283731380572160",
  "geo" : {
  },
  "id_str" : "83339066287988737",
  "in_reply_to_user_id" : 294325981,
  "text" : "@LulzSec try OldBoy - korean film, won a bunch of leaves-around-small-words awards",
  "id" : 83339066287988737,
  "in_reply_to_status_id" : 83283731380572160,
  "created_at" : "Wed Jun 22 01:02:36 +0000 2011",
  "in_reply_to_screen_name" : "LulzSec",
  "in_reply_to_user_id_str" : "294325981",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devon Ray",
      "screen_name" : "DevonRay",
      "indices" : [ 3, 12 ],
      "id_str" : "245281190",
      "id" : 245281190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83337555361267713",
  "text" : "RT @DevonRay: I've officially lost my ability to successfully meet up with someone without the using cell phones",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "83278740104286209",
    "text" : "I've officially lost my ability to successfully meet up with someone without the using cell phones",
    "id" : 83278740104286209,
    "created_at" : "Tue Jun 21 21:02:53 +0000 2011",
    "user" : {
      "name" : "Devon Ray",
      "screen_name" : "DevonRay",
      "protected" : false,
      "id_str" : "245281190",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1771205992/image_normal.jpg",
      "id" : 245281190,
      "verified" : false
    }
  },
  "id" : 83337555361267713,
  "created_at" : "Wed Jun 22 00:56:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 0, 6 ],
      "id_str" : "49019553",
      "id" : 49019553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "realworld",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83269832417619968",
  "geo" : {
  },
  "id_str" : "83337036496519168",
  "in_reply_to_user_id" : 49019553,
  "text" : "@mjoyw recipe please! Need more #realworld food skillz",
  "id" : 83337036496519168,
  "in_reply_to_status_id" : 83269832417619968,
  "created_at" : "Wed Jun 22 00:54:32 +0000 2011",
  "in_reply_to_screen_name" : "mjoyw",
  "in_reply_to_user_id_str" : "49019553",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 0, 13 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anonymous",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83335986259570689",
  "geo" : {
  },
  "id_str" : "83336842258296832",
  "in_reply_to_user_id" : 279390084,
  "text" : "@YourAnonNews its available to subscribers - the article is \"An anonymous foe\" - they mash every recent hack into #anonymous",
  "id" : 83336842258296832,
  "in_reply_to_status_id" : 83335986259570689,
  "created_at" : "Wed Jun 22 00:53:46 +0000 2011",
  "in_reply_to_screen_name" : "YourAnonNews",
  "in_reply_to_user_id_str" : "279390084",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 0, 13 ],
      "id_str" : "5988062",
      "id" : 5988062
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 27, 40 ],
      "id_str" : "279390084",
      "id" : 279390084
    }, {
      "name" : "The Lulz Boat",
      "screen_name" : "LulzSec",
      "indices" : [ 45, 53 ],
      "id_str" : "294325981",
      "id" : 294325981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83335472767713280",
  "in_reply_to_user_id" : 5988062,
  "text" : "@TheEconomist is confusing @YourAnonNews and @LulzSec in its audio transcriptions.",
  "id" : 83335472767713280,
  "created_at" : "Wed Jun 22 00:48:19 +0000 2011",
  "in_reply_to_screen_name" : "TheEconomist",
  "in_reply_to_user_id_str" : "5988062",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83330981536350208",
  "text" : "Leica M9-P or my kidney? Decisions decisions.",
  "id" : 83330981536350208,
  "created_at" : "Wed Jun 22 00:30:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Limi",
      "screen_name" : "limi",
      "indices" : [ 3, 8 ],
      "id_str" : "1045541",
      "id" : 1045541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83213501396557824",
  "text" : "RT @limi: Mullet Developer, n. \u2014 Strong back-end skills, weak front-end skills.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "68830481076060160",
    "text" : "Mullet Developer, n. \u2014 Strong back-end skills, weak front-end skills.",
    "id" : 68830481076060160,
    "created_at" : "Fri May 13 00:10:40 +0000 2011",
    "user" : {
      "name" : "Alex Limi",
      "screen_name" : "limi",
      "protected" : false,
      "id_str" : "1045541",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2244569689/Limi_-_headshot__160px_normal.jpg",
      "id" : 1045541,
      "verified" : false
    }
  },
  "id" : 83213501396557824,
  "created_at" : "Tue Jun 21 16:43:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83103353395093504",
  "text" : "Life motto: Don't hate. Dominate.",
  "id" : 83103353395093504,
  "created_at" : "Tue Jun 21 09:25:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Matt Brian",
      "screen_name" : "m4tt",
      "indices" : [ 113, 118 ],
      "id_str" : "12235562",
      "id" : 12235562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83103236755701761",
  "text" : "RT @TheNextWeb: LulzSec supposedly claims its biggest coup yet: The entire UK 2011 Census http://tnw.to/19MNa by @m4tt on @TNWindustry",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Brian",
        "screen_name" : "m4tt",
        "indices" : [ 97, 102 ],
        "id_str" : "12235562",
        "id" : 12235562
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "83093415352467456",
    "text" : "LulzSec supposedly claims its biggest coup yet: The entire UK 2011 Census http://tnw.to/19MNa by @m4tt on @TNWindustry",
    "id" : 83093415352467456,
    "created_at" : "Tue Jun 21 08:46:28 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 83103236755701761,
  "created_at" : "Tue Jun 21 09:25:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Danz",
      "screen_name" : "JimDanz",
      "indices" : [ 3, 11 ],
      "id_str" : "4064011",
      "id" : 4064011
    }, {
      "name" : "bandcamp",
      "screen_name" : "Bandcamp",
      "indices" : [ 68, 77 ],
      "id_str" : "16705752",
      "id" : 16705752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83066083774435328",
  "text" : "RT @JimDanz: music so excellent i just happily paid 30 clams for it @bandcamp: http://thewhitepanda.bandcamp.com/album/pandamonium",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "bandcamp",
        "screen_name" : "Bandcamp",
        "indices" : [ 55, 64 ],
        "id_str" : "16705752",
        "id" : 16705752
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "58455661268303873",
    "text" : "music so excellent i just happily paid 30 clams for it @bandcamp: http://thewhitepanda.bandcamp.com/album/pandamonium",
    "id" : 58455661268303873,
    "created_at" : "Thu Apr 14 09:04:50 +0000 2011",
    "user" : {
      "name" : "Jim Danz",
      "screen_name" : "JimDanz",
      "protected" : false,
      "id_str" : "4064011",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2373836789/image_normal.jpg",
      "id" : 4064011,
      "verified" : false
    }
  },
  "id" : 83066083774435328,
  "created_at" : "Tue Jun 21 06:57:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 85, 93 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http://t.co/9OKumej",
      "expanded_url" : "http://goo.gl/VV5Od",
      "display_url" : "goo.gl/VV5Od"
    } ]
  },
  "geo" : {
  },
  "id_str" : "83065765326098432",
  "text" : "\"...the choice this fall is going to be very simple. iPhone or Windows Phone...\" via @gizmodo http://t.co/9OKumej",
  "id" : 83065765326098432,
  "created_at" : "Tue Jun 21 06:56:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft News",
      "screen_name" : "MSFTnews",
      "indices" : [ 3, 12 ],
      "id_str" : "24741685",
      "id" : 24741685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SkyDrive",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "HTML5",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http://t.co/kQRZXK4",
      "expanded_url" : "http://bit.ly/l8b1WL",
      "display_url" : "bit.ly/l8b1WL"
    } ]
  },
  "geo" : {
  },
  "id_str" : "82976740544221184",
  "text" : "RT @MSFTnews: did we mention 25GB of FREE online storage? First look at new #SkyDrive: faster, simpler, #HTML5 powered http://t.co/kQRZXK4",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SkyDrive",
        "indices" : [ 62, 71 ]
      }, {
        "text" : "HTML5",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 124 ],
        "url" : "http://t.co/kQRZXK4",
        "expanded_url" : "http://bit.ly/l8b1WL",
        "display_url" : "bit.ly/l8b1WL"
      } ]
    },
    "geo" : {
    },
    "id_str" : "82927829284696065",
    "text" : "did we mention 25GB of FREE online storage? First look at new #SkyDrive: faster, simpler, #HTML5 powered http://t.co/kQRZXK4",
    "id" : 82927829284696065,
    "created_at" : "Mon Jun 20 21:48:29 +0000 2011",
    "user" : {
      "name" : "Microsoft News",
      "screen_name" : "MSFTnews",
      "protected" : false,
      "id_str" : "24741685",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1536324742/72x72_msftnews_normal.png",
      "id" : 24741685,
      "verified" : true
    }
  },
  "id" : 82976740544221184,
  "created_at" : "Tue Jun 21 01:02:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 32 ],
      "url" : "http://t.co/x6mSRvu",
      "expanded_url" : "http://yfrog.com/kjx37qjj",
      "display_url" : "yfrog.com/kjx37qjj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "82830287934996480",
  "text" : "Coincidence? http://t.co/x6mSRvu",
  "id" : 82830287934996480,
  "created_at" : "Mon Jun 20 15:20:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 119, 131 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 132, 140 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82501266340720642",
  "text" : "Idea: Atrix-style laptop dock for smartphone, but the phone is the trackpad instead of an awkward tumor like the Atrix @badboyboyce @digitil",
  "id" : 82501266340720642,
  "created_at" : "Sun Jun 19 17:33:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82380897923514368",
  "text" : "The clickety-clack of the awesome ThinkPad keyboard is keeping my roommates awake. Oops.",
  "id" : 82380897923514368,
  "created_at" : "Sun Jun 19 09:35:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82232986556309504",
  "geo" : {
  },
  "id_str" : "82305502507311104",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee I was in cambridge last summer to proctor the summer school.",
  "id" : 82305502507311104,
  "in_reply_to_status_id" : 82232986556309504,
  "created_at" : "Sun Jun 19 04:35:35 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82166581970477056",
  "geo" : {
  },
  "id_str" : "82171804185149440",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee I don't miss Cambridge summer weather at all.",
  "id" : 82171804185149440,
  "in_reply_to_status_id" : 82166581970477056,
  "created_at" : "Sat Jun 18 19:44:19 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Treacy",
      "screen_name" : "TimTreacy",
      "indices" : [ 3, 13 ],
      "id_str" : "39608482",
      "id" : 39608482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Br",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82148202081554432",
  "text" : "RT @TimTreacy: Tim Thomas' parents sold their wedding rings when he was young to support his career. Wow. You can't make this up. Go #Br ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bruins",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "82104565352251392",
    "text" : "Tim Thomas' parents sold their wedding rings when he was young to support his career. Wow. You can't make this up. Go #Bruins!!!!",
    "id" : 82104565352251392,
    "created_at" : "Sat Jun 18 15:17:08 +0000 2011",
    "user" : {
      "name" : "Tim Treacy",
      "screen_name" : "TimTreacy",
      "protected" : false,
      "id_str" : "39608482",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2870335849/85f460b1099830d9702161823a5bb8b3_normal.jpeg",
      "id" : 39608482,
      "verified" : false
    }
  },
  "id" : 82148202081554432,
  "created_at" : "Sat Jun 18 18:10:32 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81900535552286720",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee Working on the hipster look :P but it makes me unfriendly. Considering changing back.",
  "id" : 81900535552286720,
  "created_at" : "Sat Jun 18 01:46:23 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81786755002535936",
  "geo" : {
  },
  "id_str" : "81836729635569664",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee ~$10. Unless you want an official Apple one, which is hand artificed by virgin Geniuses. At least I assume that's why it's $30...",
  "id" : 81836729635569664,
  "in_reply_to_status_id" : 81786755002535936,
  "created_at" : "Fri Jun 17 21:32:51 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    }, {
      "name" : "Venmo",
      "screen_name" : "venmo",
      "indices" : [ 35, 41 ],
      "id_str" : "18580938",
      "id" : 18580938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81733200493293569",
  "geo" : {
  },
  "id_str" : "81765126260264960",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose I'll take an invite for @venmo if you still have them!",
  "id" : 81765126260264960,
  "in_reply_to_status_id" : 81733200493293569,
  "created_at" : "Fri Jun 17 16:48:19 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 69 ],
      "url" : "http://t.co/EPlABPm",
      "expanded_url" : "http://risky.biz/lulzsec",
      "display_url" : "risky.biz/lulzsec"
    } ]
  },
  "geo" : {
  },
  "id_str" : "81530729187639296",
  "text" : "Why we secretly love LulzSec | via Risky Business http://t.co/EPlABPm",
  "id" : 81530729187639296,
  "created_at" : "Fri Jun 17 01:16:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 4, 15 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http://t.co/6ffzMPO",
      "expanded_url" : "http://techcrunch.com/2011/06/15/hell-yes-mayor-bloomberg-im-with-you/",
      "display_url" : "techcrunch.com/2011/06/15/hel\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "81527671158349824",
  "text" : "via @TechCrunch Hell Yes, Mayor Bloomberg. I\u2019m With You. http://t.co/6ffzMPO",
  "id" : 81527671158349824,
  "created_at" : "Fri Jun 17 01:04:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81523315088441344",
  "text" : "RT @hotdogsladies: Apple Store has a huge-ass line of people waiting to touch an iPad.\n\nProbably just overflow from that mob over at the ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://birdhouseapp.com\" rel=\"nofollow\">Birdhouse</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "81493977211207680",
    "text" : "Apple Store has a huge-ass line of people waiting to touch an iPad.\n\nProbably just overflow from that mob over at the PlayBook SuperStore.",
    "id" : 81493977211207680,
    "created_at" : "Thu Jun 16 22:50:52 +0000 2011",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/51857279/merlin_icon_184-1_normal.png",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 81523315088441344,
  "created_at" : "Fri Jun 17 00:47:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81475209793777665",
  "geo" : {
  },
  "id_str" : "81522829127979008",
  "in_reply_to_user_id" : 110202853,
  "text" : "@maevewang might take you up on that Cuba trip.",
  "id" : 81522829127979008,
  "in_reply_to_status_id" : 81475209793777665,
  "created_at" : "Fri Jun 17 00:45:31 +0000 2011",
  "in_reply_to_screen_name" : "m_t_wang",
  "in_reply_to_user_id_str" : "110202853",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 59, 65 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kinect",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81454912822722561",
  "text" : "#kinect SDK is live! Time to build that roomba turret with @jluan",
  "id" : 81454912822722561,
  "created_at" : "Thu Jun 16 20:15:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Barnes",
      "screen_name" : "billba",
      "indices" : [ 3, 10 ],
      "id_str" : "9832392",
      "id" : 9832392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81393623953977344",
  "text" : "RT @billba: I assumed Vancouver would express its displeasure via a strongly worded note.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "81391063390105601",
    "text" : "I assumed Vancouver would express its displeasure via a strongly worded note.",
    "id" : 81391063390105601,
    "created_at" : "Thu Jun 16 16:01:56 +0000 2011",
    "user" : {
      "name" : "Bill Barnes",
      "screen_name" : "billba",
      "protected" : false,
      "id_str" : "9832392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2270557743/Bill_s-face_normal.png",
      "id" : 9832392,
      "verified" : false
    }
  },
  "id" : 81393623953977344,
  "created_at" : "Thu Jun 16 16:12:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 3, 12 ],
      "id_str" : "817386",
      "id" : 817386
    }, {
      "name" : "Ryan Kim",
      "screen_name" : "oryankim",
      "indices" : [ 56, 65 ],
      "id_str" : "28181012",
      "id" : 28181012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81392113144692736",
  "text" : "RT @Techmeme: U.S. CIO Kundra leaving for Harvard post (@oryankim / GigaOM) http://j.mp/mlPi9V http://techme.me/BfkP",
  "retweeted_status" : {
    "source" : "<a href=\"http://techmeme.com/\" rel=\"nofollow\">Techmeme</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Kim",
        "screen_name" : "oryankim",
        "indices" : [ 42, 51 ],
        "id_str" : "28181012",
        "id" : 28181012
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "81385793578467328",
    "text" : "U.S. CIO Kundra leaving for Harvard post (@oryankim / GigaOM) http://j.mp/mlPi9V http://techme.me/BfkP",
    "id" : 81385793578467328,
    "created_at" : "Thu Jun 16 15:40:59 +0000 2011",
    "user" : {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "protected" : false,
      "id_str" : "817386",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1783187293/techmeme_tw_av_normal",
      "id" : 817386,
      "verified" : false
    }
  },
  "id" : 81392113144692736,
  "created_at" : "Thu Jun 16 16:06:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 3, 12 ],
      "id_str" : "817386",
      "id" : 817386
    }, {
      "name" : "Tom Warren",
      "screen_name" : "tomwarren",
      "indices" : [ 75, 85 ],
      "id_str" : "12273252",
      "id" : 12273252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81279500419203072",
  "text" : "RT @Techmeme: Kinect for Windows SDK beta available to download this week (@tomwarren / WinRumors) http://j.mp/jlyw1r http://techme.me/Bfk3",
  "retweeted_status" : {
    "source" : "<a href=\"http://techmeme.com/\" rel=\"nofollow\">Techmeme</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Warren",
        "screen_name" : "tomwarren",
        "indices" : [ 61, 71 ],
        "id_str" : "12273252",
        "id" : 12273252
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "81223473032208384",
    "text" : "Kinect for Windows SDK beta available to download this week (@tomwarren / WinRumors) http://j.mp/jlyw1r http://techme.me/Bfk3",
    "id" : 81223473032208384,
    "created_at" : "Thu Jun 16 04:55:59 +0000 2011",
    "user" : {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "protected" : false,
      "id_str" : "817386",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1783187293/techmeme_tw_av_normal",
      "id" : 817386,
      "verified" : false
    }
  },
  "id" : 81279500419203072,
  "created_at" : "Thu Jun 16 08:38:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http://t.co/gwsAsUR",
      "expanded_url" : "http://everythingsysadmin.com/2011/06/avoid-using-the-term-cloud-com.html",
      "display_url" : "everythingsysadmin.com/2011/06/avoid-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "81269672644845568",
  "text" : "\"Cloud is what marketing and non-technical people use.\" http://t.co/gwsAsUR",
  "id" : 81269672644845568,
  "created_at" : "Thu Jun 16 07:59:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81248041956421632",
  "text" : "Loving the new X220. What's a good Twitter app for Windows? Using a browser is so 2006.",
  "id" : 81248041956421632,
  "created_at" : "Thu Jun 16 06:33:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "playbook",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "fail",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80884639966834688",
  "text" : "#playbook commercial advertises flash capability... and nothing else. #fail",
  "id" : 80884639966834688,
  "created_at" : "Wed Jun 15 06:29:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 91, 101 ],
      "id_str" : "37570179",
      "id" : 37570179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80818055743148032",
  "text" : "RT @TechCrunch: Troubled Startup Color Loses Cofounder Peter Pham http://tcrn.ch/mg5oIS by @arrington",
  "retweeted_status" : {
    "source" : "<a href=\"http://vip.wordpress.com/hosting\" rel=\"nofollow\">WordPress.com VIP</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Arrington",
        "screen_name" : "arrington",
        "indices" : [ 75, 85 ],
        "id_str" : "37570179",
        "id" : 37570179
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "80808627216199680",
    "text" : "Troubled Startup Color Loses Cofounder Peter Pham http://tcrn.ch/mg5oIS by @arrington",
    "id" : 80808627216199680,
    "created_at" : "Wed Jun 15 01:27:32 +0000 2011",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2176846885/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 80818055743148032,
  "created_at" : "Wed Jun 15 02:05:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80774406070206464",
  "geo" : {
  },
  "id_str" : "80804285658570752",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern Wind up Bird Chronicles by Murakami got me through a 14 hr flight from Taiwan!",
  "id" : 80804285658570752,
  "in_reply_to_status_id" : 80774406070206464,
  "created_at" : "Wed Jun 15 01:10:17 +0000 2011",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80801502364569600",
  "text" : "Sony nex c3 has great solution to the manual-focusing-on-LCD issue! Leica+Sony more appealing than ever.",
  "id" : 80801502364569600,
  "created_at" : "Wed Jun 15 00:59:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BostInnovation",
      "screen_name" : "BostInnovation",
      "indices" : [ 3, 18 ],
      "id_str" : "1056260852",
      "id" : 1056260852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80706352435044353",
  "text" : "RT @BostInnovation: 20 Mind Blowing Facts about MIT\u2019s Impact on Innovation http://bit.ly/lhB0Cv",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "80666463924518912",
    "text" : "20 Mind Blowing Facts about MIT\u2019s Impact on Innovation http://bit.ly/lhB0Cv",
    "id" : 80666463924518912,
    "created_at" : "Tue Jun 14 16:02:38 +0000 2011",
    "user" : {
      "name" : "BostInno",
      "screen_name" : "BostInno",
      "protected" : false,
      "id_str" : "16877220",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3314802473/f7d5c89cb0722c196a4e7639165f5907_normal.jpeg",
      "id" : 16877220,
      "verified" : false
    }
  },
  "id" : 80706352435044353,
  "created_at" : "Tue Jun 14 18:41:08 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80665117615861760",
  "text" : "Groupon is getting a lot of hate these days from small businesses and tech peeps",
  "id" : 80665117615861760,
  "created_at" : "Tue Jun 14 15:57:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80333094556667904",
  "text" : "RT @ForbesTech: China Creates Cyber-Warfare Squad http://onforb.es/kXZUo4",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "80303585396654081",
    "text" : "China Creates Cyber-Warfare Squad http://onforb.es/kXZUo4",
    "id" : 80303585396654081,
    "created_at" : "Mon Jun 13 16:00:41 +0000 2011",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 80333094556667904,
  "created_at" : "Mon Jun 13 17:57:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 3, 9 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80155998001696768",
  "text" : "RT @rands: To serif or not to serif. I've spent days on this one.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "80088566604115969",
    "text" : "To serif or not to serif. I've spent days on this one.",
    "id" : 80088566604115969,
    "created_at" : "Mon Jun 13 01:46:16 +0000 2011",
    "user" : {
      "name" : "rands",
      "screen_name" : "rands",
      "protected" : false,
      "id_str" : "30923",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2886028302/d9137f9df14bafdb1144d6b6c16259c1_normal.png",
      "id" : 30923,
      "verified" : false
    }
  },
  "id" : 80155998001696768,
  "created_at" : "Mon Jun 13 06:14:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http://t.co/GTodWmi",
      "expanded_url" : "http://yfrog.com/gzummuwoj",
      "display_url" : "yfrog.com/gzummuwoj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.2793142415, -123.1232974993 ]
  },
  "id_str" : "79593875068555265",
  "text" : "Chaos in the streets of Vancouver post fifth game win! http://t.co/GTodWmi",
  "id" : 79593875068555265,
  "created_at" : "Sat Jun 11 17:00:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79341475871195137",
  "text" : "@lolamew_ I think you mentioned the wrong khsieh!",
  "id" : 79341475871195137,
  "created_at" : "Sat Jun 11 00:17:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyphen magazine",
      "screen_name" : "hyphenmagazine",
      "indices" : [ 0, 15 ],
      "id_str" : "21952872",
      "id" : 21952872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldboy",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79265127706263552",
  "geo" : {
  },
  "id_str" : "79341006243381248",
  "in_reply_to_user_id" : 21952872,
  "text" : "@hyphenmagazine just watched Korean film #oldboy! Very well made, very intense.",
  "id" : 79341006243381248,
  "in_reply_to_status_id" : 79265127706263552,
  "created_at" : "Sat Jun 11 00:15:44 +0000 2011",
  "in_reply_to_screen_name" : "hyphenmagazine",
  "in_reply_to_user_id_str" : "21952872",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 3, 11 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "community",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79214550867656705",
  "text" : "RT @Harvard: The artistic side of science http://hvrd.me/jtG1ez #community",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "community",
        "indices" : [ 51, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "79156703010111488",
    "text" : "The artistic side of science http://hvrd.me/jtG1ez #community",
    "id" : 79156703010111488,
    "created_at" : "Fri Jun 10 12:03:23 +0000 2011",
    "user" : {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "protected" : false,
      "id_str" : "39585367",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3349317264/1954930211e08d2ba39bb6a670049eb3_normal.png",
      "id" : 39585367,
      "verified" : true
    }
  },
  "id" : 79214550867656705,
  "created_at" : "Fri Jun 10 15:53:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 0, 5 ],
      "id_str" : "132319630",
      "id" : 132319630
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 9, 17 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78993173355040768",
  "geo" : {
  },
  "id_str" : "78993669297946625",
  "in_reply_to_user_id" : 132319630,
  "text" : "@sidd is @twitter paying you that poorly?",
  "id" : 78993669297946625,
  "in_reply_to_status_id" : 78993173355040768,
  "created_at" : "Fri Jun 10 01:15:33 +0000 2011",
  "in_reply_to_screen_name" : "sidd",
  "in_reply_to_user_id_str" : "132319630",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78991950912552960",
  "text" : "New pair of glasses! I can see again.",
  "id" : 78991950912552960,
  "created_at" : "Fri Jun 10 01:08:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 40, 51 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http://t.co/8yJqJMe",
      "expanded_url" : "http://ow.ly/5e8L7",
      "display_url" : "ow.ly/5e8L7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "78965708075180033",
  "text" : "Oh snap, Lewis and Faust take sides! RT @thecrimson: Before war in Libya, Harvard profs advised Gaddafi. http://t.co/8yJqJMe",
  "id" : 78965708075180033,
  "created_at" : "Thu Jun 09 23:24:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 0, 6 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78862688603734016",
  "geo" : {
  },
  "id_str" : "78870022625308672",
  "in_reply_to_user_id" : 18918415,
  "text" : "@koush mint is backed by intuit. Maybe some privileges there?",
  "id" : 78870022625308672,
  "in_reply_to_status_id" : 78862688603734016,
  "created_at" : "Thu Jun 09 17:04:13 +0000 2011",
  "in_reply_to_screen_name" : "koush",
  "in_reply_to_user_id_str" : "18918415",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio",
      "screen_name" : "antrod",
      "indices" : [ 0, 7 ],
      "id_str" : "464493",
      "id" : 464493
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 8, 20 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Postagram",
      "screen_name" : "postagram",
      "indices" : [ 40, 50 ],
      "id_str" : "263874106",
      "id" : 263874106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78869345937260544",
  "in_reply_to_user_id" : 464493,
  "text" : "@antrod @badboyboyce have you guys seen @postagram? Pic to postcard + mailing service in a mobile app!",
  "id" : 78869345937260544,
  "created_at" : "Thu Jun 09 17:01:32 +0000 2011",
  "in_reply_to_screen_name" : "antrod",
  "in_reply_to_user_id_str" : "464493",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78852334683291648",
  "text" : "RT @WSJ: Citigroup says hackers have viewed the account information of roughly 1% of its customers http://on.wsj.com/jK9ktZ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "78810281140158465",
    "text" : "Citigroup says hackers have viewed the account information of roughly 1% of its customers http://on.wsj.com/jK9ktZ",
    "id" : 78810281140158465,
    "created_at" : "Thu Jun 09 13:06:49 +0000 2011",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 78852334683291648,
  "created_at" : "Thu Jun 09 15:53:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78739869647634432",
  "text" : "Protip: If you're airing ads on a streaming site, pick music that's catchy when played over and over. Good job AT&T, not so much Lexus...",
  "id" : 78739869647634432,
  "created_at" : "Thu Jun 09 08:27:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cameraplus",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http://t.co/ajodUze",
      "expanded_url" : "http://yfrog.com/h29wasyj",
      "display_url" : "yfrog.com/h29wasyj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "78644416750944257",
  "text" : "What the hell #cameraplus, how to I move forward or backwards from this state?? http://t.co/ajodUze",
  "id" : 78644416750944257,
  "created_at" : "Thu Jun 09 02:07:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 80, 93 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http://t.co/kE5oGt8",
      "expanded_url" : "http://yfrog.com/73v71ozj",
      "display_url" : "yfrog.com/73v71ozj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "78570607507279872",
  "text" : "Yup, blackbergsecurity.com hacked. Screenshot for posterity. Thanks for the tip @kevinmitnick  http://t.co/kE5oGt8",
  "id" : 78570607507279872,
  "created_at" : "Wed Jun 08 21:14:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78526662739894272",
  "text" : "RT @medialab: The 'Sorcerers' of the MIT Media Lab:  http://bit.ly/lQui25",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "78514082004746240",
    "text" : "The 'Sorcerers' of the MIT Media Lab:  http://bit.ly/lQui25",
    "id" : 78514082004746240,
    "created_at" : "Wed Jun 08 17:29:50 +0000 2011",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 78526662739894272,
  "created_at" : "Wed Jun 08 18:19:50 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Matt Brian",
      "screen_name" : "m4tt",
      "indices" : [ 85, 90 ],
      "id_str" : "12235562",
      "id" : 12235562
    }, {
      "name" : "TNW Mobile",
      "screen_name" : "TNWmobile",
      "indices" : [ 94, 104 ],
      "id_str" : "108621686",
      "id" : 108621686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78501972172488704",
  "text" : "RT @TheNextWeb: Samsung reportedly preparing to acquire Nokia http://tnw.to/18xPx by @m4tt on @TNWmobile",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Brian",
        "screen_name" : "m4tt",
        "indices" : [ 69, 74 ],
        "id_str" : "12235562",
        "id" : 12235562
      }, {
        "name" : "TNW Mobile",
        "screen_name" : "TNWmobile",
        "indices" : [ 78, 88 ],
        "id_str" : "108621686",
        "id" : 108621686
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "78444752428728320",
    "text" : "Samsung reportedly preparing to acquire Nokia http://tnw.to/18xPx by @m4tt on @TNWmobile",
    "id" : 78444752428728320,
    "created_at" : "Wed Jun 08 12:54:21 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 78501972172488704,
  "created_at" : "Wed Jun 08 16:41:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78497490147614720",
  "text" : "After Gingerbread, iOS 5 still underwhelming. iPhones main appeal was and remains hardware.",
  "id" : 78497490147614720,
  "created_at" : "Wed Jun 08 16:23:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCSD",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http://t.co/AslV9v1",
      "expanded_url" : "http://admin.80-20nj.info/cgi/80/e?l=8%2F11p%2Ff&w=no",
      "display_url" : "admin.80-20nj.info/cgi/80/e?l=8%2\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "78380060599517184",
  "text" : "RT @HarvardCSA: \"Don't believe anything the Chinaman says\" - racial slurs from Prof Clifford Kubiak at #UCSD http://t.co/AslV9v1",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UCSD",
        "indices" : [ 87, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 112 ],
        "url" : "http://t.co/AslV9v1",
        "expanded_url" : "http://admin.80-20nj.info/cgi/80/e?l=8%2F11p%2Ff&w=no",
        "display_url" : "admin.80-20nj.info/cgi/80/e?l=8%2\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "78369882865008640",
    "text" : "\"Don't believe anything the Chinaman says\" - racial slurs from Prof Clifford Kubiak at #UCSD http://t.co/AslV9v1",
    "id" : 78369882865008640,
    "created_at" : "Wed Jun 08 07:56:50 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 78380060599517184,
  "created_at" : "Wed Jun 08 08:37:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 0, 15 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78313343101829120",
  "geo" : {
  },
  "id_str" : "78313464195579904",
  "in_reply_to_user_id" : 18107808,
  "text" : "@NaveenSrivatsa shhh the Apple Police will hear!!",
  "id" : 78313464195579904,
  "in_reply_to_status_id" : 78313343101829120,
  "created_at" : "Wed Jun 08 04:12:39 +0000 2011",
  "in_reply_to_screen_name" : "NaveenSrivatsa",
  "in_reply_to_user_id_str" : "18107808",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78311214261870593",
  "text" : "o hai, iOS5",
  "id" : 78311214261870593,
  "created_at" : "Wed Jun 08 04:03:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Meal Time",
      "screen_name" : "EpicMealTime",
      "indices" : [ 26, 39 ],
      "id_str" : "209169572",
      "id" : 209169572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78267263731507200",
  "text" : "Tuesdays are when I watch @epicmealtime while eating whatevers-in-my-fridge-fried-rice that I make.",
  "id" : 78267263731507200,
  "created_at" : "Wed Jun 08 01:09:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78261949577691136",
  "text" : "RT @evgenymorozov: Microsoft goes bot herder hunting in streets of Russia - Register http://flpbd.it/kQ5L",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.flipboard.com\" rel=\"nofollow\">Flipboard</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "78238212367196161",
    "text" : "Microsoft goes bot herder hunting in streets of Russia - Register http://flpbd.it/kQ5L",
    "id" : 78238212367196161,
    "created_at" : "Tue Jun 07 23:13:38 +0000 2011",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3293502348/616e130436ba301efd352893fcff942f_normal.jpeg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 78261949577691136,
  "created_at" : "Wed Jun 08 00:47:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78231389723566082",
  "text" : "Things living in Seattle make me want to do: commune with nature; ride motorcycles; wear tighter jeans.",
  "id" : 78231389723566082,
  "created_at" : "Tue Jun 07 22:46:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 45, 54 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http://t.co/vuiR07t",
      "expanded_url" : "http://bit.ly/bpxAXE",
      "display_url" : "bit.ly/bpxAXE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "78230574426361856",
  "text" : "Possibly one of the coolest profs ive met RT @medialab: Hiroshi Ishii @ TEDxTokyo: http://t.co/vuiR07t",
  "id" : 78230574426361856,
  "created_at" : "Tue Jun 07 22:43:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78180819667132416",
  "geo" : {
  },
  "id_str" : "78191831573204992",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee space and time intensive! Especially if you want variety.",
  "id" : 78191831573204992,
  "in_reply_to_status_id" : 78180819667132416,
  "created_at" : "Tue Jun 07 20:09:20 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIT",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "78164416180391936",
  "text" : "Bomb squad water cannons mysterious package at #MIT. Hope it wasn't someones thesis.",
  "id" : 78164416180391936,
  "created_at" : "Tue Jun 07 18:20:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78128776533385217",
  "geo" : {
  },
  "id_str" : "78160221398249472",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee if someone is using food stamps, I don't think the cost:calorie for seeds is low enough to be sustainable though",
  "id" : 78160221398249472,
  "in_reply_to_status_id" : 78128776533385217,
  "created_at" : "Tue Jun 07 18:03:43 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 40, 46 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http://t.co/sBuCuP6",
      "expanded_url" : "http://www.autoblog.com/2011/06/06/volkswagen-rolls-out-370hp-gti-reifnitz-at-worthersee/",
      "display_url" : "autoblog.com/2011/06/06/vol\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "77916080470892544",
  "text" : "370 HP in a GTI. How about them apples, @jluan? http://t.co/sBuCuP6",
  "id" : 77916080470892544,
  "created_at" : "Tue Jun 07 01:53:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77882262326218752",
  "text" : "Resisting Bostonian urge to jaywalk at every chance in Seattle.",
  "id" : 77882262326218752,
  "created_at" : "Mon Jun 06 23:39:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77850647176810497",
  "text" : "Today: apple owning mobile with iOS5, Microsoft gunning for home media with xbox announcements.",
  "id" : 77850647176810497,
  "created_at" : "Mon Jun 06 21:33:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xbox",
      "indices" : [ 68, 73 ]
    }, {
      "text" : "facepalm",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77776073865183232",
  "text" : "Annnnnd accidental controller disconnect within first 10 seconds of #xbox e3 demo #facepalm",
  "id" : 77776073865183232,
  "created_at" : "Mon Jun 06 16:37:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndarKness",
      "screen_name" : "Alex_IndarKness",
      "indices" : [ 0, 16 ],
      "id_str" : "90575128",
      "id" : 90575128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77774438057259008",
  "geo" : {
  },
  "id_str" : "77774680475439104",
  "in_reply_to_user_id" : 90575128,
  "text" : "@Alex_IndarKness official E3 link is here http://www.xbox.com/en-US/Community/E3",
  "id" : 77774680475439104,
  "in_reply_to_status_id" : 77774438057259008,
  "created_at" : "Mon Jun 06 16:31:43 +0000 2011",
  "in_reply_to_screen_name" : "Alex_IndarKness",
  "in_reply_to_user_id_str" : "90575128",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77771776108675074",
  "text" : "Microsoft E3 stream is up and running",
  "id" : 77771776108675074,
  "created_at" : "Mon Jun 06 16:20:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77770324984344576",
  "text" : "iOS 5 looks like it's ready bury BBM",
  "id" : 77770324984344576,
  "created_at" : "Mon Jun 06 16:14:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77745324139102209",
  "geo" : {
  },
  "id_str" : "77746484740767744",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha disregard... Drowsy misreading of your previous tweet!",
  "id" : 77746484740767744,
  "in_reply_to_status_id" : 77745324139102209,
  "created_at" : "Mon Jun 06 14:39:41 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http://t.co/Kd1IHwg",
      "expanded_url" : "http://yfrog.com/gy4w7htbj",
      "display_url" : "yfrog.com/gy4w7htbj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "77304567720722432",
  "text" : "New longboard deck, handmade by Motion Boards in Seattle. Complete board soon! http://t.co/Kd1IHwg",
  "id" : 77304567720722432,
  "created_at" : "Sun Jun 05 09:23:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http://t.co/GAp4Pg2",
      "expanded_url" : "http://yfrog.com/h48a7jyzj",
      "display_url" : "yfrog.com/h48a7jyzj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "77109017511608320",
  "text" : "What has two wheels, four cylinders, and makes my heart go thump? http://t.co/GAp4Pg2",
  "id" : 77109017511608320,
  "created_at" : "Sat Jun 04 20:26:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77103335336968193",
  "text" : "Coffee crawl in Seattle's Pike Place!",
  "id" : 77103335336968193,
  "created_at" : "Sat Jun 04 20:04:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 3, 14 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77071031692570625",
  "text" : "RT @thecrimson: Following Harvard's decision to welcome back Naval ROTC, Yale will establish an on-campus unit. http://ow.ly/5a6t0",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "77039034945380353",
    "text" : "Following Harvard's decision to welcome back Naval ROTC, Yale will establish an on-campus unit. http://ow.ly/5a6t0",
    "id" : 77039034945380353,
    "created_at" : "Sat Jun 04 15:48:31 +0000 2011",
    "user" : {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "protected" : false,
      "id_str" : "16626603",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/242496967/CrimsonSeal-large-color_normal.jpg",
      "id" : 16626603,
      "verified" : false
    }
  },
  "id" : 77071031692570625,
  "created_at" : "Sat Jun 04 17:55:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "expo",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76884444534943744",
  "text" : "@PascalCrystalCG what new exciting things are you guys cooking up for Korea #expo?",
  "id" : 76884444534943744,
  "created_at" : "Sat Jun 04 05:34:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "withdrawal",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76806399123922944",
  "text" : "Where can I find bubble tea in Seattle?? #withdrawal",
  "id" : 76806399123922944,
  "created_at" : "Sat Jun 04 00:24:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 3, 9 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76800676042256384",
  "text" : "RT @koush: Yesterday, a video of a cat hugging a kitten was trending. Today, an article analyzing the video is trending. Cats still suck ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "doglover",
        "indices" : [ 127, 136 ]
      }, {
        "text" : "fb",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "76755179449499649",
    "text" : "Yesterday, a video of a cat hugging a kitten was trending. Today, an article analyzing the video is trending. Cats still suck. #doglover #fb",
    "id" : 76755179449499649,
    "created_at" : "Fri Jun 03 21:00:35 +0000 2011",
    "user" : {
      "name" : "koush",
      "screen_name" : "koush",
      "protected" : false,
      "id_str" : "18918415",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1577420755/img-18_normal.jpg",
      "id" : 18918415,
      "verified" : false
    }
  },
  "id" : 76800676042256384,
  "created_at" : "Sat Jun 04 00:01:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdwin",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76454371323428865",
  "text" : "I can assign two cores and 8gb of RAM to my virtual machine at work and still have plenty left over. #nerdwin",
  "id" : 76454371323428865,
  "created_at" : "Fri Jun 03 01:05:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony DeVincenzi",
      "screen_name" : "tonydevincenzi",
      "indices" : [ 0, 15 ],
      "id_str" : "10425532",
      "id" : 10425532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76441722208522240",
  "geo" : {
  },
  "id_str" : "76450693954813953",
  "in_reply_to_user_id" : 10425532,
  "text" : "@tonydevincenzi yea, wish I knew of this opportunity earlier! Would love to help remotely. Also, sweet 'stache",
  "id" : 76450693954813953,
  "in_reply_to_status_id" : 76441722208522240,
  "created_at" : "Fri Jun 03 00:50:40 +0000 2011",
  "in_reply_to_screen_name" : "tonydevincenzi",
  "in_reply_to_user_id_str" : "10425532",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76447768830423040",
  "text" : "Poked myself in the eyes trying to adjust glasses that werent there. Sigh.",
  "id" : 76447768830423040,
  "created_at" : "Fri Jun 03 00:39:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony DeVincenzi",
      "screen_name" : "tonydevincenzi",
      "indices" : [ 0, 15 ],
      "id_str" : "10425532",
      "id" : 10425532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76431920535322624",
  "geo" : {
  },
  "id_str" : "76436360709423104",
  "in_reply_to_user_id" : 10425532,
  "text" : "@tonydevincenzi would Invisible Forces be one of those designs?",
  "id" : 76436360709423104,
  "in_reply_to_status_id" : 76431920535322624,
  "created_at" : "Thu Jun 02 23:53:43 +0000 2011",
  "in_reply_to_screen_name" : "tonydevincenzi",
  "in_reply_to_user_id_str" : "10425532",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Klau",
      "screen_name" : "rklau",
      "indices" : [ 3, 9 ],
      "id_str" : "901651",
      "id" : 901651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76436107763531776",
  "text" : "RT @rklau: Maybe it's time for Sony to just publish its usernames and passwords in a wiki? Might save everyone a bit of time.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "76403509209214976",
    "text" : "Maybe it's time for Sony to just publish its usernames and passwords in a wiki? Might save everyone a bit of time.",
    "id" : 76403509209214976,
    "created_at" : "Thu Jun 02 21:43:10 +0000 2011",
    "user" : {
      "name" : "Rick Klau",
      "screen_name" : "rklau",
      "protected" : false,
      "id_str" : "901651",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3080833491/3e71f138887d1b5605961c3a6b505d79_normal.jpeg",
      "id" : 901651,
      "verified" : false
    }
  },
  "id" : 76436107763531776,
  "created_at" : "Thu Jun 02 23:52:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76401864937185281",
  "text" : "Seattle has the biggest collection of humorously named wifi networks",
  "id" : 76401864937185281,
  "created_at" : "Thu Jun 02 21:36:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facepalm",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76400707128918018",
  "text" : "Playstation network is back onli- oh wait, hacked again? #facepalm",
  "id" : 76400707128918018,
  "created_at" : "Thu Jun 02 21:32:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "michele panzarino",
      "screen_name" : "MPanzarino",
      "indices" : [ 100, 111 ],
      "id_str" : "860262516",
      "id" : 860262516
    }, {
      "name" : "TNW Apps",
      "screen_name" : "TNWapps",
      "indices" : [ 115, 123 ],
      "id_str" : "83493074",
      "id" : 83493074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76383607068950528",
  "text" : "RT @TheNextWeb: Angry Birds now available for Windows PCs, no browser needed http://tnw.to/18nIR by @mpanzarino on @TNWapps",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "michele panzarino",
        "screen_name" : "MPanzarino",
        "indices" : [ 84, 95 ],
        "id_str" : "860262516",
        "id" : 860262516
      }, {
        "name" : "TNW Apps",
        "screen_name" : "TNWapps",
        "indices" : [ 99, 107 ],
        "id_str" : "83493074",
        "id" : 83493074
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "76379974394839040",
    "text" : "Angry Birds now available for Windows PCs, no browser needed http://tnw.to/18nIR by @mpanzarino on @TNWapps",
    "id" : 76379974394839040,
    "created_at" : "Thu Jun 02 20:09:39 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 76383607068950528,
  "created_at" : "Thu Jun 02 20:24:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76309875449278464",
  "text" : "RT @Fake_Dispatch: BREAKING: Cell phones may cause cancer.  Bluetooth headsets cause douchiness.  Which would you rather suffer from?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "76266204012089344",
    "text" : "BREAKING: Cell phones may cause cancer.  Bluetooth headsets cause douchiness.  Which would you rather suffer from?",
    "id" : 76266204012089344,
    "created_at" : "Thu Jun 02 12:37:34 +0000 2011",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 76309875449278464,
  "created_at" : "Thu Jun 02 15:31:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa Wu ",
      "screen_name" : "resawu",
      "indices" : [ 0, 7 ],
      "id_str" : "14732370",
      "id" : 14732370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76079767975235584",
  "geo" : {
  },
  "id_str" : "76086211395072000",
  "in_reply_to_user_id" : 14732370,
  "text" : "@resawu build a gcal sync'd AC timer with arduino!",
  "id" : 76086211395072000,
  "in_reply_to_status_id" : 76079767975235584,
  "created_at" : "Thu Jun 02 00:42:21 +0000 2011",
  "in_reply_to_screen_name" : "resawu",
  "in_reply_to_user_id_str" : "14732370",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thinkgeek",
      "screen_name" : "thinkgeek",
      "indices" : [ 3, 13 ],
      "id_str" : "12611642",
      "id" : 12611642
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 34, 39 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NASATweetup",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76043991304503296",
  "text" : "RT @thinkgeek: Just signed up! RT @NASA: You have 24 hrs to put your name in for a spot at last shuttle launch #NASATweetup: http://go.n ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 19, 24 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NASATweetup",
        "indices" : [ 96, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "75959299075084288",
    "text" : "Just signed up! RT @NASA: You have 24 hrs to put your name in for a spot at last shuttle launch #NASATweetup: http://go.nasa.gov/135tweet",
    "id" : 75959299075084288,
    "created_at" : "Wed Jun 01 16:18:02 +0000 2011",
    "user" : {
      "name" : "thinkgeek",
      "screen_name" : "thinkgeek",
      "protected" : false,
      "id_str" : "12611642",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3522713236/268f433597dc1e82d2eafcfb9c5c5b20_normal.png",
      "id" : 12611642,
      "verified" : true
    }
  },
  "id" : 76043991304503296,
  "created_at" : "Wed Jun 01 21:54:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75944075538345985",
  "text" : "RT @Fake_Dispatch: BREAKING: On Friday, June 3, 2011 the PlayStation Network became self aware. But then it was hacked again and that wa ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "75890993559388160",
    "text" : "BREAKING: On Friday, June 3, 2011 the PlayStation Network became self aware. But then it was hacked again and that was that.",
    "id" : 75890993559388160,
    "created_at" : "Wed Jun 01 11:46:37 +0000 2011",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 75944075538345985,
  "created_at" : "Wed Jun 01 15:17:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75820158509260800",
  "text" : "MacBook Pro fan died again; not waking from sleep. Time to upgrade to ThinkPad X220. Woot msoft discounts!!",
  "id" : 75820158509260800,
  "created_at" : "Wed Jun 01 07:05:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Anderson",
      "screen_name" : "chr1sa",
      "indices" : [ 3, 10 ],
      "id_str" : "17595439",
      "id" : 17595439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75806867447742464",
  "text" : "RT @chr1sa: I'm in Mojave with the Scaled Composites guys, prepping for our drone demo tomorrow. Right Stuff vibe envelope is totally pu ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "75799535678533632",
    "text" : "I'm in Mojave with the Scaled Composites guys, prepping for our drone demo tomorrow. Right Stuff vibe envelope is totally pushed.",
    "id" : 75799535678533632,
    "created_at" : "Wed Jun 01 05:43:12 +0000 2011",
    "user" : {
      "name" : "Chris Anderson",
      "screen_name" : "chr1sa",
      "protected" : false,
      "id_str" : "17595439",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/696043718/chrisanderson_normal.jpg",
      "id" : 17595439,
      "verified" : true
    }
  },
  "id" : 75806867447742464,
  "created_at" : "Wed Jun 01 06:12:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]