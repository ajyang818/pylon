Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/xTW3OF83",
      "expanded_url" : "http://m.cbsnews.com/postwatch.rbml?pageType=video&cbsID=50133996",
      "display_url" : "m.cbsnews.com/postwatch.rbml\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7620993496, -73.9684867387 ]
  },
  "id_str" : "263721611016937474",
  "text" : "TED Talks have been viewed almost a billion times. Fun fact: Gangnam Style close behind at 600M. http://t.co/xTW3OF83",
  "id" : 263721611016937474,
  "created_at" : "Wed Oct 31 19:18:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 24, 30 ],
      "id_str" : "38679388",
      "id" : 38679388
    }, {
      "name" : "Google Chrome",
      "screen_name" : "googlechrome",
      "indices" : [ 44, 57 ],
      "id_str" : "56505125",
      "id" : 56505125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621506261, -73.9685639465 ]
  },
  "id_str" : "263659124275941378",
  "text" : "I can't type in the new @gmail update using @googleChrome... Frustrating to say the least.",
  "id" : 263659124275941378,
  "created_at" : "Wed Oct 31 15:10:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sandy",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7095643468, -74.0040276744 ]
  },
  "id_str" : "263115632948690944",
  "text" : "Anyone think this is warmup for the 2012 apocalypse? #sandy",
  "id" : 263115632948690944,
  "created_at" : "Tue Oct 30 03:10:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/4RHKRKj7",
      "expanded_url" : "http://timehop.com/c/508ea5a5de68361d940044b1",
      "display_url" : "timehop.com/c/508ea5a5de68\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "263004660875526146",
  "text" : "Two years ago I got a Blackberry 9630 and was HOT STUFF. http://t.co/4RHKRKj7",
  "id" : 263004660875526146,
  "created_at" : "Mon Oct 29 19:49:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bussgang",
      "screen_name" : "bussgang",
      "indices" : [ 3, 12 ],
      "id_str" : "18691131",
      "id" : 18691131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/i91BuQj2",
      "expanded_url" : "http://www.businessweek.com/articles/2012-10-25/bloomberg-view-americas-real-immigration-crisis",
      "display_url" : "businessweek.com/articles/2012-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "262328618607341570",
  "text" : "RT @bussgang: \"It would be hard to exaggerate the lunacy of US rules on skilled immigration.\" - Bloomberg View http://t.co/i91BuQj2",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http://t.co/i91BuQj2",
        "expanded_url" : "http://www.businessweek.com/articles/2012-10-25/bloomberg-view-americas-real-immigration-crisis",
        "display_url" : "businessweek.com/articles/2012-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "262295624043618304",
    "text" : "\"It would be hard to exaggerate the lunacy of US rules on skilled immigration.\" - Bloomberg View http://t.co/i91BuQj2",
    "id" : 262295624043618304,
    "created_at" : "Sat Oct 27 20:52:04 +0000 2012",
    "user" : {
      "name" : "Jeff Bussgang",
      "screen_name" : "bussgang",
      "protected" : false,
      "id_str" : "18691131",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1769148744/JB_profile_pic_normal.jpg",
      "id" : 18691131,
      "verified" : false
    }
  },
  "id" : 262328618607341570,
  "created_at" : "Sat Oct 27 23:03:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 0, 11 ],
      "id_str" : "21160381",
      "id" : 21160381
    }, {
      "name" : "Eric Wiesen",
      "screen_name" : "ewiesen",
      "indices" : [ 54, 62 ],
      "id_str" : "798536",
      "id" : 798536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7213935303, -74.0118709859 ]
  },
  "id_str" : "262314200020434944",
  "in_reply_to_user_id" : 21160381,
  "text" : "@tomloverro pouring on the haterade for Windows 8. Cc @ewiesen",
  "id" : 262314200020434944,
  "created_at" : "Sat Oct 27 22:05:53 +0000 2012",
  "in_reply_to_screen_name" : "tomloverro",
  "in_reply_to_user_id_str" : "21160381",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7019019593, -74.0109346435 ]
  },
  "id_str" : "262000866205241345",
  "text" : "If you disregard Metro, Windows 8 is just a faster Windows 7 with some UI polish, which is fine by me.",
  "id" : 262000866205241345,
  "created_at" : "Sat Oct 27 01:20:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/261948689998807041/photo/1",
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/Dyw0V2LC",
      "media_url" : "http://pbs.twimg.com/media/A6Kg8hlCAAAjbLp.jpg",
      "id_str" : "261948690007195648",
      "id" : 261948690007195648,
      "media_url_https" : "https://pbs.twimg.com/media/A6Kg8hlCAAAjbLp.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/Dyw0V2LC"
    } ],
    "hashtags" : [ {
      "text" : "W8",
      "indices" : [ 16, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261948689998807041",
  "text" : "And here we go! #W8 http://t.co/Dyw0V2LC",
  "id" : 261948689998807041,
  "created_at" : "Fri Oct 26 21:53:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/JaozQMRx",
      "expanded_url" : "http://www.washingtonpost.com/world/national-security/remote-us-base-at-core-of-secret-operations/2012/10/25/a26a9392-197a-11e2-bd10-5ff056538b7c_story_2.html",
      "display_url" : "washingtonpost.com/world/national\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "261946524299309057",
  "text" : "NICE TRY SKYNET. \"a Predator...started its engine w/ohuman direction, even though the ignition had been turned off.\" http://t.co/JaozQMRx",
  "id" : 261946524299309057,
  "created_at" : "Fri Oct 26 21:44:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Business",
      "screen_name" : "nytimesbusiness",
      "indices" : [ 3, 19 ],
      "id_str" : "1754641",
      "id" : 1754641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261844378346196992",
  "text" : "RT @nytimesbusiness: China has blocked the Times Web site over an article on wealth accumulated by the prime minister's family.  http:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/IgPy0gbM",
        "expanded_url" : "http://nyti.ms/SDYYo5",
        "display_url" : "nyti.ms/SDYYo5"
      } ]
    },
    "geo" : {
    },
    "id_str" : "261825908996972544",
    "text" : "China has blocked the Times Web site over an article on wealth accumulated by the prime minister's family.  http://t.co/IgPy0gbM",
    "id" : 261825908996972544,
    "created_at" : "Fri Oct 26 13:45:35 +0000 2012",
    "user" : {
      "name" : "NYT Business",
      "screen_name" : "nytimesbusiness",
      "protected" : false,
      "id_str" : "1754641",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2037622389/NYT_Twitter_Business_normal.png",
      "id" : 1754641,
      "verified" : false
    }
  },
  "id" : 261844378346196992,
  "created_at" : "Fri Oct 26 14:58:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 47, 58 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/NzUOTIhP",
      "expanded_url" : "http://ow.ly/eMFPx",
      "display_url" : "ow.ly/eMFPx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.762130228, -73.9685023243 ]
  },
  "id_str" : "261844161106423809",
  "text" : "It's amazing how much is still done on paper. \u201C@thecrimson: Registrar Digitalizes Midterm Grade Submission System. | http://t.co/NzUOTIhP\u201D",
  "id" : 261844161106423809,
  "created_at" : "Fri Oct 26 14:58:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Madsen",
      "screen_name" : "markmadsen",
      "indices" : [ 3, 14 ],
      "id_str" : "7648872",
      "id" : 7648872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261843877567283201",
  "text" : "RT @markmadsen: OMG OMG Harvard Business Review discovers big data. Consultants, rev your engines.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "261788965600899073",
    "text" : "OMG OMG Harvard Business Review discovers big data. Consultants, rev your engines.",
    "id" : 261788965600899073,
    "created_at" : "Fri Oct 26 11:18:47 +0000 2012",
    "user" : {
      "name" : "Mark Madsen",
      "screen_name" : "markmadsen",
      "protected" : false,
      "id_str" : "7648872",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/85422990/mark_madsen_pr_1452_bw_normal.jpg",
      "id" : 7648872,
      "verified" : false
    }
  },
  "id" : 261843877567283201,
  "created_at" : "Fri Oct 26 14:56:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104018351, -74.0063399512 ]
  },
  "id_str" : "261686615070629888",
  "text" : "A side effect of following a lot of tech people on twitter is that I now know more about the SF Giants than I would ever care to...",
  "id" : 261686615070629888,
  "created_at" : "Fri Oct 26 04:32:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/YTGYwBtc",
      "expanded_url" : "http://betabeat.com/2012/10/airbnb-series-b-c-round-peter-thiel-venture-fund-capital/",
      "display_url" : "betabeat.com/2012/10/airbnb\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "261683601022803969",
  "text" : "The problem w twitter news is the lack or checks: \"Contrary to Reports, Airbnb Has Yet Not Raised a Big Series C\" http://t.co/YTGYwBtc",
  "id" : 261683601022803969,
  "created_at" : "Fri Oct 26 04:20:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/97jD4DJv",
      "expanded_url" : "http://nymag.com/daily/intel/2012/10/hurricane-sandy-new-york-storm-snowicane.html",
      "display_url" : "nymag.com/daily/intel/20\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7622281762, -73.9685778783 ]
  },
  "id_str" : "261582832906928129",
  "text" : "\"Snowicane\" in NYC next week? Back in Buffalo we just called it \"fall.\" http://t.co/97jD4DJv",
  "id" : 261582832906928129,
  "created_at" : "Thu Oct 25 21:39:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621147238, -73.9684216282 ]
  },
  "id_str" : "261522345661968384",
  "text" : "Oof these Surface press event scripts are awkward.",
  "id" : 261522345661968384,
  "created_at" : "Thu Oct 25 17:39:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621404725, -73.9684928926 ]
  },
  "id_str" : "261521575059288064",
  "text" : "Watching the Windows 8 launch live! Sinofsky with sweet kicks on as usual.",
  "id" : 261521575059288064,
  "created_at" : "Thu Oct 25 17:36:16 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/261313022646181888/photo/1",
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/xXRg6osn",
      "media_url" : "http://pbs.twimg.com/media/A6Bez0KCYAEBVun.jpg",
      "id_str" : "261313022654570497",
      "id" : 261313022654570497,
      "media_url_https" : "https://pbs.twimg.com/media/A6Bez0KCYAEBVun.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/xXRg6osn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261313022646181888",
  "text" : "I'm just gonna come out and say that maybe this has gone a bit too far. http://t.co/xXRg6osn",
  "id" : 261313022646181888,
  "created_at" : "Thu Oct 25 03:47:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7622174215, -73.9686037722 ]
  },
  "id_str" : "261171177727352832",
  "text" : "As we near the Surface release, I'm keeping an open mind. After all, the iPad 1 received a lot hate from pundits pre-release too.",
  "id" : 261171177727352832,
  "created_at" : "Wed Oct 24 18:23:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VCnoob",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261158608480395264",
  "text" : "Today I learned that when a VC asks for a \"carve out model,\" he isn't asking for a foam mockup; he's asking for a financial model. #VCnoob",
  "id" : 261158608480395264,
  "created_at" : "Wed Oct 24 17:33:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yinon Weiss",
      "screen_name" : "yinonw",
      "indices" : [ 13, 20 ],
      "id_str" : "279724573",
      "id" : 279724573
    }, {
      "name" : "MassChallenge",
      "screen_name" : "MassChallenge",
      "indices" : [ 60, 74 ],
      "id_str" : "46240925",
      "id" : 46240925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/uuf5NRJm",
      "expanded_url" : "http://blog.rallypoint.com/post/34231383111/rallypoint-wins-worlds-largest-startup-competition",
      "display_url" : "blog.rallypoint.com/post/342313831\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "261124797612838912",
  "text" : "Big congrats @yinonw and his startup RallyPoint for winning @MassChallenge! http://t.co/uuf5NRJm",
  "id" : 261124797612838912,
  "created_at" : "Wed Oct 24 15:19:37 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/O01oAno2",
      "expanded_url" : "http://betabeat.com/2012/10/boston-new-york-biotech-research-venture-funding/",
      "display_url" : "betabeat.com/2012/10/boston\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7618218608, -73.9670999504 ]
  },
  "id_str" : "260896324688441344",
  "text" : "\"The most successful Boston startup is AMERICA\" &lt;- literally lol'd. http://t.co/O01oAno2",
  "id" : 260896324688441344,
  "created_at" : "Wed Oct 24 00:11:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/haoDcb8O",
      "expanded_url" : "http://econ.st/S0pcnp",
      "display_url" : "econ.st/S0pcnp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260894137442770946",
  "text" : "RT @TheEconomist: No Western fast-food chain has figured out how to please hungry Chinese mouths in the morning http://t.co/haoDcb8O",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http://t.co/haoDcb8O",
        "expanded_url" : "http://econ.st/S0pcnp",
        "display_url" : "econ.st/S0pcnp"
      } ]
    },
    "geo" : {
    },
    "id_str" : "260893412247617538",
    "text" : "No Western fast-food chain has figured out how to please hungry Chinese mouths in the morning http://t.co/haoDcb8O",
    "id" : 260893412247617538,
    "created_at" : "Wed Oct 24 00:00:11 +0000 2012",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 260894137442770946,
  "created_at" : "Wed Oct 24 00:03:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NYDBM",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7618009289, -73.9670670085 ]
  },
  "id_str" : "260890889021440000",
  "text" : "\"It doesn't matter if you're selling to enterprise or consumers: software needs to be beautiful, intuitive, and engaging.\" #NYDBM",
  "id" : 260890889021440000,
  "created_at" : "Tue Oct 23 23:50:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NYDBM",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7618210199, -73.9670818185 ]
  },
  "id_str" : "260882608676823040",
  "text" : "Enterprise data isn't slow; its output just has a weight and significance that you cannot afford to break. Words of wisdom from #NYDBM",
  "id" : 260882608676823040,
  "created_at" : "Tue Oct 23 23:17:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/260879370867052544/photo/1",
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/PvAnZOiC",
      "media_url" : "http://pbs.twimg.com/media/A57UZ9YCEAIYe4S.jpg",
      "id_str" : "260879370871246850",
      "id" : 260879370871246850,
      "media_url_https" : "https://pbs.twimg.com/media/A57UZ9YCEAIYe4S.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/PvAnZOiC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7618046359, -73.9670709572 ]
  },
  "id_str" : "260879370867052544",
  "text" : "All-star panel at the Bloomberg NYC Data Business Meetup! http://t.co/PvAnZOiC",
  "id" : 260879370867052544,
  "created_at" : "Tue Oct 23 23:04:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7617908299, -73.9670528396 ]
  },
  "id_str" : "260878958491475969",
  "text" : "Bloomberg Tower decor looks like a nightclub and office building had a bastard child raised by Virgin Atlantic, in a good way.",
  "id" : 260878958491475969,
  "created_at" : "Tue Oct 23 23:02:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260824433927798784",
  "text" : "RT @bznotes: We need companies like Tesla/SolarCity/Nest to succeed big to excite people --&gt; problem is we are pulling back from such ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "260822083615981569",
    "text" : "We need companies like Tesla/SolarCity/Nest to succeed big to excite people --&gt; problem is we are pulling back from such investments today.",
    "id" : 260822083615981569,
    "created_at" : "Tue Oct 23 19:16:45 +0000 2012",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 260824433927798784,
  "created_at" : "Tue Oct 23 19:26:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 43, 55 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/iAus5oKe",
      "expanded_url" : "http://kck.st/Uv09ul",
      "display_url" : "kck.st/Uv09ul"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260781732880580609",
  "text" : "I just backed Memoto Lifelogging Camera on @Kickstarter http://t.co/iAus5oKe",
  "id" : 260781732880580609,
  "created_at" : "Tue Oct 23 16:36:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/tuc1PnE0",
      "expanded_url" : "http://www.businessinsider.com/opt-out-of-verizon-data-selling-2012-10",
      "display_url" : "businessinsider.com/opt-out-of-ver\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260780147643396096",
  "text" : "If you use Verizon, here's how to opt-out of them selling your data. http://t.co/tuc1PnE0",
  "id" : 260780147643396096,
  "created_at" : "Tue Oct 23 16:30:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "General Assembly",
      "screen_name" : "GA",
      "indices" : [ 16, 19 ],
      "id_str" : "170393291",
      "id" : 170393291
    }, {
      "name" : "Brad Hargreaves",
      "screen_name" : "bhargreaves",
      "indices" : [ 23, 35 ],
      "id_str" : "15856882",
      "id" : 15856882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260778157953654784",
  "text" : "Awesome tour of @ga by @bhargreaves. Looking forward to learning all the things they didn't teach well in school.",
  "id" : 260778157953654784,
  "created_at" : "Tue Oct 23 16:22:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Coulter",
      "screen_name" : "AnnCoulter",
      "indices" : [ 42, 53 ],
      "id_str" : "196168350",
      "id" : 196168350
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/260604896636723200/photo/1",
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/1cAKyaYe",
      "media_url" : "http://pbs.twimg.com/media/A53axdNCYAAuJhq.jpg",
      "id_str" : "260604896645111808",
      "id" : 260604896645111808,
      "media_url_https" : "https://pbs.twimg.com/media/A53axdNCYAAuJhq.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/1cAKyaYe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104463019, -74.0063720675 ]
  },
  "id_str" : "260604896636723200",
  "text" : "This will probably be taken down soon, so @AnnCoulter's immature-first-grader rhetoric screenshot'd. http://t.co/1cAKyaYe",
  "id" : 260604896636723200,
  "created_at" : "Tue Oct 23 04:53:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debate",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260567770280902657",
  "text" : "If you really want to make America attractive for innovators and entrepreneurs, you should be talking about immigration reform. #debate",
  "id" : 260567770280902657,
  "created_at" : "Tue Oct 23 02:26:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260566415667507200",
  "text" : "A record 1.25 hours to get to China-bashing in this debate.",
  "id" : 260566415667507200,
  "created_at" : "Tue Oct 23 02:20:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 78, 89 ],
      "id_str" : "50055701",
      "id" : 50055701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260557258293923840",
  "text" : "\"Our Air Force is older than it ever has been... since it was founded.\" - yes @MittRomney, that's how time works.",
  "id" : 260557258293923840,
  "created_at" : "Tue Oct 23 01:44:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drunk Predator Drone",
      "screen_name" : "drunkenpredator",
      "indices" : [ 3, 19 ],
      "id_str" : "252787550",
      "id" : 252787550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260525267011915777",
  "text" : "RT @drunkenpredator: Tonight's foreign policy debate should take place Street Fighter II-style; on the wing of a Predator drone, with an ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "260485896619569154",
    "text" : "Tonight's foreign policy debate should take place Street Fighter II-style; on the wing of a Predator drone, with an armed SEAL moderating.",
    "id" : 260485896619569154,
    "created_at" : "Mon Oct 22 21:00:52 +0000 2012",
    "user" : {
      "name" : "Drunk Predator Drone",
      "screen_name" : "drunkenpredator",
      "protected" : false,
      "id_str" : "252787550",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3331819139/9d180096037780e5cf42dc7a3111d647_normal.png",
      "id" : 252787550,
      "verified" : false
    }
  },
  "id" : 260525267011915777,
  "created_at" : "Mon Oct 22 23:37:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621219941, -73.968471922 ]
  },
  "id_str" : "260446911750889472",
  "text" : "My heart goes out the entrepreneur that came in to pitch a site only to have AWS be down...",
  "id" : 260446911750889472,
  "created_at" : "Mon Oct 22 18:25:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260121446746042369",
  "text" : "Halo 4 trailers would've been a perfect Surface product placement opportunity for Microsoft.",
  "id" : 260121446746042369,
  "created_at" : "Sun Oct 21 20:52:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/mncVqec6",
      "expanded_url" : "http://dilbert.com/strips/comic/2012-10-21",
      "display_url" : "dilbert.com/strips/comic/2\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260102548923506688",
  "text" : "Dilbert understands the power of the Cloud. http://t.co/mncVqec6",
  "id" : 260102548923506688,
  "created_at" : "Sun Oct 21 19:37:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Taussig",
      "screen_name" : "ataussig",
      "indices" : [ 0, 9 ],
      "id_str" : "22097962",
      "id" : 22097962
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 10, 17 ],
      "id_str" : "224321197",
      "id" : 224321197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260070766018691072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7102200476, -74.0063685983 ]
  },
  "id_str" : "260080155400208384",
  "in_reply_to_user_id" : 22097962,
  "text" : "@ataussig @zhamed FutureAdvisors is a really well designed personal investment tool. One of Sequoia's portfolio companies.",
  "id" : 260080155400208384,
  "in_reply_to_status_id" : 260070766018691072,
  "created_at" : "Sun Oct 21 18:08:35 +0000 2012",
  "in_reply_to_screen_name" : "ataussig",
  "in_reply_to_user_id_str" : "22097962",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Turf Geography Club",
      "screen_name" : "turf",
      "indices" : [ 0, 5 ],
      "id_str" : "271115865",
      "id" : 271115865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "259403654736523264",
  "in_reply_to_user_id" : 271115865,
  "text" : "@turf oops, I meant *addicting",
  "id" : 259403654736523264,
  "created_at" : "Fri Oct 19 21:20:25 +0000 2012",
  "in_reply_to_screen_name" : "turf",
  "in_reply_to_user_id_str" : "271115865",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Turf Geography Club",
      "screen_name" : "turf",
      "indices" : [ 25, 30 ],
      "id_str" : "271115865",
      "id" : 271115865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "259403623694483456",
  "text" : "Once you get the hang of @turf, it's unbelievably addicting.",
  "id" : 259403623694483456,
  "created_at" : "Fri Oct 19 21:20:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/IorLficv",
      "expanded_url" : "http://4sq.com/QCHBlw",
      "display_url" : "4sq.com/QCHBlw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.725237, -73.994768 ]
  },
  "id_str" : "259392430024056832",
  "text" : "I'm at MakerBot Store (New York, NY) w/ 2 others [pic]: http://t.co/IorLficv",
  "id" : 259392430024056832,
  "created_at" : "Fri Oct 19 20:35:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/tLO3XbAs",
      "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=DkGMY63FF3Q",
      "display_url" : "youtube.com/watch?feature=\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "259028583111077888",
  "text" : "For fans of TED Talks, The Onion's parody is pretty darn funny. http://t.co/tLO3XbAs",
  "id" : 259028583111077888,
  "created_at" : "Thu Oct 18 20:30:01 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Siedell",
      "screen_name" : "badbanana",
      "indices" : [ 3, 13 ],
      "id_str" : "809760",
      "id" : 809760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "259023216935329792",
  "text" : "RT @badbanana: Congratulations to Newsweek for going all-digital. You are now a blog.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "258921998049239040",
    "text" : "Congratulations to Newsweek for going all-digital. You are now a blog.",
    "id" : 258921998049239040,
    "created_at" : "Thu Oct 18 13:26:29 +0000 2012",
    "user" : {
      "name" : "Tim Siedell",
      "screen_name" : "badbanana",
      "protected" : false,
      "id_str" : "809760",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1862448581/2_normal.jpg",
      "id" : 809760,
      "verified" : true
    }
  },
  "id" : 259023216935329792,
  "created_at" : "Thu Oct 18 20:08:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258981507312533505",
  "text" : "Spotted on a resume: \"# of blog posts on Hacker News front page.\"",
  "id" : 258981507312533505,
  "created_at" : "Thu Oct 18 17:22:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7559692581, -73.97849123 ]
  },
  "id_str" : "258697793709948928",
  "text" : "I kind of want a Microsoft Surface just so I can install Ubuntu and have Unity finally be useful.",
  "id" : 258697793709948928,
  "created_at" : "Wed Oct 17 22:35:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwight Merriman",
      "screen_name" : "dmerr",
      "indices" : [ 6, 12 ],
      "id_str" : "13000292",
      "id" : 13000292
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facepalm",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7385698867, -73.987606586 ]
  },
  "id_str" : "258642962102231040",
  "text" : "Asked @dmerr if he was a \"fan of MongoDB\" without knowing who he was. #facepalm",
  "id" : 258642962102231040,
  "created_at" : "Wed Oct 17 18:57:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621957624, -73.9685235196 ]
  },
  "id_str" : "258333736804954112",
  "text" : "I find watching TuneWiki trying to sync lyrics with Skrillex songs more amusing than I should.",
  "id" : 258333736804954112,
  "created_at" : "Tue Oct 16 22:28:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/uLTd6liV",
      "expanded_url" : "http://www.wired.com/underwire/2012/10/skyfall-trumpeter/",
      "display_url" : "wired.com/underwire/2012\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "258332192206356480",
  "text" : "British trumpeter has played the theme in every James Bond movie. http://t.co/uLTd6liV",
  "id" : 258332192206356480,
  "created_at" : "Tue Oct 16 22:22:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jitka",
      "screen_name" : "jitka",
      "indices" : [ 3, 9 ],
      "id_str" : "60745484",
      "id" : 60745484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258170464747286528",
  "text" : "RT @jitka: i really think a million dollar idea would be a mouse that shocks your hand if you try to read comments on news articles",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "258058495620968449",
    "text" : "i really think a million dollar idea would be a mouse that shocks your hand if you try to read comments on news articles",
    "id" : 258058495620968449,
    "created_at" : "Tue Oct 16 04:15:14 +0000 2012",
    "user" : {
      "name" : "jitka",
      "screen_name" : "jitka",
      "protected" : false,
      "id_str" : "60745484",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3237638601/b6ac474784c7c96c1d2b3592115103a6_normal.png",
      "id" : 60745484,
      "verified" : false
    }
  },
  "id" : 258170464747286528,
  "created_at" : "Tue Oct 16 11:40:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 12, 21 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/N8HFgqC3",
      "expanded_url" : "http://www.kickstarter.com/projects/peterseid/romo-the-smartphone-robot-for-everyone",
      "display_url" : "kickstarter.com/projects/peter\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104239111, -74.0063322905 ]
  },
  "id_str" : "258168673196470272",
  "text" : "Congrats!! \u201C@Romotive: And so. We've got a new robot...http://t.co/N8HFgqC3\u201D",
  "id" : 258168673196470272,
  "created_at" : "Tue Oct 16 11:33:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 3, 12 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/VyM068oE",
      "expanded_url" : "http://www.kickstarter.com/projects/peterseid/romo-the-smartphone-robot-for-everyone",
      "display_url" : "kickstarter.com/projects/peter\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "258166603596824577",
  "text" : "RT @Romotive: And so. We've got a new robot...http://t.co/VyM068oE",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http://t.co/VyM068oE",
        "expanded_url" : "http://www.kickstarter.com/projects/peterseid/romo-the-smartphone-robot-for-everyone",
        "display_url" : "kickstarter.com/projects/peter\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "258109575939620864",
    "text" : "And so. We've got a new robot...http://t.co/VyM068oE",
    "id" : 258109575939620864,
    "created_at" : "Tue Oct 16 07:38:13 +0000 2012",
    "user" : {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "protected" : false,
      "id_str" : "340545195",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2180791949/romo_normal.jpg",
      "id" : 340545195,
      "verified" : false
    }
  },
  "id" : 258166603596824577,
  "created_at" : "Tue Oct 16 11:24:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saturday Night Live",
      "screen_name" : "nbcsnl",
      "indices" : [ 9, 16 ],
      "id_str" : "28221296",
      "id" : 28221296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/4iNiVsZi",
      "expanded_url" : "http://www.hulu.com/watch/412897#i1,p0,d2",
      "display_url" : "hulu.com/watch/412897#i\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "257841588418535424",
  "text" : "Funniest @nbcsnl skit I've seen in a while. Tech Talk: iPhone 5. http://t.co/4iNiVsZi",
  "id" : 257841588418535424,
  "created_at" : "Mon Oct 15 13:53:19 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 3, 19 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/TZmM5H05",
      "expanded_url" : "http://j.mp/SUpqwa",
      "display_url" : "j.mp/SUpqwa"
    } ]
  },
  "geo" : {
  },
  "id_str" : "257609646989271040",
  "text" : "RT @newsycombinator: The tech behind Felix Baumgartners stratospheric skydive http://t.co/TZmM5H05",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.steer.me\" rel=\"nofollow\">newsycombinator</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http://t.co/TZmM5H05",
        "expanded_url" : "http://j.mp/SUpqwa",
        "display_url" : "j.mp/SUpqwa"
      } ]
    },
    "geo" : {
    },
    "id_str" : "257587850369970176",
    "text" : "The tech behind Felix Baumgartners stratospheric skydive http://t.co/TZmM5H05",
    "id" : 257587850369970176,
    "created_at" : "Sun Oct 14 21:05:03 +0000 2012",
    "user" : {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "protected" : false,
      "id_str" : "14335498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/52589204/y_normal.png",
      "id" : 14335498,
      "verified" : false
    }
  },
  "id" : 257609646989271040,
  "created_at" : "Sun Oct 14 22:31:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Bull Stratos",
      "screen_name" : "RedBullStratos",
      "indices" : [ 4, 19 ],
      "id_str" : "64767273",
      "id" : 64767273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257532586384044032",
  "text" : "The @RedBullStratos commentator is pretty terrible.",
  "id" : 257532586384044032,
  "created_at" : "Sun Oct 14 17:25:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evernote",
      "screen_name" : "evernote",
      "indices" : [ 5, 14 ],
      "id_str" : "13837292",
      "id" : 13837292
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/257282160552185856/photo/1",
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/QOWhvOIA",
      "media_url" : "http://pbs.twimg.com/media/A5IMwwsCEAAYB6r.png",
      "id_str" : "257282160556380160",
      "id" : 257282160556380160,
      "media_url_https" : "https://pbs.twimg.com/media/A5IMwwsCEAAYB6r.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/QOWhvOIA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257282160552185856",
  "text" : "Hmm, @evernote says I have a negative number of notes. http://t.co/QOWhvOIA",
  "id" : 257282160552185856,
  "created_at" : "Sun Oct 14 00:50:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "API",
      "screen_name" : "fake_api",
      "indices" : [ 3, 12 ],
      "id_str" : "301193090",
      "id" : 301193090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256950726541074432",
  "text" : "RT @fake_api: Whenever we kill an API endpoint, we have a party where we make pi\u00F1atas resembling the icons of third-party apps we broke.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "256786131507609601",
    "text" : "Whenever we kill an API endpoint, we have a party where we make pi\u00F1atas resembling the icons of third-party apps we broke.",
    "id" : 256786131507609601,
    "created_at" : "Fri Oct 12 15:59:19 +0000 2012",
    "user" : {
      "name" : "API",
      "screen_name" : "fake_api",
      "protected" : false,
      "id_str" : "301193090",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3279945746/3c9be1ccc5aad13db84dd6d47768b39b_normal.jpeg",
      "id" : 301193090,
      "verified" : false
    }
  },
  "id" : 256950726541074432,
  "created_at" : "Sat Oct 13 02:53:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chinese in America",
      "screen_name" : "mocanyc",
      "indices" : [ 23, 31 ],
      "id_str" : "80145965",
      "id" : 80145965
    }, {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 48, 58 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/256902590162423809/photo/1",
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/urUWZDfX",
      "media_url" : "http://pbs.twimg.com/media/A5Czi2zCUAA1FXg.jpg",
      "id_str" : "256902590166618112",
      "id" : 256902590166618112,
      "media_url_https" : "https://pbs.twimg.com/media/A5Czi2zCUAA1FXg.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/urUWZDfX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7193953924, -73.9989805688 ]
  },
  "id_str" : "256902590162423809",
  "text" : "Spotted on the wall of @MOCAnyc: interview with @jenny8lee! http://t.co/urUWZDfX",
  "id" : 256902590162423809,
  "created_at" : "Fri Oct 12 23:42:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621515838, -73.9685216226 ]
  },
  "id_str" : "256882046050398209",
  "text" : "Adele's Skyfall music video has been watched 8x more than the actual movie trailer.",
  "id" : 256882046050398209,
  "created_at" : "Fri Oct 12 22:20:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GenerationZ",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621390449, -73.9684847935 ]
  },
  "id_str" : "256843734392635392",
  "text" : "Met someone that registered domain, gmail, and twitter for their tentatively named newborn before signing naming docs. #GenerationZ",
  "id" : 256843734392635392,
  "created_at" : "Fri Oct 12 19:48:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 88 ],
      "url" : "https://t.co/biN2EWuY",
      "expanded_url" : "https://twitter.com/khsieh/status/240230379062177792",
      "display_url" : "twitter.com/khsieh/status/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256830796340527104",
  "text" : "Apple to pay Mondaine for using their iconic clockface. Called it. https://t.co/biN2EWuY",
  "id" : 256830796340527104,
  "created_at" : "Fri Oct 12 18:56:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jena Winberry",
      "screen_name" : "jenaow",
      "indices" : [ 3, 10 ],
      "id_str" : "404966444",
      "id" : 404966444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dplamidwest",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256779454804815873",
  "text" : "RT @jenaow: metadata standards are like toothbrushes. everyone agrees great idea, no one wants to use anybody else's. #dplamidwest",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dplamidwest",
        "indices" : [ 106, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "256435738885881857",
    "text" : "metadata standards are like toothbrushes. everyone agrees great idea, no one wants to use anybody else's. #dplamidwest",
    "id" : 256435738885881857,
    "created_at" : "Thu Oct 11 16:46:59 +0000 2012",
    "user" : {
      "name" : "Jena Winberry",
      "screen_name" : "jenaow",
      "protected" : false,
      "id_str" : "404966444",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2290042413/6gh6fwgzrbqqv9jb6c15_normal.jpeg",
      "id" : 404966444,
      "verified" : false
    }
  },
  "id" : 256779454804815873,
  "created_at" : "Fri Oct 12 15:32:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256529484394659840",
  "text" : "\"Social messaging\" is a goofy term. What other kind of messaging is there?",
  "id" : 256529484394659840,
  "created_at" : "Thu Oct 11 22:59:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "indices" : [ 3, 11 ],
      "id_str" : "184543773",
      "id" : 184543773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/UNYjMZp2",
      "expanded_url" : "http://www.slate.com/articles/health_and_science/science/2012/10/how_do_children_learn_so_quickly_bayesian_statistics_and_probabilities_help.html",
      "display_url" : "slate.com/articles/healt\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256512913316147201",
  "text" : "RT @stat110: \"Kids, at least unconsciously, are Bayesians\" -- http://t.co/UNYjMZp2",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/UNYjMZp2",
        "expanded_url" : "http://www.slate.com/articles/health_and_science/science/2012/10/how_do_children_learn_so_quickly_bayesian_statistics_and_probabilities_help.html",
        "display_url" : "slate.com/articles/healt\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "256511952602402817",
    "text" : "\"Kids, at least unconsciously, are Bayesians\" -- http://t.co/UNYjMZp2",
    "id" : 256511952602402817,
    "created_at" : "Thu Oct 11 21:49:49 +0000 2012",
    "user" : {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "protected" : false,
      "id_str" : "184543773",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1360113908/Stat110Picture_normal.jpg",
      "id" : 184543773,
      "verified" : false
    }
  },
  "id" : 256512913316147201,
  "created_at" : "Thu Oct 11 21:53:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    }, {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 11, 17 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffaloPride",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256448494750015488",
  "geo" : {
  },
  "id_str" : "256450173180452864",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick @sacca don't hate on the Buffalo Bisons, the number one-ranked 6th-ranked AAA team from western NY. #BuffaloPride",
  "id" : 256450173180452864,
  "in_reply_to_status_id" : 256448494750015488,
  "created_at" : "Thu Oct 11 17:44:20 +0000 2012",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 103, 114 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/jltrvrQ3",
      "expanded_url" : "http://gawker.com/5950524/bain-capital-wants-a-piece-of-gawker",
      "display_url" : "gawker.com/5950524/bain-c\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256391078234693633",
  "text" : "I can soundly say that my first week in VC went a lot better than this guy's. http://t.co/jltrvrQ3 via @tomloverro",
  "id" : 256391078234693633,
  "created_at" : "Thu Oct 11 13:49:31 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChinaScale",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/a42kUTIS",
      "expanded_url" : "http://www.businessinsider.com/beijing-daxing-airport-master-plan-2012-10",
      "display_url" : "businessinsider.com/beijing-daxing\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104608955, -74.0063377458 ]
  },
  "id_str" : "255987679022432256",
  "text" : "I propose the term #ChinaScale: Beijing's third airport will have more capacity than JFK, LGA, and Newark combined. http://t.co/a42kUTIS",
  "id" : 255987679022432256,
  "created_at" : "Wed Oct 10 11:06:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 0, 6 ],
      "id_str" : "14208617",
      "id" : 14208617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255830246228623360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.727712208, -73.9935806389 ]
  },
  "id_str" : "255847282057019392",
  "in_reply_to_user_id" : 14208617,
  "text" : "@robgo there are some really good translated versions of Inferno and Beowulf. I guess it depends on the effort of the translator.",
  "id" : 255847282057019392,
  "in_reply_to_status_id" : 255830246228623360,
  "created_at" : "Wed Oct 10 01:48:40 +0000 2012",
  "in_reply_to_screen_name" : "robgo",
  "in_reply_to_user_id_str" : "14208617",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShoutRoulette",
      "screen_name" : "ShoutRoulette",
      "indices" : [ 1, 15 ],
      "id_str" : "813664448",
      "id" : 813664448
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/255824862176755712/photo/1",
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/KbOYlKhO",
      "media_url" : "http://pbs.twimg.com/media/A4zfW1NCQAA_q70.jpg",
      "id_str" : "255824862185144320",
      "id" : 255824862185144320,
      "media_url_https" : "https://pbs.twimg.com/media/A4zfW1NCQAA_q70.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/KbOYlKhO"
    } ],
    "hashtags" : [ {
      "text" : "NYTM",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7303040772, -73.9955377275 ]
  },
  "id_str" : "255824862176755712",
  "text" : ".@ShoutRoulette \"built from the ground up to be angry. We coded it in all capital letters.\" Literal LOLing at #NYTM. http://t.co/KbOYlKhO",
  "id" : 255824862176755712,
  "created_at" : "Wed Oct 10 00:19:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 3, 7 ],
      "id_str" : "19494411",
      "id" : 19494411
    }, {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 116, 126 ],
      "id_str" : "200176600",
      "id" : 200176600
    }, {
      "name" : "NY Tech Meetup",
      "screen_name" : "NYTM",
      "indices" : [ 127, 132 ],
      "id_str" : "18560574",
      "id" : 18560574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "255812527643054081",
  "text" : "RT @RRE: Private entrepreneurs turned open government data into $100B of utility in the United States last year. cc @todd_park @nytm",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Todd Park",
        "screen_name" : "todd_park",
        "indices" : [ 107, 117 ],
        "id_str" : "200176600",
        "id" : 200176600
      }, {
        "name" : "NY Tech Meetup",
        "screen_name" : "NYTM",
        "indices" : [ 118, 123 ],
        "id_str" : "18560574",
        "id" : 18560574
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.7299133975, -73.9974353955 ]
    },
    "id_str" : "255811435215597568",
    "text" : "Private entrepreneurs turned open government data into $100B of utility in the United States last year. cc @todd_park @nytm",
    "id" : 255811435215597568,
    "created_at" : "Tue Oct 09 23:26:13 +0000 2012",
    "user" : {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "protected" : false,
      "id_str" : "19494411",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2781036073/47c8a2806a89312e9882b4aa968aead4_normal.png",
      "id" : 19494411,
      "verified" : false
    }
  },
  "id" : 255812527643054081,
  "created_at" : "Tue Oct 09 23:30:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 48, 55 ],
      "id_str" : "9544202",
      "id" : 9544202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7238238449, -73.9971490242 ]
  },
  "id_str" : "255754481680142336",
  "text" : "\"Never undervalue serendipity.\" Wise words from @schlaf",
  "id" : 255754481680142336,
  "created_at" : "Tue Oct 09 19:39:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Bull Stratos",
      "screen_name" : "RedBullStratos",
      "indices" : [ 24, 39 ],
      "id_str" : "64767273",
      "id" : 64767273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/60PqmJ4j",
      "expanded_url" : "http://www.redbullstratos.com/live/",
      "display_url" : "redbullstratos.com/live/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "255724560819830786",
  "text" : "Work break to watch the @RedBullStratos jump live. http://t.co/60PqmJ4j",
  "id" : 255724560819830786,
  "created_at" : "Tue Oct 09 17:41:01 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 33, 38 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104850644, -74.0064024452 ]
  },
  "id_str" : "255452180578967552",
  "text" : "Experiencing consumer fatigue on @Etsy. I wish there were more advanced filters and discovery tools.",
  "id" : 255452180578967552,
  "created_at" : "Mon Oct 08 23:38:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/efZSrSaf",
      "expanded_url" : "http://econ.st/R6ezPj",
      "display_url" : "econ.st/R6ezPj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "255395807354830848",
  "text" : "RT @TheEconomist: Analogue cameras are enjoying something of a revival http://t.co/efZSrSaf",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http://t.co/efZSrSaf",
        "expanded_url" : "http://econ.st/R6ezPj",
        "display_url" : "econ.st/R6ezPj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "255377202957385728",
    "text" : "Analogue cameras are enjoying something of a revival http://t.co/efZSrSaf",
    "id" : 255377202957385728,
    "created_at" : "Mon Oct 08 18:40:44 +0000 2012",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 255395807354830848,
  "created_at" : "Mon Oct 08 19:54:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7647157321, -73.9733110462 ]
  },
  "id_str" : "255371536247169024",
  "text" : "Globalism is an Italian-American parade float dancing to Gangnam style during a Columbus Day parade in NYC.",
  "id" : 255371536247169024,
  "created_at" : "Mon Oct 08 18:18:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Fake ESPN",
      "screen_name" : "TheFakeESPN",
      "indices" : [ 3, 15 ],
      "id_str" : "307478701",
      "id" : 307478701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "255074044053970946",
  "text" : "RT @TheFakeESPN: BuffaLOL Bills",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "255071038826741761",
    "text" : "BuffaLOL Bills",
    "id" : 255071038826741761,
    "created_at" : "Sun Oct 07 22:24:09 +0000 2012",
    "user" : {
      "name" : "The Fake ESPN",
      "screen_name" : "TheFakeESPN",
      "protected" : false,
      "id_str" : "307478701",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1373811170/TWITTERESPN_normal.jpg",
      "id" : 307478701,
      "verified" : false
    }
  },
  "id" : 255074044053970946,
  "created_at" : "Sun Oct 07 22:36:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TAPPEDNFC",
      "screen_name" : "tappednfc",
      "indices" : [ 38, 48 ],
      "id_str" : "818125609",
      "id" : 818125609
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/255041057866260480/photo/1",
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/Y53dhAvG",
      "media_url" : "http://pbs.twimg.com/media/A4oWfamCIAEN1gW.jpg",
      "id_str" : "255041057870454785",
      "id" : 255041057870454785,
      "media_url_https" : "https://pbs.twimg.com/media/A4oWfamCIAEN1gW.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/Y53dhAvG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "255041057866260480",
  "text" : "NFC tablet as a fishing lure. Only at @TAPPEDNFC hackathon. http://t.co/Y53dhAvG",
  "id" : 255041057866260480,
  "created_at" : "Sun Oct 07 20:25:01 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Games With Strangers",
      "screen_name" : "gwstrangers",
      "indices" : [ 1, 13 ],
      "id_str" : "865467308",
      "id" : 865467308
    }, {
      "name" : "TAPPEDNFC",
      "screen_name" : "tappednfc",
      "indices" : [ 62, 72 ],
      "id_str" : "818125609",
      "id" : 818125609
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/255025320753758208/photo/1",
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/LGkT7xUr",
      "media_url" : "http://pbs.twimg.com/media/A4oILZSCAAAZPi9.jpg",
      "id_str" : "255025320757952512",
      "id" : 255025320757952512,
      "media_url_https" : "https://pbs.twimg.com/media/A4oILZSCAAAZPi9.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/LGkT7xUr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7389913047, -73.9896753085 ]
  },
  "id_str" : "255025320753758208",
  "text" : ".@gwstrangers demos an NFC-based, geo-aware gaming network at @TAPPEDNFC hackathon. http://t.co/LGkT7xUr",
  "id" : 255025320753758208,
  "created_at" : "Sun Oct 07 19:22:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TAPPEDNFC",
      "screen_name" : "tappednfc",
      "indices" : [ 53, 63 ],
      "id_str" : "818125609",
      "id" : 818125609
    }, {
      "name" : "General Assembly",
      "screen_name" : "GA",
      "indices" : [ 68, 71 ],
      "id_str" : "170393291",
      "id" : 170393291
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/255022420497416192/photo/1",
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/dQOqmHrj",
      "media_url" : "http://pbs.twimg.com/media/A4oFilACQAAZ5PN.jpg",
      "id_str" : "255022420505804800",
      "id" : 255022420505804800,
      "media_url_https" : "https://pbs.twimg.com/media/A4oFilACQAAZ5PN.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/dQOqmHrj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7392290893, -73.9897133889 ]
  },
  "id_str" : "255022420497416192",
  "text" : "Excited to be a judge at the NFC hackathon hosted by @TAPPEDNFC and @GA. http://t.co/dQOqmHrj",
  "id" : 255022420497416192,
  "created_at" : "Sun Oct 07 19:10:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/yyUGoGR1",
      "expanded_url" : "http://topazanodizing.com",
      "display_url" : "topazanodizing.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.71041559, -74.0063554319 ]
  },
  "id_str" : "254437307904581632",
  "text" : "Having run an anodizing company, I can say that quality anodizing does NOT chip the way that the iPhone 5 does. http://t.co/yyUGoGR1",
  "id" : 254437307904581632,
  "created_at" : "Sat Oct 06 04:25:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 92, 104 ],
      "id_str" : "7782442",
      "id" : 7782442
    }, {
      "name" : "Jessica Shu",
      "screen_name" : "jessicajiashu",
      "indices" : [ 109, 123 ],
      "id_str" : "153693435",
      "id" : 153693435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104645579, -74.0063840254 ]
  },
  "id_str" : "254077177727946752",
  "text" : "Collecting Chinese contemporary art on a budget: no easy feat, but making headway thanks to @christinelu and @jessicajiashu!",
  "id" : 254077177727946752,
  "created_at" : "Fri Oct 05 04:34:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody",
      "screen_name" : "melody_who",
      "indices" : [ 9, 20 ],
      "id_str" : "18734681",
      "id" : 18734681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253979062756864000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104562773, -74.0063531617 ]
  },
  "id_str" : "254064426779541504",
  "in_reply_to_user_id" : 18734681,
  "text" : "Props to @melody_who for a brutal transpacific redeye into another redeye into a med school interview.",
  "id" : 254064426779541504,
  "in_reply_to_status_id" : 253979062756864000,
  "created_at" : "Fri Oct 05 03:44:14 +0000 2012",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blueprint Health",
      "screen_name" : "bphealth",
      "indices" : [ 81, 90 ],
      "id_str" : "210631738",
      "id" : 210631738
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/253913316718702593/photo/1",
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/rDinZYJB",
      "media_url" : "http://pbs.twimg.com/media/A4YU0PdCcAAi4LS.jpg",
      "id_str" : "253913316727091200",
      "id" : 253913316727091200,
      "media_url_https" : "https://pbs.twimg.com/media/A4YU0PdCcAAi4LS.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/rDinZYJB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7216777064, -74.0002046756 ]
  },
  "id_str" : "253913316718702593",
  "text" : "Room packed with hackers, surgeons, industrial designers, and pharma experts for @bphealth demo day! http://t.co/rDinZYJB",
  "id" : 253913316718702593,
  "created_at" : "Thu Oct 04 17:43:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blueprint Health",
      "screen_name" : "bphealth",
      "indices" : [ 42, 51 ],
      "id_str" : "210631738",
      "id" : 210631738
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/253901888855101441/photo/1",
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/ftHiXcXm",
      "media_url" : "http://pbs.twimg.com/media/A4YKbDVCUAAPx90.jpg",
      "id_str" : "253901888859295744",
      "id" : 253901888859295744,
      "media_url_https" : "https://pbs.twimg.com/media/A4YKbDVCUAAPx90.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/ftHiXcXm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7215817265, -74.0000371531 ]
  },
  "id_str" : "253901888855101441",
  "text" : "Excited to check out the medtech demos at @bphealth Demo Day. http://t.co/ftHiXcXm",
  "id" : 253901888855101441,
  "created_at" : "Thu Oct 04 16:58:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Watson",
      "screen_name" : "bwats",
      "indices" : [ 51, 57 ],
      "id_str" : "18500786",
      "id" : 18500786
    }, {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 128, 134 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621349016, -73.9684712774 ]
  },
  "id_str" : "253880095167610880",
  "text" : "Wired Top News and AllThingsD for trend coverage. \u201C@bwats: What's your favorite tech blog? Mine is slowly, but surely, becoming @verge.\u201D",
  "id" : 253880095167610880,
  "created_at" : "Thu Oct 04 15:31:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 3, 17 ],
      "id_str" : "16005250",
      "id" : 16005250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253687599653347328",
  "text" : "RT @angryasianman: Would've been neat if Lehrer wrapped it up by saying, \"And finally, gentlemen...\" then pressed a button and \"Gangnam  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "253686644614520832",
    "text" : "Would've been neat if Lehrer wrapped it up by saying, \"And finally, gentlemen...\" then pressed a button and \"Gangnam Style\" started playing.",
    "id" : 253686644614520832,
    "created_at" : "Thu Oct 04 02:43:04 +0000 2012",
    "user" : {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "protected" : false,
      "id_str" : "16005250",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/60849027/n636101424_111915_8115_normal.jpg",
      "id" : 16005250,
      "verified" : false
    }
  },
  "id" : 253687599653347328,
  "created_at" : "Thu Oct 04 02:46:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Murphy",
      "screen_name" : "morgan_murphy",
      "indices" : [ 3, 17 ],
      "id_str" : "21125133",
      "id" : 21125133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253676360642473985",
  "text" : "RT @morgan_murphy: \"a poor person came up to me and told me something that proves my point.\" - politicians",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "253675124501381120",
    "text" : "\"a poor person came up to me and told me something that proves my point.\" - politicians",
    "id" : 253675124501381120,
    "created_at" : "Thu Oct 04 01:57:17 +0000 2012",
    "user" : {
      "name" : "Morgan Murphy",
      "screen_name" : "morgan_murphy",
      "protected" : false,
      "id_str" : "21125133",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3445793183/7e5e38c6bf6afe39e7eaaa93b790f319_normal.jpeg",
      "id" : 21125133,
      "verified" : true
    }
  },
  "id" : 253676360642473985,
  "created_at" : "Thu Oct 04 02:02:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253675036878176257",
  "text" : "Jim Lehrer needs to assert himself more. #debates",
  "id" : 253675036878176257,
  "created_at" : "Thu Oct 04 01:56:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Lane",
      "screen_name" : "sarahlane",
      "indices" : [ 3, 13 ],
      "id_str" : "816214",
      "id" : 816214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253672851566108672",
  "text" : "RT @sarahlane: Romney just called Tesla a loser company? ENGAGE LASERS, SILICON VALLEY!",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "253670586834890752",
    "text" : "Romney just called Tesla a loser company? ENGAGE LASERS, SILICON VALLEY!",
    "id" : 253670586834890752,
    "created_at" : "Thu Oct 04 01:39:15 +0000 2012",
    "user" : {
      "name" : "Sarah Lane",
      "screen_name" : "sarahlane",
      "protected" : false,
      "id_str" : "816214",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3210260105/0ccab00b593abcf437cc7ca42a0b7349_normal.jpeg",
      "id" : 816214,
      "verified" : true
    }
  },
  "id" : 253672851566108672,
  "created_at" : "Thu Oct 04 01:48:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253672682057502720",
  "text" : "Debate in nutshell: \"You're wrong because anecdote.\" \"NO YOU'RE WRONG BECAUSE ANECDOTE.\"",
  "id" : 253672682057502720,
  "created_at" : "Thu Oct 04 01:47:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253668229493428224",
  "text" : "Romney just connected Obamacare to China, which is supposedly evil; therefore Obama is evil. Or something like that. #debates",
  "id" : 253668229493428224,
  "created_at" : "Thu Oct 04 01:29:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Spector",
      "screen_name" : "jessespector",
      "indices" : [ 3, 16 ],
      "id_str" : "16037600",
      "id" : 16037600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253667825699418113",
  "text" : "RT @jessespector: Obama and Romney going around in circles and I'm waiting for someone to crash and burn. This debate is basically NASCAR.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "253666637352415233",
    "text" : "Obama and Romney going around in circles and I'm waiting for someone to crash and burn. This debate is basically NASCAR.",
    "id" : 253666637352415233,
    "created_at" : "Thu Oct 04 01:23:33 +0000 2012",
    "user" : {
      "name" : "Jesse Spector",
      "screen_name" : "jessespector",
      "protected" : false,
      "id_str" : "16037600",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3024155130/de46de566d16a76d18ff2a203a59ed37_normal.jpeg",
      "id" : 16037600,
      "verified" : false
    }
  },
  "id" : 253667825699418113,
  "created_at" : "Thu Oct 04 01:28:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "indices" : [ 3, 19 ],
      "id_str" : "353789193",
      "id" : 353789193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253657015572910080",
  "text" : "RT @StartupLJackson: I went from bootstrapped to hyper-growth I ain\u2019t dumb.\nI got 99 problems but my pitch ain\u2019t one.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "253654316194332672",
    "text" : "I went from bootstrapped to hyper-growth I ain\u2019t dumb.\nI got 99 problems but my pitch ain\u2019t one.",
    "id" : 253654316194332672,
    "created_at" : "Thu Oct 04 00:34:36 +0000 2012",
    "user" : {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "protected" : false,
      "id_str" : "353789193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1491792938/Screen_shot_2011-08-12_at_9.54.22_AM_normal.png",
      "id" : 353789193,
      "verified" : false
    }
  },
  "id" : 253657015572910080,
  "created_at" : "Thu Oct 04 00:45:19 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253638653996306432",
  "text" : "Wallets are often (mis)designed as if all cards are removed/inserted with similar frequency.",
  "id" : 253638653996306432,
  "created_at" : "Wed Oct 03 23:32:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 34, 41 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621403696, -73.9684863083 ]
  },
  "id_str" : "253572068132659200",
  "text" : "Are you etching in the office..? \u201C@jdrive: When etching with muriatic acid, wear gloves. I seem to have to relearn this lesson annually...\u201D",
  "id" : 253572068132659200,
  "created_at" : "Wed Oct 03 19:07:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621211274, -73.9684490055 ]
  },
  "id_str" : "253553585227436033",
  "text" : "US finally allows visa-free travel for visiting Taiwanese!",
  "id" : 253553585227436033,
  "created_at" : "Wed Oct 03 17:54:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621247775, -73.9684684119 ]
  },
  "id_str" : "253494257485217795",
  "text" : "Not excited about this race for the thinnest phone. My hands cramp up trying to grip iPhone 5 on subway.",
  "id" : 253494257485217795,
  "created_at" : "Wed Oct 03 13:58:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/3p0jdTap",
      "expanded_url" : "http://www.businessinsider.com/7-arrested-in-hong-kong-after-boat-crash-2012-10",
      "display_url" : "businessinsider.com/7-arrested-in-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "253457706457903104",
  "text" : "Hong Kong reaction speed, transparency in search and rescue radically better than mainland China's. http://t.co/3p0jdTap",
  "id" : 253457706457903104,
  "created_at" : "Wed Oct 03 11:33:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 3, 15 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 39, 46 ],
      "id_str" : "224321197",
      "id" : 224321197
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 57, 66 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 72, 80 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 85, 92 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "Zappos.com CEO -Tony",
      "screen_name" : "zappos",
      "indices" : [ 93, 100 ],
      "id_str" : "7040932",
      "id" : 7040932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hacknight",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "LasV",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253345472918458368",
  "text" : "RT @badboyboyce: #hacknight intro from @zhamed featuring @romotive here @Harvard! cc @khsieh @zappos #LasV  @ Maxwell Dworkin http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zach Hamed",
        "screen_name" : "zhamed",
        "indices" : [ 22, 29 ],
        "id_str" : "224321197",
        "id" : 224321197
      }, {
        "name" : "Romotive",
        "screen_name" : "Romotive",
        "indices" : [ 40, 49 ],
        "id_str" : "340545195",
        "id" : 340545195
      }, {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 55, 63 ],
        "id_str" : "39585367",
        "id" : 39585367
      }, {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 68, 75 ],
        "id_str" : "111999960",
        "id" : 111999960
      }, {
        "name" : "Zappos.com CEO -Tony",
        "screen_name" : "zappos",
        "indices" : [ 76, 83 ],
        "id_str" : "7040932",
        "id" : 7040932
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hacknight",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "LasV",
        "indices" : [ 84, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/cdrxUurp",
        "expanded_url" : "http://instagr.am/p/QTZbCYBmWP/",
        "display_url" : "instagr.am/p/QTZbCYBmWP/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.3785699735, -71.1173858472 ]
    },
    "id_str" : "253318681973633025",
    "text" : "#hacknight intro from @zhamed featuring @romotive here @Harvard! cc @khsieh @zappos #LasV  @ Maxwell Dworkin http://t.co/cdrxUurp",
    "id" : 253318681973633025,
    "created_at" : "Wed Oct 03 02:20:54 +0000 2012",
    "user" : {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "protected" : false,
      "id_str" : "110823121",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1736585624/HaLongBay_Profile_Thumbnail_normal.jpg",
      "id" : 110823121,
      "verified" : false
    }
  },
  "id" : 253345472918458368,
  "created_at" : "Wed Oct 03 04:07:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621365565, -73.968465805 ]
  },
  "id_str" : "253198708114608128",
  "text" : "It blows my mind that fax machines haven't really changed since the 60's.",
  "id" : 253198708114608128,
  "created_at" : "Tue Oct 02 18:24:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 35, 44 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Maker Faire",
      "screen_name" : "makerfaire",
      "indices" : [ 60, 71 ],
      "id_str" : "1578141",
      "id" : 1578141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7161507136, -74.0137365909 ]
  },
  "id_str" : "252630008537948160",
  "text" : "Tired but glad to have represented @Romotive all weekend at @MakerFaire! Thanks to the hundreds of fans, new and old, that stopped by.",
  "id" : 252630008537948160,
  "created_at" : "Mon Oct 01 04:44:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]