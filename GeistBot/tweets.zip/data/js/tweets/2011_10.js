Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 78, 87 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/dGuICQWe",
      "expanded_url" : "http://j.mp/vjbHGs",
      "display_url" : "j.mp/vjbHGs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "131197927375896576",
  "text" : "YESSS. Incoming: A Native Gmail iPhone App. Finally. http://t.co/dGuICQWe via @Techmeme",
  "id" : 131197927375896576,
  "created_at" : "Tue Nov 01 02:36:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131197392191102976",
  "text" : "RSI finally kicking in. Time to explore new keyboards.",
  "id" : 131197392191102976,
  "created_at" : "Tue Nov 01 02:34:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131091932360347648",
  "text" : "What's the best Google Talk client for iOS?",
  "id" : 131091932360347648,
  "created_at" : "Mon Oct 31 19:35:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 3, 14 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/kHSubdQO",
      "expanded_url" : "http://ow.ly/7epZb",
      "display_url" : "ow.ly/7epZb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "131090035712851968",
  "text" : "RT @thecrimson: Harvard is helping in the building of a $168 million supercomputing facility. http://t.co/kHSubdQO",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/kHSubdQO",
        "expanded_url" : "http://ow.ly/7epZb",
        "display_url" : "ow.ly/7epZb"
      } ]
    },
    "geo" : {
    },
    "id_str" : "131084320432594944",
    "text" : "Harvard is helping in the building of a $168 million supercomputing facility. http://t.co/kHSubdQO",
    "id" : 131084320432594944,
    "created_at" : "Mon Oct 31 19:05:12 +0000 2011",
    "user" : {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "protected" : false,
      "id_str" : "16626603",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/242496967/CrimsonSeal-large-color_normal.jpg",
      "id" : 16626603,
      "verified" : false
    }
  },
  "id" : 131090035712851968,
  "created_at" : "Mon Oct 31 19:27:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130718327042609153",
  "text" : "Does anyone else find it incongruous that we have water conservation efforts but don't think twice about taking a crap in potable water?",
  "id" : 130718327042609153,
  "created_at" : "Sun Oct 30 18:50:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsD",
      "screen_name" : "allthingsd",
      "indices" : [ 3, 14 ],
      "id_str" : "5746402",
      "id" : 5746402
    }, {
      "name" : "Kara Swisher",
      "screen_name" : "karaswisher",
      "indices" : [ 61, 73 ],
      "id_str" : "5763262",
      "id" : 5763262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/XvGPj1G5",
      "expanded_url" : "http://dthin.gs/uhMN6U",
      "display_url" : "dthin.gs/uhMN6U"
    } ]
  },
  "geo" : {
  },
  "id_str" : "130403565339557889",
  "text" : "RT @allthingsd: China Supercomputer Uses Homegrown Chips  by @karaswisher http://t.co/XvGPj1G5",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kara Swisher",
        "screen_name" : "karaswisher",
        "indices" : [ 45, 57 ],
        "id_str" : "5763262",
        "id" : 5763262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http://t.co/XvGPj1G5",
        "expanded_url" : "http://dthin.gs/uhMN6U",
        "display_url" : "dthin.gs/uhMN6U"
      } ]
    },
    "geo" : {
    },
    "id_str" : "130382715513081856",
    "text" : "China Supercomputer Uses Homegrown Chips  by @karaswisher http://t.co/XvGPj1G5",
    "id" : 130382715513081856,
    "created_at" : "Sat Oct 29 20:37:16 +0000 2011",
    "user" : {
      "name" : "AllThingsD",
      "screen_name" : "allthingsd",
      "protected" : false,
      "id_str" : "5746402",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3121995727/217f721fb1e3311c56da15206b5848fa_normal.jpeg",
      "id" : 5746402,
      "verified" : true
    }
  },
  "id" : 130403565339557889,
  "created_at" : "Sat Oct 29 22:00:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130403438327627777",
  "text" : "People hate on freezing rain, but mother nature can SUPERCOOL WATER. How awesome is that?!",
  "id" : 130403438327627777,
  "created_at" : "Sat Oct 29 21:59:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 36, 44 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130403111524249600",
  "text" : "Cancelled Netflix and subscribed to @Spotify. Music I listen to on computer and phone &gt; movies I want to watch but aren't available.",
  "id" : 130403111524249600,
  "created_at" : "Sat Oct 29 21:58:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3683067039, -71.1154565681 ]
  },
  "id_str" : "130361516540170240",
  "text" : "LivingSocial should run a discount on Groupon deals just to see what would happen.",
  "id" : 130361516540170240,
  "created_at" : "Sat Oct 29 19:13:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Motley Fool",
      "screen_name" : "themotleyfool",
      "indices" : [ 3, 17 ],
      "id_str" : "15568127",
      "id" : 15568127
    }, {
      "name" : "Morgan Housel",
      "screen_name" : "TMFHousel",
      "indices" : [ 119, 129 ],
      "id_str" : "284278132",
      "id" : 284278132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130321560912396288",
  "text" : "RT @themotleyfool: How much do you need to earn to be among the top 1% of the world? $34,000. Fascinating numbers from @TMFHousel http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://sproutsocial.com\" rel=\"nofollow\">Sprout Social</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Morgan Housel",
        "screen_name" : "TMFHousel",
        "indices" : [ 100, 110 ],
        "id_str" : "284278132",
        "id" : 284278132
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http://t.co/A3RZ38z7",
        "expanded_url" : "http://mot.ly/tP1ME6",
        "display_url" : "mot.ly/tP1ME6"
      } ]
    },
    "geo" : {
    },
    "id_str" : "130301911353139200",
    "text" : "How much do you need to earn to be among the top 1% of the world? $34,000. Fascinating numbers from @TMFHousel http://t.co/A3RZ38z7",
    "id" : 130301911353139200,
    "created_at" : "Sat Oct 29 15:16:11 +0000 2011",
    "user" : {
      "name" : "The Motley Fool",
      "screen_name" : "themotleyfool",
      "protected" : false,
      "id_str" : "15568127",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1119788045/tmf_normal.png",
      "id" : 15568127,
      "verified" : true
    }
  },
  "id" : 130321560912396288,
  "created_at" : "Sat Oct 29 16:34:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Wang",
      "screen_name" : "annie_wang",
      "indices" : [ 0, 11 ],
      "id_str" : "29599103",
      "id" : 29599103
    }, {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 12, 24 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Tweetbot by Tapbots",
      "screen_name" : "tweetbot",
      "indices" : [ 31, 40 ],
      "id_str" : "274626857",
      "id" : 274626857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129992354735198208",
  "geo" : {
  },
  "id_str" : "129993929830563840",
  "in_reply_to_user_id" : 29599103,
  "text" : "@annie_wang @alishalisha I use @tweetbot for iOS - much slicker than the official app!",
  "id" : 129993929830563840,
  "in_reply_to_status_id" : 129992354735198208,
  "created_at" : "Fri Oct 28 18:52:22 +0000 2011",
  "in_reply_to_screen_name" : "annie_wang",
  "in_reply_to_user_id_str" : "29599103",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/HarvardCSA/status/129993206141173760/photo/1",
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/nCWXOAdo",
      "media_url" : "http://pbs.twimg.com/media/Ac3UIduCQAADzU6.jpg",
      "id_str" : "129993206145368064",
      "id" : 129993206145368064,
      "media_url_https" : "https://pbs.twimg.com/media/Ac3UIduCQAADzU6.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/nCWXOAdo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129993797391237120",
  "text" : "RT @HarvardCSA: Taking our annual Executive Board pictures! Bundled up for the freezing Cambridge dawn. http://t.co/nCWXOAdo",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/HarvardCSA/status/129993206141173760/photo/1",
        "indices" : [ 88, 108 ],
        "url" : "http://t.co/nCWXOAdo",
        "media_url" : "http://pbs.twimg.com/media/Ac3UIduCQAADzU6.jpg",
        "id_str" : "129993206145368064",
        "id" : 129993206145368064,
        "media_url_https" : "https://pbs.twimg.com/media/Ac3UIduCQAADzU6.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/nCWXOAdo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "129993206141173760",
    "text" : "Taking our annual Executive Board pictures! Bundled up for the freezing Cambridge dawn. http://t.co/nCWXOAdo",
    "id" : 129993206141173760,
    "created_at" : "Fri Oct 28 18:49:30 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 129993797391237120,
  "created_at" : "Fri Oct 28 18:51:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129920869169508352",
  "text" : "Let's be clear: \"tech\" includes jet engines, construction equip, energy, etc... Not just cute little web apps. Don't bastardize the term.",
  "id" : 129920869169508352,
  "created_at" : "Fri Oct 28 14:02:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 0, 16 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129808658312855552",
  "geo" : {
  },
  "id_str" : "129901510384549888",
  "in_reply_to_user_id" : 228489296,
  "text" : "@GlobalAsianista if you would like a shirt I ship too :)",
  "id" : 129901510384549888,
  "in_reply_to_status_id" : 129808658312855552,
  "created_at" : "Fri Oct 28 12:45:08 +0000 2011",
  "in_reply_to_screen_name" : "GlobalAsianista",
  "in_reply_to_user_id_str" : "228489296",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129748332905107456",
  "text" : "I understand product placement in music vids, but someone should tell Pitbull that German rear-wheel coupes are bad in the desert.",
  "id" : 129748332905107456,
  "created_at" : "Fri Oct 28 02:36:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Graves",
      "screen_name" : "ryangraves",
      "indices" : [ 0, 11 ],
      "id_str" : "14303261",
      "id" : 14303261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/OMng25dv",
      "expanded_url" : "http://gmail.com",
      "display_url" : "gmail.com"
    } ]
  },
  "in_reply_to_status_id_str" : "129747040048644096",
  "geo" : {
  },
  "id_str" : "129747662328168448",
  "in_reply_to_user_id" : 14303261,
  "text" : "@ryangraves let's figure this out on email. kane.hsieh at http://t.co/OMng25dv - speak to you soon.",
  "id" : 129747662328168448,
  "in_reply_to_status_id" : 129747040048644096,
  "created_at" : "Fri Oct 28 02:33:47 +0000 2011",
  "in_reply_to_screen_name" : "ryangraves",
  "in_reply_to_user_id_str" : "14303261",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Graves",
      "screen_name" : "ryangraves",
      "indices" : [ 0, 11 ],
      "id_str" : "14303261",
      "id" : 14303261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129724327355621376",
  "in_reply_to_user_id" : 14303261,
  "text" : "@ryangraves Would love to hear more about Uber opportunity in NY!",
  "id" : 129724327355621376,
  "created_at" : "Fri Oct 28 01:01:04 +0000 2011",
  "in_reply_to_screen_name" : "ryangraves",
  "in_reply_to_user_id_str" : "14303261",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chenglin Yuan",
      "screen_name" : "chenglinnn",
      "indices" : [ 40, 51 ],
      "id_str" : "49660090",
      "id" : 49660090
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 52, 64 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 65, 75 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/129691277708103680/photo/1",
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/NcJNTPcB",
      "media_url" : "http://pbs.twimg.com/media/AczBh6qCEAAmj7n.jpg",
      "id_str" : "129691277712297984",
      "id" : 129691277712297984,
      "media_url_https" : "https://pbs.twimg.com/media/AczBh6qCEAAmj7n.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/NcJNTPcB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129691277708103680",
  "text" : "Harvard food entrepreneurship panel! W/ @chenglinnn @badboyboyce @momogoose and more http://t.co/NcJNTPcB",
  "id" : 129691277708103680,
  "created_at" : "Thu Oct 27 22:49:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/CJYfCxIo",
      "expanded_url" : "http://wsj.com",
      "display_url" : "wsj.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "129690901936218112",
  "text" : "RT @WSJ: Breaking: Hewlett-Packard decides to keep its PC business, concluding a spinoff would be too costly. http://t.co/CJYfCxIo",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http://t.co/CJYfCxIo",
        "expanded_url" : "http://wsj.com",
        "display_url" : "wsj.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "129650888276066304",
    "text" : "Breaking: Hewlett-Packard decides to keep its PC business, concluding a spinoff would be too costly. http://t.co/CJYfCxIo",
    "id" : 129650888276066304,
    "created_at" : "Thu Oct 27 20:09:15 +0000 2011",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 129690901936218112,
  "created_at" : "Thu Oct 27 22:48:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129635422547615744",
  "text" : "RT @TheEconomist: Changes in information technology are leading to more herd behaviour and a more unified global society http://t.co/ArF ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http://t.co/ArFC1UHM",
        "expanded_url" : "http://econ.st/sEE6Fw",
        "display_url" : "econ.st/sEE6Fw"
      } ]
    },
    "geo" : {
    },
    "id_str" : "129547268993982464",
    "text" : "Changes in information technology are leading to more herd behaviour and a more unified global society http://t.co/ArFC1UHM",
    "id" : 129547268993982464,
    "created_at" : "Thu Oct 27 13:17:30 +0000 2011",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 129635422547615744,
  "created_at" : "Thu Oct 27 19:07:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129455160362676224",
  "text" : "I love love love working on Mather House's dual hexacore Mac Pro",
  "id" : 129455160362676224,
  "created_at" : "Thu Oct 27 07:11:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129371318083784704",
  "text" : "I almost got run over walking while tweeting bc I couldn't hear a hybrid in EV mode backing up silently. Technology will be the end of me.",
  "id" : 129371318083784704,
  "created_at" : "Thu Oct 27 01:38:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven",
      "screen_name" : "mash_daddy",
      "indices" : [ 0, 11 ],
      "id_str" : "193150867",
      "id" : 193150867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129314730270670849",
  "geo" : {
  },
  "id_str" : "129330608987049984",
  "in_reply_to_user_id" : 193150867,
  "text" : "@mash_daddy hearing accessibility options let you use the LED for notifications in iOS5",
  "id" : 129330608987049984,
  "in_reply_to_status_id" : 129314730270670849,
  "created_at" : "Wed Oct 26 22:56:34 +0000 2011",
  "in_reply_to_screen_name" : "mash_daddy",
  "in_reply_to_user_id_str" : "193150867",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129298475920801792",
  "text" : "Student: \"so how do you pitch funding [for these robots]?\"\nProf: \"put a gun on it and say its military\"",
  "id" : 129298475920801792,
  "created_at" : "Wed Oct 26 20:48:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unhelpful",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129284071879741440",
  "text" : "WHO papers cite a lot other WHO papers that also happen to be unpublished. #unhelpful",
  "id" : 129284071879741440,
  "created_at" : "Wed Oct 26 19:51:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 97, 111 ],
      "id_str" : "16005250",
      "id" : 16005250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/xwgQ0bow",
      "expanded_url" : "http://www.whatsupshutup.com/harvardyaleshirt/",
      "display_url" : "whatsupshutup.com/harvardyaleshi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "129247450753024000",
  "text" : "I made  shirts for the Harvard Yale game. Not entirely politically correct! http://t.co/xwgQ0bow @angryasianman might get a kick out of it",
  "id" : 129247450753024000,
  "created_at" : "Wed Oct 26 17:26:08 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "indices" : [ 3, 15 ],
      "id_str" : "717313",
      "id" : 717313
    }, {
      "name" : "Peter Bright",
      "screen_name" : "DrPizza",
      "indices" : [ 118, 126 ],
      "id_str" : "11375732",
      "id" : 11375732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/zu644DWJ",
      "expanded_url" : "http://arstechnica.com/microsoft/news/2011/10/hands-on-nokias-lumia-800-is-exactly-what-microsoft-windows-phone-7-need.ars",
      "display_url" : "arstechnica.com/microsoft/news\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "129244382112120832",
  "text" : "RT @arstechnica: Hands-on: Nokia's Lumia 800 is exactly what Microsoft, Windows Phone 7 need: http://t.co/zu644DWJ by @drpizza",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.arstechnica.com\" rel=\"nofollow\">Ars auto-tweeter</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Bright",
        "screen_name" : "DrPizza",
        "indices" : [ 101, 109 ],
        "id_str" : "11375732",
        "id" : 11375732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http://t.co/zu644DWJ",
        "expanded_url" : "http://arstechnica.com/microsoft/news/2011/10/hands-on-nokias-lumia-800-is-exactly-what-microsoft-windows-phone-7-need.ars",
        "display_url" : "arstechnica.com/microsoft/news\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "129242950562619392",
    "text" : "Hands-on: Nokia's Lumia 800 is exactly what Microsoft, Windows Phone 7 need: http://t.co/zu644DWJ by @drpizza",
    "id" : 129242950562619392,
    "created_at" : "Wed Oct 26 17:08:15 +0000 2011",
    "user" : {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "protected" : false,
      "id_str" : "717313",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2215576731/ars-logo_normal.png",
      "id" : 717313,
      "verified" : true
    }
  },
  "id" : 129244382112120832,
  "created_at" : "Wed Oct 26 17:13:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nokia",
      "screen_name" : "nokia",
      "indices" : [ 0, 6 ],
      "id_str" : "24727891",
      "id" : 24727891
    }, {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 51, 60 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129108598528811008",
  "in_reply_to_user_id" : 24727891,
  "text" : "@Nokia World 2011 is going on right now! Following @engadget's liveblog. Because sleep is overrated.",
  "id" : 129108598528811008,
  "created_at" : "Wed Oct 26 08:14:23 +0000 2011",
  "in_reply_to_screen_name" : "nokia",
  "in_reply_to_user_id_str" : "24727891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean",
      "screen_name" : "deanshu",
      "indices" : [ 0, 8 ],
      "id_str" : "231525350",
      "id" : 231525350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128962551844323328",
  "geo" : {
  },
  "id_str" : "128962881273344001",
  "in_reply_to_user_id" : 231525350,
  "text" : "@deanshu Yea this is a *warranty* repair. Except it's like flossing w razor wire. I've settled international credit theft faster than this.",
  "id" : 128962881273344001,
  "in_reply_to_status_id" : 128962551844323328,
  "created_at" : "Tue Oct 25 22:35:21 +0000 2011",
  "in_reply_to_screen_name" : "deanshu",
  "in_reply_to_user_id_str" : "231525350",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 34, 41 ],
      "id_str" : "17307429",
      "id" : 17307429
    }, {
      "name" : "BBB | US",
      "screen_name" : "bbb_us",
      "indices" : [ 105, 112 ],
      "id_str" : "15602091",
      "id" : 15602091
    }, {
      "name" : "consumerist",
      "screen_name" : "consumerist",
      "indices" : [ 113, 125 ],
      "id_str" : "11774052",
      "id" : 11774052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128935438051311618",
  "text" : "After weeks of failed promises by @lenovo, no repair, no refund, and no replacement, I've filed with the @bbb_us @consumerist",
  "id" : 128935438051311618,
  "created_at" : "Tue Oct 25 20:46:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 34, 41 ],
      "id_str" : "17307429",
      "id" : 17307429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128931391776886784",
  "text" : "The \"direct line\" to support that @lenovo provides goes straight to voicemail",
  "id" : 128931391776886784,
  "created_at" : "Tue Oct 25 20:30:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 14, 21 ],
      "id_str" : "17307429",
      "id" : 17307429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128930239471558657",
  "text" : "Not only does @lenovo provide NO guarantee for repair time, they offer NO refunds or replacements if they arbitrarily hold for weeks",
  "id" : 128930239471558657,
  "created_at" : "Tue Oct 25 20:25:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 0, 7 ],
      "id_str" : "17307429",
      "id" : 17307429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128927057810956289",
  "in_reply_to_user_id" : 17307429,
  "text" : "@Lenovo support is a nightmare to wade through. 4 promised calls that never game, 5 weeks over due repairs, no refund, no replacement.",
  "id" : 128927057810956289,
  "created_at" : "Tue Oct 25 20:13:00 +0000 2011",
  "in_reply_to_screen_name" : "lenovo",
  "in_reply_to_user_id_str" : "17307429",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 101, 112 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/kEmM3Bug",
      "expanded_url" : "http://www.forbes.com/sites/tarabrown/2011/10/24/how-to-meet-other-women-at-tech-conferences/",
      "display_url" : "forbes.com/sites/tarabrow\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128861212090974209",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha for your thesis! - how to meet other women at tech conferences http://t.co/kEmM3Bug via @ForbesTech",
  "id" : 128861212090974209,
  "created_at" : "Tue Oct 25 15:51:21 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128860369061023744",
  "text" : "There is nothing quite as depressing as a fluorescent-lit underground computer lab during a sunny fall day.",
  "id" : 128860369061023744,
  "created_at" : "Tue Oct 25 15:48:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "fangjon",
      "indices" : [ 0, 8 ],
      "id_str" : "46477577",
      "id" : 46477577
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 9, 21 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128823349974548480",
  "geo" : {
  },
  "id_str" : "128859756625543168",
  "in_reply_to_user_id" : 46477577,
  "text" : "@fangjon @badboyboyce East Asia whirlwind tour planning begins next week :D",
  "id" : 128859756625543168,
  "in_reply_to_status_id" : 128823349974548480,
  "created_at" : "Tue Oct 25 15:45:34 +0000 2011",
  "in_reply_to_screen_name" : "fangjon",
  "in_reply_to_user_id_str" : "46477577",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/uow3EkEI",
      "expanded_url" : "http://on.cnn.com/rpLeCh",
      "display_url" : "on.cnn.com/rpLeCh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128841342435602433",
  "text" : "\"Damascus Doctors\" - group of guerilla doctors aiding protesters in Syria. http://t.co/uow3EkEI",
  "id" : 128841342435602433,
  "created_at" : "Tue Oct 25 14:32:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 43, 55 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovationneversleeps",
      "indices" : [ 57, 79 ]
    }, {
      "text" : "butsometimesitnaps",
      "indices" : [ 80, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128741286214770688",
  "text" : "All nighter of work, tag teaming naps with @badboyboyce. #innovationneversleeps #butsometimesitnaps",
  "id" : 128741286214770688,
  "created_at" : "Tue Oct 25 07:54:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128544352724193280",
  "geo" : {
  },
  "id_str" : "128545166528217088",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee you can mix and match PDFs in OSX Preview",
  "id" : 128545166528217088,
  "in_reply_to_status_id" : 128544352724193280,
  "created_at" : "Mon Oct 24 18:55:30 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gawker",
      "screen_name" : "Gawker",
      "indices" : [ 3, 10 ],
      "id_str" : "8936082",
      "id" : 8936082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/qe7cT2B2",
      "expanded_url" : "http://gawker.com/5852770/",
      "display_url" : "gawker.com/5852770/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128541396759085056",
  "text" : "RT @Gawker: Harvard Investigation: Why Does Everyone Play on Facebook During Class? http://t.co/qe7cT2B2",
  "retweeted_status" : {
    "source" : "<a href=\"http://gawkermedia.com\" rel=\"nofollow\">Gawker Media Group</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http://t.co/qe7cT2B2",
        "expanded_url" : "http://gawker.com/5852770/",
        "display_url" : "gawker.com/5852770/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "128520648648704000",
    "text" : "Harvard Investigation: Why Does Everyone Play on Facebook During Class? http://t.co/qe7cT2B2",
    "id" : 128520648648704000,
    "created_at" : "Mon Oct 24 17:18:05 +0000 2011",
    "user" : {
      "name" : "Gawker",
      "screen_name" : "Gawker",
      "protected" : false,
      "id_str" : "8936082",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/777177440/gawker_normal.jpg",
      "id" : 8936082,
      "verified" : true
    }
  },
  "id" : 128541396759085056,
  "created_at" : "Mon Oct 24 18:40:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/BQAAoicQ",
      "expanded_url" : "http://laughingsquid.com/new-software-system-for-realistically-adding-objects-into-photos/",
      "display_url" : "laughingsquid.com/new-software-s\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128326210760613888",
  "text" : "SIGGRAPH videos always blow my mind. Synthetic lighting: http://t.co/BQAAoicQ",
  "id" : 128326210760613888,
  "created_at" : "Mon Oct 24 04:25:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/128211275275706370/photo/1",
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/hN0fBL8i",
      "media_url" : "http://pbs.twimg.com/media/Acd_eb9CIAEimnk.jpg",
      "id_str" : "128211275279900673",
      "id" : 128211275279900673,
      "media_url_https" : "https://pbs.twimg.com/media/Acd_eb9CIAEimnk.jpg",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com/hN0fBL8i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128211275275706370",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce and @hugovanvuuren talking shop; self conscious about black and corduroy. http://t.co/hN0fBL8i",
  "id" : 128211275275706370,
  "created_at" : "Sun Oct 23 20:48:45 +0000 2011",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128029483579080705",
  "text" : "It seems that many websites are down for maintenance at 5AM on Sunday.",
  "id" : 128029483579080705,
  "created_at" : "Sun Oct 23 08:46:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 57, 70 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128001617818681344",
  "text" : "Jon Stewart holds his iPhone upside down in the 10/20/11 @TheDailyShow",
  "id" : 128001617818681344,
  "created_at" : "Sun Oct 23 06:55:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127968252092624896",
  "text" : "In the middle of nowhere, Massachusetts. I had forgotten how beautiful the night sky can be.",
  "id" : 127968252092624896,
  "created_at" : "Sun Oct 23 04:43:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 3, 9 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/8nxCeAJ0",
      "expanded_url" : "http://www.netmarketshare.com/browser-market-share.aspx?qprid=1&qpcustomb=0",
      "display_url" : "netmarketshare.com/browser-market\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "127882905690189825",
  "text" : "RT @koush: Wow, Chrome is on track to overtake Firefox. http://t.co/8nxCeAJ0",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http://t.co/8nxCeAJ0",
        "expanded_url" : "http://www.netmarketshare.com/browser-market-share.aspx?qprid=1&qpcustomb=0",
        "display_url" : "netmarketshare.com/browser-market\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "127874443790921728",
    "text" : "Wow, Chrome is on track to overtake Firefox. http://t.co/8nxCeAJ0",
    "id" : 127874443790921728,
    "created_at" : "Sat Oct 22 22:30:17 +0000 2011",
    "user" : {
      "name" : "koush",
      "screen_name" : "koush",
      "protected" : false,
      "id_str" : "18918415",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1577420755/img-18_normal.jpg",
      "id" : 18918415,
      "verified" : false
    }
  },
  "id" : 127882905690189825,
  "created_at" : "Sat Oct 22 23:03:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "fangjon",
      "indices" : [ 0, 8 ],
      "id_str" : "46477577",
      "id" : 46477577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127598107893579777",
  "geo" : {
  },
  "id_str" : "127826501155565569",
  "in_reply_to_user_id" : 46477577,
  "text" : "@fangjon hanging out with Ian and Allen in  Brooklyn :)",
  "id" : 127826501155565569,
  "in_reply_to_status_id" : 127598107893579777,
  "created_at" : "Sat Oct 22 19:19:47 +0000 2011",
  "in_reply_to_screen_name" : "fangjon",
  "in_reply_to_user_id_str" : "46477577",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127825408409346048",
  "text" : "Every day I'm strugglin' *dodododoDOdodo*",
  "id" : 127825408409346048,
  "created_at" : "Sat Oct 22 19:15:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pun",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127518395783593985",
  "text" : "Just broke my land speed record. In a Maserati. This transmission is SO clutch. #pun",
  "id" : 127518395783593985,
  "created_at" : "Fri Oct 21 22:55:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 0, 9 ],
      "id_str" : "18008249",
      "id" : 18008249
    }, {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 10, 25 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127353435837304832",
  "geo" : {
  },
  "id_str" : "127358141062053888",
  "in_reply_to_user_id" : 18008249,
  "text" : "@thepunit @NaveenSrivatsa breakfast? What a novel idea.",
  "id" : 127358141062053888,
  "in_reply_to_status_id" : 127353435837304832,
  "created_at" : "Fri Oct 21 12:18:41 +0000 2011",
  "in_reply_to_screen_name" : "thepunit",
  "in_reply_to_user_id_str" : "18008249",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia",
      "screen_name" : "NataliaZarina",
      "indices" : [ 11, 25 ],
      "id_str" : "74196868",
      "id" : 74196868
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 41, 49 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 61, 69 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 70, 82 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 85, 92 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hustlers",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/S0GT6JbF",
      "expanded_url" : "http://instagr.am/p/CyVaj/",
      "display_url" : "instagr.am/p/CyVaj/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "127068586412998658",
  "text" : "Nostalgia: @nataliazarina's photo of the @harvard  #hustlers @digitil @badboyboyce & @khsieh http://t.co/S0GT6JbF",
  "id" : 127068586412998658,
  "created_at" : "Thu Oct 20 17:08:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126964145437425665",
  "text" : "Watching clips from #GOP debate. It's like a kindergarten class run by Romney. Sigh.",
  "id" : 126964145437425665,
  "created_at" : "Thu Oct 20 10:13:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "niniane",
      "screen_name" : "niniane",
      "indices" : [ 0, 8 ],
      "id_str" : "9239622",
      "id" : 9239622
    }, {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 19, 31 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 123, 133 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126849726225203200",
  "geo" : {
  },
  "id_str" : "126869362454958080",
  "in_reply_to_user_id" : 9239622,
  "text" : "@niniane my friend @alishalisha is writing a thesis on female founders/entrepreneurs! Thought you guys would get along cc: @jenny8lee",
  "id" : 126869362454958080,
  "in_reply_to_status_id" : 126849726225203200,
  "created_at" : "Thu Oct 20 03:56:27 +0000 2011",
  "in_reply_to_screen_name" : "niniane",
  "in_reply_to_user_id_str" : "9239622",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nokia",
      "screen_name" : "nokia",
      "indices" : [ 41, 47 ],
      "id_str" : "24727891",
      "id" : 24727891
    }, {
      "name" : "Verizon Wireless USA",
      "screen_name" : "VerizonWireless",
      "indices" : [ 64, 80 ],
      "id_str" : "59889953",
      "id" : 59889953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126825781572812800",
  "text" : "Please please please let there be a CDMA @nokia 800 release for @verizonwireless",
  "id" : 126825781572812800,
  "created_at" : "Thu Oct 20 01:03:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sriracha hot sauce",
      "screen_name" : "hotsriracha",
      "indices" : [ 0, 12 ],
      "id_str" : "44901968",
      "id" : 44901968
    }, {
      "name" : "sriracha hot sauce",
      "screen_name" : "hotsriracha",
      "indices" : [ 36, 48 ],
      "id_str" : "44901968",
      "id" : 44901968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truestory",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126824621508005888",
  "in_reply_to_user_id" : 44901968,
  "text" : "@hotsriracha and fried rice = good. @hotsriracha and gin = not so good. #truestory",
  "id" : 126824621508005888,
  "created_at" : "Thu Oct 20 00:58:40 +0000 2011",
  "in_reply_to_screen_name" : "hotsriracha",
  "in_reply_to_user_id_str" : "44901968",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 0, 7 ],
      "id_str" : "17307429",
      "id" : 17307429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126818038807932929",
  "geo" : {
  },
  "id_str" : "126824147786539008",
  "in_reply_to_user_id" : 17307429,
  "text" : "@lenovo Thanks for the response! Just DM'd you.",
  "id" : 126824147786539008,
  "in_reply_to_status_id" : 126818038807932929,
  "created_at" : "Thu Oct 20 00:56:47 +0000 2011",
  "in_reply_to_screen_name" : "lenovo",
  "in_reply_to_user_id_str" : "17307429",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 0, 7 ],
      "id_str" : "17307429",
      "id" : 17307429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126813635065544704",
  "in_reply_to_user_id" : 17307429,
  "text" : "@lenovo the repair you said would take 7 days is taking 30, and the call you promised in under 48 hours is still pending going into 72...",
  "id" : 126813635065544704,
  "created_at" : "Thu Oct 20 00:15:01 +0000 2011",
  "in_reply_to_screen_name" : "lenovo",
  "in_reply_to_user_id_str" : "17307429",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows Phone",
      "screen_name" : "windowsphone",
      "indices" : [ 48, 61 ],
      "id_str" : "16425197",
      "id" : 16425197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126541700171694080",
  "text" : "Galaxy Nexus for Verizon looks HOT. Waiting for @windowsphone announcements next week.",
  "id" : 126541700171694080,
  "created_at" : "Wed Oct 19 06:14:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fallObservations",
      "indices" : [ 41, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126390852649091072",
  "text" : "Sprinting squirrels are really graceful. #fallObservations",
  "id" : 126390852649091072,
  "created_at" : "Tue Oct 18 20:15:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126381654221651968",
  "text" : "When I'm running low on clean socks, it's easier to use amazon prime than it is to do laundry. What is my life.",
  "id" : 126381654221651968,
  "created_at" : "Tue Oct 18 19:38:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126358215930818561",
  "text" : "\"Given its users, if iCloud ever became sentient, it would be a giant Arcade Fire fan with lots of hipster photographs.\"",
  "id" : 126358215930818561,
  "created_at" : "Tue Oct 18 18:05:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126178490771972096",
  "text" : "RT @hotdogsladies: N.B: I've moved my Google Buzz and Jaiku posts about Google Wave and Dodgeball to Google+ in advance of the release o ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "126176997641699329",
    "text" : "N.B: I've moved my Google Buzz and Jaiku posts about Google Wave and Dodgeball to Google+ in advance of the release of GoogleDoublePlusGood.",
    "id" : 126176997641699329,
    "created_at" : "Tue Oct 18 06:05:15 +0000 2011",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/51857279/merlin_icon_184-1_normal.png",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 126178490771972096,
  "created_at" : "Tue Oct 18 06:11:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 4, 11 ],
      "id_str" : "17307429",
      "id" : 17307429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126076372467716096",
  "text" : "Hey @Lenovo, you said 7 days for repair, you meant 30+. Now I have no comp and you have my $$ because you won't refund me. What's the deal?",
  "id" : 126076372467716096,
  "created_at" : "Mon Oct 17 23:25:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "IndarKness",
      "screen_name" : "Alex_IndarKness",
      "indices" : [ 9, 25 ],
      "id_str" : "90575128",
      "id" : 90575128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125830838574260224",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil @Alex_IndarKness thanks for the suggestions, using GNOME classic in Ubuntu 11.10. I can't wait to get my Win7 machine back...",
  "id" : 125830838574260224,
  "created_at" : "Mon Oct 17 07:09:44 +0000 2011",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 103, 111 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125784412037201921",
  "text" : "Ubuntu's Unity interface is TERRIBLE. And they removed the regular desktop from 11.10. Recommendations @digitil?",
  "id" : 125784412037201921,
  "created_at" : "Mon Oct 17 04:05:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 7, 17 ],
      "id_str" : "74286565",
      "id" : 74286565
    }, {
      "name" : "Nokia",
      "screen_name" : "nokia",
      "indices" : [ 22, 28 ],
      "id_str" : "24727891",
      "id" : 24727891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125783868979691520",
  "text" : "So hey @microsoft and @nokia, what's the dealio with a Nokia Mango device launch? Because the iPhone 4S and Nexus Prime are pretty tempting.",
  "id" : 125783868979691520,
  "created_at" : "Mon Oct 17 04:03:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 0, 5 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125676958716665857",
  "in_reply_to_user_id" : 1439921,
  "text" : "@Kane any chance I could convince you to gift your twitter username?",
  "id" : 125676958716665857,
  "created_at" : "Sun Oct 16 20:58:16 +0000 2011",
  "in_reply_to_screen_name" : "kane1735613",
  "in_reply_to_user_id_str" : "1439921",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/D2Wv2zXq",
      "expanded_url" : "http://econ.st/qwYuik",
      "display_url" : "econ.st/qwYuik"
    } ]
  },
  "geo" : {
  },
  "id_str" : "125670012479471616",
  "text" : "RT @TheEconomist: Happiness is in your DNA; and different races may have different propensities for it http://t.co/D2Wv2zXq",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/D2Wv2zXq",
        "expanded_url" : "http://econ.st/qwYuik",
        "display_url" : "econ.st/qwYuik"
      } ]
    },
    "geo" : {
    },
    "id_str" : "125668682939637760",
    "text" : "Happiness is in your DNA; and different races may have different propensities for it http://t.co/D2Wv2zXq",
    "id" : 125668682939637760,
    "created_at" : "Sun Oct 16 20:25:23 +0000 2011",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 125670012479471616,
  "created_at" : "Sun Oct 16 20:30:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Parmelee",
      "screen_name" : "GlobalFools",
      "indices" : [ 3, 15 ],
      "id_str" : "50026097",
      "id" : 50026097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/5RIxTtjI",
      "expanded_url" : "http://fb.me/1o41AZ3bI",
      "display_url" : "fb.me/1o41AZ3bI"
    } ]
  },
  "geo" : {
  },
  "id_str" : "125665193962377216",
  "text" : "RT @GlobalFools: The crackberry outage in Europe and Middle East wasn't all bad news. Traffic accidents are down.... http://t.co/5RIxTtjI",
  "id" : 125665193962377216,
  "created_at" : "Sun Oct 16 20:11:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 0, 9 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/124970755850108928/photo/1",
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/NXVOQhF8",
      "media_url" : "http://pbs.twimg.com/media/Abv8PYYCAAEMu20.jpg",
      "id_str" : "124970755854303233",
      "id" : 124970755854303233,
      "media_url_https" : "https://pbs.twimg.com/media/Abv8PYYCAAEMu20.jpg",
      "sizes" : [ {
        "h" : 1296,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/NXVOQhF8"
    } ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 64, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124970755850108928",
  "in_reply_to_user_id" : 18008249,
  "text" : "@thepunit getting directions the old school way. No smartphone. #firstworldproblems http://t.co/NXVOQhF8",
  "id" : 124970755850108928,
  "created_at" : "Fri Oct 14 22:12:05 +0000 2011",
  "in_reply_to_screen_name" : "thepunit",
  "in_reply_to_user_id_str" : "18008249",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 3, 9 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124961242388500482",
  "text" : "RT @jluan: &lt;1 mile visibility, 0 ft AGL clouds at JFK. Nice instrument landing, Delta!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "124681224802406400",
    "text" : "&lt;1 mile visibility, 0 ft AGL clouds at JFK. Nice instrument landing, Delta!",
    "id" : 124681224802406400,
    "created_at" : "Fri Oct 14 03:01:35 +0000 2011",
    "user" : {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "protected" : false,
      "id_str" : "27015881",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1366826138/72500_1527561949320_1242810207_31307527_6609490_n_1__normal.jpg",
      "id" : 27015881,
      "verified" : false
    }
  },
  "id" : 124961242388500482,
  "created_at" : "Fri Oct 14 21:34:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 41, 52 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/K3k1VmHy",
      "expanded_url" : "http://4sq.com/oiDqZ6",
      "display_url" : "4sq.com/oiDqZ6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124848300112355329",
  "text" : "I just unlocked the \"JetSetter\" badge on @foursquare! http://t.co/K3k1VmHy",
  "id" : 124848300112355329,
  "created_at" : "Fri Oct 14 14:05:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124830926369865728",
  "text" : "Ubuntu releases 11.10 a day after I install 11.04 on three laptops. Typical.",
  "id" : 124830926369865728,
  "created_at" : "Fri Oct 14 12:56:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 37, 48 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/bmKnioa0",
      "expanded_url" : "http://4sq.com/qX23Av",
      "display_url" : "4sq.com/qX23Av"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124806070853042176",
  "text" : "I just unlocked the \"Local\" badge on @foursquare! http://t.co/bmKnioa0",
  "id" : 124806070853042176,
  "created_at" : "Fri Oct 14 11:17:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124714145575747584",
  "text" : "I don't understand how anyone lived with a single core processor. Even with an SSD and 4 GB of RAM this AMD Fusion is struggling.",
  "id" : 124714145575747584,
  "created_at" : "Fri Oct 14 05:12:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 0, 13 ],
      "id_str" : "202968305",
      "id" : 202968305
    }, {
      "name" : "Kim Kardashian",
      "screen_name" : "KimKardashian",
      "indices" : [ 37, 51 ],
      "id_str" : "25365536",
      "id" : 25365536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124711450664108032",
  "in_reply_to_user_id" : 202968305,
  "text" : "@jamesdotcuff don't you know? Me and @KimKardashian are like bffs",
  "id" : 124711450664108032,
  "created_at" : "Fri Oct 14 05:01:41 +0000 2011",
  "in_reply_to_screen_name" : "jamesdotcuff",
  "in_reply_to_user_id_str" : "202968305",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124563024794238977",
  "text" : "NOW I know why Herman Cain's 9-9-9 tax code is so catchy - it's like Dominoes 5-5-5 pizza deal, only completely absurd.",
  "id" : 124563024794238977,
  "created_at" : "Thu Oct 13 19:11:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Streetinsider.com",
      "screen_name" : "Street_Insider",
      "indices" : [ 3, 18 ],
      "id_str" : "84402174",
      "id" : 84402174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124545805951569920",
  "text" : "RT @Street_Insider: $AAPL iPhone 4S breakdown also appears to show chip from $SWKS.  So we have $AVGO, $QCOM, $TQNT and SWKS so far",
  "retweeted_status" : {
    "source" : "<a href=\"http://stocktwits.com\" rel=\"nofollow\">StockTwits Web</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "124518972673634304",
    "text" : "$AAPL iPhone 4S breakdown also appears to show chip from $SWKS.  So we have $AVGO, $QCOM, $TQNT and SWKS so far",
    "id" : 124518972673634304,
    "created_at" : "Thu Oct 13 16:16:51 +0000 2011",
    "user" : {
      "name" : "Streetinsider.com",
      "screen_name" : "Street_Insider",
      "protected" : false,
      "id_str" : "84402174",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/504446210/small_icon_blue_on_blue_normal.jpg",
      "id" : 84402174,
      "verified" : false
    }
  },
  "id" : 124545805951569920,
  "created_at" : "Thu Oct 13 18:03:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Paiji",
      "screen_name" : "spaiji",
      "indices" : [ 13, 20 ],
      "id_str" : "213867225",
      "id" : 213867225
    }, {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 25, 36 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/3KJMdoK1",
      "expanded_url" : "http://onforb.es/oAdUvY",
      "display_url" : "onforb.es/oAdUvY"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124516959965548545",
  "text" : "Check it out @spaiji! RT @ForbesTech: Female Founders Of Snapette Not Your Typical Geek Entrepreneurs - http://t.co/3KJMdoK1",
  "id" : 124516959965548545,
  "created_at" : "Thu Oct 13 16:08:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124365590935773184",
  "text" : "Installing Chromium OS. Because I can.",
  "id" : 124365590935773184,
  "created_at" : "Thu Oct 13 06:07:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rudolph",
      "screen_name" : "BenThePCGuy",
      "indices" : [ 0, 12 ],
      "id_str" : "91396874",
      "id" : 91396874
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackberry",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "mango",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124359298074681344",
  "in_reply_to_user_id" : 91396874,
  "text" : "@benthepcguy I would've tweeted this from my #Blackberry but its battery only lasts 40 minutes. Any chance for some sweet #mango?",
  "id" : 124359298074681344,
  "created_at" : "Thu Oct 13 05:42:21 +0000 2011",
  "in_reply_to_screen_name" : "BenThePCGuy",
  "in_reply_to_user_id_str" : "91396874",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean",
      "screen_name" : "deanshu",
      "indices" : [ 0, 8 ],
      "id_str" : "231525350",
      "id" : 231525350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124310906019651584",
  "geo" : {
  },
  "id_str" : "124357476836573185",
  "in_reply_to_user_id" : 231525350,
  "text" : "@deanshu we're using Lenovo when everyone else is using Macs. That makes us some sort of bizzaro hipsters.",
  "id" : 124357476836573185,
  "in_reply_to_status_id" : 124310906019651584,
  "created_at" : "Thu Oct 13 05:35:07 +0000 2011",
  "in_reply_to_screen_name" : "deanshu",
  "in_reply_to_user_id_str" : "231525350",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124354432203894784",
  "text" : "I'm making a commitment to read one non-school book a month. My to-read pile is slowing taking over my desk at the moment.",
  "id" : 124354432203894784,
  "created_at" : "Thu Oct 13 05:23:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124234084921774081",
  "text" : "ThinkPad X120e is a lame substitute for the X220 I'm waiting to be repaired. Ironically, the 120 can run OpenGL.",
  "id" : 124234084921774081,
  "created_at" : "Wed Oct 12 21:24:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Kangleon",
      "screen_name" : "angelokangleon",
      "indices" : [ 0, 15 ],
      "id_str" : "56125689",
      "id" : 56125689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124177567950454784",
  "geo" : {
  },
  "id_str" : "124182527899484161",
  "in_reply_to_user_id" : 56125689,
  "text" : "@angelokangleon thanks for the feedback! Let me know if you want the full resolution files to print or anything.",
  "id" : 124182527899484161,
  "in_reply_to_status_id" : 124177567950454784,
  "created_at" : "Wed Oct 12 17:59:56 +0000 2011",
  "in_reply_to_screen_name" : "angelokangleon",
  "in_reply_to_user_id_str" : "56125689",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UNIQLO",
      "screen_name" : "UniqloUSA",
      "indices" : [ 90, 100 ],
      "id_str" : "96184837",
      "id" : 96184837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124169586449981440",
  "text" : "In NY this Friday for interviews, and arguably more importantly, the grand opening of the @UniqloUSA flagship.",
  "id" : 124169586449981440,
  "created_at" : "Wed Oct 12 17:08:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    }, {
      "name" : "Parmy Olson",
      "screen_name" : "parmy",
      "indices" : [ 101, 107 ],
      "id_str" : "19116515",
      "id" : 19116515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/9fxKuuzw",
      "expanded_url" : "http://tinyurl.com/5sje4f2",
      "display_url" : "tinyurl.com/5sje4f2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124168927315107840",
  "text" : "RT @ForbesTech: Microsoft Uses Facebook As Giant 'Lab' To Study Game Theory http://t.co/9fxKuuzw via @parmy",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Parmy Olson",
        "screen_name" : "parmy",
        "indices" : [ 85, 91 ],
        "id_str" : "19116515",
        "id" : 19116515
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http://t.co/9fxKuuzw",
        "expanded_url" : "http://tinyurl.com/5sje4f2",
        "display_url" : "tinyurl.com/5sje4f2"
      } ]
    },
    "geo" : {
    },
    "id_str" : "124145987185946624",
    "text" : "Microsoft Uses Facebook As Giant 'Lab' To Study Game Theory http://t.co/9fxKuuzw via @parmy",
    "id" : 124145987185946624,
    "created_at" : "Wed Oct 12 15:34:44 +0000 2011",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 124168927315107840,
  "created_at" : "Wed Oct 12 17:05:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio",
      "screen_name" : "antrod",
      "indices" : [ 0, 7 ],
      "id_str" : "464493",
      "id" : 464493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123948382032105473",
  "geo" : {
  },
  "id_str" : "123978974102687745",
  "in_reply_to_user_id" : 464493,
  "text" : "@antrod iOS 5 sync is not bad. At least from my past 3 months of beta usage.",
  "id" : 123978974102687745,
  "in_reply_to_status_id" : 123948382032105473,
  "created_at" : "Wed Oct 12 04:31:05 +0000 2011",
  "in_reply_to_screen_name" : "antrod",
  "in_reply_to_user_id_str" : "464493",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123784518476902400",
  "geo" : {
  },
  "id_str" : "123821008099622912",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin which Lenovo? My X220 is in for repairs :(",
  "id" : 123821008099622912,
  "in_reply_to_status_id" : 123784518476902400,
  "created_at" : "Tue Oct 11 18:03:23 +0000 2011",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123776971074310145",
  "text" : "Finally back in Cambridge.",
  "id" : 123776971074310145,
  "created_at" : "Tue Oct 11 15:08:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pace",
      "screen_name" : "notpace",
      "indices" : [ 16, 24 ],
      "id_str" : "301753230",
      "id" : 301753230
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OccupyBoston",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123643342025261057",
  "text" : "Sitting next to @notpace at SFO and watching #OccupyBoston on live stream. Does anyone have any REAL news about what's happening there?",
  "id" : 123643342025261057,
  "created_at" : "Tue Oct 11 06:17:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tokyo_fm",
      "screen_name" : "tokyo_fm",
      "indices" : [ 39, 48 ],
      "id_str" : "64282167",
      "id" : 64282167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youtube",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/pHPkpt0u",
      "expanded_url" : "http://bit.ly/i6nKao",
      "display_url" : "bit.ly/i6nKao"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123642279972962304",
  "text" : "Fantastic working or chilling music RT @tokyo_fm: [The Shanghai Restoration Project] Miss Shanghai (#youtube http://t.co/pHPkpt0u )",
  "id" : 123642279972962304,
  "created_at" : "Tue Oct 11 06:13:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Paiji",
      "screen_name" : "spaiji",
      "indices" : [ 0, 7 ],
      "id_str" : "213867225",
      "id" : 213867225
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 65, 77 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123629990691614720",
  "geo" : {
  },
  "id_str" : "123634537556226049",
  "in_reply_to_user_id" : 213867225,
  "text" : "@spaiji Don't you mean European carryall? And sure! Name a time. @badboyboyce is always up for a coffee fix.",
  "id" : 123634537556226049,
  "in_reply_to_status_id" : 123629990691614720,
  "created_at" : "Tue Oct 11 05:42:25 +0000 2011",
  "in_reply_to_screen_name" : "spaiji",
  "in_reply_to_user_id_str" : "213867225",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123609843092295680",
  "text" : "Wow, TSA in San Fran international was actually really nice.",
  "id" : 123609843092295680,
  "created_at" : "Tue Oct 11 04:04:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marissamayer",
      "screen_name" : "marissamayer",
      "indices" : [ 21, 34 ],
      "id_str" : "17503180",
      "id" : 17503180
    }, {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 74, 81 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Harvard",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123544913995505664",
  "text" : "Ironic that I missed @marissamayer speak at #Harvard because I'm visiting @google in Mountain View.",
  "id" : 123544913995505664,
  "created_at" : "Mon Oct 10 23:46:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123478487922249728",
  "text" : "I might have to declare homework bankruptcy this week. Three coding assignments, out of state, and no computer.",
  "id" : 123478487922249728,
  "created_at" : "Mon Oct 10 19:22:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/i0p8TvKK",
      "expanded_url" : "http://econ.st/o3QNoD",
      "display_url" : "econ.st/o3QNoD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123457230057111553",
  "text" : "RT @TheEconomist: The energy efficiency of computing is doubling every 18 months. Daily chart October 10th http://t.co/i0p8TvKK",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http://t.co/i0p8TvKK",
        "expanded_url" : "http://econ.st/o3QNoD",
        "display_url" : "econ.st/o3QNoD"
      } ]
    },
    "geo" : {
    },
    "id_str" : "123401193526538240",
    "text" : "The energy efficiency of computing is doubling every 18 months. Daily chart October 10th http://t.co/i0p8TvKK",
    "id" : 123401193526538240,
    "created_at" : "Mon Oct 10 14:15:11 +0000 2011",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 123457230057111553,
  "created_at" : "Mon Oct 10 17:57:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 27, 40 ],
      "id_str" : "202968305",
      "id" : 202968305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hpc",
      "indices" : [ 50, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/Ncac0H7k",
      "expanded_url" : "http://m.cbsnews.com/storysynopsis.rbml?feed_id=0&catid=20117829&videofeed=36",
      "display_url" : "m.cbsnews.com/storysynopsis.\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123426753111801856",
  "text" : "But can in play Crysis? RT @jamesdotcuff: Our new #hpc ctr in the news: http://t.co/Ncac0H7k",
  "id" : 123426753111801856,
  "created_at" : "Mon Oct 10 15:56:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Qwikster",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123295645598625792",
  "text" : "Blockbuster's TV commercials are just crapping all over Netflix and #Qwikster's price changes.",
  "id" : 123295645598625792,
  "created_at" : "Mon Oct 10 07:15:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 62, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123197359176957953",
  "text" : "It's fleet week in San Fran and taxis are impossible to hail. #firstworldproblems",
  "id" : 123197359176957953,
  "created_at" : "Mon Oct 10 00:45:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Lin",
      "screen_name" : "linamelia",
      "indices" : [ 3, 13 ],
      "id_str" : "40585115",
      "id" : 40585115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/WyZ6oswF",
      "expanded_url" : "http://nyti.ms/pmPu9T",
      "display_url" : "nyti.ms/pmPu9T"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123104915773075456",
  "text" : "RT @linamelia: The tricks people use to film food commercials. NYTimes: Grilled Chicken, That Temperamental Star http://t.co/WyZ6oswF",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/nytimes-for-ipad/id357066198?mt=8\" rel=\"nofollow\">NYTimes for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http://t.co/WyZ6oswF",
        "expanded_url" : "http://nyti.ms/pmPu9T",
        "display_url" : "nyti.ms/pmPu9T"
      } ]
    },
    "geo" : {
    },
    "id_str" : "123102300335128577",
    "text" : "The tricks people use to film food commercials. NYTimes: Grilled Chicken, That Temperamental Star http://t.co/WyZ6oswF",
    "id" : 123102300335128577,
    "created_at" : "Sun Oct 09 18:27:30 +0000 2011",
    "user" : {
      "name" : "Amelia Lin",
      "screen_name" : "linamelia",
      "protected" : false,
      "id_str" : "40585115",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2104994526/profile_picture_normal.png",
      "id" : 40585115,
      "verified" : false
    }
  },
  "id" : 123104915773075456,
  "created_at" : "Sun Oct 09 18:37:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 0, 9 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122935688441241600",
  "in_reply_to_user_id" : 340545195,
  "text" : "@Romotive I just supported you guys for the special edition Romo :) Good luck! PS if I could get #23 that would be wonderful",
  "id" : 122935688441241600,
  "created_at" : "Sun Oct 09 07:25:26 +0000 2011",
  "in_reply_to_screen_name" : "Romotive",
  "in_reply_to_user_id_str" : "340545195",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 53, 59 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122888620901277696",
  "geo" : {
  },
  "id_str" : "122890082616217600",
  "in_reply_to_user_id" : 218624970,
  "text" : "Whirlwind tour of Palo Alto thanks to @gate0proj and @jluan - now off to San Fran!",
  "id" : 122890082616217600,
  "in_reply_to_status_id" : 122888620901277696,
  "created_at" : "Sun Oct 09 04:24:13 +0000 2011",
  "in_reply_to_screen_name" : "kchow343",
  "in_reply_to_user_id_str" : "218624970",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122883643965308929",
  "text" : "Just had my first In-and-Out experience. Liked the lemonade more than the burger.",
  "id" : 122883643965308929,
  "created_at" : "Sun Oct 09 03:58:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Harvard",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122772245641834496",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose I'm seeing a lot of food trucks at #Harvard these days! What's your status?",
  "id" : 122772245641834496,
  "created_at" : "Sat Oct 08 20:35:59 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Paiji",
      "screen_name" : "spaiji",
      "indices" : [ 0, 7 ],
      "id_str" : "213867225",
      "id" : 213867225
    }, {
      "name" : "Snapette",
      "screen_name" : "Snapette",
      "indices" : [ 37, 46 ],
      "id_str" : "258416075",
      "id" : 258416075
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 62, 74 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122748686743777280",
  "geo" : {
  },
  "id_str" : "122770791921221633",
  "in_reply_to_user_id" : 213867225,
  "text" : "@spaiji what's the guy/girl ratio of @snapette users? Because @badboyboyce and I would totally use it.",
  "id" : 122770791921221633,
  "in_reply_to_status_id" : 122748686743777280,
  "created_at" : "Sat Oct 08 20:30:12 +0000 2011",
  "in_reply_to_screen_name" : "spaiji",
  "in_reply_to_user_id_str" : "213867225",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122660588575932416",
  "text" : "Boarding airplanes back to front, row by row is pretty non-optimal.",
  "id" : 122660588575932416,
  "created_at" : "Sat Oct 08 13:12:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122650810202062848",
  "geo" : {
  },
  "id_str" : "122651102968676352",
  "in_reply_to_user_id" : 218624970,
  "text" : "@gate0proj are you and WeeWee going to be free from your Ikea bonanza? :)",
  "id" : 122651102968676352,
  "in_reply_to_status_id" : 122650810202062848,
  "created_at" : "Sat Oct 08 12:34:36 +0000 2011",
  "in_reply_to_screen_name" : "kchow343",
  "in_reply_to_user_id_str" : "218624970",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 25, 31 ],
      "id_str" : "27015881",
      "id" : 27015881
    }, {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 36, 43 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122648810173370368",
  "text" : "Off to San Fran to visit @jluan and @google!",
  "id" : 122648810173370368,
  "created_at" : "Sat Oct 08 12:25:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122395433061449728",
  "text" : "My rapper name will be Optimus Rhyme.",
  "id" : 122395433061449728,
  "created_at" : "Fri Oct 07 19:38:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 92, 101 ],
      "id_str" : "18008249",
      "id" : 18008249
    }, {
      "name" : "Steven",
      "screen_name" : "mash_daddy",
      "indices" : [ 102, 113 ],
      "id_str" : "193150867",
      "id" : 193150867
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 114, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122186569548431360",
  "text" : "My roommates and I cant party bc we are in San Fran, Seattle, DC, and Cambridge separately. @thepunit @mash_daddy #firstworldproblems",
  "id" : 122186569548431360,
  "created_at" : "Fri Oct 07 05:48:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/xd6ZOtWH",
      "expanded_url" : "http://www.bgr.com/2011/10/06/samsung-galaxy-nexus-full-specs-revealed-verizon-wireless-exclusive/",
      "display_url" : "bgr.com/2011/10/06/sam\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "122062051542708224",
  "text" : "Nexus Prime on Verizon looks fantastic: http://t.co/xd6ZOtWH",
  "id" : 122062051542708224,
  "created_at" : "Thu Oct 06 21:33:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121877047114084352",
  "text" : "I wonder what American politics would be like if state primaries were scheduled at random.",
  "id" : 121877047114084352,
  "created_at" : "Thu Oct 06 09:18:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121840903211065345",
  "text" : "That hedge fund that used twitter mood as a metric in their trading models must be flipping out. #jobs",
  "id" : 121840903211065345,
  "created_at" : "Thu Oct 06 06:55:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 3, 9 ],
      "id_str" : "18918415",
      "id" : 18918415
    }, {
      "name" : "NowReport",
      "screen_name" : "NowReport",
      "indices" : [ 22, 32 ],
      "id_str" : "91935208",
      "id" : 91935208
    }, {
      "name" : "Fake Steve Jobs",
      "screen_name" : "FakeSteveJobs",
      "indices" : [ 44, 58 ],
      "id_str" : "25915748",
      "id" : 25915748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121828052723445760",
  "text" : "RT @koush: Apparently @NowReport is the old @fakestevejobs account or whatever. Wow. And Lame.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NowReport",
        "screen_name" : "NowReport",
        "indices" : [ 11, 21 ],
        "id_str" : "91935208",
        "id" : 91935208
      }, {
        "name" : "Fake Steve Jobs",
        "screen_name" : "FakeSteveJobs",
        "indices" : [ 33, 47 ],
        "id_str" : "25915748",
        "id" : 25915748
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "121827801681756160",
    "text" : "Apparently @NowReport is the old @fakestevejobs account or whatever. Wow. And Lame.",
    "id" : 121827801681756160,
    "created_at" : "Thu Oct 06 06:03:06 +0000 2011",
    "user" : {
      "name" : "koush",
      "screen_name" : "koush",
      "protected" : false,
      "id_str" : "18918415",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1577420755/img-18_normal.jpg",
      "id" : 18918415,
      "verified" : false
    }
  },
  "id" : 121828052723445760,
  "created_at" : "Thu Oct 06 06:04:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 32, 38 ],
      "id_str" : "18918415",
      "id" : 18918415
    }, {
      "name" : "NowReport",
      "screen_name" : "NowReport",
      "indices" : [ 77, 87 ],
      "id_str" : "91935208",
      "id" : 91935208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121827939112321024",
  "text" : "Same thing happened to me... RT @koush: How the hell am I suddenly following @NowReport??",
  "id" : 121827939112321024,
  "created_at" : "Thu Oct 06 06:03:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/121821343099518976/photo/1",
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/46Ia4dGQ",
      "media_url" : "http://pbs.twimg.com/media/AbDL3bnCAAAc6VZ.jpg",
      "id_str" : "121821343103713280",
      "id" : 121821343103713280,
      "media_url_https" : "https://pbs.twimg.com/media/AbDL3bnCAAAc6VZ.jpg",
      "sizes" : [ {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com/46Ia4dGQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121821343099518976",
  "text" : "Why I use Micro 4/3 in two words: Stupid fast. http://t.co/46Ia4dGQ",
  "id" : 121821343099518976,
  "created_at" : "Thu Oct 06 05:37:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121766110486999040",
  "text" : "This iPhone feels just a little bit heavier today. #jobs",
  "id" : 121766110486999040,
  "created_at" : "Thu Oct 06 01:57:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean",
      "screen_name" : "deanshu",
      "indices" : [ 0, 8 ],
      "id_str" : "231525350",
      "id" : 231525350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121722367046205440",
  "in_reply_to_user_id" : 231525350,
  "text" : "@deanshu econ midterms will always be there. Beautiful fall days are few and far between! Take it from a nostalgic senior.",
  "id" : 121722367046205440,
  "created_at" : "Wed Oct 05 23:04:08 +0000 2011",
  "in_reply_to_screen_name" : "deanshu",
  "in_reply_to_user_id_str" : "231525350",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/121686421303078912/photo/1",
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/2lzX8i3S",
      "media_url" : "http://pbs.twimg.com/media/AbBRJ8wCMAEvbj3.jpg",
      "id_str" : "121686421307273217",
      "id" : 121686421307273217,
      "media_url_https" : "https://pbs.twimg.com/media/AbBRJ8wCMAEvbj3.jpg",
      "sizes" : [ {
        "h" : 607,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 454
      } ],
      "display_url" : "pic.twitter.com/2lzX8i3S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121686421303078912",
  "text" : "This guy in full spandex with a Chrome bag on a Pista can't decide if he wants to be a hipster or a cyclist. http://t.co/2lzX8i3S",
  "id" : 121686421303078912,
  "created_at" : "Wed Oct 05 20:41:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Housel",
      "screen_name" : "TMFHousel",
      "indices" : [ 3, 13 ],
      "id_str" : "284278132",
      "id" : 284278132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121685569049858048",
  "text" : "RT @TMFHousel: \"Immediate across the board debt forgiveness for all.\" Yes, the rivers flow with prosperity when you nuke every bank.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "121671129113964544",
    "text" : "\"Immediate across the board debt forgiveness for all.\" Yes, the rivers flow with prosperity when you nuke every bank.",
    "id" : 121671129113964544,
    "created_at" : "Wed Oct 05 19:40:32 +0000 2011",
    "user" : {
      "name" : "Morgan Housel",
      "screen_name" : "TMFHousel",
      "protected" : false,
      "id_str" : "284278132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3070370654/f72b96c49e7ef06a3adafe81c3a3cba3_normal.png",
      "id" : 284278132,
      "verified" : false
    }
  },
  "id" : 121685569049858048,
  "created_at" : "Wed Oct 05 20:37:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean",
      "screen_name" : "deanshu",
      "indices" : [ 0, 8 ],
      "id_str" : "231525350",
      "id" : 231525350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121632891179503616",
  "geo" : {
  },
  "id_str" : "121683887222042624",
  "in_reply_to_user_id" : 231525350,
  "text" : "@deanshu today's a perfect fall day to be out and taking pictures around Cambridge!",
  "id" : 121683887222042624,
  "in_reply_to_status_id" : 121632891179503616,
  "created_at" : "Wed Oct 05 20:31:14 +0000 2011",
  "in_reply_to_screen_name" : "deanshu",
  "in_reply_to_user_id_str" : "231525350",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121682645099888640",
  "text" : "Dear cyclists:\nIf you want to be respected and legally protected, stop running lights and riding on the goddamn sidewalk.",
  "id" : 121682645099888640,
  "created_at" : "Wed Oct 05 20:26:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121633296428965888",
  "text" : "I think each of my eyes perceives light with a slightly different white balance.",
  "id" : 121633296428965888,
  "created_at" : "Wed Oct 05 17:10:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Gaiss",
      "screen_name" : "MichaelGaiss",
      "indices" : [ 3, 16 ],
      "id_str" : "14653432",
      "id" : 14653432
    }, {
      "name" : "danprimack",
      "screen_name" : "danprimack",
      "indices" : [ 27, 38 ],
      "id_str" : "16246929",
      "id" : 16246929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121621104983945216",
  "text" : "RT @MichaelGaiss: Ditto RT @danprimack: Today heard a new term: \"Youngry.\" (young + hungry). like it.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "danprimack",
        "screen_name" : "danprimack",
        "indices" : [ 9, 20 ],
        "id_str" : "16246929",
        "id" : 16246929
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "121593388909871104",
    "text" : "Ditto RT @danprimack: Today heard a new term: \"Youngry.\" (young + hungry). like it.",
    "id" : 121593388909871104,
    "created_at" : "Wed Oct 05 14:31:37 +0000 2011",
    "user" : {
      "name" : "Michael Gaiss",
      "screen_name" : "MichaelGaiss",
      "protected" : false,
      "id_str" : "14653432",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2649031049/47436efb20460e307e5ae72418f241b0_normal.png",
      "id" : 14653432,
      "verified" : false
    }
  },
  "id" : 121621104983945216,
  "created_at" : "Wed Oct 05 16:21:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "huh",
      "indices" : [ 43, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121480811550736385",
  "text" : "Wait, Samsung started as a noodle company? #huh",
  "id" : 121480811550736385,
  "created_at" : "Wed Oct 05 07:04:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121412036998606848",
  "text" : "My Lenovo X220 just up and died on me. Mobo failure. What terrible timing.",
  "id" : 121412036998606848,
  "created_at" : "Wed Oct 05 02:31:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "want",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121322858721980417",
  "text" : "Apparently Tesla model S will have a near 50/50 weight distribution. #want",
  "id" : 121322858721980417,
  "created_at" : "Tue Oct 04 20:36:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121317015834210304",
  "text" : "Checking out the Tesla recruit event at #harvard!",
  "id" : 121317015834210304,
  "created_at" : "Tue Oct 04 20:13:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121264184636874752",
  "text" : "Apparently we're getting an iPhone 4s? http://j.mp/ph5Zfs",
  "id" : 121264184636874752,
  "created_at" : "Tue Oct 04 16:43:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldtantrum",
      "indices" : [ 59, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121225634029649920",
  "text" : "if the new iPhone is Sprint exclusive I'm going to throw a #firstworldtantrum",
  "id" : 121225634029649920,
  "created_at" : "Tue Oct 04 14:10:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121132084638130176",
  "text" : "Sleeping in the Science Center tonight. Damn you, Cambridge weather.",
  "id" : 121132084638130176,
  "created_at" : "Tue Oct 04 07:58:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Anonymous",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121105834989207552",
  "text" : "Hmm, threat from #Anonymous: \"On Oct. 10, NYSE shall be erased from the Internet.\" http://j.mp/quruGf",
  "id" : 121105834989207552,
  "created_at" : "Tue Oct 04 06:14:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPhone5",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "iPhone5",
      "indices" : [ 9, 17 ]
    }, {
      "text" : "iPhone5",
      "indices" : [ 18, 26 ]
    }, {
      "text" : "iPhone5",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121093949661265920",
  "text" : "#iPhone5 #iPhone5 #iPhone5 #iPhone5",
  "id" : 121093949661265920,
  "created_at" : "Tue Oct 04 05:27:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio",
      "screen_name" : "antrod",
      "indices" : [ 0, 7 ],
      "id_str" : "464493",
      "id" : 464493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121083696353783808",
  "in_reply_to_user_id" : 464493,
  "text" : "@antrod I just bought an HP reissue of the old 15c calculator. Thought you might get a kick out of that.",
  "id" : 121083696353783808,
  "created_at" : "Tue Oct 04 04:46:17 +0000 2011",
  "in_reply_to_screen_name" : "antrod",
  "in_reply_to_user_id_str" : "464493",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121083551784501248",
  "text" : "RT @bznotes: QOTD: \"Its time to stop selling digital shovels on FB & panties on internet; & focus on real problems/opportunities around  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "121071904755953664",
    "text" : "QOTD: \"Its time to stop selling digital shovels on FB & panties on internet; & focus on real problems/opportunities around advanced energy\".",
    "id" : 121071904755953664,
    "created_at" : "Tue Oct 04 03:59:26 +0000 2011",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 121083551784501248,
  "created_at" : "Tue Oct 04 04:45:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCG_Consultant",
      "screen_name" : "BCG_Consultant",
      "indices" : [ 21, 36 ],
      "id_str" : "246368526",
      "id" : 246368526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121068116963889153",
  "text" : "Food and drinks with @BCG_Consultant leading up to interview on Wednesday. At least one allnighter between now and then. Fingers crossed.",
  "id" : 121068116963889153,
  "created_at" : "Tue Oct 04 03:44:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120924012258922497",
  "text" : "Windows Phone 7 makes up 30% of HTC sales? Say what?",
  "id" : 120924012258922497,
  "created_at" : "Mon Oct 03 18:11:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/CP9ZDem6",
      "expanded_url" : "http://bit.ly/r2B83s",
      "display_url" : "bit.ly/r2B83s"
    } ]
  },
  "geo" : {
  },
  "id_str" : "120907400550158336",
  "text" : "RT @wired: Iran taking Russia to court over scotched missile sale: http://t.co/CP9ZDem6",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http://t.co/CP9ZDem6",
        "expanded_url" : "http://bit.ly/r2B83s",
        "display_url" : "bit.ly/r2B83s"
      } ]
    },
    "geo" : {
    },
    "id_str" : "120897150203854848",
    "text" : "Iran taking Russia to court over scotched missile sale: http://t.co/CP9ZDem6",
    "id" : 120897150203854848,
    "created_at" : "Mon Oct 03 16:25:01 +0000 2011",
    "user" : {
      "name" : "Wired",
      "screen_name" : "wired",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2958887633/eab60d838d5c4bb20fa52f0577a2c698_normal.jpeg",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 120907400550158336,
  "created_at" : "Mon Oct 03 17:05:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iwantitiwantit",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120756524401438721",
  "text" : "I think the amount of fanboys trying to preorder the Metal Gear Solid RISK set is crashing the servers http://j.mp/nw6ws8 #iwantitiwantit",
  "id" : 120756524401438721,
  "created_at" : "Mon Oct 03 07:06:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 25, 37 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OptimizationNeverSleeps",
      "indices" : [ 0, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120683479087333376",
  "text" : "#OptimizationNeverSleeps @badboyboyce",
  "id" : 120683479087333376,
  "created_at" : "Mon Oct 03 02:15:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120617132567429121",
  "text" : "I want a tablet. Anyone feel strongly about Honeycomb either way?",
  "id" : 120617132567429121,
  "created_at" : "Sun Oct 02 21:52:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 3, 16 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120590309221601280",
  "text" : "RT @sunilnagaraj: People really love taking pictures of their food.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "120578682006941696",
    "text" : "People really love taking pictures of their food.",
    "id" : 120578682006941696,
    "created_at" : "Sun Oct 02 19:19:32 +0000 2011",
    "user" : {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "protected" : false,
      "id_str" : "14877810",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/285143601/sunil_march_normal.jpg",
      "id" : 14877810,
      "verified" : false
    }
  },
  "id" : 120590309221601280,
  "created_at" : "Sun Oct 02 20:05:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Liu",
      "screen_name" : "eliseliu",
      "indices" : [ 44, 53 ],
      "id_str" : "14458332",
      "id" : 14458332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "waytooexcited",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120547258675625985",
  "text" : "But iPhone 5 announcement is in 3 days!! RT @eliseliu: iphone iphone iphone iphone #waytooexcited",
  "id" : 120547258675625985,
  "created_at" : "Sun Oct 02 17:14:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lasers",
      "indices" : [ 126, 133 ]
    }, {
      "text" : "p",
      "indices" : [ 134, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120543139235766274",
  "text" : "RT @HarvardCSA: GOP candidate Michele Bachmann seems to have US-China relations confused with a Bond movie http://ow.ly/6KJOw #lasers #p ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lasers",
        "indices" : [ 110, 117 ]
      }, {
        "text" : "pewpew",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "120536049981206528",
    "text" : "GOP candidate Michele Bachmann seems to have US-China relations confused with a Bond movie http://ow.ly/6KJOw #lasers #pewpew",
    "id" : 120536049981206528,
    "created_at" : "Sun Oct 02 16:30:08 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 120543139235766274,
  "created_at" : "Sun Oct 02 16:58:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120292993944137728",
  "geo" : {
  },
  "id_str" : "120296805169770496",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj permanent end of the accelerator but analysis of its data continues.",
  "id" : 120296805169770496,
  "in_reply_to_status_id" : 120292993944137728,
  "created_at" : "Sun Oct 02 00:39:28 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 3, 16 ],
      "id_str" : "101114131",
      "id" : 101114131
    }, {
      "name" : "Kevin Lee",
      "screen_name" : "kevineriklee",
      "indices" : [ 41, 54 ],
      "id_str" : "38612181",
      "id" : 38612181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120287519580499968",
  "text" : "At @Blueasiacafe with @themonkeychow and @kevineriklee. Trying milk tea with herbal jelly. Mmm.",
  "id" : 120287519580499968,
  "created_at" : "Sun Oct 02 00:02:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tevatron",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120159326299111425",
  "geo" : {
  },
  "id_str" : "120283753737224193",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj end of operational service, apparently. Still a ton of data from #tevatron to analyze",
  "id" : 120283753737224193,
  "in_reply_to_status_id" : 120159326299111425,
  "created_at" : "Sat Oct 01 23:47:36 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120156333898080257",
  "text" : "Shuttle was grounded. Now Tevatron is closed. What a lame year for American science.",
  "id" : 120156333898080257,
  "created_at" : "Sat Oct 01 15:21:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120014731334516737",
  "text" : "I watched a Droid Bionic commercial on mute and thought it was a Michael Bay movie trailer.",
  "id" : 120014731334516737,
  "created_at" : "Sat Oct 01 05:58:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]