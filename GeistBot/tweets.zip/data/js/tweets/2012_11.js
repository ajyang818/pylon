Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 16, 23 ],
      "id_str" : "9544202",
      "id" : 9544202
    }, {
      "name" : "Lemnos Labs Inc",
      "screen_name" : "lemnoslabs",
      "indices" : [ 71, 82 ],
      "id_str" : "266116717",
      "id" : 266116717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hardware",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "IoT",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/WVS9AJOg",
      "expanded_url" : "http://hardware20.eventbrite.com/",
      "display_url" : "hardware20.eventbrite.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "274700200826793984",
  "text" : "See you there! \u201C@schlaf: If you love #hardware and #IoT you can't miss @LemnosLabs Hardware 2.0 Conference. http://t.co/WVS9AJOg\"",
  "id" : 274700200826793984,
  "created_at" : "Sat Dec 01 02:23:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/274662527093338112/photo/1",
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/WEH5K21O",
      "media_url" : "http://pbs.twimg.com/media/A8_MHPjCcAAbFHC.jpg",
      "id_str" : "274662527097532416",
      "id" : 274662527097532416,
      "media_url_https" : "https://pbs.twimg.com/media/A8_MHPjCcAAbFHC.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/WEH5K21O"
    } ],
    "hashtags" : [ {
      "text" : "loveit",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621287133, -73.9685423577 ]
  },
  "id_str" : "274662527093338112",
  "text" : "I got to visit a dog hotel as part of my job today. #loveit http://t.co/WEH5K21O",
  "id" : 274662527093338112,
  "created_at" : "Fri Nov 30 23:53:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Czaplicki",
      "screen_name" : "czaplic",
      "indices" : [ 3, 11 ],
      "id_str" : "876620772",
      "id" : 876620772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/JfSmdKfo",
      "expanded_url" : "http://news.ycombinator.com/item?id=4854052",
      "display_url" : "news.ycombinator.com/item?id=4854052"
    } ]
  },
  "geo" : {
  },
  "id_str" : "274564036639719424",
  "text" : "RT @czaplic: Just submitted  my Emerging Languages talk to HN!  http://t.co/JfSmdKfo",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http://t.co/JfSmdKfo",
        "expanded_url" : "http://news.ycombinator.com/item?id=4854052",
        "display_url" : "news.ycombinator.com/item?id=4854052"
      } ]
    },
    "geo" : {
    },
    "id_str" : "274561166930501632",
    "text" : "Just submitted  my Emerging Languages talk to HN!  http://t.co/JfSmdKfo",
    "id" : 274561166930501632,
    "created_at" : "Fri Nov 30 17:10:57 +0000 2012",
    "user" : {
      "name" : "Evan Czaplicki",
      "screen_name" : "czaplic",
      "protected" : false,
      "id_str" : "876620772",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2710444804/a339c20be895dc40205e4ef32c3c3daa_normal.jpeg",
      "id" : 876620772,
      "verified" : false
    }
  },
  "id" : 274564036639719424,
  "created_at" : "Fri Nov 30 17:22:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard GSD",
      "screen_name" : "HarvardGSD",
      "indices" : [ 17, 28 ],
      "id_str" : "19272669",
      "id" : 19272669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274562622265901056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621239432, -73.9685284867 ]
  },
  "id_str" : "274563983393030144",
  "in_reply_to_user_id" : 19272669,
  "text" : "It's ironic that @HarvardGSD's twitter profile picture is really pixelated.",
  "id" : 274563983393030144,
  "in_reply_to_status_id" : 274562622265901056,
  "created_at" : "Fri Nov 30 17:22:09 +0000 2012",
  "in_reply_to_screen_name" : "HarvardGSD",
  "in_reply_to_user_id_str" : "19272669",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/274553657662525441/photo/1",
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/e3M73Iua",
      "media_url" : "http://pbs.twimg.com/media/A89pGNVCUAAe6GZ.jpg",
      "id_str" : "274553657670914048",
      "id" : 274553657670914048,
      "media_url_https" : "https://pbs.twimg.com/media/A89pGNVCUAAe6GZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/e3M73Iua"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7622380017, -73.9686646643 ]
  },
  "id_str" : "274553657662525441",
  "text" : "It's official. I've found the most boring food in the world. http://t.co/e3M73Iua",
  "id" : 274553657662525441,
  "created_at" : "Fri Nov 30 16:41:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Yu",
      "screen_name" : "Intenex",
      "indices" : [ 0, 8 ],
      "id_str" : "195474206",
      "id" : 195474206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/hG8CXpmI",
      "expanded_url" : "http://doomsday.info",
      "display_url" : "doomsday.info"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621350813, -73.968541448 ]
  },
  "id_str" : "274544606350278656",
  "in_reply_to_user_id" : 195474206,
  "text" : "@Intenex idea: http://t.co/hG8CXpmI - analog backups (tape, paper) of all your data! For the super paranoid.",
  "id" : 274544606350278656,
  "created_at" : "Fri Nov 30 16:05:09 +0000 2012",
  "in_reply_to_screen_name" : "Intenex",
  "in_reply_to_user_id_str" : "195474206",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 24, 34 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/DobXKzgg",
      "expanded_url" : "http://igg.me/p/281621/cstw/1835928",
      "display_url" : "igg.me/p/281621/cstw/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "274543294963400705",
  "text" : "I just backed moj.io on @indiegogo! http://t.co/DobXKzgg",
  "id" : 274543294963400705,
  "created_at" : "Fri Nov 30 15:59:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.762128697, -73.9685385956 ]
  },
  "id_str" : "274533922132590593",
  "text" : "Spin on Nigerian 419 in inbox: Cpl. John Adams found $11M in Libya and needs my help evacuating it. For AMERICA. And profit.",
  "id" : 274533922132590593,
  "created_at" : "Fri Nov 30 15:22:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Wu",
      "screen_name" : "thevickywu",
      "indices" : [ 0, 11 ],
      "id_str" : "525310501",
      "id" : 525310501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274529310700879872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621182111, -73.9685290649 ]
  },
  "id_str" : "274532140065095681",
  "in_reply_to_user_id" : 525310501,
  "text" : "@thevickywu fair point. But heuristics have their use! Heteronormativity =/= intolerance, unforch people are often both.",
  "id" : 274532140065095681,
  "in_reply_to_status_id" : 274529310700879872,
  "created_at" : "Fri Nov 30 15:15:37 +0000 2012",
  "in_reply_to_screen_name" : "thevickywu",
  "in_reply_to_user_id_str" : "525310501",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Wu",
      "screen_name" : "thevickywu",
      "indices" : [ 0, 11 ],
      "id_str" : "525310501",
      "id" : 525310501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274495189253492736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621691925, -73.9685690196 ]
  },
  "id_str" : "274529049471234050",
  "in_reply_to_user_id" : 525310501,
  "text" : "@thevickywu heteronormativity can be a useful albeit lazy heuristic. Kind of like industrial designers assuming everyone is right handed.",
  "id" : 274529049471234050,
  "in_reply_to_status_id" : 274495189253492736,
  "created_at" : "Fri Nov 30 15:03:20 +0000 2012",
  "in_reply_to_screen_name" : "thevickywu",
  "in_reply_to_user_id_str" : "525310501",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "indices" : [ 52, 62 ],
      "id_str" : "5668942",
      "id" : 5668942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/9GJAsMwQ",
      "expanded_url" : "http://www.smbc-comics.com/index.php?db=comics&id=1898#comic",
      "display_url" : "smbc-comics.com/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7553876342, -73.9831390451 ]
  },
  "id_str" : "274309996563550209",
  "text" : "Reminds me of the SMBC comic. http://t.co/9GJAsMwQ \u201C@sarahcuda: problem is YOU DON'T SHOW THE VALLEY OR REAL ENTREPRENEURS AT ALL.\"",
  "id" : 274309996563550209,
  "created_at" : "Fri Nov 30 00:32:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perfect Menu",
      "screen_name" : "perfectmenuapp",
      "indices" : [ 0, 15 ],
      "id_str" : "952991119",
      "id" : 952991119
    }, {
      "name" : "Kiwiana Restaurant",
      "screen_name" : "KiwianaNYC",
      "indices" : [ 39, 50 ],
      "id_str" : "311728535",
      "id" : 311728535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274295660751224832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7552109845, -73.98309912 ]
  },
  "id_str" : "274304729482424320",
  "in_reply_to_user_id" : 952991119,
  "text" : "@perfectmenuapp Great! Just registered @kiwiananyc. Nice patch response time :)",
  "id" : 274304729482424320,
  "in_reply_to_status_id" : 274295660751224832,
  "created_at" : "Fri Nov 30 00:11:58 +0000 2012",
  "in_reply_to_screen_name" : "perfectmenuapp",
  "in_reply_to_user_id_str" : "952991119",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perfect Menu",
      "screen_name" : "perfectmenuapp",
      "indices" : [ 4, 19 ],
      "id_str" : "952991119",
      "id" : 952991119
    }, {
      "name" : "Kiwiana Restaurant",
      "screen_name" : "KiwianaNYC",
      "indices" : [ 50, 61 ],
      "id_str" : "311728535",
      "id" : 311728535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274292840333455360",
  "text" : "Hey @PerfectMenuApp, considered deploying you for @KiwianaNYC, but your site login is unsecured!",
  "id" : 274292840333455360,
  "created_at" : "Thu Nov 29 23:24:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621317385, -73.9685379205 ]
  },
  "id_str" : "274273552818122752",
  "text" : "Any note taking app I use invariably turns into a list of books I want to read.",
  "id" : 274273552818122752,
  "created_at" : "Thu Nov 29 22:08:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Aoun",
      "screen_name" : "adrianaoun",
      "indices" : [ 0, 11 ],
      "id_str" : "74832539",
      "id" : 74832539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7620816662, -73.9684802962 ]
  },
  "id_str" : "274234524286726144",
  "in_reply_to_user_id" : 74832539,
  "text" : "@adrianaoun not a bad guess, but Chens are going to have a bad time!",
  "id" : 274234524286726144,
  "created_at" : "Thu Nov 29 19:33:00 +0000 2012",
  "in_reply_to_screen_name" : "adrianaoun",
  "in_reply_to_user_id_str" : "74832539",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wavii",
      "screen_name" : "wavii",
      "indices" : [ 7, 13 ],
      "id_str" : "21543692",
      "id" : 21543692
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/274231265971023872/photo/1",
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/xjju8V68",
      "media_url" : "http://pbs.twimg.com/media/A85D4isCMAAgcq0.jpg",
      "id_str" : "274231265979412480",
      "id" : 274231265979412480,
      "media_url_https" : "https://pbs.twimg.com/media/A85D4isCMAAgcq0.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/xjju8V68"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621449176, -73.9685501161 ]
  },
  "id_str" : "274231265971023872",
  "text" : "Protip @wavii: assuming contacts w same past name are family doesn't really work with Asians. http://t.co/xjju8V68",
  "id" : 274231265971023872,
  "created_at" : "Thu Nov 29 19:20:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/WDjw07Pm",
      "expanded_url" : "http://www.dpreview.com/news/2012/11/28/michael-woodford-interview-in-amateur-photographer-magazine",
      "display_url" : "dpreview.com/news/2012/11/2\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "274166876920229888",
  "text" : "Inspiring: Olympus CEO fired for whistleblowing donating unfair-dismissal awards to charity. http://t.co/WDjw07Pm",
  "id" : 274166876920229888,
  "created_at" : "Thu Nov 29 15:04:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 3, 14 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/ugCPPJwy",
      "expanded_url" : "http://nyti.ms/QrtV1q",
      "display_url" : "nyti.ms/QrtV1q"
    } ]
  },
  "geo" : {
  },
  "id_str" : "274013893049868288",
  "text" : "RT @nickbilton: Photo of NYPD Officer giving boots to barefoot homeless man warms hearts all over Web: http://t.co/ugCPPJwy",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http://t.co/ugCPPJwy",
        "expanded_url" : "http://nyti.ms/QrtV1q",
        "display_url" : "nyti.ms/QrtV1q"
      } ]
    },
    "geo" : {
    },
    "id_str" : "274011286126346240",
    "text" : "Photo of NYPD Officer giving boots to barefoot homeless man warms hearts all over Web: http://t.co/ugCPPJwy",
    "id" : 274011286126346240,
    "created_at" : "Thu Nov 29 04:45:56 +0000 2012",
    "user" : {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "protected" : false,
      "id_str" : "1586501",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3004953754/981f9dceb963d56f998e557e81e4115f_normal.jpeg",
      "id" : 1586501,
      "verified" : true
    }
  },
  "id" : 274013893049868288,
  "created_at" : "Thu Nov 29 04:56:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274000190443237377",
  "text" : "RT @bznotes: Somebody told me tech bloggers pen 5-7 stories a day. Seriously? Finally I found a group of people with more ADD than VCs.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "273995009819279363",
    "text" : "Somebody told me tech bloggers pen 5-7 stories a day. Seriously? Finally I found a group of people with more ADD than VCs.",
    "id" : 273995009819279363,
    "created_at" : "Thu Nov 29 03:41:15 +0000 2012",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 274000190443237377,
  "created_at" : "Thu Nov 29 04:01:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 19, 30 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/edCExZFE",
      "expanded_url" : "http://ow.ly/fDMc3",
      "display_url" : "ow.ly/fDMc3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7513709145, -73.9672423366 ]
  },
  "id_str" : "273851375119638528",
  "text" : "\"U studying ;)\" RT @thecrimson: Harvard psych prof conducting study on how best to motivate children via text msgs. http://t.co/edCExZFE",
  "id" : 273851375119638528,
  "created_at" : "Wed Nov 28 18:10:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/273848519016738817/photo/1",
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/xVHJi2cE",
      "media_url" : "http://pbs.twimg.com/media/A8znxvLCcAAtpZO.jpg",
      "id_str" : "273848519025127424",
      "id" : 273848519025127424,
      "media_url_https" : "https://pbs.twimg.com/media/A8znxvLCcAAtpZO.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/xVHJi2cE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7513628407, -73.9672377505 ]
  },
  "id_str" : "273848519016738817",
  "text" : "Ban Ki Moon and Indian UN mission unveil the $35 Aakash 2 tablet. Mind blowing cost-engineering project. http://t.co/xVHJi2cE",
  "id" : 273848519016738817,
  "created_at" : "Wed Nov 28 17:59:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621081329, -73.9685093701 ]
  },
  "id_str" : "273799932404703233",
  "text" : "I wonder if there's a stock library of footage of smart looking people soldering things that all these Kickstarter videos are using.",
  "id" : 273799932404703233,
  "created_at" : "Wed Nov 28 14:46:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/gyBR4lLz",
      "expanded_url" : "http://www.wired.com/dangerroom/2012/11/zhuhai",
      "display_url" : "wired.com/dangerroom/201\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "273561762157174784",
  "text" : "The Wing Loong drone looks like a Reaper, but costs 1/30th. China's certainly progressed from just copying handbags. http://t.co/gyBR4lLz",
  "id" : 273561762157174784,
  "created_at" : "Tue Nov 27 22:59:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 3, 15 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/PmobQSOx",
      "expanded_url" : "http://lil.lu/U0Xlzd",
      "display_url" : "lil.lu/U0Xlzd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "273462621351575552",
  "text" : "RT @christinelu: China's Official People\u2019s Daily Quotes the Onion: Kim Jong Eun \u2018Sexiest Man Alive\u2019 [WSJ] -- LOL http://t.co/PmobQSOx",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http://t.co/PmobQSOx",
        "expanded_url" : "http://lil.lu/U0Xlzd",
        "display_url" : "lil.lu/U0Xlzd"
      } ]
    },
    "geo" : {
    },
    "id_str" : "273461581722038272",
    "text" : "China's Official People\u2019s Daily Quotes the Onion: Kim Jong Eun \u2018Sexiest Man Alive\u2019 [WSJ] -- LOL http://t.co/PmobQSOx",
    "id" : 273461581722038272,
    "created_at" : "Tue Nov 27 16:21:36 +0000 2012",
    "user" : {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "protected" : false,
      "id_str" : "7782442",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3450541400/337b7b26ba5560ad0bd34ff4cfd4f160_normal.jpeg",
      "id" : 7782442,
      "verified" : false
    }
  },
  "id" : 273462621351575552,
  "created_at" : "Tue Nov 27 16:25:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 0, 7 ],
      "id_str" : "224321197",
      "id" : 224321197
    }, {
      "name" : "Perry Hewitt",
      "screen_name" : "perryhewitt",
      "indices" : [ 8, 20 ],
      "id_str" : "1363481",
      "id" : 1363481
    }, {
      "name" : "PSY",
      "screen_name" : "psy_oppa",
      "indices" : [ 42, 51 ],
      "id_str" : "740216334",
      "id" : 740216334
    }, {
      "name" : "TEDTalks Updates",
      "screen_name" : "tedtalks",
      "indices" : [ 61, 70 ],
      "id_str" : "15492359",
      "id" : 15492359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272734402017124353",
  "geo" : {
  },
  "id_str" : "273085280918056961",
  "in_reply_to_user_id" : 224321197,
  "text" : "@zhamed @perryhewitt better yet just have @psy_oppa speak at @TEDtalks",
  "id" : 273085280918056961,
  "in_reply_to_status_id" : 272734402017124353,
  "created_at" : "Mon Nov 26 15:26:19 +0000 2012",
  "in_reply_to_screen_name" : "zhamed",
  "in_reply_to_user_id_str" : "224321197",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HN from Y Combinator",
      "screen_name" : "hnycombinator",
      "indices" : [ 40, 54 ],
      "id_str" : "15042473",
      "id" : 15042473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/t53Y7UTB",
      "expanded_url" : "http://goo.gl/fb/cLpeJ",
      "display_url" : "goo.gl/fb/cLpeJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9363033963, -78.7299412536 ]
  },
  "id_str" : "272666121918881792",
  "text" : "Fascinating discussion on Hacker News. \u201C@hnycombinator: Know of a Hacker in Cambridge who wants a bookstore? http://t.co/t53Y7UTB\u201D",
  "id" : 272666121918881792,
  "created_at" : "Sun Nov 25 11:40:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Wang",
      "screen_name" : "aaronwngxcalhs",
      "indices" : [ 3, 18 ],
      "id_str" : "240994166",
      "id" : 240994166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RedDawn",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "272664448857169920",
  "text" : "RT @aaronwngxcalhs: #RedDawn made you hate Asians you say? And I have to protect \"your\" freedom. -sigh-",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RedDawn",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "272517224298844160",
    "text" : "#RedDawn made you hate Asians you say? And I have to protect \"your\" freedom. -sigh-",
    "id" : 272517224298844160,
    "created_at" : "Sun Nov 25 01:49:04 +0000 2012",
    "user" : {
      "name" : "Aaron Wang",
      "screen_name" : "aaronwngxcalhs",
      "protected" : false,
      "id_str" : "240994166",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3408079180/e4cb34ab3d4c2d25b2850e56fe23f5ff_normal.jpeg",
      "id" : 240994166,
      "verified" : false
    }
  },
  "id" : 272664448857169920,
  "created_at" : "Sun Nov 25 11:34:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/272399446975868928/photo/1",
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/tuVKdNmG",
      "media_url" : "http://pbs.twimg.com/media/A8fB2pJCcAE5ioB.jpg",
      "id_str" : "272399446980063233",
      "id" : 272399446980063233,
      "media_url_https" : "https://pbs.twimg.com/media/A8fB2pJCcAE5ioB.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/tuVKdNmG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9717819403, -78.6935380087 ]
  },
  "id_str" : "272399446975868928",
  "text" : "You know you're in Buffalo when... http://t.co/tuVKdNmG",
  "id" : 272399446975868928,
  "created_at" : "Sat Nov 24 18:01:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0069920382, -78.7001346501 ]
  },
  "id_str" : "272370474300874753",
  "text" : "Gangnam style is now the most viewed video in history with 801M views. For reference, ALL of TED only has 1B views total.",
  "id" : 272370474300874753,
  "created_at" : "Sat Nov 24 16:05:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your in America Bot",
      "screen_name" : "YourInAmerica",
      "indices" : [ 30, 44 ],
      "id_str" : "517110438",
      "id" : 517110438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272149733835943936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.006566411, -78.6999118898 ]
  },
  "id_str" : "272151215368982528",
  "in_reply_to_user_id" : 517110438,
  "text" : "Loving the delicious irony of @YourInAmerica",
  "id" : 272151215368982528,
  "in_reply_to_status_id" : 272149733835943936,
  "created_at" : "Sat Nov 24 01:34:40 +0000 2012",
  "in_reply_to_screen_name" : "YourInAmerica",
  "in_reply_to_user_id_str" : "517110438",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0069775001, -78.6998720715 ]
  },
  "id_str" : "272052180566020097",
  "text" : "Instagram needs an option to filter selfies and food from the feed.",
  "id" : 272052180566020097,
  "created_at" : "Fri Nov 23 19:01:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen O'Brien",
      "screen_name" : "colleenobrien",
      "indices" : [ 0, 14 ],
      "id_str" : "14078449",
      "id" : 14078449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272026920240173057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0070304505, -78.6998417793 ]
  },
  "id_str" : "272050388520275968",
  "in_reply_to_user_id" : 14078449,
  "text" : "@colleenobrien nothing, just went for the chaos!",
  "id" : 272050388520275968,
  "in_reply_to_status_id" : 272026920240173057,
  "created_at" : "Fri Nov 23 18:54:01 +0000 2012",
  "in_reply_to_screen_name" : "colleenobrien",
  "in_reply_to_user_id_str" : "14078449",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 3, 19 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "272016630656147456",
  "text" : "RT @GlobalAsianista: In the spirit of Black Friday I write about a \"bizarre North Korean documentary\" on the consumer slaves of the West ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/cEFgoAr2",
        "expanded_url" : "http://globalasianculture.com/2012/north-korea-talks-consumer-slaves/",
        "display_url" : "globalasianculture.com/2012/north-kor\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "272005706322935808",
    "text" : "In the spirit of Black Friday I write about a \"bizarre North Korean documentary\" on the consumer slaves of the West: http://t.co/cEFgoAr2",
    "id" : 272005706322935808,
    "created_at" : "Fri Nov 23 15:56:28 +0000 2012",
    "user" : {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "protected" : false,
      "id_str" : "228489296",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1479092871/Twitter4_normal.jpg",
      "id" : 228489296,
      "verified" : false
    }
  },
  "id" : 272016630656147456,
  "created_at" : "Fri Nov 23 16:39:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/271843331397533696/photo/1",
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/suK4a8aW",
      "media_url" : "http://pbs.twimg.com/media/A8XIEdLCQAEc7Sr.jpg",
      "id_str" : "271843331401728001",
      "id" : 271843331401728001,
      "media_url_https" : "https://pbs.twimg.com/media/A8XIEdLCQAEc7Sr.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com/suK4a8aW"
    } ],
    "hashtags" : [ {
      "text" : "Murrica",
      "indices" : [ 27, 35 ]
    }, {
      "text" : "BlackFriday",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "271843331397533696",
  "text" : "A fine American tradition. #Murrica #BlackFriday. http://t.co/suK4a8aW",
  "id" : 271843331397533696,
  "created_at" : "Fri Nov 23 05:11:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "indices" : [ 52, 61 ],
      "id_str" : "237573925",
      "id" : 237573925
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/271779395692265472/photo/1",
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/nYiBJGba",
      "media_url" : "http://pbs.twimg.com/media/A8WN66ICAAEHgpa.jpg",
      "id_str" : "271779395700654081",
      "id" : 271779395700654081,
      "media_url_https" : "https://pbs.twimg.com/media/A8WN66ICAAEHgpa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/nYiBJGba"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9949786275, -78.6865283806 ]
  },
  "id_str" : "271779395692265472",
  "text" : "Happy grumpy thanksgiving from the Hsieh household! @touhsieh http://t.co/nYiBJGba",
  "id" : 271779395692265472,
  "created_at" : "Fri Nov 23 00:57:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 3, 9 ],
      "id_str" : "17856596",
      "id" : 17856596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "271447009041477632",
  "text" : "RT @Wayne: Everyone in Boston wanted to build the uncool, so went enterprise. Now it's cool, so of course seeing more consumer tech now. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "contrarian",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "271415596858634240",
    "text" : "Everyone in Boston wanted to build the uncool, so went enterprise. Now it's cool, so of course seeing more consumer tech now. #contrarian",
    "id" : 271415596858634240,
    "created_at" : "Thu Nov 22 00:51:35 +0000 2012",
    "user" : {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "protected" : false,
      "id_str" : "17856596",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3472053434/8cecfad95a11c1f1ede129b33c0b4fef_normal.jpeg",
      "id" : 17856596,
      "verified" : false
    }
  },
  "id" : 271447009041477632,
  "created_at" : "Thu Nov 22 02:56:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "indices" : [ 1, 10 ],
      "id_str" : "237573925",
      "id" : 237573925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffaloprobs",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271350974537428992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.762096306, -73.9685056328 ]
  },
  "id_str" : "271358491027984384",
  "in_reply_to_user_id" : 237573925,
  "text" : "\"@touhsieh: You know you're back in Buffalo when you go to Wegmans and it turns out to be a high school reunion #buffaloprobs\"",
  "id" : 271358491027984384,
  "in_reply_to_status_id" : 271350974537428992,
  "created_at" : "Wed Nov 21 21:04:40 +0000 2012",
  "in_reply_to_screen_name" : "touhsieh",
  "in_reply_to_user_id_str" : "237573925",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/ETSSN6Q6",
      "expanded_url" : "http://manualdesigns.bigcartel.com/",
      "display_url" : "manualdesigns.bigcartel.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "271265512527380480",
  "text" : "Drooling over Manual Designs' classic M-power prints. http://t.co/ETSSN6Q6",
  "id" : 271265512527380480,
  "created_at" : "Wed Nov 21 14:55:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271107195343626240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104207607, -74.0065006719 ]
  },
  "id_str" : "271107626245451776",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick different use cases; Reeder fills in for the lack of an official Google Reader iOS app.",
  "id" : 271107626245451776,
  "in_reply_to_status_id" : 271107195343626240,
  "created_at" : "Wed Nov 21 04:27:49 +0000 2012",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271082099451248641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7493403633, -73.9838617549 ]
  },
  "id_str" : "271101045168537600",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick Reeder and Evernote for content consumption and creation, respectively.",
  "id" : 271101045168537600,
  "in_reply_to_status_id" : 271082099451248641,
  "created_at" : "Wed Nov 21 04:01:40 +0000 2012",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7557234642, -73.9792987914 ]
  },
  "id_str" : "271100138641035264",
  "text" : "Sina Weibo's registration process is different than it was a month ago. I'm unable to register an overseas account now.",
  "id" : 271100138641035264,
  "created_at" : "Wed Nov 21 03:58:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "271059338905399296",
  "text" : "Getting a haircut in Chinatown is my quarterly Mandarin stress test.",
  "id" : 271059338905399296,
  "created_at" : "Wed Nov 21 01:15:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7625022391, -73.9686429129 ]
  },
  "id_str" : "271027052642177024",
  "text" : "Immigration is broken. My taxi driver explained Navier-Stokes eqtn to me. He can't get hired as engineer, drives to feed fam.",
  "id" : 271027052642177024,
  "created_at" : "Tue Nov 20 23:07:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 25, 38 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.775287617, -73.9607213438 ]
  },
  "id_str" : "270960104470355968",
  "text" : "Why assume we own cars? \u201C@sunilnagaraj: What is the name of the service that will drive you and your car home at the end of the night?\u201D",
  "id" : 270960104470355968,
  "created_at" : "Tue Nov 20 18:41:37 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7091346776, -74.0065649658 ]
  },
  "id_str" : "270700063427272704",
  "text" : "Knowledge teaches one to doubt; unfortunately this means that the ignorant are often confident while the intelligent self-doubt.",
  "id" : 270700063427272704,
  "created_at" : "Tue Nov 20 01:28:19 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3696247833, -71.1170240943 ]
  },
  "id_str" : "270197264549572609",
  "text" : "Trying to set up a Weibo account. Flagged as \"security problem\" because I didn't specify oversea status. Limited access. Oops.",
  "id" : 270197264549572609,
  "created_at" : "Sun Nov 18 16:10:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Klein",
      "screen_name" : "zachklein",
      "indices" : [ 3, 13 ],
      "id_str" : "11969",
      "id" : 11969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269894604998987776",
  "text" : "RT @zachklein: During the NHL lockout, the Buffalo Sabes launched Sabres Univ. Employees are paid to teach each other their skills.  htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/IP7K9yDy",
        "expanded_url" : "http://espn.go.com/nhl/story/_/id/8639544/nhl-buffalo-sabres-use-lockout-enrich-staff",
        "display_url" : "espn.go.com/nhl/story/_/id\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "269625759604285440",
    "text" : "During the NHL lockout, the Buffalo Sabes launched Sabres Univ. Employees are paid to teach each other their skills.  http://t.co/IP7K9yDy",
    "id" : 269625759604285440,
    "created_at" : "Sat Nov 17 02:19:25 +0000 2012",
    "user" : {
      "name" : "Zach Klein",
      "screen_name" : "zachklein",
      "protected" : false,
      "id_str" : "11969",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2811796449/fc89959fc8a6531f0f769203a68a2552_normal.jpeg",
      "id" : 11969,
      "verified" : false
    }
  },
  "id" : 269894604998987776,
  "created_at" : "Sat Nov 17 20:07:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Brichter",
      "screen_name" : "lorenb",
      "indices" : [ 13, 20 ],
      "id_str" : "9943672",
      "id" : 9943672
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/269878105517199362/photo/1",
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/4uA5n3ZE",
      "media_url" : "http://pbs.twimg.com/media/A77MtQRCEAAPb4l.jpg",
      "id_str" : "269878105521393664",
      "id" : 269878105521393664,
      "media_url_https" : "https://pbs.twimg.com/media/A77MtQRCEAAPb4l.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/4uA5n3ZE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3529092546, -71.1307544893 ]
  },
  "id_str" : "269878105517199362",
  "text" : "Letterpress' @lorenb writes the best software changelogs. http://t.co/4uA5n3ZE",
  "id" : 269878105517199362,
  "created_at" : "Sat Nov 17 19:02:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 3, 9 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269862682834915330",
  "text" : "RT @sacca: Waiting for a lull in global war and famine so that I won't sound insensitive when bitching about there being no hockey.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "269610365107712000",
    "text" : "Waiting for a lull in global war and famine so that I won't sound insensitive when bitching about there being no hockey.",
    "id" : 269610365107712000,
    "created_at" : "Sat Nov 17 01:18:14 +0000 2012",
    "user" : {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "protected" : false,
      "id_str" : "586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1771648774/Sacca_profile_normal.jpg",
      "id" : 586,
      "verified" : true
    }
  },
  "id" : 269862682834915330,
  "created_at" : "Sat Nov 17 18:00:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tim leong",
      "screen_name" : "timleong",
      "indices" : [ 3, 12 ],
      "id_str" : "20487008",
      "id" : 20487008
    }, {
      "name" : "Scott Dadich",
      "screen_name" : "sdadich",
      "indices" : [ 26, 34 ],
      "id_str" : "4310571",
      "id" : 4310571
    }, {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 63, 69 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269628909119754240",
  "text" : "RT @timleong: Congrats to @sdadich, the new Editor in Chief of @wired!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Dadich",
        "screen_name" : "sdadich",
        "indices" : [ 12, 20 ],
        "id_str" : "4310571",
        "id" : 4310571
      }, {
        "name" : "Wired",
        "screen_name" : "wired",
        "indices" : [ 49, 55 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "269515300322557952",
    "text" : "Congrats to @sdadich, the new Editor in Chief of @wired!",
    "id" : 269515300322557952,
    "created_at" : "Fri Nov 16 19:00:29 +0000 2012",
    "user" : {
      "name" : "tim leong",
      "screen_name" : "timleong",
      "protected" : false,
      "id_str" : "20487008",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1472083176/twitter3_normal.jpg",
      "id" : 20487008,
      "verified" : false
    }
  },
  "id" : 269628909119754240,
  "created_at" : "Sat Nov 17 02:31:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/269483515983327233/photo/1",
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/wEKVwFj6",
      "media_url" : "http://pbs.twimg.com/media/A71l1HtCcAIv6Ez.jpg",
      "id_str" : "269483515987521538",
      "id" : 269483515987521538,
      "media_url_https" : "https://pbs.twimg.com/media/A71l1HtCcAIv6Ez.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/wEKVwFj6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3794718017, -71.1163547076 ]
  },
  "id_str" : "269483515983327233",
  "text" : "This DeltaVision brochure has a screen and speakers... http://t.co/wEKVwFj6",
  "id" : 269483515983327233,
  "created_at" : "Fri Nov 16 16:54:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 13, 21 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3779671826, -71.117077712 ]
  },
  "id_str" : "269116908538830848",
  "text" : "According to @timehop, two years ago I was super excited about the Blackberry Storm 2.",
  "id" : 269116908538830848,
  "created_at" : "Thu Nov 15 16:37:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Brichter",
      "screen_name" : "lorenb",
      "indices" : [ 3, 10 ],
      "id_str" : "9943672",
      "id" : 9943672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269102587750522880",
  "text" : "RT @lorenb: All I want for my birthday is for Letterpress 1.1 to get approved.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "269079008254251008",
    "text" : "All I want for my birthday is for Letterpress 1.1 to get approved.",
    "id" : 269079008254251008,
    "created_at" : "Thu Nov 15 14:06:49 +0000 2012",
    "user" : {
      "name" : "Loren Brichter",
      "screen_name" : "lorenb",
      "protected" : false,
      "id_str" : "9943672",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1054030005/hello_normal.png",
      "id" : 9943672,
      "verified" : false
    }
  },
  "id" : 269102587750522880,
  "created_at" : "Thu Nov 15 15:40:31 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/268844232498884608/photo/1",
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/BcnaDnvk",
      "media_url" : "http://pbs.twimg.com/media/A7sgZ7JCMAEyWo-.jpg",
      "id_str" : "268844232503078913",
      "id" : 268844232503078913,
      "media_url_https" : "https://pbs.twimg.com/media/A7sgZ7JCMAEyWo-.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/BcnaDnvk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "268844232498884608",
  "text" : "Only at tech events is there a line at the men's bathroom. http://t.co/BcnaDnvk",
  "id" : 268844232498884608,
  "created_at" : "Wed Nov 14 22:33:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "techstars",
      "screen_name" : "techstars",
      "indices" : [ 18, 28 ],
      "id_str" : "14277276",
      "id" : 14277276
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/268835273293574145/photo/1",
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/MgjfU02y",
      "media_url" : "http://pbs.twimg.com/media/A7sYQbgCMAA9BRU.jpg",
      "id_str" : "268835273297768448",
      "id" : 268835273297768448,
      "media_url_https" : "https://pbs.twimg.com/media/A7sYQbgCMAA9BRU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/MgjfU02y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3500115553, -71.0658366691 ]
  },
  "id_str" : "268835273293574145",
  "text" : "First sex joke of @techstars demo day. http://t.co/MgjfU02y",
  "id" : 268835273293574145,
  "created_at" : "Wed Nov 14 21:58:19 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/AwJL0kbc",
      "expanded_url" : "http://www.nytimes.com/2012/11/14/dining/reviews/restaurant-review-guys-american-kitchen-bar-in-times-square.html",
      "display_url" : "nytimes.com/2012/11/14/din\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "268784174868074496",
  "text" : "Pete Wells unloads on Guy Fieri's new restaurant. Cringe- and chuckle-worthy. http://t.co/AwJL0kbc",
  "id" : 268784174868074496,
  "created_at" : "Wed Nov 14 18:35:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "techstars",
      "screen_name" : "techstars",
      "indices" : [ 45, 55 ],
      "id_str" : "14277276",
      "id" : 14277276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3734464031, -71.1207632349 ]
  },
  "id_str" : "268752750509178880",
  "text" : "I love demo days. T-minus 4 hours for Boston @techstars to start.",
  "id" : 268752750509178880,
  "created_at" : "Wed Nov 14 16:30:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kim",
      "screen_name" : "pushingatoms",
      "indices" : [ 0, 13 ],
      "id_str" : "19954028",
      "id" : 19954028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268634582981701632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.6400409993, -73.7877336983 ]
  },
  "id_str" : "268706116731559936",
  "in_reply_to_user_id" : 19954028,
  "text" : "@pushingatoms a giant touchscreen in the dash is a terrible idea. Have to look away from road to do anything. No controls to feel for.",
  "id" : 268706116731559936,
  "in_reply_to_status_id" : 268634582981701632,
  "created_at" : "Wed Nov 14 13:25:05 +0000 2012",
  "in_reply_to_screen_name" : "pushingatoms",
  "in_reply_to_user_id_str" : "19954028",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 66, 78 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Jeff Solnet",
      "screen_name" : "jfsolnet",
      "indices" : [ 79, 88 ],
      "id_str" : "24945651",
      "id" : 24945651
    }, {
      "name" : "Danny B.",
      "screen_name" : "dpbicknell",
      "indices" : [ 89, 100 ],
      "id_str" : "88327007",
      "id" : 88327007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268621214682083328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.6401010923, -73.7877226688 ]
  },
  "id_str" : "268705767367012352",
  "in_reply_to_user_id" : 110823121,
  "text" : "Romotive switched from Asana to Trello for project management. cc @badboyboyce @jfsolnet @dpbicknell",
  "id" : 268705767367012352,
  "in_reply_to_status_id" : 268621214682083328,
  "created_at" : "Wed Nov 14 13:23:41 +0000 2012",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "268684086502125568",
  "text" : "RT @TheEconomist: Chinese auction houses have emerged as big players, accounting for around 40% of global auction turnover http://t.co/9 ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http://t.co/9A2Jp5zU",
        "expanded_url" : "http://econ.st/TXZD6H",
        "display_url" : "econ.st/TXZD6H"
      } ]
    },
    "geo" : {
    },
    "id_str" : "268566233039900672",
    "text" : "Chinese auction houses have emerged as big players, accounting for around 40% of global auction turnover http://t.co/9A2Jp5zU",
    "id" : 268566233039900672,
    "created_at" : "Wed Nov 14 04:09:14 +0000 2012",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 268684086502125568,
  "created_at" : "Wed Nov 14 11:57:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blackberryideas",
      "screen_name" : "blackberryideas",
      "indices" : [ 50, 66 ],
      "id_str" : "1032836058",
      "id" : 1032836058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "268119302593470464",
  "text" : "It's like kicking someone while they're down, but @blackberryideas is hilarious.",
  "id" : 268119302593470464,
  "created_at" : "Mon Nov 12 22:33:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621685943, -73.968663366 ]
  },
  "id_str" : "268114814218428416",
  "text" : "RSS is inherently chronological and not ideal for socially ranked feeds such as Hacker News and Reddit. Any tools solve this problem?",
  "id" : 268114814218428416,
  "created_at" : "Mon Nov 12 22:15:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621051743, -73.9684592822 ]
  },
  "id_str" : "268083821826670592",
  "text" : "RIM says BB10 has \"cutting edge multimedia\" capabilities. The two remaining self-identified \"multimedia\" fans cheer.",
  "id" : 268083821826670592,
  "created_at" : "Mon Nov 12 20:12:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/267849328167616512/photo/1",
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/vnfu9uTV",
      "media_url" : "http://pbs.twimg.com/media/A7eXi3sCAAEd5lc.jpg",
      "id_str" : "267849328171810817",
      "id" : 267849328171810817,
      "media_url_https" : "https://pbs.twimg.com/media/A7eXi3sCAAEd5lc.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/vnfu9uTV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104645336, -74.0063223045 ]
  },
  "id_str" : "267849328167616512",
  "text" : "Got one of the last production batches of Buckyballs. RIP, Buckyballs. http://t.co/vnfu9uTV",
  "id" : 267849328167616512,
  "created_at" : "Mon Nov 12 04:40:31 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104971268, -74.0063548747 ]
  },
  "id_str" : "267418518927060992",
  "text" : "Halo 4 = Prometheus + Final Fantasy + Rambo",
  "id" : 267418518927060992,
  "created_at" : "Sun Nov 11 00:08:37 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Liang",
      "screen_name" : "daveliang",
      "indices" : [ 0, 10 ],
      "id_str" : "20615976",
      "id" : 20615976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267281665490051072",
  "geo" : {
  },
  "id_str" : "267374529511317504",
  "in_reply_to_user_id" : 20615976,
  "text" : "@daveliang it's killing me, but I can't recall the title. Instrumentals play for about 20 seconds, no vocals.",
  "id" : 267374529511317504,
  "in_reply_to_status_id" : 267281665490051072,
  "created_at" : "Sat Nov 10 21:13:50 +0000 2012",
  "in_reply_to_screen_name" : "daveliang",
  "in_reply_to_user_id_str" : "20615976",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "267374309843017729",
  "text" : "The hacking scene of Skyfall sounded like a writer tried to include all the cool sounding words from a comp sci textbook into a monologue.",
  "id" : 267374309843017729,
  "created_at" : "Sat Nov 10 21:12:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Liang",
      "screen_name" : "daveliang",
      "indices" : [ 95, 105 ],
      "id_str" : "20615976",
      "id" : 20615976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7423605182, -73.9774014652 ]
  },
  "id_str" : "267145253318975488",
  "text" : "Overheard: The Shanghai Restoration Project plays in the Macau scene of James Bond Skyfall. cc @daveliang",
  "id" : 267145253318975488,
  "created_at" : "Sat Nov 10 06:02:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7620973817, -73.9685026291 ]
  },
  "id_str" : "266964406066376705",
  "text" : "Someone invent computer vision software that removes pictures of food from my social media feeds please.",
  "id" : 266964406066376705,
  "created_at" : "Fri Nov 09 18:04:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Humble Bundle",
      "screen_name" : "humble",
      "indices" : [ 110, 117 ],
      "id_str" : "11167502",
      "id" : 11167502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/iS63Ipkx",
      "expanded_url" : "http://www.humblebundle.com",
      "display_url" : "humblebundle.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266687070708301825",
  "text" : "Just supported the new HumbleBundle for Android! Worth it for the soundtracks alone. http://t.co/iS63Ipkx via @humble",
  "id" : 266687070708301825,
  "created_at" : "Thu Nov 08 23:42:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Ebert",
      "screen_name" : "ebertchicago",
      "indices" : [ 55, 68 ],
      "id_str" : "79797834",
      "id" : 79797834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/GmPRF6j2",
      "expanded_url" : "http://bit.ly/SwRkew",
      "display_url" : "bit.ly/SwRkew"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621858682, -73.968661153 ]
  },
  "id_str" : "266656639271174144",
  "text" : "Technically one of only 2 or 3 Bond films in years... \u201C@ebertchicago: \"Skyfall\" is the best Bond film in years. http://t.co/GmPRF6j2\u201D",
  "id" : 266656639271174144,
  "created_at" : "Thu Nov 08 21:41:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266650311085670400",
  "text" : "Kayak acquired by Priceline for 1.8 Instagrams!",
  "id" : 266650311085670400,
  "created_at" : "Thu Nov 08 21:16:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/3VKp45wx",
      "expanded_url" : "http://allthingsd.com/20121106/heres-how-bravos-silicon-valley-stars-pitch-start-up-investors-slides/",
      "display_url" : "allthingsd.com/20121106/heres\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266575179797381121",
  "text" : "The worst part is, this isn't even the worst deck that I've seen. http://t.co/3VKp45wx",
  "id" : 266575179797381121,
  "created_at" : "Thu Nov 08 16:17:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266568264728055810",
  "text" : "Bram Stoker still sounds like he's a lead character in Jackass.",
  "id" : 266568264728055810,
  "created_at" : "Thu Nov 08 15:50:01 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/G15PZTHH",
      "expanded_url" : "http://www.npr.org/blogs/krulwich/2012/10/02/162163801/obama-s-secret-weapon-in-the-south-small-dead-but-still-kickin",
      "display_url" : "npr.org/blogs/krulwich\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266561858603999232",
  "text" : "Obama's support in the South: following the rabbit hole all the way down. http://t.co/G15PZTHH",
  "id" : 266561858603999232,
  "created_at" : "Thu Nov 08 15:24:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266232653232078849",
  "text" : "Whatever happened to the Nexus Q? Wasn't that supposed to be a thing?",
  "id" : 266232653232078849,
  "created_at" : "Wed Nov 07 17:36:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "atebits",
      "screen_name" : "atebits",
      "indices" : [ 3, 11 ],
      "id_str" : "11178592",
      "id" : 11178592
    }, {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 72, 78 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/SQLbgzhh",
      "expanded_url" : "http://www.wired.com/gamelife/2012/11/letterpress-solved-games/",
      "display_url" : "wired.com/gamelife/2012/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266224032570023938",
  "text" : "RT @atebits: Interesting article on Letterpress and \"solved\" games, via @Wired: http://t.co/SQLbgzhh",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wired",
        "screen_name" : "wired",
        "indices" : [ 59, 65 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http://t.co/SQLbgzhh",
        "expanded_url" : "http://www.wired.com/gamelife/2012/11/letterpress-solved-games/",
        "display_url" : "wired.com/gamelife/2012/\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "266222891035676672",
    "text" : "Interesting article on Letterpress and \"solved\" games, via @Wired: http://t.co/SQLbgzhh",
    "id" : 266222891035676672,
    "created_at" : "Wed Nov 07 16:57:38 +0000 2012",
    "user" : {
      "name" : "atebits",
      "screen_name" : "atebits",
      "protected" : false,
      "id_str" : "11178592",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2908929564/10ff1ad0792b9bd737de740418511681_normal.png",
      "id" : 11178592,
      "verified" : false
    }
  },
  "id" : 266224032570023938,
  "created_at" : "Wed Nov 07 17:02:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 38, 52 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7621117281, -73.9684943853 ]
  },
  "id_str" : "266194826398154754",
  "text" : "To which the US responds, \"Maybe.\" - \u201C@Fake_Dispatch: As the United States walks out the bedroom door, Ohio says from the bed, \"Call me?\"\u201D",
  "id" : 266194826398154754,
  "created_at" : "Wed Nov 07 15:06:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104558524, -74.0063499663 ]
  },
  "id_str" : "266048778908356608",
  "text" : "Brian Williams: Donald Trump has \"driven well past the last exit to relevance and veered into something closer to irresponsible.\"",
  "id" : 266048778908356608,
  "created_at" : "Wed Nov 07 05:25:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NY Tech Meetup",
      "screen_name" : "NYTM",
      "indices" : [ 46, 51 ],
      "id_str" : "18560574",
      "id" : 18560574
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/NYTM/status/266046602718875651/photo/1",
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/1PknNmTl",
      "media_url" : "http://pbs.twimg.com/media/A7Ev-cFCEAAJdte.jpg",
      "id_str" : "266046602727264256",
      "id" : 266046602727264256,
      "media_url_https" : "https://pbs.twimg.com/media/A7Ev-cFCEAAJdte.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/1PknNmTl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104578052, -74.0063368228 ]
  },
  "id_str" : "266048029021319168",
  "text" : "That would've looked really sinister in red. \u201C@NYTM: America's decision reflected by the Empire State building http://t.co/1PknNmTl\u201D",
  "id" : 266048029021319168,
  "created_at" : "Wed Nov 07 05:22:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 3, 17 ],
      "id_str" : "15593773",
      "id" : 15593773
    }, {
      "name" : "Ben Smith",
      "screen_name" : "BuzzFeedBen",
      "indices" : [ 28, 40 ],
      "id_str" : "9532402",
      "id" : 9532402
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/BuzzFeedBen/status/265930397056126976/photo/1",
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/M2qyb3yJ",
      "media_url" : "http://pbs.twimg.com/media/A7DGSYPCUAEQ1QJ.png",
      "id_str" : "265930397060321281",
      "id" : 265930397060321281,
      "media_url_https" : "https://pbs.twimg.com/media/A7DGSYPCUAEQ1QJ.png",
      "sizes" : [ {
        "h" : 295,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com/M2qyb3yJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266015378440876032",
  "text" : "RT @lexiberylross: Whoa. RT @BuzzFeedBen: Have our 3 election-night results splashes ready: http://t.co/M2qyb3yJ",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Smith",
        "screen_name" : "BuzzFeedBen",
        "indices" : [ 9, 21 ],
        "id_str" : "9532402",
        "id" : 9532402
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/BuzzFeedBen/status/265930397056126976/photo/1",
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/M2qyb3yJ",
        "media_url" : "http://pbs.twimg.com/media/A7DGSYPCUAEQ1QJ.png",
        "id_str" : "265930397060321281",
        "id" : 265930397060321281,
        "media_url_https" : "https://pbs.twimg.com/media/A7DGSYPCUAEQ1QJ.png",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com/M2qyb3yJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "265933850960605186",
    "text" : "Whoa. RT @BuzzFeedBen: Have our 3 election-night results splashes ready: http://t.co/M2qyb3yJ",
    "id" : 265933850960605186,
    "created_at" : "Tue Nov 06 21:49:05 +0000 2012",
    "user" : {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "protected" : false,
      "id_str" : "15593773",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1909477451/image_normal.jpg",
      "id" : 15593773,
      "verified" : false
    }
  },
  "id" : 266015378440876032,
  "created_at" : "Wed Nov 07 03:13:03 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/vbLjEuip",
      "expanded_url" : "http://blog.kanehsieh.com/2012/11/05/the-problem-with-the-tesla-model-s/",
      "display_url" : "blog.kanehsieh.com/2012/11/05/the\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "265485739205222401",
  "text" : "There's a glaring problem in an otherwise amazing Tesla Model S. And it has to do with skeuomorphism. http://t.co/vbLjEuip",
  "id" : 265485739205222401,
  "created_at" : "Mon Nov 05 16:08:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikeFuel",
      "screen_name" : "NikeFuel",
      "indices" : [ 13, 22 ],
      "id_str" : "466807381",
      "id" : 466807381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265300057006432256",
  "text" : "Anyone tried @NikeFuel? Worth it?",
  "id" : 265300057006432256,
  "created_at" : "Mon Nov 05 03:50:37 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/3wk2hQUr",
      "expanded_url" : "http://disney.wikia.com/wiki/Darth_Vader",
      "display_url" : "disney.wikia.com/wiki/Darth_Vad\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "265202986224066560",
  "text" : "Spotted on the Disney character wiki: http://t.co/3wk2hQUr",
  "id" : 265202986224066560,
  "created_at" : "Sun Nov 04 21:24:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smokey Robotic",
      "screen_name" : "SmokeyRobotic",
      "indices" : [ 16, 30 ],
      "id_str" : "154203947",
      "id" : 154203947
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/264877858239942656/photo/1",
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/14VMDpdo",
      "media_url" : "http://pbs.twimg.com/media/A60JAjnCEAAI__j.jpg",
      "id_str" : "264877858248331264",
      "id" : 264877858248331264,
      "media_url_https" : "https://pbs.twimg.com/media/A60JAjnCEAAI__j.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/14VMDpdo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104223068, -74.0062894504 ]
  },
  "id_str" : "264877858239942656",
  "text" : "Best band ever: @SmokeyRobotic does a personal Happy Birthday song for my girlfriend's birthday! http://t.co/14VMDpdo",
  "id" : 264877858239942656,
  "created_at" : "Sat Nov 03 23:52:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kaczynski",
      "screen_name" : "BuzzFeedAndrew",
      "indices" : [ 3, 18 ],
      "id_str" : "326255267",
      "id" : 326255267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/mXloYgVe",
      "expanded_url" : "http://twitpic.com/b9tz8y",
      "display_url" : "twitpic.com/b9tz8y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "264772142296600576",
  "text" : "RT @BuzzFeedAndrew: Fire powered cell phone chargers being sold in downtown Manhattan.\n http://t.co/mXloYgVe",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http://t.co/mXloYgVe",
        "expanded_url" : "http://twitpic.com/b9tz8y",
        "display_url" : "twitpic.com/b9tz8y"
      } ]
    },
    "geo" : {
    },
    "id_str" : "264590248602918912",
    "text" : "Fire powered cell phone chargers being sold in downtown Manhattan.\n http://t.co/mXloYgVe",
    "id" : 264590248602918912,
    "created_at" : "Sat Nov 03 04:50:05 +0000 2012",
    "user" : {
      "name" : "Andrew Kaczynski",
      "screen_name" : "BuzzFeedAndrew",
      "protected" : false,
      "id_str" : "326255267",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3609516107/982914058b727d49e0e61d17f9b0238b_normal.jpeg",
      "id" : 326255267,
      "verified" : true
    }
  },
  "id" : 264772142296600576,
  "created_at" : "Sat Nov 03 16:52:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/H0qXIkH4",
      "expanded_url" : "http://thenextweb.com/microsoft/2012/11/02/microsofts-security-team-is-killing-it-not-one-product-on-kasperskys-top-10-vulnerabilities-list/",
      "display_url" : "thenextweb.com/microsoft/2012\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "264491591350231040",
  "text" : "How secure is your IT? Hint: Oracle, Adobe, and Apple are losers, Microsoft is big winner. http://t.co/H0qXIkH4",
  "id" : 264491591350231040,
  "created_at" : "Fri Nov 02 22:18:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Memoto",
      "screen_name" : "Memototeam",
      "indices" : [ 4, 15 ],
      "id_str" : "527334899",
      "id" : 527334899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/yDTdBb3w",
      "expanded_url" : "http://www.colbertnation.com/the-colbert-report-videos/420709/november-01-2012/colbert-report--tip-wag---constant-documentation---billy-graham",
      "display_url" : "colbertnation.com/the-colbert-re\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "264364441343229952",
  "text" : "The @Memototeam got a shoutout from Colbert last night! Glad I pledged at the early bird level. http://t.co/yDTdBb3w",
  "id" : 264364441343229952,
  "created_at" : "Fri Nov 02 13:52:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    }, {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 12, 19 ],
      "id_str" : "9544202",
      "id" : 9544202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/6rOcKMPo",
      "expanded_url" : "http://www.economist.com/node/21560523",
      "display_url" : "economist.com/node/21560523"
    } ]
  },
  "in_reply_to_status_id_str" : "264179631710666752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7114312306, -74.0168208232 ]
  },
  "id_str" : "264191554967699456",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin @schlaf there's a very good Economist article on the human microbiome as well. http://t.co/6rOcKMPo",
  "id" : 264191554967699456,
  "in_reply_to_status_id" : 264179631710666752,
  "created_at" : "Fri Nov 02 02:25:49 +0000 2012",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 26, 31 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264048897536692224",
  "text" : "Don't understand all this @Uber hate. It's a BLACK CAR service thats machine-optimized for DEMAND. Not a malicious scrooge.",
  "id" : 264048897536692224,
  "created_at" : "Thu Nov 01 16:58:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]