Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 0, 13 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22572590541",
  "geo" : {
  },
  "id_str" : "22573906840",
  "in_reply_to_user_id" : 112919587,
  "text" : "@vcruzcontrol its too hot sometimes to not wear flip flops!",
  "id" : 22573906840,
  "in_reply_to_status_id" : 22572590541,
  "created_at" : "Tue Aug 31 01:19:28 +0000 2010",
  "in_reply_to_screen_name" : "vcruzcontrol",
  "in_reply_to_user_id_str" : "112919587",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Harvard",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22559256999",
  "text" : "Final leg of flight!  See you soon, #Harvard",
  "id" : 22559256999,
  "created_at" : "Mon Aug 30 21:52:54 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cambridge",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22485051837",
  "text" : "Back to reliable internet.  Next stop, #Cambridge",
  "id" : 22485051837,
  "created_at" : "Mon Aug 30 01:35:26 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22033458817",
  "text" : "Twitter Freedom in Hong Kong!  Next stop, Taipei.",
  "id" : 22033458817,
  "created_at" : "Tue Aug 24 21:43:29 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "droid",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21817308860",
  "text" : "Droid Pro coming with CDMA + GSM.  YESSSSS #droid",
  "id" : 21817308860,
  "created_at" : "Sun Aug 22 09:05:42 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21162083336",
  "text" : "When I'm in the Boston I sleep on West Coast time.  When I'm in China I sleep on GMT.  Must find balance!",
  "id" : 21162083336,
  "created_at" : "Sat Aug 14 16:29:29 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "China",
      "indices" : [ 41, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20762012674",
  "text" : "Tweeting from behind the Great Firewall. #China",
  "id" : 20762012674,
  "created_at" : "Tue Aug 10 03:13:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20668184596",
  "text" : "Wheels up from O'Hare! Next stop, Peking International.",
  "id" : 20668184596,
  "created_at" : "Mon Aug 09 00:59:49 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20661887150",
  "text" : "Argo Tea in downtown Chicago is 10x better than Starbucks. Bummin' it out in O'Hare now",
  "id" : 20661887150,
  "created_at" : "Sun Aug 08 23:17:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omnom",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20633613526",
  "text" : "Taking advantage of long layover to get dim sum in Chicago Chinatown. #omnom",
  "id" : 20633613526,
  "created_at" : "Sun Aug 08 14:54:15 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20628427581",
  "text" : "Stuck on the tarmac at O'Hare argh.",
  "id" : 20628427581,
  "created_at" : "Sun Aug 08 13:31:38 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20618014531",
  "text" : "Watching the sunrise from Logan Airport.  Beijing or Bust.",
  "id" : 20618014531,
  "created_at" : "Sun Aug 08 09:41:09 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20509040284",
  "geo" : {
  },
  "id_str" : "20513271611",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil you have sperry's?  Paradigm shift",
  "id" : 20513271611,
  "in_reply_to_status_id" : 20509040284,
  "created_at" : "Sat Aug 07 01:10:30 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20501197467",
  "text" : "RT @hotdogsladies: Apparently, Google had wanted to turn Wave off weeks ago, but nobody could figure out how.",
  "id" : 20501197467,
  "created_at" : "Fri Aug 06 21:50:53 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20477921873",
  "text" : "Last full day at Harvard for the summer.  Asia, get ready.",
  "id" : 20477921873,
  "created_at" : "Fri Aug 06 15:34:57 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20401796355",
  "text" : "I need to find cheap luggage around the square!",
  "id" : 20401796355,
  "created_at" : "Thu Aug 05 16:54:11 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usps",
      "indices" : [ 104, 109 ]
    }, {
      "text" : "fail",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20401237153",
  "text" : "Post Office in Harvard Sq is the most poorly run, inefficient waste of human time I've seen in a while. #usps #fail",
  "id" : 20401237153,
  "created_at" : "Thu Aug 05 16:46:13 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leisure Station ",
      "screen_name" : "LeisureStation",
      "indices" : [ 7, 22 ],
      "id_str" : "148929648",
      "id" : 148929648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boba",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20345070544",
  "text" : "Dinner @leisurestation by MIT. Mmm #boba",
  "id" : 20345070544,
  "created_at" : "Thu Aug 05 00:14:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20234165013",
  "text" : "At Mulan for lunch. Leaving for China in 5 days. Packing needs to happen.",
  "id" : 20234165013,
  "created_at" : "Tue Aug 03 16:34:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20070263763",
  "text" : "Crossed the Charles at the Mystic power plant. No tourists, no gilt, nothing. Just a bridge and a river and the beautiful day.",
  "id" : 20070263763,
  "created_at" : "Sun Aug 01 15:43:19 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 3, 18 ],
      "id_str" : "18107808",
      "id" : 18107808
    }, {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 63, 75 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20070212987",
  "text" : "RT @NaveenSrivatsa: Junior year starts in one month. Crazy. RT @alishalisha: Wow it's August.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alisha Ramos",
        "screen_name" : "alishalisha",
        "indices" : [ 43, 55 ],
        "id_str" : "15101900",
        "id" : 15101900
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "20068668088",
    "text" : "Junior year starts in one month. Crazy. RT @alishalisha: Wow it's August.",
    "id" : 20068668088,
    "created_at" : "Sun Aug 01 15:17:35 +0000 2010",
    "user" : {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "protected" : true,
      "id_str" : "18107808",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1745313225/IMG_0625edited2_normal.jpg",
      "id" : 18107808,
      "verified" : false
    }
  },
  "id" : 20070212987,
  "created_at" : "Sun Aug 01 15:42:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]