Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64450110024712192",
  "text" : "Resisting the urge to take apart the iphone",
  "id" : 64450110024712192,
  "created_at" : "Sat Apr 30 22:04:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64431121940750336",
  "text" : "Someone port #android to iPhone 4 and receive my unconditional love",
  "id" : 64431121940750336,
  "created_at" : "Sat Apr 30 20:49:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://taptaptap.com/camera+\" rel=\"nofollow\">Camera+</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Ramsey",
      "screen_name" : "willdanieley",
      "indices" : [ 9, 22 ],
      "id_str" : "141380372",
      "id" : 141380372
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 34, 42 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64421958372175872",
  "text" : "Watching @willdanieley on sax for @Harvard Arts First http://campl.us/15T",
  "id" : 64421958372175872,
  "created_at" : "Sat Apr 30 20:12:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64168462683082753",
  "geo" : {
  },
  "id_str" : "64182717901832192",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee Mather formal is in the courtyard! Unfortunately I am working tonight.",
  "id" : 64182717901832192,
  "in_reply_to_status_id" : 64168462683082753,
  "created_at" : "Sat Apr 30 04:22:07 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 0, 8 ],
      "id_str" : "86144785",
      "id" : 86144785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64170710771318784",
  "geo" : {
  },
  "id_str" : "64182664168607744",
  "in_reply_to_user_id" : 86144785,
  "text" : "@xobabyb I have an extra ticket if you want.",
  "id" : 64182664168607744,
  "in_reply_to_status_id" : 64170710771318784,
  "created_at" : "Sat Apr 30 04:21:54 +0000 2011",
  "in_reply_to_screen_name" : "xobabyb",
  "in_reply_to_user_id_str" : "86144785",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64168278200827904",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee it's Mather formal night!",
  "id" : 64168278200827904,
  "created_at" : "Sat Apr 30 03:24:44 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64158861510184960",
  "geo" : {
  },
  "id_str" : "64164981469495296",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee I use \"Sent from my mobile device. Please excuse the typing missed cakes.\"",
  "id" : 64164981469495296,
  "in_reply_to_status_id" : 64158861510184960,
  "created_at" : "Sat Apr 30 03:11:38 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 41, 49 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64164602090496000",
  "text" : "Excited to DJ Eliot Fete tomorrow night! @harvard formal season.",
  "id" : 64164602090496000,
  "created_at" : "Sat Apr 30 03:10:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Playbook",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64127194317848578",
  "text" : "I played with the Blackberry #Playbook today. It was extremely underwhelming.",
  "id" : 64127194317848578,
  "created_at" : "Sat Apr 30 00:41:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http://t.co/uwTYuwc",
      "expanded_url" : "http://www.core77.com/blog/object_culture/upenn_engineering_students_present_alpha_possibly_the_most_high-tech_bicycle_ever_19166.asp?",
      "display_url" : "core77.com/blog/object_cu\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "64126120416653312",
  "text" : "Sweet bike with electronic clutch, awkward geometry http://t.co/uwTYuwc",
  "id" : 64126120416653312,
  "created_at" : "Sat Apr 30 00:37:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    }, {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 40, 49 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64024604544479232",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose for lunch in the sunshine at @medialab. Today is a good day.",
  "id" : 64024604544479232,
  "created_at" : "Fri Apr 29 17:53:49 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 0, 6 ],
      "id_str" : "49019553",
      "id" : 49019553
    }, {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 7, 15 ],
      "id_str" : "86144785",
      "id" : 86144785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omnom",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63839842311749632",
  "geo" : {
  },
  "id_str" : "63869197935063040",
  "in_reply_to_user_id" : 49019553,
  "text" : "@mjoyw @xobabyb Sunday brunch then? There's a breakfast menu too. #omnom",
  "id" : 63869197935063040,
  "in_reply_to_status_id" : 63839842311749632,
  "created_at" : "Fri Apr 29 07:36:18 +0000 2011",
  "in_reply_to_screen_name" : "mjoyw",
  "in_reply_to_user_id_str" : "49019553",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 0, 8 ],
      "id_str" : "86144785",
      "id" : 86144785
    }, {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 9, 15 ],
      "id_str" : "49019553",
      "id" : 49019553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63814202745307136",
  "geo" : {
  },
  "id_str" : "63831438797180929",
  "in_reply_to_user_id" : 86144785,
  "text" : "@xobabyb @mjoyw Sunday works!",
  "id" : 63831438797180929,
  "in_reply_to_status_id" : 63814202745307136,
  "created_at" : "Fri Apr 29 05:06:15 +0000 2011",
  "in_reply_to_screen_name" : "xobabyb",
  "in_reply_to_user_id_str" : "86144785",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 0, 6 ],
      "id_str" : "49019553",
      "id" : 49019553
    }, {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 7, 15 ],
      "id_str" : "86144785",
      "id" : 86144785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63792445003010048",
  "geo" : {
  },
  "id_str" : "63794347317006336",
  "in_reply_to_user_id" : 49019553,
  "text" : "@mjoyw @xobabyb I'm down! Early? Have to DJ Fete.",
  "id" : 63794347317006336,
  "in_reply_to_status_id" : 63792445003010048,
  "created_at" : "Fri Apr 29 02:38:52 +0000 2011",
  "in_reply_to_screen_name" : "mjoyw",
  "in_reply_to_user_id_str" : "49019553",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 0, 8 ],
      "id_str" : "86144785",
      "id" : 86144785
    }, {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 9, 15 ],
      "id_str" : "49019553",
      "id" : 49019553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63787180849508352",
  "geo" : {
  },
  "id_str" : "63792032417710080",
  "in_reply_to_user_id" : 86144785,
  "text" : "@xobabyb @mjoyw they have it! Had to ask Ian to translate for me.",
  "id" : 63792032417710080,
  "in_reply_to_status_id" : 63787180849508352,
  "created_at" : "Fri Apr 29 02:29:40 +0000 2011",
  "in_reply_to_screen_name" : "xobabyb",
  "in_reply_to_user_id_str" : "86144785",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63759134604001281",
  "text" : "Data on Verizon iPhone seems really slow",
  "id" : 63759134604001281,
  "created_at" : "Fri Apr 29 00:18:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63698351023063040",
  "text" : "Etsy doesn't let you register an email with a '.' in it?",
  "id" : 63698351023063040,
  "created_at" : "Thu Apr 28 20:17:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63679091118845952",
  "text" : "First tweet from an iPhone. Jim got a Thunderbolt. I feel tainted.",
  "id" : 63679091118845952,
  "created_at" : "Thu Apr 28 19:00:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 34, 42 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http://t.co/uZPRSy4",
      "expanded_url" : "http://twitpic.com/4ql9ux",
      "display_url" : "twitpic.com/4ql9ux"
    } ]
  },
  "geo" : {
  },
  "id_str" : "63648119765733376",
  "text" : "Got my print matted and ready for @Harvard Arts First week! http://t.co/uZPRSy4",
  "id" : 63648119765733376,
  "created_at" : "Thu Apr 28 16:57:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http://t.co/uKyxgIg",
      "expanded_url" : "http://bit.ly/mT6mpM",
      "display_url" : "bit.ly/mT6mpM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "63332143320928256",
  "text" : "So much serif font!! RT ellachou: McKinsey report on China's Digital Consumers (PDF) http://t.co/uKyxgIg",
  "id" : 63332143320928256,
  "created_at" : "Wed Apr 27 20:02:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 11, 22 ],
      "id_str" : "21061803",
      "id" : 21061803
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 48, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63320192612188160",
  "text" : "Agree with @_Eric_Chen, this humidity is awful. #firstworldproblems",
  "id" : 63320192612188160,
  "created_at" : "Wed Apr 27 19:14:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63319417018269696",
  "text" : "Google Docs now has an Android app!",
  "id" : 63319417018269696,
  "created_at" : "Wed Apr 27 19:11:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 36, 47 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63299673674366976",
  "text" : "YouTube founders buy Delicious! via @techcrunch",
  "id" : 63299673674366976,
  "created_at" : "Wed Apr 27 17:53:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63295105372651520",
  "text" : "Typing on a netbook has resulted me in me sending some pretty stupid sounding emails.",
  "id" : 63295105372651520,
  "created_at" : "Wed Apr 27 17:35:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63293438296203264",
  "text" : "I really want an iPhone just so I can stick an M9 sticker on the back and feel cool. #nerdtweet",
  "id" : 63293438296203264,
  "created_at" : "Wed Apr 27 17:28:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63156478483234816",
  "geo" : {
  },
  "id_str" : "63162180073299968",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose going to bed... if only I had some banh mi as am bedtime snack.",
  "id" : 63162180073299968,
  "in_reply_to_status_id" : 63156478483234816,
  "created_at" : "Wed Apr 27 08:46:51 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63126303410360320",
  "text" : "I'm glad I didn't buy a Sabres jersey last week.",
  "id" : 63126303410360320,
  "created_at" : "Wed Apr 27 06:24:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 0, 6 ],
      "id_str" : "49019553",
      "id" : 49019553
    }, {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 7, 15 ],
      "id_str" : "86144785",
      "id" : 86144785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63098615668801536",
  "geo" : {
  },
  "id_str" : "63126172082511872",
  "in_reply_to_user_id" : 49019553,
  "text" : "@mjoyw @xobabyb for late night ramen go to Louie's! He's Taiwanese and sometimes gives for free if you have a nice convo in Chinese",
  "id" : 63126172082511872,
  "in_reply_to_status_id" : 63098615668801536,
  "created_at" : "Wed Apr 27 06:23:46 +0000 2011",
  "in_reply_to_screen_name" : "mjoyw",
  "in_reply_to_user_id_str" : "49019553",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63102570968784896",
  "text" : "Nikon announces 50mm 1.8 G. About damn time.",
  "id" : 63102570968784896,
  "created_at" : "Wed Apr 27 04:49:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dropbox",
      "screen_name" : "Dropbox",
      "indices" : [ 13, 21 ],
      "id_str" : "14749606",
      "id" : 14749606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http://t.co/945tlsV",
      "expanded_url" : "http://twitpic.com/4pz671",
      "display_url" : "twitpic.com/4pz671"
    } ]
  },
  "geo" : {
  },
  "id_str" : "63072866761064449",
  "text" : "Albert Ni of @dropbox presenting at #harvard! http://t.co/945tlsV",
  "id" : 63072866761064449,
  "created_at" : "Wed Apr 27 02:51:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Liang",
      "screen_name" : "daveliang",
      "indices" : [ 15, 25 ],
      "id_str" : "20615976",
      "id" : 20615976
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 85, 97 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63026328487723008",
  "text" : "Excited to see @daveliang and The Shanghai Restoration Project in NYC next week with @badboyboyce!",
  "id" : 63026328487723008,
  "created_at" : "Tue Apr 26 23:47:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63002314390253568",
  "text" : "Playstation Network taken down, and my credit card info compromised :(",
  "id" : 63002314390253568,
  "created_at" : "Tue Apr 26 22:11:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SLR Magic",
      "screen_name" : "slrmagic",
      "indices" : [ 0, 9 ],
      "id_str" : "177890993",
      "id" : 177890993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62889191821946880",
  "geo" : {
  },
  "id_str" : "62998008861696000",
  "in_reply_to_user_id" : 177890993,
  "text" : "@slrmagic I'm trying to send an email but I keep getting bounced!",
  "id" : 62998008861696000,
  "in_reply_to_status_id" : 62889191821946880,
  "created_at" : "Tue Apr 26 21:54:30 +0000 2011",
  "in_reply_to_screen_name" : "slrmagic",
  "in_reply_to_user_id_str" : "177890993",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62806075551924224",
  "text" : "What I wouldn't give for a local 24 hour asian food joint.",
  "id" : 62806075551924224,
  "created_at" : "Tue Apr 26 09:11:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Her Campus",
      "screen_name" : "HerCampus",
      "indices" : [ 13, 23 ],
      "id_str" : "65576332",
      "id" : 65576332
    }, {
      "name" : "Stephanie Kaplan",
      "screen_name" : "stephaniekaplan",
      "indices" : [ 29, 45 ],
      "id_str" : "31307826",
      "id" : 31307826
    }, {
      "name" : "Annie Wang",
      "screen_name" : "annie_wang",
      "indices" : [ 46, 57 ],
      "id_str" : "29599103",
      "id" : 29599103
    }, {
      "name" : "Windsor Hanger",
      "screen_name" : "windsorhanger",
      "indices" : [ 58, 72 ],
      "id_str" : "168510952",
      "id" : 168510952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http://t.co/hAwKKlK",
      "expanded_url" : "http://cot.ag/g7U4wd",
      "display_url" : "cot.ag/g7U4wd"
    } ]
  },
  "in_reply_to_status_id_str" : "62619983473156098",
  "geo" : {
  },
  "id_str" : "62690532803092481",
  "in_reply_to_user_id" : 31307826,
  "text" : "Teaching the @HerCampus team @stephaniekaplan @annie_wang @windsorhanger how to shoot! Check out the pics http://t.co/hAwKKlK",
  "id" : 62690532803092481,
  "in_reply_to_status_id" : 62619983473156098,
  "created_at" : "Tue Apr 26 01:32:42 +0000 2011",
  "in_reply_to_screen_name" : "stephaniekaplan",
  "in_reply_to_user_id_str" : "31307826",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62656176038481920",
  "text" : "RT @medialab: MIT Announces Joi Ito as Next Media Lab Director:  http://bit.ly/eE73sf",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "62655112929218560",
    "text" : "MIT Announces Joi Ito as Next Media Lab Director:  http://bit.ly/eE73sf",
    "id" : 62655112929218560,
    "created_at" : "Mon Apr 25 23:11:57 +0000 2011",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 62656176038481920,
  "created_at" : "Mon Apr 25 23:16:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62603727118405632",
  "text" : "Green milk tea, 1/2 sugar + boba + lychee jelly + pudding = heaven.",
  "id" : 62603727118405632,
  "created_at" : "Mon Apr 25 19:47:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62601725416181760",
  "text" : "For such a talented student body, Harvard has a pretty dysfunctional dating scene.",
  "id" : 62601725416181760,
  "created_at" : "Mon Apr 25 19:39:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 3, 14 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "honeycomb",
      "indices" : [ 89, 99 ]
    }, {
      "text" : "android",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62600312099307520",
  "text" : "RT @droid_life: BlackBerry Playbook Now Runs Honeycomb, Wait What? - http://goo.gl/942O3 #honeycomb #android",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "honeycomb",
        "indices" : [ 73, 83 ]
      }, {
        "text" : "android",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "62600094469464064",
    "text" : "BlackBerry Playbook Now Runs Honeycomb, Wait What? - http://goo.gl/942O3 #honeycomb #android",
    "id" : 62600094469464064,
    "created_at" : "Mon Apr 25 19:33:20 +0000 2011",
    "user" : {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "protected" : false,
      "id_str" : "96501375",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1639322866/dl_square_normal.jpg",
      "id" : 96501375,
      "verified" : true
    }
  },
  "id" : 62600312099307520,
  "created_at" : "Mon Apr 25 19:34:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "john pepper",
      "screen_name" : "bolocoCEO",
      "indices" : [ 0, 10 ],
      "id_str" : "184524050",
      "id" : 184524050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62347671477817344",
  "geo" : {
  },
  "id_str" : "62352014293729280",
  "in_reply_to_user_id" : 184524050,
  "text" : "@bolocoCEO No card - but no worries, as long as it doesn't happen again!",
  "id" : 62352014293729280,
  "in_reply_to_status_id" : 62347671477817344,
  "created_at" : "Mon Apr 25 03:07:33 +0000 2011",
  "in_reply_to_screen_name" : "bolocoCEO",
  "in_reply_to_user_id_str" : "184524050",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "boloco",
      "screen_name" : "boloco",
      "indices" : [ 0, 7 ],
      "id_str" : "17234834",
      "id" : 17234834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62270982878007296",
  "geo" : {
  },
  "id_str" : "62346123146297345",
  "in_reply_to_user_id" : 17234834,
  "text" : "@boloco harv sq - there was a big order ahead of us, but instead of pipelining the orders they just took our orders and made us wait 30 min!",
  "id" : 62346123146297345,
  "in_reply_to_status_id" : 62270982878007296,
  "created_at" : "Mon Apr 25 02:44:08 +0000 2011",
  "in_reply_to_screen_name" : "boloco",
  "in_reply_to_user_id_str" : "17234834",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62269314971082752",
  "text" : "I think boloco matches the MBTA in sheer inefficiency.",
  "id" : 62269314971082752,
  "created_at" : "Sun Apr 24 21:38:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62232747862794240",
  "geo" : {
  },
  "id_str" : "62236128056578049",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern the Epic Soundtracks station on Pandora makes everything you do seem badass",
  "id" : 62236128056578049,
  "in_reply_to_status_id" : 62232747862794240,
  "created_at" : "Sun Apr 24 19:27:03 +0000 2011",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 43, 55 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "identities",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http://t.co/GZToASX",
      "expanded_url" : "http://twitpic.com/4o9m1c",
      "display_url" : "twitpic.com/4o9m1c"
    } ]
  },
  "geo" : {
  },
  "id_str" : "61634016989810688",
  "text" : "Running #identities fashion show cams with @badboyboyce http://t.co/GZToASX",
  "id" : 61634016989810688,
  "created_at" : "Sat Apr 23 03:34:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61509981391962113",
  "text" : "\"We're lucky that smugglers aren't coming out of MIT\" - AS&E rep on our suggestions for beating backscatter",
  "id" : 61509981391962113,
  "created_at" : "Fri Apr 22 19:21:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 3, 15 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61503985454039041",
  "text" : "RT @alishalisha: Will never take Harvard housing for granted.",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "61503139865567232",
    "text" : "Will never take Harvard housing for granted.",
    "id" : 61503139865567232,
    "created_at" : "Fri Apr 22 18:54:25 +0000 2011",
    "user" : {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "protected" : false,
      "id_str" : "15101900",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1746276803/Picture_10_normal.png",
      "id" : 15101900,
      "verified" : false
    }
  },
  "id" : 61503985454039041,
  "created_at" : "Fri Apr 22 18:57:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61499830551330816",
  "text" : "\"The press is ignorant. The radiation dose is comparable to a few minutes flying at altitude\"",
  "id" : 61499830551330816,
  "created_at" : "Fri Apr 22 18:41:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIT",
      "indices" : [ 8, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61499588632252416",
  "text" : "Talk at #MIT on xray backscatter experts. Big Brother is watching.",
  "id" : 61499588632252416,
  "created_at" : "Fri Apr 22 18:40:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 38, 48 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61482222867316737",
  "text" : "I keep waking up late and haven't had @momogoose in two weeks!!",
  "id" : 61482222867316737,
  "created_at" : "Fri Apr 22 17:31:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thisiswhyimfat",
      "indices" : [ 71, 86 ]
    }, {
      "text" : "notreally",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61337484281397249",
  "text" : "It's 4am and i am craving good bubble tea and Taiwanese boxed lunch... #thisiswhyimfat #notreally",
  "id" : 61337484281397249,
  "created_at" : "Fri Apr 22 07:56:10 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61336626416189440",
  "text" : "RT @HarvardCSA: Living in China this summer? Come join the CSA China Directory and see who else is around your area! http://harvardcsa.o ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "61325661440196608",
    "text" : "Living in China this summer? Come join the CSA China Directory and see who else is around your area! http://harvardcsa.org/directory",
    "id" : 61325661440196608,
    "created_at" : "Fri Apr 22 07:09:11 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 61336626416189440,
  "created_at" : "Fri Apr 22 07:52:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chen Fang",
      "screen_name" : "chenbfang",
      "indices" : [ 38, 48 ],
      "id_str" : "74640882",
      "id" : 74640882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bing",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61250475391070209",
  "text" : "#Bing Rewards now Live! Rolled out by @chenbfang",
  "id" : 61250475391070209,
  "created_at" : "Fri Apr 22 02:10:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61182894781116416",
  "text" : "I love the Droid, but I miss Blackberry a lot... if only it had better native Gmail support",
  "id" : 61182894781116416,
  "created_at" : "Thu Apr 21 21:41:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61173294199615489",
  "text" : "Dear cyclists, i love bikes, i build bikes, but follow the goddamn traffic rules",
  "id" : 61173294199615489,
  "created_at" : "Thu Apr 21 21:03:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60748815585644544",
  "text" : "Mercedes A-Class and ToyoBuru FT86 coming to states? Pinch me I'm dreaming.",
  "id" : 60748815585644544,
  "created_at" : "Wed Apr 20 16:57:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60479265505947648",
  "text" : "Playbook launched today? Yawn.",
  "id" : 60479265505947648,
  "created_at" : "Tue Apr 19 23:05:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gmail",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60246334342565888",
  "text" : "Maybe I'm late to notice, but #gmail \"show if unread\" label conditions are super useful.",
  "id" : 60246334342565888,
  "created_at" : "Tue Apr 19 07:40:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 24, 30 ],
      "id_str" : "49019553",
      "id" : 49019553
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 57, 64 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60112508521955330",
  "text" : "Anything for totoro. RT @mjoyw: got my totoro backk yayy @khsieh  :]]",
  "id" : 60112508521955330,
  "created_at" : "Mon Apr 18 22:48:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "supercomputer",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http://t.co/67zLBFg",
      "expanded_url" : "http://www.techradar.com/news/computing/the-10-fastest-computers-in-the-world-941548",
      "display_url" : "techradar.com/news/computing\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "60032864133197826",
  "text" : "China and US dominate the chart, but France has the prettiest #supercomputer http://t.co/67zLBFg",
  "id" : 60032864133197826,
  "created_at" : "Mon Apr 18 17:32:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58973918031126528",
  "text" : "\"true-north seeking fiber optic gyro\" sounds so badass #nerdtweet",
  "id" : 58973918031126528,
  "created_at" : "Fri Apr 15 19:24:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58972658930417664",
  "text" : "Hanumant Singh speaking about underwater robots and imaging @ MIT Media Lab!",
  "id" : 58972658930417664,
  "created_at" : "Fri Apr 15 19:19:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChristineYin",
      "screen_name" : "Christine_Y",
      "indices" : [ 1, 13 ],
      "id_str" : "416751825",
      "id" : 416751825
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 84, 96 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http://t.co/VZyoREc",
      "expanded_url" : "http://www.yelp.com/html/puppy_deal/",
      "display_url" : "yelp.com/html/puppy_dea\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "58451138026020864",
  "text" : "\u201C@christine_y: \"netflix for puppies,\" BEST X FOR Y EVER http://t.co/VZyoREc\u201D dammit @badboyboyce, we were too late",
  "id" : 58451138026020864,
  "created_at" : "Thu Apr 14 08:46:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chen Fang",
      "screen_name" : "chenbfang",
      "indices" : [ 3, 13 ],
      "id_str" : "74640882",
      "id" : 74640882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kinect",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58450867489214464",
  "text" : "RT @chenbfang: #Kinect for Windows SDK coming Spring 2011. Subscribe here: http://bit.ly/hBoJnB Who's excited for Win 8 Kinect-ready apps?",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/seesmic_desktop/sd2\" rel=\"nofollow\">Seesmic Desktop</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kinect",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "58428078166249472",
    "text" : "#Kinect for Windows SDK coming Spring 2011. Subscribe here: http://bit.ly/hBoJnB Who's excited for Win 8 Kinect-ready apps?",
    "id" : 58428078166249472,
    "created_at" : "Thu Apr 14 07:15:14 +0000 2011",
    "user" : {
      "name" : "Chen Fang",
      "screen_name" : "chenbfang",
      "protected" : false,
      "id_str" : "74640882",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1874956711/23535353_normal.png",
      "id" : 74640882,
      "verified" : false
    }
  },
  "id" : 58450867489214464,
  "created_at" : "Thu Apr 14 08:45:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http://t.co/pRapexf",
      "expanded_url" : "http://gizmodo.com/#!5791744/windows-phone-7-you-were-supposed-to-be-great-so-what-happened",
      "display_url" : "gizmodo.com/#!5791744/wind\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "58395126409601024",
  "text" : "Windows Phone 7, I love you, but please get in the game http://t.co/pRapexf",
  "id" : 58395126409601024,
  "created_at" : "Thu Apr 14 05:04:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58292986534043648",
  "text" : "Dinner in the Square with this summer's Microsoft interns! #nerdtweet",
  "id" : 58292986534043648,
  "created_at" : "Wed Apr 13 22:18:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58093954788372480",
  "geo" : {
  },
  "id_str" : "58101343117787136",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose my sleep schedule has passed normal people's waking schedule. This is bad.",
  "id" : 58101343117787136,
  "in_reply_to_status_id" : 58093954788372480,
  "created_at" : "Wed Apr 13 09:36:54 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 9, 19 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57950790135971840",
  "text" : "ran into @jenny8lee mailing a big purple hippo in Harvard Square!",
  "id" : 57950790135971840,
  "created_at" : "Tue Apr 12 23:38:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Sheen",
      "screen_name" : "charliesheen",
      "indices" : [ 0, 13 ],
      "id_str" : "259379883",
      "id" : 259379883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57902605640286208",
  "geo" : {
  },
  "id_str" : "57905100043194369",
  "in_reply_to_user_id" : 259379883,
  "text" : "@charliesheen Kane Hsieh",
  "id" : 57905100043194369,
  "in_reply_to_status_id" : 57902605640286208,
  "created_at" : "Tue Apr 12 20:37:06 +0000 2011",
  "in_reply_to_screen_name" : "charliesheen",
  "in_reply_to_user_id_str" : "259379883",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57638987334029312",
  "text" : "Harvard's WiFi is faster than the ethernet connection in my dorm. wtf?",
  "id" : 57638987334029312,
  "created_at" : "Tue Apr 12 02:59:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sayl",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57613605260111872",
  "text" : "These standard-issue college dorm chairs are awful. Has anyone tried the H.Miller #Sayl?",
  "id" : 57613605260111872,
  "created_at" : "Tue Apr 12 01:18:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 82, 94 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57611685808181248",
  "text" : "You know what would be great? A rent-a-dog-service. The Zipcar of dogs. Get on it @badboyboyce",
  "id" : 57611685808181248,
  "created_at" : "Tue Apr 12 01:11:10 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56810297205342208",
  "text" : "Spring spring spring!",
  "id" : 56810297205342208,
  "created_at" : "Sat Apr 09 20:06:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56455896271818752",
  "text" : "Putting QR-codes on ads in the subway is silly because phones don't get data signal...",
  "id" : 56455896271818752,
  "created_at" : "Fri Apr 08 20:38:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56060300658610176",
  "text" : "Finally got around to reading Yu Hua's Brothers. Heartwrenching book.",
  "id" : 56060300658610176,
  "created_at" : "Thu Apr 07 18:26:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http://t.co/fcesSt3",
      "expanded_url" : "http://www.panopticongallery.com/exhibitions/index.html",
      "display_url" : "panopticongallery.com/exhibitions/in\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "55803274959405056",
  "text" : "Does anyone want to go to the Panopticon polaroid exhibit with me? http://t.co/fcesSt3",
  "id" : 55803274959405056,
  "created_at" : "Thu Apr 07 01:25:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 5, 12 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "epic",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54800793584406528",
  "text" : "Used @square for the first time to get $$ from roommates for bacon prosciutto sausage pizza. #epic",
  "id" : 54800793584406528,
  "created_at" : "Mon Apr 04 07:01:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chen Fang",
      "screen_name" : "chenbfang",
      "indices" : [ 3, 13 ],
      "id_str" : "74640882",
      "id" : 74640882
    }, {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 15, 26 ],
      "id_str" : "14620776",
      "id" : 14620776
    }, {
      "name" : "Nikki Lee",
      "screen_name" : "nkkl",
      "indices" : [ 27, 32 ],
      "id_str" : "22096585",
      "id" : 22096585
    }, {
      "name" : "Helen Han",
      "screen_name" : "helenyhan",
      "indices" : [ 33, 43 ],
      "id_str" : "237710848",
      "id" : 237710848
    }, {
      "name" : "Tiffany Lien",
      "screen_name" : "tiflien",
      "indices" : [ 44, 52 ],
      "id_str" : "40926811",
      "id" : 40926811
    }, {
      "name" : "Tony Pino",
      "screen_name" : "aapino",
      "indices" : [ 53, 60 ],
      "id_str" : "7133902",
      "id" : 7133902
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 61, 68 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "Grantland Chew",
      "screen_name" : "grantland",
      "indices" : [ 69, 79 ],
      "id_str" : "8170682",
      "id" : 8170682
    }, {
      "name" : "Max Wendkos",
      "screen_name" : "MaxWendkos",
      "indices" : [ 80, 91 ],
      "id_str" : "47243142",
      "id" : 47243142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54644216021790720",
  "text" : "RT @chenbfang: @ellenchisa @nkkl @helenyhan @tiflien @aapino @khsieh @grantland @maxwendkos Share 100 facts about yourself. Use hashtag  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/seesmic_desktop/sd2\" rel=\"nofollow\">Seesmic Desktop</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ellen Chisa",
        "screen_name" : "ellenchisa",
        "indices" : [ 0, 11 ],
        "id_str" : "14620776",
        "id" : 14620776
      }, {
        "name" : "Nikki Lee",
        "screen_name" : "nkkl",
        "indices" : [ 12, 17 ],
        "id_str" : "22096585",
        "id" : 22096585
      }, {
        "name" : "Helen Han",
        "screen_name" : "helenyhan",
        "indices" : [ 18, 28 ],
        "id_str" : "237710848",
        "id" : 237710848
      }, {
        "name" : "Tiffany Lien",
        "screen_name" : "tiflien",
        "indices" : [ 29, 37 ],
        "id_str" : "40926811",
        "id" : 40926811
      }, {
        "name" : "Tony Pino",
        "screen_name" : "aapino",
        "indices" : [ 38, 45 ],
        "id_str" : "7133902",
        "id" : 7133902
      }, {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 46, 53 ],
        "id_str" : "111999960",
        "id" : 111999960
      }, {
        "name" : "Grantland Chew",
        "screen_name" : "grantland",
        "indices" : [ 54, 64 ],
        "id_str" : "8170682",
        "id" : 8170682
      }, {
        "name" : "Max Wendkos",
        "screen_name" : "MaxWendkos",
        "indices" : [ 65, 76 ],
        "id_str" : "47243142",
        "id" : 47243142
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "100factsaboutme",
        "indices" : [ 121, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "54434171791212544",
    "in_reply_to_user_id" : 14620776,
    "text" : "@ellenchisa @nkkl @helenyhan @tiflien @aapino @khsieh @grantland @maxwendkos Share 100 facts about yourself. Use hashtag #100factsaboutme.",
    "id" : 54434171791212544,
    "created_at" : "Sun Apr 03 06:44:52 +0000 2011",
    "in_reply_to_screen_name" : "ellenchisa",
    "in_reply_to_user_id_str" : "14620776",
    "user" : {
      "name" : "Chen Fang",
      "screen_name" : "chenbfang",
      "protected" : false,
      "id_str" : "74640882",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1874956711/23535353_normal.png",
      "id" : 74640882,
      "verified" : false
    }
  },
  "id" : 54644216021790720,
  "created_at" : "Sun Apr 03 20:39:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurav Kumar",
      "screen_name" : "fR0DDY",
      "indices" : [ 3, 10 ],
      "id_str" : "28605577",
      "id" : 28605577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54239900526067712",
  "text" : "RT @fR0DDY: Q: How to generate a random string?\nA: Put a fresh student in front of vi and tell him to quit.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "52746601323696128",
    "text" : "Q: How to generate a random string?\nA: Put a fresh student in front of vi and tell him to quit.",
    "id" : 52746601323696128,
    "created_at" : "Tue Mar 29 14:59:04 +0000 2011",
    "user" : {
      "name" : "Gaurav Kumar",
      "screen_name" : "fR0DDY",
      "protected" : false,
      "id_str" : "28605577",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/547408511/me_normal.jpg",
      "id" : 28605577,
      "verified" : false
    }
  },
  "id" : 54239900526067712,
  "created_at" : "Sat Apr 02 17:52:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53886045309239296",
  "text" : "Making fun of bad movie holograms in Media Lab class #nerdtweet",
  "id" : 53886045309239296,
  "created_at" : "Fri Apr 01 18:26:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]