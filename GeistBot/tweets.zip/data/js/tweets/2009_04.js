Grailbird.data.tweets_2009_04 = 
 [ {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1656614364",
  "text" : "Tweeting in haiku / makes me think before typing. / I should speak in verse (haiku 35)",
  "id" : 1656614364,
  "created_at" : "Thu Apr 30 05:19:18 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1656599681",
  "text" : "Last day of classes / its probably a bad sign / that I'm so happy (haiku 34)",
  "id" : 1656599681,
  "created_at" : "Thu Apr 30 05:16:32 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1638760641",
  "text" : "My first all nighter / this entire freshman year. / I feel accomplished (haiku 33)",
  "id" : 1638760641,
  "created_at" : "Tue Apr 28 13:25:19 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1630418506",
  "text" : "Splash of color (alternatively, Scorpian Chainsaw): http://tinyurl.com/c42qr4",
  "id" : 1630418506,
  "created_at" : "Mon Apr 27 16:53:10 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1618086688",
  "text" : "Leading prefrosh pack / to a mather house party. / its like sheep herding (haiku 32)",
  "id" : 1618086688,
  "created_at" : "Sun Apr 26 03:38:42 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1617727818",
  "text" : "It's saturday night / and I'm stuck doing homework. / I hate this last week (haiku #31)",
  "id" : 1617727818,
  "created_at" : "Sun Apr 26 02:40:44 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1601287512",
  "text" : "Five days, three papers / midterm, and presentation. / well I say, bring it (haiku #30)",
  "id" : 1601287512,
  "created_at" : "Fri Apr 24 05:10:54 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1594287716",
  "text" : "One More robbery, / this time using a pistol. / nice job, gun control (haiku #29)",
  "id" : 1594287716,
  "created_at" : "Thu Apr 23 14:06:12 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1592226247",
  "text" : "One more week of school / and its the hardest week yet. / also, I want food (haiku #28)",
  "id" : 1592226247,
  "created_at" : "Thu Apr 23 06:39:50 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1578951691",
  "text" : "atmosphere: http://tinyurl.com/clrwjk",
  "id" : 1578951691,
  "created_at" : "Tue Apr 21 21:54:41 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1573565039",
  "text" : "Birds chirp in the gloom / right before beautiful dawn. / too bad I'm still up (haiku #27)",
  "id" : 1573565039,
  "created_at" : "Tue Apr 21 08:46:37 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1572486440",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha how are things going? / you seem to be down lately. / hang tight in home stretch!! (Haiku #26)",
  "id" : 1572486440,
  "created_at" : "Tue Apr 21 04:39:24 +0000 2009",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1570146667",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow hey there melody, / name-calling was uncalled for! / you stupid dumbass :P (haiku #25)",
  "id" : 1570146667,
  "created_at" : "Mon Apr 20 23:38:20 +0000 2009",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1567621787",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow show me printed book / I want to see your pictures / crowned with dumb title (haiku #24)",
  "id" : 1567621787,
  "created_at" : "Mon Apr 20 18:24:09 +0000 2009",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1567107389",
  "text" : "Two more weeks of class. / the weather is getting nice. / two weeks: two too long (haiku #23)",
  "id" : 1567107389,
  "created_at" : "Mon Apr 20 17:17:41 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1550025053",
  "text" : "Its time for sunrise / and I'm sitting in a boat / alone on Charles (haiku #22)",
  "id" : 1550025053,
  "created_at" : "Sat Apr 18 10:58:44 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1548003369",
  "text" : "Flight of the conchords, / what a way to end a week! / time for early race... (Haiku #21)",
  "id" : 1548003369,
  "created_at" : "Sat Apr 18 02:48:16 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "20y",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1531407350",
  "text" : "Quoth the lamont guard / \"what the hell is ratatat?\" / I had to chuckle (haiku #20y",
  "id" : 1531407350,
  "created_at" : "Thu Apr 16 04:39:17 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1531257853",
  "text" : "Time for confession / I've been skipping the food class. / I don't miss much though (haiku #20)",
  "id" : 1531257853,
  "created_at" : "Thu Apr 16 04:12:41 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1523079281",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha don't hate on Avril. / I own some of her CDs! / please don't judge me now :P (haiku #19)",
  "id" : 1523079281,
  "created_at" : "Wed Apr 15 04:47:59 +0000 2009",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1513681749",
  "text" : "Cabot bathroom stalls / covered in nerd graffiti. / tempted to add on (haiku #183",
  "id" : 1513681749,
  "created_at" : "Tue Apr 14 02:10:25 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1491303516",
  "text" : "The squirrels are horny / and the birds sing in blue skies. / hooray for spring time! (Haiku #17)",
  "id" : 1491303516,
  "created_at" : "Fri Apr 10 16:22:26 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1461473207",
  "text" : "Cramming PS1 / in a fluroescent prison, / or, science center (haiku #17)",
  "id" : 1461473207,
  "created_at" : "Mon Apr 06 06:42:08 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1441965105",
  "text" : "I need to find time / to at least haiku some more. / where do the days go? (Haiku #15)",
  "id" : 1441965105,
  "created_at" : "Fri Apr 03 00:06:08 +0000 2009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]