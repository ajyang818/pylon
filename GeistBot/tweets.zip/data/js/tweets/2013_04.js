Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329283764180111361",
  "text" : "OH: \"Hummus is just yuppie nachos.\"",
  "id" : 329283764180111361,
  "created_at" : "Tue Apr 30 17:19:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "KaneWWE",
      "indices" : [ 74, 82 ],
      "id_str" : "892245979",
      "id" : 892245979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329065571364786176",
  "text" : "I learn a lot about pro wrestling from all the people that mistake me for @KaneWWE.",
  "id" : 329065571364786176,
  "created_at" : "Tue Apr 30 02:52:00 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikita Kansra",
      "screen_name" : "NikitaKansra",
      "indices" : [ 0, 13 ],
      "id_str" : "1132551883",
      "id" : 1132551883
    }, {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 14, 25 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329045731681898497",
  "geo" : {
  },
  "id_str" : "329047695127900160",
  "in_reply_to_user_id" : 1132551883,
  "text" : "@NikitaKansra @thecrimson I think you guys are off by like three zeros.",
  "id" : 329047695127900160,
  "in_reply_to_status_id" : 329045731681898497,
  "created_at" : "Tue Apr 30 01:40:58 +0000 2013",
  "in_reply_to_screen_name" : "NikitaKansra",
  "in_reply_to_user_id_str" : "1132551883",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aleksi Aaltonen",
      "screen_name" : "aleksiaaltonen",
      "indices" : [ 0, 15 ],
      "id_str" : "14356041",
      "id" : 14356041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328807630250336256",
  "geo" : {
  },
  "id_str" : "328868681104912386",
  "in_reply_to_user_id" : 14356041,
  "text" : "@aleksiaaltonen Looking forward to all the features in the pipeline!",
  "id" : 328868681104912386,
  "in_reply_to_status_id" : 328807630250336256,
  "created_at" : "Mon Apr 29 13:49:38 +0000 2013",
  "in_reply_to_screen_name" : "aleksiaaltonen",
  "in_reply_to_user_id_str" : "14356041",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "truthNSoul",
      "screen_name" : "mrtruthandsoul",
      "indices" : [ 0, 15 ],
      "id_str" : "323911083",
      "id" : 323911083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328317193756487680",
  "geo" : {
  },
  "id_str" : "328604170515005440",
  "in_reply_to_user_id" : 323911083,
  "text" : "@mrtruthandsoul amazing.",
  "id" : 328604170515005440,
  "in_reply_to_status_id" : 328317193756487680,
  "created_at" : "Sun Apr 28 20:18:34 +0000 2013",
  "in_reply_to_screen_name" : "mrtruthandsoul",
  "in_reply_to_user_id_str" : "323911083",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "truthNSoul",
      "screen_name" : "mrtruthandsoul",
      "indices" : [ 3, 18 ],
      "id_str" : "323911083",
      "id" : 323911083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "328604066286546944",
  "text" : "RT @mrtruthandsoul: Chipotle but they mix the beans &amp; cheese like at Cold Stone Creamery...\n\nCold Stone Beanery, if you will.\n\nGet at m\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "328317193756487680",
    "text" : "Chipotle but they mix the beans &amp; cheese like at Cold Stone Creamery...\n\nCold Stone Beanery, if you will.\n\nGet at me, venture capitalists.",
    "id" : 328317193756487680,
    "created_at" : "Sun Apr 28 01:18:13 +0000 2013",
    "user" : {
      "name" : "truthNSoul",
      "screen_name" : "mrtruthandsoul",
      "protected" : false,
      "id_str" : "323911083",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3046936012/2daa4217232725207af71ba16f6f686a_normal.jpeg",
      "id" : 323911083,
      "verified" : false
    }
  },
  "id" : 328604066286546944,
  "created_at" : "Sun Apr 28 20:18:09 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328570113483735041",
  "geo" : {
  },
  "id_str" : "328580107620978688",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil I uninstalled after a month - was nifty but unfinished product. Aggregate data view and foursquare connect glaringly missing.",
  "id" : 328580107620978688,
  "in_reply_to_status_id" : 328570113483735041,
  "created_at" : "Sun Apr 28 18:42:57 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 55, 71 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http://t.co/fhVDoiYcPA",
      "expanded_url" : "http://imgur.com/a/mN8Zs",
      "display_url" : "imgur.com/a/mN8Zs"
    } ]
  },
  "in_reply_to_status_id_str" : "328544305901887488",
  "geo" : {
  },
  "id_str" : "328553376625352705",
  "in_reply_to_user_id" : 228489296,
  "text" : "Amazing to see the ratios of fresh to processed food. \u201C@GlobalAsianista: photo project: a week's worth of groceries http://t.co/fhVDoiYcPA\u201D",
  "id" : 328553376625352705,
  "in_reply_to_status_id" : 328544305901887488,
  "created_at" : "Sun Apr 28 16:56:43 +0000 2013",
  "in_reply_to_screen_name" : "GlobalAsianista",
  "in_reply_to_user_id_str" : "228489296",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 0, 15 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 37, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328550723598036992",
  "geo" : {
  },
  "id_str" : "328552000474189824",
  "in_reply_to_user_id" : 18107808,
  "text" : "@NaveenSrivatsa the first-est of the #firstworldproblems",
  "id" : 328552000474189824,
  "in_reply_to_status_id" : 328550723598036992,
  "created_at" : "Sun Apr 28 16:51:15 +0000 2013",
  "in_reply_to_screen_name" : "NaveenSrivatsa",
  "in_reply_to_user_id_str" : "18107808",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Feng",
      "screen_name" : "amfeng",
      "indices" : [ 0, 7 ],
      "id_str" : "195478230",
      "id" : 195478230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328271539571159040",
  "geo" : {
  },
  "id_str" : "328272054199672833",
  "in_reply_to_user_id" : 195478230,
  "text" : "@amfeng is that a Herman Miller SAYL chair? It looks awesome!",
  "id" : 328272054199672833,
  "in_reply_to_status_id" : 328271539571159040,
  "created_at" : "Sat Apr 27 22:18:51 +0000 2013",
  "in_reply_to_screen_name" : "amfeng",
  "in_reply_to_user_id_str" : "195478230",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 0, 8 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328255551505047552",
  "geo" : {
  },
  "id_str" : "328255902715092992",
  "in_reply_to_user_id" : 436143123,
  "text" : "@timehop yea! Not all the things I want to remember about a day I share on social media; right now those thoughts don't get captured.",
  "id" : 328255902715092992,
  "in_reply_to_status_id" : 328255551505047552,
  "created_at" : "Sat Apr 27 21:14:40 +0000 2013",
  "in_reply_to_screen_name" : "timehop",
  "in_reply_to_user_id_str" : "436143123",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 42, 50 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "328255042991845376",
  "text" : "You know what would be an awesome feature @timehop? If I could leave private notes + pics to future self via the app!",
  "id" : 328255042991845376,
  "created_at" : "Sat Apr 27 21:11:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Eisenberg",
      "screen_name" : "Eisenberg",
      "indices" : [ 0, 10 ],
      "id_str" : "14693588",
      "id" : 14693588
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 81, 89 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328182216393887744",
  "geo" : {
  },
  "id_str" : "328226326815318016",
  "in_reply_to_user_id" : 14693588,
  "text" : "@Eisenberg I think it was a coincidence - got same Amazon email and I've been on @spotify premium for months.",
  "id" : 328226326815318016,
  "in_reply_to_status_id" : 328182216393887744,
  "created_at" : "Sat Apr 27 19:17:09 +0000 2013",
  "in_reply_to_screen_name" : "Eisenberg",
  "in_reply_to_user_id_str" : "14693588",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 32, 43 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/nickbilton/status/327937916343025664/photo/1",
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/hDFFbc56PE",
      "media_url" : "http://pbs.twimg.com/media/BI0RzCRCAAMMwLG.jpg",
      "id_str" : "327937916347219971",
      "id" : 327937916347219971,
      "media_url_https" : "https://pbs.twimg.com/media/BI0RzCRCAAMMwLG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/hDFFbc56PE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327937916343025664",
  "geo" : {
  },
  "id_str" : "327941189942784002",
  "in_reply_to_user_id" : 1586501,
  "text" : "Publish it in 140 char chunks! \u201C@nickbilton: Just hit this word count - and not done yet! - on The Twitter Book. http://t.co/hDFFbc56PE\u201D",
  "id" : 327941189942784002,
  "in_reply_to_status_id" : 327937916343025664,
  "created_at" : "Sat Apr 27 00:24:07 +0000 2013",
  "in_reply_to_screen_name" : "nickbilton",
  "in_reply_to_user_id_str" : "1586501",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/feedly/id396069556?mt=8&uo=4\" rel=\"nofollow\">feedly on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http://t.co/qLB8VtzPBR",
      "expanded_url" : "http://feedly.com/k/ZN006T",
      "display_url" : "feedly.com/k/ZN006T"
    } ]
  },
  "geo" : {
  },
  "id_str" : "327884651521798144",
  "text" : "No regret: Bloomberg and NYT refused to censor; banned in China. http://t.co/qLB8VtzPBR",
  "id" : 327884651521798144,
  "created_at" : "Fri Apr 26 20:39:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane Sarhan",
      "screen_name" : "kanes",
      "indices" : [ 0, 6 ],
      "id_str" : "46507923",
      "id" : 46507923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327830827444621312",
  "geo" : {
  },
  "id_str" : "327831172895883264",
  "in_reply_to_user_id" : 46507923,
  "text" : "@kanes a lot of hard work... Let's meet! Shoot me an email! First name at rre.",
  "id" : 327831172895883264,
  "in_reply_to_status_id" : 327830827444621312,
  "created_at" : "Fri Apr 26 17:06:57 +0000 2013",
  "in_reply_to_screen_name" : "kanes",
  "in_reply_to_user_id_str" : "46507923",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 22, 27 ],
      "id_str" : "11522502",
      "id" : 11522502
    }, {
      "name" : "Brian Watson",
      "screen_name" : "bwats",
      "indices" : [ 45, 51 ],
      "id_str" : "18500786",
      "id" : 18500786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "327803563290025984",
  "text" : "\"Williamsburg is like @etsy in real life.\" - @bwats dropping knowledge",
  "id" : 327803563290025984,
  "created_at" : "Fri Apr 26 15:17:14 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ent. Roundtable",
      "screen_name" : "ERoundtable",
      "indices" : [ 17, 29 ],
      "id_str" : "86093480",
      "id" : 86093480
    }, {
      "name" : "maxstoller",
      "screen_name" : "maxstoller",
      "indices" : [ 58, 69 ],
      "id_str" : "15337726",
      "id" : 15337726
    }, {
      "name" : "Eugenia Koo",
      "screen_name" : "itwentviral",
      "indices" : [ 70, 82 ],
      "id_str" : "261491851",
      "id" : 261491851
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ERANYC",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http://t.co/zLYg31VY91",
      "expanded_url" : "http://4sq.com/15MaZ4W",
      "display_url" : "4sq.com/15MaZ4W"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.74534180590688, -74.00783748099224 ]
  },
  "id_str" : "327778725846462466",
  "text" : "Lots of faces at @eroundtable demo day. #ERANYC (@ IAC w/ @maxstoller @itwentviral) [pic]: http://t.co/zLYg31VY91",
  "id" : 327778725846462466,
  "created_at" : "Fri Apr 26 13:38:32 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 0, 6 ],
      "id_str" : "3840",
      "id" : 3840
    }, {
      "name" : "Harvard GSD",
      "screen_name" : "HarvardGSD",
      "indices" : [ 40, 51 ],
      "id_str" : "19272669",
      "id" : 19272669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http://t.co/lXhZj1SIKV",
      "expanded_url" : "http://m.dpreview.com/previews/panasonic-lumix-dmc-gh3",
      "display_url" : "m.dpreview.com/previews/panas\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "327572853883023360",
  "in_reply_to_user_id" : 3840,
  "text" : "@Jason Panasonic GH3. Used Canon 5Ds at @HarvardGSD but would choose GH3 now. http://t.co/lXhZj1SIKV",
  "id" : 327572853883023360,
  "created_at" : "Fri Apr 26 00:00:29 +0000 2013",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/327252826814304256/photo/1",
      "indices" : [ 48, 70 ],
      "url" : "http://t.co/8dH7P2Y9IM",
      "media_url" : "http://pbs.twimg.com/media/BIqitk5CUAABWwO.jpg",
      "id_str" : "327252826818498560",
      "id" : 327252826818498560,
      "media_url_https" : "https://pbs.twimg.com/media/BIqitk5CUAABWwO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/8dH7P2Y9IM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "327252826814304256",
  "text" : "Just Gundam RX-78 riding a Covenant Ghost. Nbd. http://t.co/8dH7P2Y9IM",
  "id" : 327252826814304256,
  "created_at" : "Thu Apr 25 02:48:48 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "indices" : [ 3, 13 ],
      "id_str" : "13369702",
      "id" : 13369702
    }, {
      "name" : "Matt Krna",
      "screen_name" : "mattkrna",
      "indices" : [ 79, 88 ],
      "id_str" : "97469025",
      "id" : 97469025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http://t.co/g9hBfB7vZG",
      "expanded_url" : "http://bit.ly/11ENPrL",
      "display_url" : "bit.ly/11ENPrL"
    } ]
  },
  "geo" : {
  },
  "id_str" : "327221776398561281",
  "text" : "RT @NikhilKal: \"sooo..Netflix is the new HBO and Amazon is the new Netflix?\" - @mattkrna http://t.co/g9hBfB7vZG",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Krna",
        "screen_name" : "mattkrna",
        "indices" : [ 64, 73 ],
        "id_str" : "97469025",
        "id" : 97469025
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http://t.co/g9hBfB7vZG",
        "expanded_url" : "http://bit.ly/11ENPrL",
        "display_url" : "bit.ly/11ENPrL"
      } ]
    },
    "geo" : {
    },
    "id_str" : "327212138647126016",
    "text" : "\"sooo..Netflix is the new HBO and Amazon is the new Netflix?\" - @mattkrna http://t.co/g9hBfB7vZG",
    "id" : 327212138647126016,
    "created_at" : "Thu Apr 25 00:07:07 +0000 2013",
    "user" : {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "protected" : false,
      "id_str" : "13369702",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3437624104/ebd80fda5433a8aec0fee038589e7079_normal.jpeg",
      "id" : 13369702,
      "verified" : false
    }
  },
  "id" : 327221776398561281,
  "created_at" : "Thu Apr 25 00:45:25 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eugenia Koo",
      "screen_name" : "itwentviral",
      "indices" : [ 79, 91 ],
      "id_str" : "261491851",
      "id" : 261491851
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/327141652525359104/photo/1",
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/2jyYekN9XN",
      "media_url" : "http://pbs.twimg.com/media/BIo9mYaCIAAx0dl.jpg",
      "id_str" : "327141652533747712",
      "id" : 327141652533747712,
      "media_url_https" : "https://pbs.twimg.com/media/BIo9mYaCIAAx0dl.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/2jyYekN9XN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "327141652525359104",
  "text" : "When laptop wifi fails in the office, we resort to iPads with silly keyboards. @itwentviral http://t.co/2jyYekN9XN",
  "id" : 327141652525359104,
  "created_at" : "Wed Apr 24 19:27:02 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.J. Kandy",
      "screen_name" : "AJKandy",
      "indices" : [ 0, 8 ],
      "id_str" : "1508831",
      "id" : 1508831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327139117341237248",
  "geo" : {
  },
  "id_str" : "327139308161101824",
  "in_reply_to_user_id" : 1508831,
  "text" : "@AJKandy tried already, with 8.8.4.4 as alternate. No joy.",
  "id" : 327139308161101824,
  "in_reply_to_status_id" : 327139117341237248,
  "created_at" : "Wed Apr 24 19:17:43 +0000 2013",
  "in_reply_to_screen_name" : "AJKandy",
  "in_reply_to_user_id_str" : "1508831",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/oEGu68Q2mJ",
      "expanded_url" : "http://google.com",
      "display_url" : "google.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "327138955373989888",
  "text" : "Weird bug w laptop wifi: no connections except anything with http://t.co/oEGu68Q2mJ in the URL. Only affecting thinkpads. Hmm.",
  "id" : 327138955373989888,
  "created_at" : "Wed Apr 24 19:16:19 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amanda peyton",
      "screen_name" : "amandapey",
      "indices" : [ 0, 10 ],
      "id_str" : "18348795",
      "id" : 18348795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327107782522306561",
  "geo" : {
  },
  "id_str" : "327122934659440642",
  "in_reply_to_user_id" : 18348795,
  "text" : "@amandapey hah! I was just wondering about that this morning! Perfectly time post.",
  "id" : 327122934659440642,
  "in_reply_to_status_id" : 327107782522306561,
  "created_at" : "Wed Apr 24 18:12:39 +0000 2013",
  "in_reply_to_screen_name" : "amandapey",
  "in_reply_to_user_id_str" : "18348795",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Fleishman",
      "screen_name" : "GlennF",
      "indices" : [ 7, 14 ],
      "id_str" : "8315692",
      "id" : 8315692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WWDC",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314961372054163458",
  "geo" : {
  },
  "id_str" : "327090944635727872",
  "in_reply_to_user_id" : 8315692,
  "text" : "#WWDC \u201C@GlennF: Jony Ives seizes his speaking tube. \u201CRemove the stitching!\u201D His voice echoes down the vast spaces of Apple\u2019s skeu factories\u201D",
  "id" : 327090944635727872,
  "in_reply_to_status_id" : 314961372054163458,
  "created_at" : "Wed Apr 24 16:05:32 +0000 2013",
  "in_reply_to_screen_name" : "GlennF",
  "in_reply_to_user_id_str" : "8315692",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Solochek",
      "screen_name" : "asolochek",
      "indices" : [ 0, 10 ],
      "id_str" : "15008336",
      "id" : 15008336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326933166797516800",
  "geo" : {
  },
  "id_str" : "326935035674517504",
  "in_reply_to_user_id" : 15008336,
  "text" : "@asolochek I can't believe a mechanical drive in a laptop even lasted that long.",
  "id" : 326935035674517504,
  "in_reply_to_status_id" : 326933166797516800,
  "created_at" : "Wed Apr 24 05:46:01 +0000 2013",
  "in_reply_to_screen_name" : "asolochek",
  "in_reply_to_user_id_str" : "15008336",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    }, {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 12, 23 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326929092702265346",
  "geo" : {
  },
  "id_str" : "326929469363347456",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin @tomloverro at this point, I think ANY leads are worth the noise for him/her...",
  "id" : 326929469363347456,
  "in_reply_to_status_id" : 326929092702265346,
  "created_at" : "Wed Apr 24 05:23:54 +0000 2013",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 71, 82 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/326928839362088960/photo/1",
      "indices" : [ 83, 105 ],
      "url" : "http://t.co/AV5RAOhsrZ",
      "media_url" : "http://pbs.twimg.com/media/BIl8DBmCEAArwD_.jpg",
      "id_str" : "326928839370477568",
      "id" : 326928839370477568,
      "media_url_https" : "https://pbs.twimg.com/media/BIl8DBmCEAArwD_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/AV5RAOhsrZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326928839362088960",
  "text" : "This is why you backup. I cannot imagine this guy's pain right now. cc @tomloverro http://t.co/AV5RAOhsrZ",
  "id" : 326928839362088960,
  "created_at" : "Wed Apr 24 05:21:24 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David R. Chan",
      "screen_name" : "chandavkl",
      "indices" : [ 48, 58 ],
      "id_str" : "25759493",
      "id" : 25759493
    }, {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 71, 78 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http://t.co/neykIJdHbp",
      "expanded_url" : "http://www.latimes.com/news/local/la-me-chinese-eater-20130422-dto,0,6902048.htmlstory",
      "display_url" : "latimes.com/news/local/la-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "326903777166757889",
  "text" : "Amazing dataset of 6,297 Chinese restaurants by @chandavkl. Take note, @jdrive http://t.co/neykIJdHbp",
  "id" : 326903777166757889,
  "created_at" : "Wed Apr 24 03:41:48 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http://t.co/bp6GrHi0xu",
      "expanded_url" : "http://www.youtube.com/watch?v=loinY8MmVq8",
      "display_url" : "youtube.com/watch?v=loinY8\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "326896230158450688",
  "text" : "The GE Connected Hospitals commercial w Agent Smith was more creepy than inspiring. http://t.co/bp6GrHi0xu",
  "id" : 326896230158450688,
  "created_at" : "Wed Apr 24 03:11:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feedly",
      "screen_name" : "feedly",
      "indices" : [ 38, 45 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/326815405739999233/photo/1",
      "indices" : [ 78, 100 ],
      "url" : "http://t.co/B1EJx1JZ8R",
      "media_url" : "http://pbs.twimg.com/media/BIkU4UaCAAE5AJF.jpg",
      "id_str" : "326815405744193537",
      "id" : 326815405744193537,
      "media_url_https" : "https://pbs.twimg.com/media/BIkU4UaCAAE5AJF.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/B1EJx1JZ8R"
    } ],
    "hashtags" : [ {
      "text" : "apple",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326815405739999233",
  "text" : "It's that time of the quarter when my @feedly reader becomes unusable. #apple http://t.co/B1EJx1JZ8R",
  "id" : 326815405739999233,
  "created_at" : "Tue Apr 23 21:50:39 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 3, 14 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326814760349872128",
  "text" : "RT @nickbilton: Breaking: TechCrunch blog posts on Apple down to 5, from 18 during the same time last quarter. AllthingsD remains flat with\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://wrenapp.com\" rel=\"nofollow\">Wren for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "326808539035234304",
    "text" : "Breaking: TechCrunch blog posts on Apple down to 5, from 18 during the same time last quarter. AllthingsD remains flat with Apple 3 posts.",
    "id" : 326808539035234304,
    "created_at" : "Tue Apr 23 21:23:22 +0000 2013",
    "user" : {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "protected" : false,
      "id_str" : "1586501",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3004953754/981f9dceb963d56f998e557e81e4115f_normal.jpeg",
      "id" : 1586501,
      "verified" : true
    }
  },
  "id" : 326814760349872128,
  "created_at" : "Tue Apr 23 21:48:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 44, 50 ],
      "id_str" : "3840",
      "id" : 3840
    }, {
      "name" : "launchticker",
      "screen_name" : "launchticker",
      "indices" : [ 55, 68 ],
      "id_str" : "529798141",
      "id" : 529798141
    }, {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 74, 78 ],
      "id_str" : "19494411",
      "id" : 19494411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326779714201071616",
  "text" : "Just signed up to be a monthly supporter of @jason and @launchticker with @rre. I read ever ticker email without fail.",
  "id" : 326779714201071616,
  "created_at" : "Tue Apr 23 19:28:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 3, 16 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326776152452628482",
  "text" : "RT @pourmecoffee: I think if I hacked AP, I would go with \"SETI detects coherent narrowband non-terrestrial signal. President to address na\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "326748612841308160",
    "text" : "I think if I hacked AP, I would go with \"SETI detects coherent narrowband non-terrestrial signal. President to address nation at 7 pm EST.\"",
    "id" : 326748612841308160,
    "created_at" : "Tue Apr 23 17:25:14 +0000 2013",
    "user" : {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "protected" : false,
      "id_str" : "16906137",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/421566216/coffee1242220886_normal.jpg",
      "id" : 16906137,
      "verified" : true
    }
  },
  "id" : 326776152452628482,
  "created_at" : "Tue Apr 23 19:14:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "respect",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326770814982692865",
  "text" : "Waiting for a bathroom stall. Guy walks out with a machine learning textbook. #respect",
  "id" : 326770814982692865,
  "created_at" : "Tue Apr 23 18:53:28 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 6, 14 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/NevmuqquNB",
      "expanded_url" : "http://nyti.ms/10wNWtD",
      "display_url" : "nyti.ms/10wNWtD"
    } ]
  },
  "in_reply_to_status_id_str" : "326736414811226112",
  "geo" : {
  },
  "id_str" : "326763154203893760",
  "in_reply_to_user_id" : 807095,
  "text" : "Wut. \u201C@nytimes: Cooper Union to Charge Undergraduate Tuition http://t.co/NevmuqquNB\u201D",
  "id" : 326763154203893760,
  "in_reply_to_status_id" : 326736414811226112,
  "created_at" : "Tue Apr 23 18:23:01 +0000 2013",
  "in_reply_to_screen_name" : "nytimes",
  "in_reply_to_user_id_str" : "807095",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 3, 14 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326513828420517890",
  "text" : "RT @tenderlove: Startup idea: \"What should I have for dinner besides salami?\" as a service",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "326511139016024064",
    "text" : "Startup idea: \"What should I have for dinner besides salami?\" as a service",
    "id" : 326511139016024064,
    "created_at" : "Tue Apr 23 01:41:36 +0000 2013",
    "user" : {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "protected" : false,
      "id_str" : "14761655",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3465297833/b5a676cd352a58483043b1179e57a9ce_normal.jpeg",
      "id" : 14761655,
      "verified" : false
    }
  },
  "id" : 326513828420517890,
  "created_at" : "Tue Apr 23 01:52:17 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Coneybeer",
      "screen_name" : "robconeybeer",
      "indices" : [ 0, 13 ],
      "id_str" : "36020201",
      "id" : 36020201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326490703578406912",
  "geo" : {
  },
  "id_str" : "326492481757782017",
  "in_reply_to_user_id" : 36020201,
  "text" : "@robconeybeer I've had Rep 2 units ship with misconfigured firmware. Flip the \"acceleration\" in Settings, it worked for us.",
  "id" : 326492481757782017,
  "in_reply_to_status_id" : 326490703578406912,
  "created_at" : "Tue Apr 23 00:27:28 +0000 2013",
  "in_reply_to_screen_name" : "robconeybeer",
  "in_reply_to_user_id_str" : "36020201",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Brennan",
      "screen_name" : "bjp",
      "indices" : [ 0, 4 ],
      "id_str" : "431330888",
      "id" : 431330888
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 5, 12 ],
      "id_str" : "224321197",
      "id" : 224321197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326467438009016320",
  "geo" : {
  },
  "id_str" : "326468391936344064",
  "in_reply_to_user_id" : 431330888,
  "text" : "@bjp @zhamed wow, Mr. Anish's tweets are pretty racist.",
  "id" : 326468391936344064,
  "in_reply_to_status_id" : 326467438009016320,
  "created_at" : "Mon Apr 22 22:51:44 +0000 2013",
  "in_reply_to_screen_name" : "bjp",
  "in_reply_to_user_id_str" : "431330888",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/326466281563906048/photo/1",
      "indices" : [ 98, 120 ],
      "url" : "http://t.co/c8gIY0X0Wi",
      "media_url" : "http://pbs.twimg.com/media/BIfXWngCYAEBhsx.jpg",
      "id_str" : "326466281568100353",
      "id" : 326466281568100353,
      "media_url_https" : "https://pbs.twimg.com/media/BIfXWngCYAEBhsx.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/c8gIY0X0Wi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326466281563906048",
  "text" : "Changing twitter usernames and having everyone still think you're a club promoter from the south: http://t.co/c8gIY0X0Wi",
  "id" : 326466281563906048,
  "created_at" : "Mon Apr 22 22:43:21 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 8, 15 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326460795460411393",
  "geo" : {
  },
  "id_str" : "326462316373737473",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo @khsieh these convos still throw me off. Still acclimating to usernames.",
  "id" : 326462316373737473,
  "in_reply_to_status_id" : 326460795460411393,
  "created_at" : "Mon Apr 22 22:27:36 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http://t.co/zvbHIB5qa8",
      "expanded_url" : "http://t.imehop.com/13qUQ0s",
      "display_url" : "t.imehop.com/13qUQ0s"
    } ]
  },
  "geo" : {
  },
  "id_str" : "326394912767631363",
  "text" : "Called it. http://t.co/zvbHIB5qa8",
  "id" : 326394912767631363,
  "created_at" : "Mon Apr 22 17:59:45 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxstoller",
      "screen_name" : "maxstoller",
      "indices" : [ 0, 11 ],
      "id_str" : "15337726",
      "id" : 15337726
    }, {
      "name" : "John Brennan",
      "screen_name" : "bjp",
      "indices" : [ 12, 16 ],
      "id_str" : "431330888",
      "id" : 431330888
    }, {
      "name" : "Spare",
      "screen_name" : "SpareApp",
      "indices" : [ 74, 83 ],
      "id_str" : "406496242",
      "id" : 406496242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326176182536114176",
  "geo" : {
  },
  "id_str" : "326201062358908929",
  "in_reply_to_user_id" : 15337726,
  "text" : "@maxstoller @bjp if there's any extra build lying around I'd love to test @spareapp :)",
  "id" : 326201062358908929,
  "in_reply_to_status_id" : 326176182536114176,
  "created_at" : "Mon Apr 22 05:09:28 +0000 2013",
  "in_reply_to_screen_name" : "maxstoller",
  "in_reply_to_user_id_str" : "15337726",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Tarsa",
      "screen_name" : "SteveTarsa",
      "indices" : [ 0, 11 ],
      "id_str" : "1371005376",
      "id" : 1371005376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "326180695720488960",
  "in_reply_to_user_id" : 1371005376,
  "text" : "@SteveTarsa took you long enough to get on Twitter!",
  "id" : 326180695720488960,
  "created_at" : "Mon Apr 22 03:48:32 +0000 2013",
  "in_reply_to_screen_name" : "SteveTarsa",
  "in_reply_to_user_id_str" : "1371005376",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326132680381050880",
  "geo" : {
  },
  "id_str" : "326138999318130688",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil amazing news!",
  "id" : 326138999318130688,
  "in_reply_to_status_id" : 326132680381050880,
  "created_at" : "Mon Apr 22 01:02:51 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Zacharias",
      "screen_name" : "zacman85",
      "indices" : [ 0, 9 ],
      "id_str" : "7495722",
      "id" : 7495722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326011460016820224",
  "geo" : {
  },
  "id_str" : "326016659473170433",
  "in_reply_to_user_id" : 7495722,
  "text" : "@zacman85 when I first tried Curiosity I could never get it to connect and just stopped playing. Any good now?",
  "id" : 326016659473170433,
  "in_reply_to_status_id" : 326011460016820224,
  "created_at" : "Sun Apr 21 16:56:43 +0000 2013",
  "in_reply_to_screen_name" : "zacman85",
  "in_reply_to_user_id_str" : "7495722",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Deighton",
      "screen_name" : "HBSmktg",
      "indices" : [ 28, 36 ],
      "id_str" : "13520",
      "id" : 13520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/LHbSAoG793",
      "expanded_url" : "http://bit.ly/XJ0LgL",
      "display_url" : "bit.ly/XJ0LgL"
    } ]
  },
  "in_reply_to_status_id_str" : "325996849355964417",
  "geo" : {
  },
  "id_str" : "326015051360247809",
  "in_reply_to_user_id" : 13520,
  "text" : "The two are not exclusive! \u201C@HBSmktg: Americans spend 6x as much time on social media than on news/serious content http://t.co/LHbSAoG793\u201D",
  "id" : 326015051360247809,
  "in_reply_to_status_id" : 325996849355964417,
  "created_at" : "Sun Apr 21 16:50:19 +0000 2013",
  "in_reply_to_screen_name" : "HBSmktg",
  "in_reply_to_user_id_str" : "13520",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325742121749467136",
  "geo" : {
  },
  "id_str" : "325743239065903105",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive what'd you make from leather?",
  "id" : 325743239065903105,
  "in_reply_to_status_id" : 325742121749467136,
  "created_at" : "Sat Apr 20 22:50:14 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scharpling",
      "screen_name" : "scharpling",
      "indices" : [ 3, 14 ],
      "id_str" : "17769258",
      "id" : 17769258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325740643437649920",
  "text" : "RT @scharpling: I remember reading THE GREAT GATSBY in school and feeling like it would be better in 3-D with late period Jay-Z songs playi\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325025084332969984",
    "text" : "I remember reading THE GREAT GATSBY in school and feeling like it would be better in 3-D with late period Jay-Z songs playing throughout.",
    "id" : 325025084332969984,
    "created_at" : "Thu Apr 18 23:16:33 +0000 2013",
    "user" : {
      "name" : "scharpling",
      "screen_name" : "scharpling",
      "protected" : false,
      "id_str" : "17769258",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1139063161/photo_normal.jpg",
      "id" : 17769258,
      "verified" : true
    }
  },
  "id" : 325740643437649920,
  "created_at" : "Sat Apr 20 22:39:56 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 54, 60 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/325682721231888385/photo/1",
      "indices" : [ 62, 84 ],
      "url" : "http://t.co/TGSxwp6uwk",
      "media_url" : "http://pbs.twimg.com/media/BIUOtZ0CYAAUIWY.jpg",
      "id_str" : "325682721240276992",
      "id" : 325682721240276992,
      "media_url_https" : "https://pbs.twimg.com/media/BIUOtZ0CYAAUIWY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/TGSxwp6uwk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325682721231888385",
  "text" : "The best description of Windows 8 I've ever heard, by @wired. http://t.co/TGSxwp6uwk",
  "id" : 325682721231888385,
  "created_at" : "Sat Apr 20 18:49:46 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 43, 51 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325416511546200065",
  "text" : "Two days ago I told my Luddite friend that @twitter had a cool music app and she said \"meh.\" Today convincing her to join is a no-brainer.",
  "id" : 325416511546200065,
  "created_at" : "Sat Apr 20 01:11:56 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Police Dept.",
      "screen_name" : "Boston_Police",
      "indices" : [ 3, 17 ],
      "id_str" : "19185333",
      "id" : 19185333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325415978328526848",
  "text" : "RT @Boston_Police: In our time of rejoicing, let us not forget the families of Martin Richard, Lingzi Lu, Krystle Campbell and Officer Sean\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325415459333758976",
    "text" : "In our time of rejoicing, let us not forget the families of Martin Richard, Lingzi Lu, Krystle Campbell and Officer Sean Collier.",
    "id" : 325415459333758976,
    "created_at" : "Sat Apr 20 01:07:46 +0000 2013",
    "user" : {
      "name" : "Boston Police Dept.",
      "screen_name" : "Boston_Police",
      "protected" : false,
      "id_str" : "19185333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/72731279/coin_boston_normal.jpg",
      "id" : 19185333,
      "verified" : true
    }
  },
  "id" : 325415978328526848,
  "created_at" : "Sat Apr 20 01:09:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 3, 13 ],
      "id_str" : "22745680",
      "id" : 22745680
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 48, 55 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/peterogburn/status/325404302711607297/photo/1",
      "indices" : [ 57, 79 ],
      "url" : "http://t.co/PF8OP5AYFp",
      "media_url" : "http://pbs.twimg.com/media/BIQRfT_CUAAPfcF.jpg",
      "id_str" : "325404302715801600",
      "id" : 325404302715801600,
      "media_url_https" : "https://pbs.twimg.com/media/BIQRfT_CUAAPfcF.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/PF8OP5AYFp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325414678756986880",
  "text" : "RT @Besvinick: Greatest closed caption ever. RT @isaach: http://t.co/PF8OP5AYFp",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Isaac Hepworth",
        "screen_name" : "isaach",
        "indices" : [ 33, 40 ],
        "id_str" : "7852612",
        "id" : 7852612
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/peterogburn/status/325404302711607297/photo/1",
        "indices" : [ 42, 64 ],
        "url" : "http://t.co/PF8OP5AYFp",
        "media_url" : "http://pbs.twimg.com/media/BIQRfT_CUAAPfcF.jpg",
        "id_str" : "325404302715801600",
        "id" : 325404302715801600,
        "media_url_https" : "https://pbs.twimg.com/media/BIQRfT_CUAAPfcF.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/PF8OP5AYFp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325406217956622337",
    "text" : "Greatest closed caption ever. RT @isaach: http://t.co/PF8OP5AYFp",
    "id" : 325406217956622337,
    "created_at" : "Sat Apr 20 00:31:02 +0000 2013",
    "user" : {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "protected" : false,
      "id_str" : "22745680",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1771642433/image1327185038_normal.png",
      "id" : 22745680,
      "verified" : false
    }
  },
  "id" : 325414678756986880,
  "created_at" : "Sat Apr 20 01:04:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Police Dept.",
      "screen_name" : "Boston_Police",
      "indices" : [ 3, 17 ],
      "id_str" : "19185333",
      "id" : 19185333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325413715010793472",
  "text" : "RT @Boston_Police: CAPTURED!!! The hunt is over. The search is done. The terror is over. And justice has won. Suspect in custody.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325413032110989313",
    "text" : "CAPTURED!!! The hunt is over. The search is done. The terror is over. And justice has won. Suspect in custody.",
    "id" : 325413032110989313,
    "created_at" : "Sat Apr 20 00:58:07 +0000 2013",
    "user" : {
      "name" : "Boston Police Dept.",
      "screen_name" : "Boston_Police",
      "protected" : false,
      "id_str" : "19185333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/72731279/coin_boston_normal.jpg",
      "id" : 19185333,
      "verified" : true
    }
  },
  "id" : 325413715010793472,
  "created_at" : "Sat Apr 20 01:00:50 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325411943345184768",
  "text" : "There will be convos about the cost of 4/19 manhunt, but there's something invaluable about a city that will shut itself down for justice.",
  "id" : 325411943345184768,
  "created_at" : "Sat Apr 20 00:53:47 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Brennan",
      "screen_name" : "bjp",
      "indices" : [ 3, 7 ],
      "id_str" : "431330888",
      "id" : 431330888
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325411124331814912",
  "text" : "RT @bjp: The new 4/20: Buy your heros a beer day. #BostonStrong",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BostonStrong",
        "indices" : [ 41, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325410940763914240",
    "text" : "The new 4/20: Buy your heros a beer day. #BostonStrong",
    "id" : 325410940763914240,
    "created_at" : "Sat Apr 20 00:49:48 +0000 2013",
    "user" : {
      "name" : "John Brennan",
      "screen_name" : "bjp",
      "protected" : false,
      "id_str" : "431330888",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2718571123/d07931c68e369df48615f8c7c6821a7b_normal.png",
      "id" : 431330888,
      "verified" : false
    }
  },
  "id" : 325411124331814912,
  "created_at" : "Sat Apr 20 00:50:32 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Dreben",
      "screen_name" : "Double_Drebble",
      "indices" : [ 0, 15 ],
      "id_str" : "1240021650",
      "id" : 1240021650
    }, {
      "name" : "Jeff Solnet",
      "screen_name" : "jfsolnet",
      "indices" : [ 16, 25 ],
      "id_str" : "24945651",
      "id" : 24945651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325404359456354304",
  "geo" : {
  },
  "id_str" : "325408230744403968",
  "in_reply_to_user_id" : 1240021650,
  "text" : "@Double_Drebble @jfsolnet yea, it's not really advertised but all the processes are in place so if you take initiative it's totally doable.",
  "id" : 325408230744403968,
  "in_reply_to_status_id" : 325404359456354304,
  "created_at" : "Sat Apr 20 00:39:02 +0000 2013",
  "in_reply_to_screen_name" : "Double_Drebble",
  "in_reply_to_user_id_str" : "1240021650",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Dreben",
      "screen_name" : "Double_Drebble",
      "indices" : [ 0, 15 ],
      "id_str" : "1240021650",
      "id" : 1240021650
    }, {
      "name" : "Jeff Solnet",
      "screen_name" : "jfsolnet",
      "indices" : [ 16, 25 ],
      "id_str" : "24945651",
      "id" : 24945651
    }, {
      "name" : "Harvard GSD",
      "screen_name" : "HarvardGSD",
      "indices" : [ 84, 95 ],
      "id_str" : "19272669",
      "id" : 19272669
    }, {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 100, 109 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325387915603636224",
  "geo" : {
  },
  "id_str" : "325400898773872640",
  "in_reply_to_user_id" : 1240021650,
  "text" : "@Double_Drebble @jfsolnet there's no official design track but you can cross reg at @HarvardGSD and @medialab for design - highly rec.",
  "id" : 325400898773872640,
  "in_reply_to_status_id" : 325387915603636224,
  "created_at" : "Sat Apr 20 00:09:54 +0000 2013",
  "in_reply_to_screen_name" : "Double_Drebble",
  "in_reply_to_user_id_str" : "1240021650",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "indices" : [ 3, 11 ],
      "id_str" : "184543773",
      "id" : 184543773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vi",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325353325438566402",
  "text" : "RT @stat110: Dear Harvard 2017, I look forward to meeting you under better circumstances. Meanwhile, feel free to ask me any questions. #vi\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "virtualvisitas",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325339064096157697",
    "text" : "Dear Harvard 2017, I look forward to meeting you under better circumstances. Meanwhile, feel free to ask me any questions. #virtualvisitas",
    "id" : 325339064096157697,
    "created_at" : "Fri Apr 19 20:04:12 +0000 2013",
    "user" : {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "protected" : false,
      "id_str" : "184543773",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1360113908/Stat110Picture_normal.jpg",
      "id" : 184543773,
      "verified" : false
    }
  },
  "id" : 325353325438566402,
  "created_at" : "Fri Apr 19 21:00:52 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 63, 75 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Jeff Solnet",
      "screen_name" : "jfsolnet",
      "indices" : [ 80, 89 ],
      "id_str" : "24945651",
      "id" : 24945651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Visitas2013",
      "indices" : [ 106, 118 ]
    }, {
      "text" : "virtualvisitas",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325352323197063168",
  "text" : "Hey '17, feel free to ask any q's! I was '12, Mather roomies w @badboyboyce and @jfsolnet, and CS/design. #Visitas2013 #virtualvisitas",
  "id" : 325352323197063168,
  "created_at" : "Fri Apr 19 20:56:53 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 3, 19 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325326547135369216",
  "text" : "RT @fivethirtyeight: Can't wait til they catch the bastard, but it's valid to inquire about the tangible and intangible costs of shutting a\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325325170531262464",
    "text" : "Can't wait til they catch the bastard, but it's valid to inquire about the tangible and intangible costs of shutting a whole city down.",
    "id" : 325325170531262464,
    "created_at" : "Fri Apr 19 19:08:59 +0000 2013",
    "user" : {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "protected" : false,
      "id_str" : "16017475",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1110592135/fivethirtyeight73_twitter_normal.png",
      "id" : 16017475,
      "verified" : true
    }
  },
  "id" : 325326547135369216,
  "created_at" : "Fri Apr 19 19:14:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 10, 21 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/thecrimson/status/325264239000420352/photo/1",
      "indices" : [ 97, 119 ],
      "url" : "http://t.co/naYXYAtY3o",
      "media_url" : "http://pbs.twimg.com/media/BIOSGiACAAIGwsw.jpg",
      "id_str" : "325264239004614658",
      "id" : 325264239004614658,
      "media_url_https" : "https://pbs.twimg.com/media/BIOSGiACAAIGwsw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 619
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 619
      } ],
      "display_url" : "pic.twitter.com/naYXYAtY3o"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http://t.co/xMSApXD6f1",
      "expanded_url" : "http://ow.ly/kea67",
      "display_url" : "ow.ly/kea67"
    } ]
  },
  "in_reply_to_status_id_str" : "325264239000420352",
  "geo" : {
  },
  "id_str" : "325274988997386241",
  "in_reply_to_user_id" : 16626603,
  "text" : "Surreal. \u201C@thecrimson: Harvard Square on lockdown. See full photo gallery:http://t.co/xMSApXD6f1 http://t.co/naYXYAtY3o\u201D",
  "id" : 325274988997386241,
  "in_reply_to_status_id" : 325264239000420352,
  "created_at" : "Fri Apr 19 15:49:35 +0000 2013",
  "in_reply_to_screen_name" : "thecrimson",
  "in_reply_to_user_id_str" : "16626603",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS News",
      "screen_name" : "CBSNews",
      "indices" : [ 1, 9 ],
      "id_str" : "15012486",
      "id" : 15012486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325239208413384706",
  "geo" : {
  },
  "id_str" : "325264474430906369",
  "in_reply_to_user_id" : 15012486,
  "text" : "\u201C@CBSNews: UPDATE: Boston Police are asking social media users not to post information they hear on police frequencies/scanner channels.\u201D",
  "id" : 325264474430906369,
  "in_reply_to_status_id" : 325239208413384706,
  "created_at" : "Fri Apr 19 15:07:48 +0000 2013",
  "in_reply_to_screen_name" : "CBSNews",
  "in_reply_to_user_id_str" : "15012486",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "indices" : [ 3, 19 ],
      "id_str" : "353789193",
      "id" : 353789193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325263500236689411",
  "text" : "RT @StartupLJackson: Reddit was wrong?!?! I need some time to internalize this shit.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325245405967306752",
    "text" : "Reddit was wrong?!?! I need some time to internalize this shit.",
    "id" : 325245405967306752,
    "created_at" : "Fri Apr 19 13:52:02 +0000 2013",
    "user" : {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "protected" : false,
      "id_str" : "353789193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1491792938/Screen_shot_2011-08-12_at_9.54.22_AM_normal.png",
      "id" : 353789193,
      "verified" : false
    }
  },
  "id" : 325263500236689411,
  "created_at" : "Fri Apr 19 15:03:56 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joi Ito",
      "screen_name" : "Joi",
      "indices" : [ 24, 28 ],
      "id_str" : "691353",
      "id" : 691353
    }, {
      "name" : "MIT News",
      "screen_name" : "MITnews",
      "indices" : [ 128, 136 ],
      "id_str" : "1380107316",
      "id" : 1380107316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http://t.co/vmtwVri2ks",
      "expanded_url" : "http://mitne.ws/14BJefz",
      "display_url" : "mitne.ws/14BJefz"
    } ]
  },
  "in_reply_to_status_id_str" : "325254691510444032",
  "geo" : {
  },
  "id_str" : "325262277748068352",
  "in_reply_to_user_id" : 691353,
  "text" : "He was so young... RIP \u201C@Joi: MIT officer killed in the line of duty identified as Sean Collier, 26 http://t.co/vmtwVri2ks (via @MITnews)\u201D",
  "id" : 325262277748068352,
  "in_reply_to_status_id" : 325254691510444032,
  "created_at" : "Fri Apr 19 14:59:04 +0000 2013",
  "in_reply_to_screen_name" : "Joi",
  "in_reply_to_user_id_str" : "691353",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Mnookin",
      "screen_name" : "sethmnookin",
      "indices" : [ 3, 15 ],
      "id_str" : "22931893",
      "id" : 22931893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325137536106242048",
  "text" : "RT @sethmnookin: This is classic I'd rather be late and right scenario. It doesn't matter who's first by five minutes; it does matter if ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325136364737814528",
    "text" : "This is classic I'd rather be late and right scenario. It doesn't matter who's first by five minutes; it does matter if bad info given out.",
    "id" : 325136364737814528,
    "created_at" : "Fri Apr 19 06:38:44 +0000 2013",
    "user" : {
      "name" : "Seth Mnookin",
      "screen_name" : "sethmnookin",
      "protected" : false,
      "id_str" : "22931893",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2895645801/d556ecf78b6c4483f4d2856836d8a09f_normal.png",
      "id" : 22931893,
      "verified" : false
    }
  },
  "id" : 325137536106242048,
  "created_at" : "Fri Apr 19 06:43:24 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https://t.co/URPqMN0NG9",
      "expanded_url" : "https://itun.es/us/RA2XC.i",
      "display_url" : "itun.es/us/RA2XC.i"
    } ]
  },
  "geo" : {
  },
  "id_str" : "325137372473868288",
  "text" : "Mobile users: there are police scanner apps if you are unable to connect to web streams. Confirm this one working. https://t.co/URPqMN0NG9",
  "id" : 325137372473868288,
  "created_at" : "Fri Apr 19 06:42:45 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http://t.co/hxo4QtxQM0",
      "expanded_url" : "http://www.broadcastify.com/listen/feed/6254/web",
      "display_url" : "broadcastify.com/listen/feed/62\u2026"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http://t.co/ZJkG1lGXnj",
      "expanded_url" : "http://tunein.com/station/?StationId=146109",
      "display_url" : "tunein.com/station/?Stati\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "325135967394598912",
  "text" : "Both struggling under traffic, but Boston police scanners available here: http://t.co/hxo4QtxQM0 and http://t.co/ZJkG1lGXnj",
  "id" : 325135967394598912,
  "created_at" : "Fri Apr 19 06:37:10 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Solnet",
      "screen_name" : "jfsolnet",
      "indices" : [ 0, 9 ],
      "id_str" : "24945651",
      "id" : 24945651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325133187342798848",
  "geo" : {
  },
  "id_str" : "325133493069815809",
  "in_reply_to_user_id" : 24945651,
  "text" : "@jfsolnet I hope so too... It's been a week of hell but at least it's not years of frustrated searching. Fingers crossed.",
  "id" : 325133493069815809,
  "in_reply_to_status_id" : 325133187342798848,
  "created_at" : "Fri Apr 19 06:27:20 +0000 2013",
  "in_reply_to_screen_name" : "jfsolnet",
  "in_reply_to_user_id_str" : "24945651",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Plait",
      "screen_name" : "BadAstronomer",
      "indices" : [ 3, 17 ],
      "id_str" : "4620451",
      "id" : 4620451
    }, {
      "name" : "Maryn McKenna",
      "screen_name" : "marynmck",
      "indices" : [ 34, 43 ],
      "id_str" : "15684633",
      "id" : 15684633
    }, {
      "name" : "Jennifer Ouellette",
      "screen_name" : "JenLucPiquant",
      "indices" : [ 89, 103 ],
      "id_str" : "128292609",
      "id" : 128292609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325129907363524608",
  "text" : "RT @BadAstronomer: Science writer @marynmck is transcribing police scanner reports. /via @JenLucPiquant",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maryn McKenna",
        "screen_name" : "marynmck",
        "indices" : [ 15, 24 ],
        "id_str" : "15684633",
        "id" : 15684633
      }, {
        "name" : "Jennifer Ouellette",
        "screen_name" : "JenLucPiquant",
        "indices" : [ 70, 84 ],
        "id_str" : "128292609",
        "id" : 128292609
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325129407872266240",
    "text" : "Science writer @marynmck is transcribing police scanner reports. /via @JenLucPiquant",
    "id" : 325129407872266240,
    "created_at" : "Fri Apr 19 06:11:06 +0000 2013",
    "user" : {
      "name" : "Phil Plait",
      "screen_name" : "BadAstronomer",
      "protected" : false,
      "id_str" : "4620451",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2841958952/70b39e0e3fb8bd9c7977d544b59d77fa_normal.png",
      "id" : 4620451,
      "verified" : true
    }
  },
  "id" : 325129907363524608,
  "created_at" : "Fri Apr 19 06:13:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 3, 9 ],
      "id_str" : "17856596",
      "id" : 17856596
    }, {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 96, 101 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http://t.co/q06FIqwJYS",
      "expanded_url" : "http://www.broadcastify.com/listen/feed/6254/web",
      "display_url" : "broadcastify.com/listen/feed/62\u2026"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http://t.co/snzHVZTqyH",
      "expanded_url" : "http://tunein.com/station/?StationId=146109",
      "display_url" : "tunein.com/station/?Stati\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "325125902591741952",
  "text" : "RT @Wayne: Listen to the scanner (2 links): http://t.co/q06FIqwJYS http://t.co/snzHVZTqyH // cc @kane",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kane",
        "screen_name" : "kane",
        "indices" : [ 85, 90 ],
        "id_str" : "19380775",
        "id" : 19380775
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http://t.co/q06FIqwJYS",
        "expanded_url" : "http://www.broadcastify.com/listen/feed/6254/web",
        "display_url" : "broadcastify.com/listen/feed/62\u2026"
      }, {
        "indices" : [ 56, 78 ],
        "url" : "http://t.co/snzHVZTqyH",
        "expanded_url" : "http://tunein.com/station/?StationId=146109",
        "display_url" : "tunein.com/station/?Stati\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "325125527897772032",
    "text" : "Listen to the scanner (2 links): http://t.co/q06FIqwJYS http://t.co/snzHVZTqyH // cc @kane",
    "id" : 325125527897772032,
    "created_at" : "Fri Apr 19 05:55:41 +0000 2013",
    "user" : {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "protected" : false,
      "id_str" : "17856596",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3472053434/8cecfad95a11c1f1ede129b33c0b4fef_normal.jpeg",
      "id" : 17856596,
      "verified" : false
    }
  },
  "id" : 325125902591741952,
  "created_at" : "Fri Apr 19 05:57:10 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 0, 6 ],
      "id_str" : "17856596",
      "id" : 17856596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325124831941111809",
  "geo" : {
  },
  "id_str" : "325125033745866752",
  "in_reply_to_user_id" : 17856596,
  "text" : "@Wayne thanks. Appreciate you being on top of news this past terrible week.",
  "id" : 325125033745866752,
  "in_reply_to_status_id" : 325124831941111809,
  "created_at" : "Fri Apr 19 05:53:43 +0000 2013",
  "in_reply_to_screen_name" : "Wayne",
  "in_reply_to_user_id_str" : "17856596",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Chang",
      "screen_name" : "Wayne",
      "indices" : [ 0, 6 ],
      "id_str" : "17856596",
      "id" : 17856596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http://t.co/20KK9sVEEL",
      "expanded_url" : "http://tun.in/seU6F",
      "display_url" : "tun.in/seU6F"
    } ]
  },
  "in_reply_to_status_id_str" : "325124014416752640",
  "geo" : {
  },
  "id_str" : "325124292851425280",
  "in_reply_to_user_id" : 17856596,
  "text" : "@Wayne please pass along the scanner link, not just hearsay... Misinformation is damaging. http://t.co/20KK9sVEEL",
  "id" : 325124292851425280,
  "in_reply_to_status_id" : 325124014416752640,
  "created_at" : "Fri Apr 19 05:50:46 +0000 2013",
  "in_reply_to_screen_name" : "Wayne",
  "in_reply_to_user_id_str" : "17856596",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Stites",
      "screen_name" : "AdamBCC",
      "indices" : [ 3, 11 ],
      "id_str" : "32626866",
      "id" : 32626866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325123805188075520",
  "text" : "RT @AdamBCC: So we got 4chan and Reddit doing full criminal investigations and Twitter doing full media coverage. Welcome to 2013, every ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "325119085987905536",
    "text" : "So we got 4chan and Reddit doing full criminal investigations and Twitter doing full media coverage. Welcome to 2013, everybody.",
    "id" : 325119085987905536,
    "created_at" : "Fri Apr 19 05:30:05 +0000 2013",
    "user" : {
      "name" : "Adam Stites",
      "screen_name" : "AdamBCC",
      "protected" : false,
      "id_str" : "32626866",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3610126581/85adca3c7883caa4379011e5c9e831e0_normal.png",
      "id" : 32626866,
      "verified" : false
    }
  },
  "id" : 325123805188075520,
  "created_at" : "Fri Apr 19 05:48:50 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 125, 136 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http://t.co/20KK9sVEEL",
      "expanded_url" : "http://tun.in/seU6F",
      "display_url" : "tun.in/seU6F"
    } ]
  },
  "in_reply_to_status_id_str" : "325122781261996032",
  "geo" : {
  },
  "id_str" : "325123154232090624",
  "in_reply_to_user_id" : 21160381,
  "text" : "Alternative link to police scanner for Bos shootout. Pass the link along, not just transcript plz. http://t.co/20KK9sVEEL cc @tomloverro",
  "id" : 325123154232090624,
  "in_reply_to_status_id" : 325122781261996032,
  "created_at" : "Fri Apr 19 05:46:15 +0000 2013",
  "in_reply_to_screen_name" : "tomloverro",
  "in_reply_to_user_id_str" : "21160381",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/v84CreoX7E",
      "expanded_url" : "http://www.broadcastify.com/listen/ctid/1221",
      "display_url" : "broadcastify.com/listen/ctid/12\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "325122455142285312",
  "text" : "It's really not productive for everyone to be tweeting and RT'ing the police scanner... Once again, scanner is here: http://t.co/v84CreoX7E",
  "id" : 325122455142285312,
  "created_at" : "Fri Apr 19 05:43:28 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Police Dept.",
      "screen_name" : "Boston_Police",
      "indices" : [ 82, 96 ],
      "id_str" : "19185333",
      "id" : 19185333
    }, {
      "name" : "Cambridge Police",
      "screen_name" : "CambridgePolice",
      "indices" : [ 101, 117 ],
      "id_str" : "157799302",
      "id" : 157799302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325112118414303234",
  "text" : "A reminder not to wantonly RT stuff lest it lead to irresponsible rumor... Follow @Boston_Police and @CambridgePolice for news.",
  "id" : 325112118414303234,
  "created_at" : "Fri Apr 19 05:02:23 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge Police",
      "screen_name" : "CambridgePolice",
      "indices" : [ 3, 19 ],
      "id_str" : "157799302",
      "id" : 157799302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIT",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "325101347072524289",
  "text" : "RT @CambridgePolice: Our thoughts &amp; prayers are with the officer's family &amp; our brothers &amp; sisters at the #MIT Police http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MIT",
        "indices" : [ 97, 101 ]
      }, {
        "text" : "CambMA",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http://t.co/3Yi0Rr8pof",
        "expanded_url" : "http://ow.ly/1VkTrW",
        "display_url" : "ow.ly/1VkTrW"
      } ]
    },
    "geo" : {
    },
    "id_str" : "325101241149566976",
    "text" : "Our thoughts &amp; prayers are with the officer's family &amp; our brothers &amp; sisters at the #MIT Police http://t.co/3Yi0Rr8pof #CambMA",
    "id" : 325101241149566976,
    "created_at" : "Fri Apr 19 04:19:10 +0000 2013",
    "user" : {
      "name" : "Cambridge Police",
      "screen_name" : "CambridgePolice",
      "protected" : false,
      "id_str" : "157799302",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3592040695/c66865d1561f0d6fd99b91bc16fce266_normal.png",
      "id" : 157799302,
      "verified" : true
    }
  },
  "id" : 325101347072524289,
  "created_at" : "Fri Apr 19 04:19:35 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 0, 11 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324996804280205312",
  "geo" : {
  },
  "id_str" : "325020457772388352",
  "in_reply_to_user_id" : 21160381,
  "text" : "@tomloverro but the default iOS app already supports other cities!",
  "id" : 325020457772388352,
  "in_reply_to_status_id" : 324996804280205312,
  "created_at" : "Thu Apr 18 22:58:10 +0000 2013",
  "in_reply_to_screen_name" : "tomloverro",
  "in_reply_to_user_id_str" : "21160381",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "indices" : [ 27, 37 ],
      "id_str" : "13369702",
      "id" : 13369702
    }, {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 42, 49 ],
      "id_str" : "9544202",
      "id" : 9544202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http://t.co/F19FtVGHTJ",
      "expanded_url" : "http://betabeat.com/pitch/the-pitch-season-2-episode-one-doppelhanger-real-fashion-inspiration-for-real-ladies/",
      "display_url" : "betabeat.com/pitch/the-pitc\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "324996479615901696",
  "text" : "Ahaha excellent showing by @NikhilKal and @schlaf. When are you guys getting syndicated? http://t.co/F19FtVGHTJ",
  "id" : 324996479615901696,
  "created_at" : "Thu Apr 18 21:22:53 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AircraftTalking",
      "screen_name" : "AircraftTalking",
      "indices" : [ 44, 60 ],
      "id_str" : "827765124",
      "id" : 827765124
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/AircraftTalking/status/324991218629111808/photo/1",
      "indices" : [ 116, 138 ],
      "url" : "http://t.co/GjpP1shGGB",
      "media_url" : "http://pbs.twimg.com/media/BIKZyp4CcAAO6vS.jpg",
      "id_str" : "324991218637500416",
      "id" : 324991218637500416,
      "media_url_https" : "https://pbs.twimg.com/media/BIKZyp4CcAAO6vS.jpg",
      "sizes" : [ {
        "h" : 635,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 635,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com/GjpP1shGGB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324991218629111808",
  "geo" : {
  },
  "id_str" : "324995623290028032",
  "in_reply_to_user_id" : 827765124,
  "text" : "Timeless. Can't believe it's been decades. \u201C@AircraftTalking: Pic of the one of the most beautiful prototypes ever. http://t.co/GjpP1shGGB\u201D",
  "id" : 324995623290028032,
  "in_reply_to_status_id" : 324991218629111808,
  "created_at" : "Thu Apr 18 21:19:29 +0000 2013",
  "in_reply_to_screen_name" : "AircraftTalking",
  "in_reply_to_user_id_str" : "827765124",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "324994752154050560",
  "text" : "Can someone explain the compelling need for an iOS weather app when there's built in forecasting in the pull down tray?",
  "id" : 324994752154050560,
  "created_at" : "Thu Apr 18 21:16:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Music",
      "screen_name" : "TwitterMusic",
      "indices" : [ 54, 67 ],
      "id_str" : "373471064",
      "id" : 373471064
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/324971096573112320/photo/1",
      "indices" : [ 94, 116 ],
      "url" : "http://t.co/mLKdLaLRbN",
      "media_url" : "http://pbs.twimg.com/media/BIKHfZYCcAAy6Ns.jpg",
      "id_str" : "324971096581500928",
      "id" : 324971096581500928,
      "media_url_https" : "https://pbs.twimg.com/media/BIKHfZYCcAAy6Ns.jpg",
      "sizes" : [ {
        "h" : 1050,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1050,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/mLKdLaLRbN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "324971096573112320",
  "text" : "I haven't seen the Fail Whale in a while. I wonder if @twittermusic is straining the servers? http://t.co/mLKdLaLRbN",
  "id" : 324971096573112320,
  "created_at" : "Thu Apr 18 19:42:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 4, 13 ],
      "id_str" : "13982132",
      "id" : 13982132
    }, {
      "name" : "dhairya dand",
      "screen_name" : "3dee",
      "indices" : [ 66, 71 ],
      "id_str" : "15045759",
      "id" : 15045759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http://t.co/hhO1dq6GAR",
      "expanded_url" : "http://vimeo.com/63494095#",
      "display_url" : "vimeo.com/63494095#"
    } ]
  },
  "geo" : {
  },
  "id_str" : "324910855575711744",
  "text" : "The @medialab never fails to amaze... amazing touchscreen tech by @3dee: http://t.co/hhO1dq6GAR",
  "id" : 324910855575711744,
  "created_at" : "Thu Apr 18 15:42:39 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Music",
      "screen_name" : "TwitterMusic",
      "indices" : [ 3, 16 ],
      "id_str" : "373471064",
      "id" : 373471064
    }, {
      "name" : "Mystery Man",
      "screen_name" : "spotfy",
      "indices" : [ 48, 55 ],
      "id_str" : "321358072",
      "id" : 321358072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "324906223805804544",
  "text" : "My @TwitterMusic account is running just fine w @spotfy but I'm hearing that a lot of accounts aren't syncing properly.",
  "id" : 324906223805804544,
  "created_at" : "Thu Apr 18 15:24:14 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 11, 20 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "324745749680230400",
  "text" : "Loving the @LinkedIn app redesign -modern interface and much smoother experience.",
  "id" : 324745749680230400,
  "created_at" : "Thu Apr 18 04:46:34 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Police Dept.",
      "screen_name" : "Boston_Police",
      "indices" : [ 31, 45 ],
      "id_str" : "19185333",
      "id" : 19185333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324591574807891968",
  "geo" : {
  },
  "id_str" : "324600582352539648",
  "in_reply_to_user_id" : 19185333,
  "text" : "The problem w digital news... \u201C@Boston_Police: Despite reports to the contrary there has not been an arrest in the Marathon attack.\u201D",
  "id" : 324600582352539648,
  "in_reply_to_status_id" : 324591574807891968,
  "created_at" : "Wed Apr 17 19:09:44 +0000 2013",
  "in_reply_to_screen_name" : "Boston_Police",
  "in_reply_to_user_id_str" : "19185333",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Watson",
      "screen_name" : "bwats",
      "indices" : [ 0, 6 ],
      "id_str" : "18500786",
      "id" : 18500786
    }, {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 7, 17 ],
      "id_str" : "22745680",
      "id" : 22745680
    }, {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 31, 39 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324548446235291649",
  "geo" : {
  },
  "id_str" : "324550617727127552",
  "in_reply_to_user_id" : 18500786,
  "text" : "@bwats @besvinick don't forget @vineapp",
  "id" : 324550617727127552,
  "in_reply_to_status_id" : 324548446235291649,
  "created_at" : "Wed Apr 17 15:51:11 +0000 2013",
  "in_reply_to_screen_name" : "bwats",
  "in_reply_to_user_id_str" : "18500786",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cassie zhang",
      "screen_name" : "thinkblots",
      "indices" : [ 81, 92 ],
      "id_str" : "30731836",
      "id" : 30731836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facepalm",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http://t.co/l9XK5W6MQp",
      "expanded_url" : "http://www.businessinsider.com/thomas-herndon-michael-ash-and-robert-pollin-on-reinhart-and-rogoff-2013-4",
      "display_url" : "businessinsider.com/thomas-herndon\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "324368804064940032",
  "geo" : {
  },
  "id_str" : "324385907576827904",
  "in_reply_to_user_id" : 30731836,
  "text" : "Excel error potentially nullifies results of highly cited econ paper. #facepalm \u201C@thinkblots: LOL. http://t.co/l9XK5W6MQp\u201D",
  "id" : 324385907576827904,
  "in_reply_to_status_id" : 324368804064940032,
  "created_at" : "Wed Apr 17 04:56:41 +0000 2013",
  "in_reply_to_screen_name" : "thinkblots",
  "in_reply_to_user_id_str" : "30731836",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Password",
      "screen_name" : "1Password",
      "indices" : [ 56, 66 ],
      "id_str" : "793926",
      "id" : 793926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "324260016267874305",
  "text" : "Finally getting around to migrating account security to @1Password. Never realized how many passwords I actually had...",
  "id" : 324260016267874305,
  "created_at" : "Tue Apr 16 20:36:26 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 0, 8 ],
      "id_str" : "38399009",
      "id" : 38399009
    }, {
      "name" : "Blossom Coffee",
      "screen_name" : "BlossomCoffee",
      "indices" : [ 16, 30 ],
      "id_str" : "368542213",
      "id" : 368542213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324211519967596545",
  "geo" : {
  },
  "id_str" : "324214203177119744",
  "in_reply_to_user_id" : 38399009,
  "text" : "@bznotes was it @BlossomCoffee? They make an excellent coffee machine.",
  "id" : 324214203177119744,
  "in_reply_to_status_id" : 324211519967596545,
  "created_at" : "Tue Apr 16 17:34:24 +0000 2013",
  "in_reply_to_screen_name" : "bznotes",
  "in_reply_to_user_id_str" : "38399009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Middlebrooks",
      "screen_name" : "middlebrooks",
      "indices" : [ 33, 46 ],
      "id_str" : "334232372",
      "id" : 334232372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324153581152378881",
  "geo" : {
  },
  "id_str" : "324165933000183808",
  "in_reply_to_user_id" : 334232372,
  "text" : "Even as a Sabres fan, Godspeed. \u201C@middlebrooks: I can't wait to put on my jersey today... I get to play for the strongest city out there.\u201D",
  "id" : 324165933000183808,
  "in_reply_to_status_id" : 324153581152378881,
  "created_at" : "Tue Apr 16 14:22:35 +0000 2013",
  "in_reply_to_screen_name" : "middlebrooks",
  "in_reply_to_user_id_str" : "334232372",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Cannon",
      "screen_name" : "CarlCannon",
      "indices" : [ 22, 33 ],
      "id_str" : "103447346",
      "id" : 103447346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/JKfyRvkZSt",
      "expanded_url" : "http://bit.ly/OGyp2x",
      "display_url" : "bit.ly/OGyp2x"
    } ]
  },
  "in_reply_to_status_id_str" : "323989971226742786",
  "geo" : {
  },
  "id_str" : "324015113935912960",
  "in_reply_to_user_id" : 103447346,
  "text" : "Suck it, terrorists. \u201C@CarlCannon: Runner knocked down by bomb is 78-yr-old Bill Iffrig. He got up and finished: http://t.co/JKfyRvkZSt\u201D",
  "id" : 324015113935912960,
  "in_reply_to_status_id" : 323989971226742786,
  "created_at" : "Tue Apr 16 04:23:17 +0000 2013",
  "in_reply_to_screen_name" : "CarlCannon",
  "in_reply_to_user_id_str" : "103447346",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "324011508352839680",
  "text" : "For every person injured or killed in Boston today, dozens rushed in to help. That is why we cannot lose.",
  "id" : 324011508352839680,
  "created_at" : "Tue Apr 16 04:08:58 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ford",
      "screen_name" : "HemlockMartinis",
      "indices" : [ 3, 19 ],
      "id_str" : "26559241",
      "id" : 26559241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "323988868636495873",
  "text" : "RT @HemlockMartinis: Worth noting that the last time someone pissed off Boston, the British Empire lost most of its territory in North A ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "323981430789136384",
    "text" : "Worth noting that the last time someone pissed off Boston, the British Empire lost most of its territory in North America.",
    "id" : 323981430789136384,
    "created_at" : "Tue Apr 16 02:09:27 +0000 2013",
    "user" : {
      "name" : "Matt Ford",
      "screen_name" : "HemlockMartinis",
      "protected" : false,
      "id_str" : "26559241",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3448912442/b215ff08b354825cbb688fe50f4e6d3b_normal.jpeg",
      "id" : 26559241,
      "verified" : false
    }
  },
  "id" : 323988868636495873,
  "created_at" : "Tue Apr 16 02:39:00 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JFK Library",
      "screen_name" : "JFKLibrary",
      "indices" : [ 32, 43 ],
      "id_str" : "32520240",
      "id" : 32520240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323894491075444736",
  "geo" : {
  },
  "id_str" : "323906479579090945",
  "in_reply_to_user_id" : 32520240,
  "text" : "Concise, calm reporting. Thnx. \u201C@JFKLibrary: Fire in building is out, appears to have started in the mechanical room of new building.\"",
  "id" : 323906479579090945,
  "in_reply_to_status_id" : 323894491075444736,
  "created_at" : "Mon Apr 15 21:11:37 +0000 2013",
  "in_reply_to_screen_name" : "JFKLibrary",
  "in_reply_to_user_id_str" : "32520240",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Chang",
      "screen_name" : "emilychangtv",
      "indices" : [ 1, 14 ],
      "id_str" : "74130577",
      "id" : 74130577
    }, {
      "name" : "Associated Press",
      "screen_name" : "AssociatedPress",
      "indices" : [ 80, 96 ],
      "id_str" : "49304503",
      "id" : 49304503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323903300007231488",
  "geo" : {
  },
  "id_str" : "323903691407097856",
  "in_reply_to_user_id" : 74130577,
  "text" : "\u201C@emilychangtv: Boston cell service shut down to prevent remote detonations via @AssociatedPress\u201D",
  "id" : 323903691407097856,
  "in_reply_to_status_id" : 323903300007231488,
  "created_at" : "Mon Apr 15 21:00:32 +0000 2013",
  "in_reply_to_screen_name" : "emilychangtv",
  "in_reply_to_user_id_str" : "74130577",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NowThis News",
      "screen_name" : "nowthisnews",
      "indices" : [ 3, 15 ],
      "id_str" : "701725963",
      "id" : 701725963
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonMarathon",
      "indices" : [ 68, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http://t.co/jnejLHmg6b",
      "expanded_url" : "http://nowth.is/117VE7p",
      "display_url" : "nowth.is/117VE7p"
    } ]
  },
  "geo" : {
  },
  "id_str" : "323903295829721088",
  "text" : "RT @nowthisnews: Google has launched a \u201Cperson finder\u201D page for the #BostonMarathon tragedy. Share widely: http://t.co/jnejLHmg6b",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BostonMarathon",
        "indices" : [ 51, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http://t.co/jnejLHmg6b",
        "expanded_url" : "http://nowth.is/117VE7p",
        "display_url" : "nowth.is/117VE7p"
      } ]
    },
    "geo" : {
    },
    "id_str" : "323901769635725313",
    "text" : "Google has launched a \u201Cperson finder\u201D page for the #BostonMarathon tragedy. Share widely: http://t.co/jnejLHmg6b",
    "id" : 323901769635725313,
    "created_at" : "Mon Apr 15 20:52:54 +0000 2013",
    "user" : {
      "name" : "NowThis News",
      "screen_name" : "nowthisnews",
      "protected" : false,
      "id_str" : "701725963",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3443505030/b17e770871f33cd8349084bd0b456d67_normal.png",
      "id" : 701725963,
      "verified" : true
    }
  },
  "id" : 323903295829721088,
  "created_at" : "Mon Apr 15 20:58:58 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitchyTeam",
      "screen_name" : "TwitchyTeam",
      "indices" : [ 15, 27 ],
      "id_str" : "469194846",
      "id" : 469194846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/Xp8yTkTM01",
      "expanded_url" : "http://bit.ly/12gqyOW",
      "display_url" : "bit.ly/12gqyOW"
    } ]
  },
  "in_reply_to_status_id_str" : "323902021860225028",
  "geo" : {
  },
  "id_str" : "323903101528592384",
  "in_reply_to_user_id" : 469194846,
  "text" : "This is sick. \u201C@TwitchyTeam: Fake Twitter accounts already soliciting 'donations' for victims of Boston explosions http://t.co/Xp8yTkTM01\u201D",
  "id" : 323903101528592384,
  "in_reply_to_status_id" : 323902021860225028,
  "created_at" : "Mon Apr 15 20:58:11 +0000 2013",
  "in_reply_to_screen_name" : "TwitchyTeam",
  "in_reply_to_user_id_str" : "469194846",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthea Watson Strong",
      "screen_name" : "antheaws",
      "indices" : [ 1, 10 ],
      "id_str" : "15018709",
      "id" : 15018709
    } ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/BGlobeSports/status/323889004246343681/photo/1",
      "indices" : [ 76, 99 ],
      "url" : "https://t.co/tMjoKlKrwO",
      "media_url" : "http://pbs.twimg.com/media/BH6vVVWCIAIK4Q7.jpg",
      "id_str" : "323889004258926594",
      "id" : 323889004258926594,
      "media_url_https" : "https://pbs.twimg.com/media/BH6vVVWCIAIK4Q7.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 723,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2267,
        "resize" : "fit",
        "w" : 3212
      } ],
      "display_url" : "pic.twitter.com/tMjoKlKrwO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323892397190815744",
  "geo" : {
  },
  "id_str" : "323893184176459777",
  "in_reply_to_user_id" : 15018709,
  "text" : "\u201C@antheaws: The picture that defines the moment.  Boston first responders.  https://t.co/tMjoKlKrwO\u201D",
  "id" : 323893184176459777,
  "in_reply_to_status_id" : 323892397190815744,
  "created_at" : "Mon Apr 15 20:18:47 +0000 2013",
  "in_reply_to_screen_name" : "antheaws",
  "in_reply_to_user_id_str" : "15018709",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge Police",
      "screen_name" : "CambridgePolice",
      "indices" : [ 3, 19 ],
      "id_str" : "157799302",
      "id" : 157799302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CambMA",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "323892963128254464",
  "text" : "RT @CambridgePolice: 16:00 Report of possible INCIDENT/BOMBS/THREATS at BRATTLE ST &amp; FARWELL PL in #CambMA",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.cambridgepolice.org\" rel=\"nofollow\">PDRMS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CambMA",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "323890976701685760",
    "text" : "16:00 Report of possible INCIDENT/BOMBS/THREATS at BRATTLE ST &amp; FARWELL PL in #CambMA",
    "id" : 323890976701685760,
    "created_at" : "Mon Apr 15 20:10:01 +0000 2013",
    "user" : {
      "name" : "Cambridge Police",
      "screen_name" : "CambridgePolice",
      "protected" : false,
      "id_str" : "157799302",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3592040695/c66865d1561f0d6fd99b91bc16fce266_normal.png",
      "id" : 157799302,
      "verified" : true
    }
  },
  "id" : 323892963128254464,
  "created_at" : "Mon Apr 15 20:17:54 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge Police",
      "screen_name" : "CambridgePolice",
      "indices" : [ 3, 19 ],
      "id_str" : "157799302",
      "id" : 157799302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CambMA",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "323892952210472960",
  "text" : "RT @CambridgePolice: 15:51 Report of possible INCIDENT/BOMBS/THREATS at 0XX CENTRAL SQ in #CambMA",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.cambridgepolice.org\" rel=\"nofollow\">PDRMS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CambMA",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "323888460987518976",
    "text" : "15:51 Report of possible INCIDENT/BOMBS/THREATS at 0XX CENTRAL SQ in #CambMA",
    "id" : 323888460987518976,
    "created_at" : "Mon Apr 15 20:00:01 +0000 2013",
    "user" : {
      "name" : "Cambridge Police",
      "screen_name" : "CambridgePolice",
      "protected" : false,
      "id_str" : "157799302",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3592040695/c66865d1561f0d6fd99b91bc16fce266_normal.png",
      "id" : 157799302,
      "verified" : true
    }
  },
  "id" : 323892952210472960,
  "created_at" : "Mon Apr 15 20:17:52 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/KuEsQ7MyWX",
      "expanded_url" : "http://live.reuters.com/Event/Boston_Marathon_Explosion",
      "display_url" : "live.reuters.com/Event/Boston_M\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "323889246136066050",
  "text" : "If you are following the Boston Marathon explosions, live coverage is available here. Stay safe, Boston friends: http://t.co/KuEsQ7MyWX",
  "id" : 323889246136066050,
  "created_at" : "Mon Apr 15 20:03:08 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Tech Review",
      "screen_name" : "techreview",
      "indices" : [ 75, 86 ],
      "id_str" : "15808647",
      "id" : 15808647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/Brco8L71cJ",
      "expanded_url" : "http://www.technologyreview.com/news/513661/bitcoin-isnt-the-only-cryptocurrency-in-town/?ref=rss",
      "display_url" : "technologyreview.com/news/513661/bi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "323825850883661826",
  "text" : "Bitcoin is so last week. A good rundown of alternative cryptocurrencies by @techreview. http://t.co/Brco8L71cJ",
  "id" : 323825850883661826,
  "created_at" : "Mon Apr 15 15:51:13 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajv",
      "indices" : [ 0, 4 ],
      "id_str" : "792537",
      "id" : 792537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323792401040809984",
  "geo" : {
  },
  "id_str" : "323808159749779457",
  "in_reply_to_user_id" : 792537,
  "text" : "@ajv is the space dog-friendly? Our portfolio co. BarkBox needs a new space to grow its team (and its four legged friends).",
  "id" : 323808159749779457,
  "in_reply_to_status_id" : 323792401040809984,
  "created_at" : "Mon Apr 15 14:40:56 +0000 2013",
  "in_reply_to_screen_name" : "ajv",
  "in_reply_to_user_id_str" : "792537",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http://t.co/n4Gr6OKRJn",
      "expanded_url" : "http://fishbowl.pastiche.org/2013/04/14/it_security_in_a_nutshell/",
      "display_url" : "fishbowl.pastiche.org/2013/04/14/it_\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "323803378683633664",
  "text" : "The weakest point in any secure system is a dumb person at one end of it. http://t.co/n4Gr6OKRJn",
  "id" : 323803378683633664,
  "created_at" : "Mon Apr 15 14:21:56 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Wiesen",
      "screen_name" : "ewiesen",
      "indices" : [ 0, 8 ],
      "id_str" : "798536",
      "id" : 798536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323598220125143040",
  "geo" : {
  },
  "id_str" : "323625306151849984",
  "in_reply_to_user_id" : 798536,
  "text" : "@ewiesen pig roast! 20 lbs of pig butt and 12 friends makes for a good Sunday afternoon.",
  "id" : 323625306151849984,
  "in_reply_to_status_id" : 323598220125143040,
  "created_at" : "Mon Apr 15 02:34:20 +0000 2013",
  "in_reply_to_screen_name" : "ewiesen",
  "in_reply_to_user_id_str" : "798536",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/323573844134744065/photo/1",
      "indices" : [ 50, 72 ],
      "url" : "http://t.co/PypH8oTFhU",
      "media_url" : "http://pbs.twimg.com/media/BH2QsmbCUAAnvaF.jpg",
      "id_str" : "323573844143132672",
      "id" : 323573844143132672,
      "media_url_https" : "https://pbs.twimg.com/media/BH2QsmbCUAAnvaF.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/PypH8oTFhU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "323573844134744065",
  "text" : "Epic bubble tea order for Sunday night pig roast. http://t.co/PypH8oTFhU",
  "id" : 323573844134744065,
  "created_at" : "Sun Apr 14 23:09:51 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Zacharias",
      "screen_name" : "zacman85",
      "indices" : [ 0, 9 ],
      "id_str" : "7495722",
      "id" : 7495722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323472509787856897",
  "geo" : {
  },
  "id_str" : "323474711587741696",
  "in_reply_to_user_id" : 7495722,
  "text" : "@zacman85 little ticker tapes of hashes flying everywhere.",
  "id" : 323474711587741696,
  "in_reply_to_status_id" : 323472509787856897,
  "created_at" : "Sun Apr 14 16:35:55 +0000 2013",
  "in_reply_to_screen_name" : "zacman85",
  "in_reply_to_user_id_str" : "7495722",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323197048046366720",
  "geo" : {
  },
  "id_str" : "323211588356169729",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil Path, every few months when I think it's a good idea for some reason.",
  "id" : 323211588356169729,
  "in_reply_to_status_id" : 323197048046366720,
  "created_at" : "Sat Apr 13 23:10:22 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asenkut",
      "screen_name" : "asenkut",
      "indices" : [ 3, 11 ],
      "id_str" : "8095292",
      "id" : 8095292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http://t.co/seJC2JOm3H",
      "expanded_url" : "http://www.economist.com/news/business/21576101-start-ups-founded-immigrants-are-creating-jobs-all-over-america-jobs-machine",
      "display_url" : "economist.com/news/business/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "323197861883953152",
  "text" : "RT @asenkut: Immigrants founded 40% of Fortune500 &amp; behind 7 of 10 firms w most valuable brands in the world: http://t.co/seJC2JOm3H ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Economist",
        "screen_name" : "TheEconomist",
        "indices" : [ 128, 141 ],
        "id_str" : "5988062",
        "id" : 5988062
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http://t.co/seJC2JOm3H",
        "expanded_url" : "http://www.economist.com/news/business/21576101-start-ups-founded-immigrants-are-creating-jobs-all-over-america-jobs-machine",
        "display_url" : "economist.com/news/business/\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "323122204592205824",
    "text" : "Immigrants founded 40% of Fortune500 &amp; behind 7 of 10 firms w most valuable brands in the world: http://t.co/seJC2JOm3H via @TheEconomist",
    "id" : 323122204592205824,
    "created_at" : "Sat Apr 13 17:15:11 +0000 2013",
    "user" : {
      "name" : "asenkut",
      "screen_name" : "asenkut",
      "protected" : false,
      "id_str" : "8095292",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1773834473/Aydin_twitter_normal.jpg",
      "id" : 8095292,
      "verified" : false
    }
  },
  "id" : 323197861883953152,
  "created_at" : "Sat Apr 13 22:15:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/323183809707261952/photo/1",
      "indices" : [ 59, 81 ],
      "url" : "http://t.co/OWum33qQ4M",
      "media_url" : "http://pbs.twimg.com/media/BHwt9m9CQAAgcXD.jpg",
      "id_str" : "323183809715650560",
      "id" : 323183809715650560,
      "media_url_https" : "https://pbs.twimg.com/media/BHwt9m9CQAAgcXD.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/OWum33qQ4M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "323183809707261952",
  "text" : "The MoMA Design Store is kind of like a high brow SkyMall. http://t.co/OWum33qQ4M",
  "id" : 323183809707261952,
  "created_at" : "Sat Apr 13 21:19:59 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http://t.co/i60s5mJXHH",
      "expanded_url" : "http://app.net",
      "display_url" : "app.net"
    } ]
  },
  "geo" : {
  },
  "id_str" : "322924686759559168",
  "text" : "So I finally made an http://t.co/i60s5mJXHH account. Now what?",
  "id" : 322924686759559168,
  "created_at" : "Sat Apr 13 04:10:19 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "322848835703562241",
  "text" : "Three guys at urinals, all on smart phones. That's socially acceptable now I guess? Still gross.",
  "id" : 322848835703562241,
  "created_at" : "Fri Apr 12 23:08:55 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facepalm",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "322798101461090304",
  "text" : "The One line was supposed to decrease HTC device confusion, but now there's a One, One X, One X+, One VX, One S, and One SV. #facepalm",
  "id" : 322798101461090304,
  "created_at" : "Fri Apr 12 19:47:19 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http://t.co/JKk0iSmv8E",
      "expanded_url" : "http://t.imehop.com/12RE3Hq",
      "display_url" : "t.imehop.com/12RE3Hq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "322754537125445633",
  "text" : "This still creeps me out. http://t.co/JKk0iSmv8E",
  "id" : 322754537125445633,
  "created_at" : "Fri Apr 12 16:54:12 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ahsan Malik",
      "screen_name" : "amalik49",
      "indices" : [ 3, 12 ],
      "id_str" : "26874106",
      "id" : 26874106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "322459223927685121",
  "text" : "RT @amalik49: BitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinNor ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyFeed",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "322453249586249728",
    "text" : "BitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinBitcoinNorthKorea #MyFeed",
    "id" : 322453249586249728,
    "created_at" : "Thu Apr 11 20:57:00 +0000 2013",
    "user" : {
      "name" : "Ahsan Malik",
      "screen_name" : "amalik49",
      "protected" : false,
      "id_str" : "26874106",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1776893678/Golden-Gate-Bridge_normal.jpg",
      "id" : 26874106,
      "verified" : false
    }
  },
  "id" : 322459223927685121,
  "created_at" : "Thu Apr 11 21:20:44 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony DeVincenzi",
      "screen_name" : "tonydevincenzi",
      "indices" : [ 9, 24 ],
      "id_str" : "10425532",
      "id" : 10425532
    }, {
      "name" : "Sold.",
      "screen_name" : "usesold",
      "indices" : [ 42, 50 ],
      "id_str" : "1002702354",
      "id" : 1002702354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http://t.co/7kOhG9gz0S",
      "expanded_url" : "http://usesold.com/",
      "display_url" : "usesold.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "322375283296571392",
  "text" : "Congrats @tonydevincenzi on the launch of @UseSold! The beta was awesome, excited to see it at scale. http://t.co/7kOhG9gz0S",
  "id" : 322375283296571392,
  "created_at" : "Thu Apr 11 15:47:11 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lemnos Labs Inc",
      "screen_name" : "lemnoslabs",
      "indices" : [ 39, 50 ],
      "id_str" : "266116717",
      "id" : 266116717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lemnosIOT",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322136616636395522",
  "geo" : {
  },
  "id_str" : "322192413307322368",
  "in_reply_to_user_id" : 266116717,
  "text" : "Do you mean that % has printed parts? \u201C@lemnoslabs: 12% of the current generation of GE jet engines are 3D printed in metal #lemnosIOT\u201D",
  "id" : 322192413307322368,
  "in_reply_to_status_id" : 322136616636395522,
  "created_at" : "Thu Apr 11 03:40:32 +0000 2013",
  "in_reply_to_screen_name" : "lemnoslabs",
  "in_reply_to_user_id_str" : "266116717",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Collison",
      "screen_name" : "collision",
      "indices" : [ 0, 10 ],
      "id_str" : "5418912",
      "id" : 5418912
    }, {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 11, 25 ],
      "id_str" : "128968036",
      "id" : 128968036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322094605996814337",
  "geo" : {
  },
  "id_str" : "322097696557117440",
  "in_reply_to_user_id" : 5418912,
  "text" : "@collision @kellerrinaudo everyone is always *in the process* of reading Infinite Jest :)",
  "id" : 322097696557117440,
  "in_reply_to_status_id" : 322094605996814337,
  "created_at" : "Wed Apr 10 21:24:09 +0000 2013",
  "in_reply_to_screen_name" : "collision",
  "in_reply_to_user_id_str" : "5418912",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Watson",
      "screen_name" : "BrandonWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "13434092",
      "id" : 13434092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322057863084265472",
  "geo" : {
  },
  "id_str" : "322061244959973378",
  "in_reply_to_user_id" : 13434092,
  "text" : "@BrandonWatson I was thinking more Dan Brown.",
  "id" : 322061244959973378,
  "in_reply_to_status_id" : 322057863084265472,
  "created_at" : "Wed Apr 10 18:59:19 +0000 2013",
  "in_reply_to_screen_name" : "BrandonWatson",
  "in_reply_to_user_id_str" : "13434092",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 0, 10 ],
      "id_str" : "15792969",
      "id" : 15792969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321823837647953920",
  "geo" : {
  },
  "id_str" : "321833427714318336",
  "in_reply_to_user_id" : 15792969,
  "text" : "@rosenthal awesome! Hope you guys get your next product inspiration from hacking with those kits.",
  "id" : 321833427714318336,
  "in_reply_to_status_id" : 321823837647953920,
  "created_at" : "Wed Apr 10 03:54:03 +0000 2013",
  "in_reply_to_screen_name" : "rosenthal",
  "in_reply_to_user_id_str" : "15792969",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "321784341724282880",
  "text" : "Neutralino: supersymmetric quantum particle or posh dietary supplement?",
  "id" : 321784341724282880,
  "created_at" : "Wed Apr 10 00:39:00 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 3, 7 ],
      "id_str" : "19494411",
      "id" : 19494411
    }, {
      "name" : "BarkBox",
      "screen_name" : "getbarkbox",
      "indices" : [ 46, 57 ],
      "id_str" : "419538326",
      "id" : 419538326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http://t.co/DHRPAz2zvr",
      "expanded_url" : "http://www.rre.com/press/304-meet-bark-co-",
      "display_url" : "rre.com/press/304-meet\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "321769454369398786",
  "text" : "RT @RRE: We're doubling down on portfolio co. @getbarkbox - awesome team, awesome product. Plus, puppies. http://t.co/DHRPAz2zvr",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BarkBox",
        "screen_name" : "getbarkbox",
        "indices" : [ 37, 48 ],
        "id_str" : "419538326",
        "id" : 419538326
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http://t.co/DHRPAz2zvr",
        "expanded_url" : "http://www.rre.com/press/304-meet-bark-co-",
        "display_url" : "rre.com/press/304-meet\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "321769192049213440",
    "text" : "We're doubling down on portfolio co. @getbarkbox - awesome team, awesome product. Plus, puppies. http://t.co/DHRPAz2zvr",
    "id" : 321769192049213440,
    "created_at" : "Tue Apr 09 23:38:48 +0000 2013",
    "user" : {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "protected" : false,
      "id_str" : "19494411",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2781036073/47c8a2806a89312e9882b4aa968aead4_normal.png",
      "id" : 19494411,
      "verified" : false
    }
  },
  "id" : 321769454369398786,
  "created_at" : "Tue Apr 09 23:39:50 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 60, 67 ],
      "id_str" : "204789792",
      "id" : 204789792
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 68, 75 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/321762059639476225/photo/1",
      "indices" : [ 76, 98 ],
      "url" : "http://t.co/Xn3UZgf5rf",
      "media_url" : "http://pbs.twimg.com/media/BHcg43OCUAAStie.jpg",
      "id_str" : "321762059647864832",
      "id" : 321762059647864832,
      "media_url_https" : "https://pbs.twimg.com/media/BHcg43OCUAAStie.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/Xn3UZgf5rf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "321762059639476225",
  "text" : "SoftBank Capital's NY office has the most excellent art. cc @etaooo @khsieh http://t.co/Xn3UZgf5rf",
  "id" : 321762059639476225,
  "created_at" : "Tue Apr 09 23:10:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 36, 44 ],
      "id_str" : "632391390",
      "id" : 632391390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/G9aodnFa45",
      "expanded_url" : "http://4sq.com/10QDSb4",
      "display_url" : "4sq.com/10QDSb4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7445836313, -73.9930031359 ]
  },
  "id_str" : "321671449490362369",
  "text" : "Awesome talent from Buffalo and the @Z80Labs teams! (@ SoftBank Capital w/ 6 others) [pic]: http://t.co/G9aodnFa45",
  "id" : 321671449490362369,
  "created_at" : "Tue Apr 09 17:10:24 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/321625683774304256/photo/1",
      "indices" : [ 40, 62 ],
      "url" : "http://t.co/WQ1RxPvhZc",
      "media_url" : "http://pbs.twimg.com/media/BHak2vhCcAEnNbq.jpg",
      "id_str" : "321625683778498561",
      "id" : 321625683778498561,
      "media_url_https" : "https://pbs.twimg.com/media/BHak2vhCcAEnNbq.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      } ],
      "display_url" : "pic.twitter.com/WQ1RxPvhZc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "321625683774304256",
  "text" : "Every generation has its call to glory. http://t.co/WQ1RxPvhZc",
  "id" : 321625683774304256,
  "created_at" : "Tue Apr 09 14:08:33 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "321436019037704193",
  "text" : "Is there any technical reason that USB (or any data plug) can't be rotationally symmetric?",
  "id" : 321436019037704193,
  "created_at" : "Tue Apr 09 01:34:53 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Watson",
      "screen_name" : "bwats",
      "indices" : [ 60, 66 ],
      "id_str" : "18500786",
      "id" : 18500786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http://t.co/z50eOgOcf0",
      "expanded_url" : "http://brianwatson.me/post/47458526290/per-dm",
      "display_url" : "brianwatson.me/post/474585262\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "321319425619918848",
  "geo" : {
  },
  "id_str" : "321321125416157184",
  "in_reply_to_user_id" : 18500786,
  "text" : "Awesome in idea, still could use some polish in execution. \u201C@bwats: \"Per dm,\" why I love the Twitter dm. http://t.co/z50eOgOcf0\u201D",
  "id" : 321321125416157184,
  "in_reply_to_status_id" : 321319425619918848,
  "created_at" : "Mon Apr 08 17:58:20 +0000 2013",
  "in_reply_to_screen_name" : "bwats",
  "in_reply_to_user_id_str" : "18500786",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http://t.co/d8uLtIhE4Z",
      "expanded_url" : "http://4sq.com/XzgReM",
      "display_url" : "4sq.com/XzgReM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7174168228, -73.9909314009 ]
  },
  "id_str" : "321284990220513281",
  "text" : "It's like a little Narnia of technology in the Lower East Side (@ Projective Space LES w/ 3 others) http://t.co/d8uLtIhE4Z",
  "id" : 321284990220513281,
  "created_at" : "Mon Apr 08 15:34:45 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 0, 10 ],
      "id_str" : "15792969",
      "id" : 15792969
    }, {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "indices" : [ 29, 38 ],
      "id_str" : "17877351",
      "id" : 17877351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321088999919845377",
  "geo" : {
  },
  "id_str" : "321091644587917312",
  "in_reply_to_user_id" : 15792969,
  "text" : "@rosenthal Arduino kits from @sparkfun!",
  "id" : 321091644587917312,
  "in_reply_to_status_id" : 321088999919845377,
  "created_at" : "Mon Apr 08 02:46:28 +0000 2013",
  "in_reply_to_screen_name" : "rosenthal",
  "in_reply_to_user_id_str" : "15792969",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 34, 41 ],
      "id_str" : "18327902",
      "id" : 18327902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321067798539411456",
  "geo" : {
  },
  "id_str" : "321078076597485569",
  "in_reply_to_user_id" : 18327902,
  "text" : "That's where heuristics come in. \u201C@alexia: You can't always algorithm your way to success.\u201D",
  "id" : 321078076597485569,
  "in_reply_to_status_id" : 321067798539411456,
  "created_at" : "Mon Apr 08 01:52:33 +0000 2013",
  "in_reply_to_screen_name" : "alexia",
  "in_reply_to_user_id_str" : "18327902",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 0, 7 ],
      "id_str" : "9544202",
      "id" : 9544202
    }, {
      "name" : "Lerer Ventures",
      "screen_name" : "lererventures",
      "indices" : [ 8, 22 ],
      "id_str" : "147666931",
      "id" : 147666931
    }, {
      "name" : "maxstoller",
      "screen_name" : "maxstoller",
      "indices" : [ 23, 34 ],
      "id_str" : "15337726",
      "id" : 15337726
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 67, 79 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321053693506105346",
  "geo" : {
  },
  "id_str" : "321060278093635584",
  "in_reply_to_user_id" : 9544202,
  "text" : "@schlaf @lererventures @maxstoller this sounds like a question for @badboyboyce",
  "id" : 321060278093635584,
  "in_reply_to_status_id" : 321053693506105346,
  "created_at" : "Mon Apr 08 00:41:49 +0000 2013",
  "in_reply_to_screen_name" : "schlaf",
  "in_reply_to_user_id_str" : "9544202",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 0, 11 ],
      "id_str" : "652193",
      "id" : 652193
    }, {
      "name" : "Bill Murray",
      "screen_name" : "BillMurray",
      "indices" : [ 12, 23 ],
      "id_str" : "64043577",
      "id" : 64043577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https://t.co/P4DbWO2juc",
      "expanded_url" : "https://twitter.com/donpdonp/status/51341741323857920",
      "display_url" : "twitter.com/donpdonp/statu\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "321022232581251072",
  "in_reply_to_user_id" : 652193,
  "text" : "@parislemon @BillMurray that's a pretty blatant copy of this tweet from two years ago: https://t.co/P4DbWO2juc",
  "id" : 321022232581251072,
  "created_at" : "Sun Apr 07 22:10:39 +0000 2013",
  "in_reply_to_screen_name" : "parislemon",
  "in_reply_to_user_id_str" : "652193",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia",
      "screen_name" : "NataliaZarina",
      "indices" : [ 3, 17 ],
      "id_str" : "74196868",
      "id" : 74196868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320888986975485953",
  "text" : "RT @NataliaZarina: and now, for the shortest summary of 'The Lean Startup' ever: Use the scientific method to build your company. Tada!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "320885779368906753",
    "text" : "and now, for the shortest summary of 'The Lean Startup' ever: Use the scientific method to build your company. Tada!",
    "id" : 320885779368906753,
    "created_at" : "Sun Apr 07 13:08:26 +0000 2013",
    "user" : {
      "name" : "Natalia",
      "screen_name" : "NataliaZarina",
      "protected" : false,
      "id_str" : "74196868",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3489396704/acd0fac2e201624d3ac30e29033feb5a_normal.jpeg",
      "id" : 74196868,
      "verified" : false
    }
  },
  "id" : 320888986975485953,
  "created_at" : "Sun Apr 07 13:21:10 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/320658195116879874/photo/1",
      "indices" : [ 71, 93 ],
      "url" : "http://t.co/WT5kyozoST",
      "media_url" : "http://pbs.twimg.com/media/BHM07fbCcAAuSbz.jpg",
      "id_str" : "320658195125268480",
      "id" : 320658195125268480,
      "media_url_https" : "https://pbs.twimg.com/media/BHM07fbCcAAuSbz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 608
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 608
      } ],
      "display_url" : "pic.twitter.com/WT5kyozoST"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320658195116879874",
  "text" : "The first time I've ever really really wanted to understand Swedish... http://t.co/WT5kyozoST",
  "id" : 320658195116879874,
  "created_at" : "Sat Apr 06 22:04:06 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dulcie Madden",
      "screen_name" : "dulciemadden",
      "indices" : [ 50, 63 ],
      "id_str" : "104002466",
      "id" : 104002466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320657584707227648",
  "text" : "Best dog name I've heard: \"Thunderpants.\" Thanks, @dulciemadden",
  "id" : 320657584707227648,
  "created_at" : "Sat Apr 06 22:01:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex List",
      "screen_name" : "ayylist",
      "indices" : [ 0, 8 ],
      "id_str" : "22728511",
      "id" : 22728511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320629971276148736",
  "geo" : {
  },
  "id_str" : "320631460023390208",
  "in_reply_to_user_id" : 22728511,
  "text" : "@ayylist general relaxing of policy and deportation; adding more exemptions and rules will result in a hairball. See US tax code.",
  "id" : 320631460023390208,
  "in_reply_to_status_id" : 320629971276148736,
  "created_at" : "Sat Apr 06 20:17:51 +0000 2013",
  "in_reply_to_screen_name" : "ayylist",
  "in_reply_to_user_id_str" : "22728511",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex List",
      "screen_name" : "ayylist",
      "indices" : [ 0, 8 ],
      "id_str" : "22728511",
      "id" : 22728511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320629225877020672",
  "geo" : {
  },
  "id_str" : "320629515833458688",
  "in_reply_to_user_id" : 22728511,
  "text" : "@ayylist yea, but then you have a chicken and egg problem. 30 days to leave country when sponsorship ends; can you raise $1M by then?",
  "id" : 320629515833458688,
  "in_reply_to_status_id" : 320629225877020672,
  "created_at" : "Sat Apr 06 20:10:08 +0000 2013",
  "in_reply_to_screen_name" : "ayylist",
  "in_reply_to_user_id_str" : "22728511",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex List",
      "screen_name" : "ayylist",
      "indices" : [ 0, 8 ],
      "id_str" : "22728511",
      "id" : 22728511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320627691923574784",
  "geo" : {
  },
  "id_str" : "320628020551503872",
  "in_reply_to_user_id" : 22728511,
  "text" : "@ayylist unfortunately no - if no company sponsors a visa (eg you start your own company), foreign nationals risk deportation.",
  "id" : 320628020551503872,
  "in_reply_to_status_id" : 320627691923574784,
  "created_at" : "Sat Apr 06 20:04:11 +0000 2013",
  "in_reply_to_screen_name" : "ayylist",
  "in_reply_to_user_id_str" : "22728511",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/320615012903309313/photo/1",
      "indices" : [ 114, 136 ],
      "url" : "http://t.co/GYDBbdnMS7",
      "media_url" : "http://pbs.twimg.com/media/BHMNp9JCUAAv-Ok.jpg",
      "id_str" : "320615012911697920",
      "id" : 320615012911697920,
      "media_url_https" : "https://pbs.twimg.com/media/BHMNp9JCUAAv-Ok.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/GYDBbdnMS7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320615012903309313",
  "text" : "Killing the American dream: MIT-educated entrepreneur risks deportation bc US doesn't support visas for startups. http://t.co/GYDBbdnMS7",
  "id" : 320615012903309313,
  "created_at" : "Sat Apr 06 19:12:30 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Zacharias",
      "screen_name" : "zacman85",
      "indices" : [ 0, 9 ],
      "id_str" : "7495722",
      "id" : 7495722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320603927852769280",
  "geo" : {
  },
  "id_str" : "320604143603556353",
  "in_reply_to_user_id" : 7495722,
  "text" : "@zacman85 reminds me of the Half Life Combine soldiers.",
  "id" : 320604143603556353,
  "in_reply_to_status_id" : 320603927852769280,
  "created_at" : "Sat Apr 06 18:29:19 +0000 2013",
  "in_reply_to_screen_name" : "zacman85",
  "in_reply_to_user_id_str" : "7495722",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Gardner",
      "screen_name" : "mggardner",
      "indices" : [ 0, 10 ],
      "id_str" : "21432808",
      "id" : 21432808
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 11, 18 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320358788265828352",
  "geo" : {
  },
  "id_str" : "320594805992337408",
  "in_reply_to_user_id" : 21432808,
  "text" : "@mggardner @medium by ATF definition you can make a gun with a 3D printer, which is the point of the post.",
  "id" : 320594805992337408,
  "in_reply_to_status_id" : 320358788265828352,
  "created_at" : "Sat Apr 06 17:52:12 +0000 2013",
  "in_reply_to_screen_name" : "mggardner",
  "in_reply_to_user_id_str" : "21432808",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Collison",
      "screen_name" : "collision",
      "indices" : [ 0, 10 ],
      "id_str" : "5418912",
      "id" : 5418912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320588438770425857",
  "geo" : {
  },
  "id_str" : "320592552967409665",
  "in_reply_to_user_id" : 5418912,
  "text" : "@collision phones should actually use front camera to track orientation of your eyes relative to screen to autorotate.",
  "id" : 320592552967409665,
  "in_reply_to_status_id" : 320588438770425857,
  "created_at" : "Sat Apr 06 17:43:15 +0000 2013",
  "in_reply_to_screen_name" : "collision",
  "in_reply_to_user_id_str" : "5418912",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 3, 10 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 17, 24 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 48, 53 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320577026731954177",
  "text" : "RT @khsieh: i am @khsieh. hear me roar!. thanks @kane for the identity crisis",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 5, 12 ],
        "id_str" : "111999960",
        "id" : 111999960
      }, {
        "name" : "Kane",
        "screen_name" : "kane",
        "indices" : [ 36, 41 ],
        "id_str" : "19380775",
        "id" : 19380775
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "320576964958228481",
    "text" : "i am @khsieh. hear me roar!. thanks @kane for the identity crisis",
    "id" : 320576964958228481,
    "created_at" : "Sat Apr 06 16:41:19 +0000 2013",
    "user" : {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "protected" : false,
      "id_str" : "111999960",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2281882681/f87qtjz3d40uc8g5czwn_normal.jpeg",
      "id" : 111999960,
      "verified" : false
    }
  },
  "id" : 320577026731954177,
  "created_at" : "Sat Apr 06 16:41:33 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 0, 6 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320575066909839360",
  "geo" : {
  },
  "id_str" : "320575975198978050",
  "in_reply_to_user_id" : 3840,
  "text" : "@Jason I believe note taking and time mgmt software are intrinsically difficult bc everyone has their own immutable habits/preferences.",
  "id" : 320575975198978050,
  "in_reply_to_status_id" : 320575066909839360,
  "created_at" : "Sat Apr 06 16:37:23 +0000 2013",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 51, 58 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/320574755344359425/photo/1",
      "indices" : [ 59, 81 ],
      "url" : "http://t.co/02hTOmYDgt",
      "media_url" : "http://pbs.twimg.com/media/BHLpCqDCIAAFOgN.jpg",
      "id_str" : "320574755352748032",
      "id" : 320574755352748032,
      "media_url_https" : "https://pbs.twimg.com/media/BHLpCqDCIAAFOgN.jpg",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/02hTOmYDgt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320574755344359425",
  "text" : "It's sad because I would totally use iContacts. cc @jdrive http://t.co/02hTOmYDgt",
  "id" : 320574755344359425,
  "created_at" : "Sat Apr 06 16:32:32 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 28, 35 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http://t.co/Ip6t4DUqYe",
      "expanded_url" : "http://Instagram.com/p/XxMKlsSbRA/",
      "display_url" : "Instagram.com/p/XxMKlsSbRA/"
    } ]
  },
  "in_reply_to_status_id_str" : "320561237098385408",
  "geo" : {
  },
  "id_str" : "320571673923428353",
  "in_reply_to_user_id" : 15137329,
  "text" : "Still using the Ball base? \u201C@jdrive: Building the ultimate watch. http://t.co/Ip6t4DUqYe\u201D",
  "id" : 320571673923428353,
  "in_reply_to_status_id" : 320561237098385408,
  "created_at" : "Sat Apr 06 16:20:17 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 22, 27 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320553905345921026",
  "text" : "I am finally, finally @kane.",
  "id" : 320553905345921026,
  "created_at" : "Sat Apr 06 15:09:41 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "indices" : [ 0, 10 ],
      "id_str" : "5668942",
      "id" : 5668942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320451306466725888",
  "geo" : {
  },
  "id_str" : "320452068135534592",
  "in_reply_to_user_id" : 5668942,
  "text" : "@sarahcuda congrats Sarah!!",
  "id" : 320452068135534592,
  "in_reply_to_status_id" : 320451306466725888,
  "created_at" : "Sat Apr 06 08:25:01 +0000 2013",
  "in_reply_to_screen_name" : "sarahcuda",
  "in_reply_to_user_id_str" : "5668942",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 0, 7 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 49, 56 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320402120736124929",
  "in_reply_to_user_id" : 111999960,
  "text" : "@khsieh Finally got our usernames sorted out! cc @etaooo",
  "id" : 320402120736124929,
  "created_at" : "Sat Apr 06 05:06:33 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Petersen",
      "screen_name" : "ryanp2",
      "indices" : [ 0, 7 ],
      "id_str" : "395978320",
      "id" : 395978320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320371039425138689",
  "geo" : {
  },
  "id_str" : "320371490484809729",
  "in_reply_to_user_id" : 395978320,
  "text" : "@ryanp2 fb and Samsung are already starting to push Google branding and apps out of Android; I imagine Google doesn't like that.",
  "id" : 320371490484809729,
  "in_reply_to_status_id" : 320371039425138689,
  "created_at" : "Sat Apr 06 03:04:50 +0000 2013",
  "in_reply_to_screen_name" : "ryanp2",
  "in_reply_to_user_id_str" : "395978320",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Petersen",
      "screen_name" : "ryanp2",
      "indices" : [ 0, 7 ],
      "id_str" : "395978320",
      "id" : 395978320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320369515034718209",
  "geo" : {
  },
  "id_str" : "320370140166377475",
  "in_reply_to_user_id" : 395978320,
  "text" : "@ryanp2 tbd. Maybe via teleco buy?",
  "id" : 320370140166377475,
  "in_reply_to_status_id" : 320369515034718209,
  "created_at" : "Sat Apr 06 02:59:28 +0000 2013",
  "in_reply_to_screen_name" : "ryanp2",
  "in_reply_to_user_id_str" : "395978320",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320356591390060548",
  "text" : "Calling it: Google Fiber is followed by Google Wireless - a data-only, no-contract wireless plan based on Google Voice.",
  "id" : 320356591390060548,
  "created_at" : "Sat Apr 06 02:05:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 0, 10 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320349372527280129",
  "geo" : {
  },
  "id_str" : "320350792479543296",
  "in_reply_to_user_id" : 14326765,
  "text" : "@johnhcook Tony Stark?",
  "id" : 320350792479543296,
  "in_reply_to_status_id" : 320349372527280129,
  "created_at" : "Sat Apr 06 01:42:35 +0000 2013",
  "in_reply_to_screen_name" : "johnhcook",
  "in_reply_to_user_id_str" : "14326765",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320346570094702592",
  "text" : "2D icons and circular thumbnails will be the WordArt and gif-backgrounds of this generation.",
  "id" : 320346570094702592,
  "created_at" : "Sat Apr 06 01:25:48 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HN from Y Combinator",
      "screen_name" : "hnycombinator",
      "indices" : [ 63, 77 ],
      "id_str" : "15042473",
      "id" : 15042473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http://t.co/IXLyjvjvrX",
      "expanded_url" : "http://goo.gl/fb/6TFsu",
      "display_url" : "goo.gl/fb/6TFsu"
    } ]
  },
  "in_reply_to_status_id_str" : "320331614720761856",
  "geo" : {
  },
  "id_str" : "320342203278966784",
  "in_reply_to_user_id" : 15042473,
  "text" : "Coincidentally, this is also a lot of my git commit comments. \u201C@hnycombinator: Die Git Die http://t.co/IXLyjvjvrX\u201D",
  "id" : 320342203278966784,
  "in_reply_to_status_id" : 320331614720761856,
  "created_at" : "Sat Apr 06 01:08:27 +0000 2013",
  "in_reply_to_screen_name" : "hnycombinator",
  "in_reply_to_user_id_str" : "15042473",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320332576680189953",
  "text" : "It's awesome that Klout scores come with two significant digits. Just in case you weren't sure.",
  "id" : 320332576680189953,
  "created_at" : "Sat Apr 06 00:30:12 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320331030080913408",
  "text" : "To the man with the collapsible bar tending kit mixing himself a drink on the Amtrak Accela: well done.",
  "id" : 320331030080913408,
  "created_at" : "Sat Apr 06 00:24:03 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slow",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320322454067216384",
  "text" : "I just made the connection between Twitter, the bird logo, and the egg profile pics... #slow",
  "id" : 320322454067216384,
  "created_at" : "Fri Apr 05 23:49:59 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http://t.co/2tnz9D9co5",
      "expanded_url" : "http://www.nytimes.com/interactive/2013/04/07/magazine/food-global-drinks.html",
      "display_url" : "nytimes.com/interactive/20\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "320318786945290240",
  "text" : "Added to my \"to do, but actually\" list. http://t.co/2tnz9D9co5",
  "id" : 320318786945290240,
  "created_at" : "Fri Apr 05 23:35:24 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amtrak ",
      "screen_name" : "Amtrak",
      "indices" : [ 15, 22 ],
      "id_str" : "119166791",
      "id" : 119166791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320306766212628481",
  "text" : "I used to want @amtrak to meet the expectation of \"running on time;\" now I just want them to hit the low bar of \"running.\"",
  "id" : 320306766212628481,
  "created_at" : "Fri Apr 05 22:47:38 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 39, 47 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320265240325533696",
  "text" : "Is there any way to reshare posts from @timehop after the initial share?",
  "id" : 320265240325533696,
  "created_at" : "Fri Apr 05 20:02:38 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320264676913053696",
  "text" : "Anyone want to start Vbvntv with me? A haute Linux distro targeted at typography designers and content curators.",
  "id" : 320264676913053696,
  "created_at" : "Fri Apr 05 20:00:23 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320263849624350720",
  "geo" : {
  },
  "id_str" : "320264110476505088",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin not me, apparently.",
  "id" : 320264110476505088,
  "in_reply_to_status_id" : 320263849624350720,
  "created_at" : "Fri Apr 05 19:58:08 +0000 2013",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 16, 23 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 44, 52 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http://t.co/X0RCWZ6yo1",
      "expanded_url" : "http://gizmo.do/S2Agr32",
      "display_url" : "gizmo.do/S2Agr32"
    } ]
  },
  "in_reply_to_status_id_str" : "320235919842086912",
  "geo" : {
  },
  "id_str" : "320256274967171072",
  "in_reply_to_user_id" : 2890961,
  "text" : "Wow, posting on @medium got me syndicated. \u201C@Gizmodo: Why do we keep making ebooks like paper books? http://t.co/X0RCWZ6yo1\u201D",
  "id" : 320256274967171072,
  "in_reply_to_status_id" : 320235919842086912,
  "created_at" : "Fri Apr 05 19:27:00 +0000 2013",
  "in_reply_to_screen_name" : "Gizmodo",
  "in_reply_to_user_id_str" : "2890961",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Zuckerman",
      "screen_name" : "EthanZ",
      "indices" : [ 3, 10 ],
      "id_str" : "1051171",
      "id" : 1051171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320239596506075136",
  "text" : "RT @EthanZ: Incredible. Myanmar slashes price of SIM card from $2000 to $125, now to $2USD. Massive social implications: http://t.co/Ah9 ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http://t.co/Ah9RqXDfE1",
        "expanded_url" : "http://mydaydream89.wordpress.com/2013/04/06/burma-set-for-mobile-revolution-as-govt-slashes-sim-card-prices/",
        "display_url" : "mydaydream89.wordpress.com/2013/04/06/bur\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "320234546471788544",
    "text" : "Incredible. Myanmar slashes price of SIM card from $2000 to $125, now to $2USD. Massive social implications: http://t.co/Ah9RqXDfE1",
    "id" : 320234546471788544,
    "created_at" : "Fri Apr 05 18:00:40 +0000 2013",
    "user" : {
      "name" : "Ethan Zuckerman",
      "screen_name" : "EthanZ",
      "protected" : false,
      "id_str" : "1051171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2184637155/lol_me_normal.jpg",
      "id" : 1051171,
      "verified" : false
    }
  },
  "id" : 320239596506075136,
  "created_at" : "Fri Apr 05 18:20:44 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Howard",
      "screen_name" : "mark_a_howard",
      "indices" : [ 0, 14 ],
      "id_str" : "12287112",
      "id" : 12287112
    }, {
      "name" : "Louis Steiner",
      "screen_name" : "LouisSteiner",
      "indices" : [ 15, 28 ],
      "id_str" : "15481156",
      "id" : 15481156
    }, {
      "name" : "Tesla Motors",
      "screen_name" : "TeslaMotors",
      "indices" : [ 46, 58 ],
      "id_str" : "13298072",
      "id" : 13298072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "320161565116608512",
  "in_reply_to_user_id" : 12287112,
  "text" : "@mark_a_howard @louissteiner It's an op-Ed on @teslamotors' implementation. Surely you don't have to write a book to review it?",
  "id" : 320161565116608512,
  "created_at" : "Fri Apr 05 13:10:40 +0000 2013",
  "in_reply_to_screen_name" : "mark_a_howard",
  "in_reply_to_user_id_str" : "12287112",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snezan",
      "screen_name" : "snezan",
      "indices" : [ 0, 7 ],
      "id_str" : "3479511",
      "id" : 3479511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319910473803890688",
  "geo" : {
  },
  "id_str" : "320153033885507584",
  "in_reply_to_user_id" : 3479511,
  "text" : "@snezan Short spin in the S. unable to own, unfortunately.",
  "id" : 320153033885507584,
  "in_reply_to_status_id" : 319910473803890688,
  "created_at" : "Fri Apr 05 12:36:46 +0000 2013",
  "in_reply_to_screen_name" : "snezan",
  "in_reply_to_user_id_str" : "3479511",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Novosad",
      "screen_name" : "AlexDaUkrainian",
      "indices" : [ 0, 16 ],
      "id_str" : "138132205",
      "id" : 138132205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319931126296760322",
  "geo" : {
  },
  "id_str" : "320152807518924802",
  "in_reply_to_user_id" : 138132205,
  "text" : "@AlexDaUkrainian sure, and I am always a fan of radically bold technology - my point was that it's a beta implementation at best.",
  "id" : 320152807518924802,
  "in_reply_to_status_id" : 319931126296760322,
  "created_at" : "Fri Apr 05 12:35:52 +0000 2013",
  "in_reply_to_screen_name" : "AlexDaUkrainian",
  "in_reply_to_user_id_str" : "138132205",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 0, 8 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319955300880875520",
  "geo" : {
  },
  "id_str" : "320152360766824448",
  "in_reply_to_user_id" : 624947324,
  "text" : "@mailbox was on time warner wifi behind AirPort Extreme. It started working again on its own.",
  "id" : 320152360766824448,
  "in_reply_to_status_id" : 319955300880875520,
  "created_at" : "Fri Apr 05 12:34:05 +0000 2013",
  "in_reply_to_screen_name" : "mailbox",
  "in_reply_to_user_id_str" : "624947324",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Yu",
      "screen_name" : "Intenex",
      "indices" : [ 0, 8 ],
      "id_str" : "195474206",
      "id" : 195474206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320150168957759488",
  "geo" : {
  },
  "id_str" : "320151974286860288",
  "in_reply_to_user_id" : 195474206,
  "text" : "@Intenex at this point, probably a self-trained Pavlovian response.",
  "id" : 320151974286860288,
  "in_reply_to_status_id" : 320150168957759488,
  "created_at" : "Fri Apr 05 12:32:33 +0000 2013",
  "in_reply_to_screen_name" : "Intenex",
  "in_reply_to_user_id_str" : "195474206",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 0, 6 ],
      "id_str" : "14208617",
      "id" : 14208617
    }, {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 7, 14 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320018382520987649",
  "geo" : {
  },
  "id_str" : "320028637573308416",
  "in_reply_to_user_id" : 14208617,
  "text" : "@robgo @jdrive it's okay though, drop-proofness was one of the major selling points during the keynote.",
  "id" : 320028637573308416,
  "in_reply_to_status_id" : 320018382520987649,
  "created_at" : "Fri Apr 05 04:22:27 +0000 2013",
  "in_reply_to_screen_name" : "robgo",
  "in_reply_to_user_id_str" : "14208617",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis Steiner",
      "screen_name" : "LouisSteiner",
      "indices" : [ 0, 13 ],
      "id_str" : "15481156",
      "id" : 15481156
    }, {
      "name" : "Tesla Motors",
      "screen_name" : "TeslaMotors",
      "indices" : [ 14, 26 ],
      "id_str" : "13298072",
      "id" : 13298072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319962073444540417",
  "geo" : {
  },
  "id_str" : "319967541525102592",
  "in_reply_to_user_id" : 15481156,
  "text" : "@LouisSteiner @TeslaMotors - happy to hear that. Hopefully there's stuff in the pipeline that will take advantage of what the tech can do.",
  "id" : 319967541525102592,
  "in_reply_to_status_id" : 319962073444540417,
  "created_at" : "Fri Apr 05 00:19:41 +0000 2013",
  "in_reply_to_screen_name" : "LouisSteiner",
  "in_reply_to_user_id_str" : "15481156",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "319892269610188800",
  "text" : "Between Samsung Galaxy S4 announcement and Facebook Home announcement, it's fair to say that Google is being pushed out of Android.",
  "id" : 319892269610188800,
  "created_at" : "Thu Apr 04 19:20:35 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/feedly/id396069556?mt=8&uo=4\" rel=\"nofollow\">feedly on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http://t.co/AaGoP3DeaX",
      "expanded_url" : "http://feedproxy.google.com/~r/TheNextWeb/~3/Hu_jh1j8PWY/",
      "display_url" : "feedproxy.google.com/~r/TheNextWeb/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "319891862943055875",
  "text" : "Huawei's not allowed in US and Facebook's not allowed in China... So what's the point of Huawei FB phone? http://t.co/AaGoP3DeaX",
  "id" : 319891862943055875,
  "created_at" : "Thu Apr 04 19:18:58 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319663826708615169",
  "geo" : {
  },
  "id_str" : "319667404164702208",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive I'm more worried about the helicopters I *can't* hear...",
  "id" : 319667404164702208,
  "in_reply_to_status_id" : 319663826708615169,
  "created_at" : "Thu Apr 04 04:27:02 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319657374782746624",
  "geo" : {
  },
  "id_str" : "319661751903875072",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive your language makes it sound like you're welcoming me as a fellow member!",
  "id" : 319661751903875072,
  "in_reply_to_status_id" : 319657374782746624,
  "created_at" : "Thu Apr 04 04:04:35 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 26, 33 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https://t.co/9YVlnkNWmg",
      "expanded_url" : "https://medium.com/",
      "display_url" : "medium.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "319656161643225088",
  "text" : "Honored to be featured on @medium for my piece on 3D printing! https://t.co/9YVlnkNWmg",
  "id" : 319656161643225088,
  "created_at" : "Thu Apr 04 03:42:22 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drunk Predator Drone",
      "screen_name" : "drunkenpredator",
      "indices" : [ 3, 19 ],
      "id_str" : "252787550",
      "id" : 252787550
    }, {
      "name" : "Conor Friedersdorf",
      "screen_name" : "conor64",
      "indices" : [ 71, 79 ],
      "id_str" : "14046504",
      "id" : 14046504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "319573798498213888",
  "text" : "RT @drunkenpredator: Hyperbole thick enough to cut with a band saw. RT @conor64: An Urgent Proposal to Protect People From Domestic Dron ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Conor Friedersdorf",
        "screen_name" : "conor64",
        "indices" : [ 50, 58 ],
        "id_str" : "14046504",
        "id" : 14046504
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http://t.co/He6WuENJha",
        "expanded_url" : "http://bit.ly/16xfu0F",
        "display_url" : "bit.ly/16xfu0F"
      } ]
    },
    "geo" : {
    },
    "id_str" : "319568862179893248",
    "text" : "Hyperbole thick enough to cut with a band saw. RT @conor64: An Urgent Proposal to Protect People From Domestic Drones http://t.co/He6WuENJha",
    "id" : 319568862179893248,
    "created_at" : "Wed Apr 03 21:55:28 +0000 2013",
    "user" : {
      "name" : "Drunk Predator Drone",
      "screen_name" : "drunkenpredator",
      "protected" : false,
      "id_str" : "252787550",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3331819139/9d180096037780e5cf42dc7a3111d647_normal.png",
      "id" : 252787550,
      "verified" : false
    }
  },
  "id" : 319573798498213888,
  "created_at" : "Wed Apr 03 22:15:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Wile",
      "screen_name" : "rjwile",
      "indices" : [ 35, 42 ],
      "id_str" : "27810354",
      "id" : 27810354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http://t.co/M3FLBnqtnR",
      "expanded_url" : "http://www.businessinsider.com/robotics-startup-ceo-on-moving-to-california-2013-4",
      "display_url" : "businessinsider.com/robotics-start\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "319305000520146944",
  "text" : "Great interview of Romotive CEO by @rjwile, but photo credit would be appreciated! http://t.co/M3FLBnqtnR",
  "id" : 319305000520146944,
  "created_at" : "Wed Apr 03 04:26:59 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/feedly/id396069556?mt=8&uo=4\" rel=\"nofollow\">feedly on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 86, 92 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/R9W37V9S9j",
      "expanded_url" : "http://feedly.com/k/16jKhvS",
      "display_url" : "feedly.com/k/16jKhvS"
    } ]
  },
  "geo" : {
  },
  "id_str" : "319300931189633025",
  "text" : "\"White House drops $100M to help scientists map the human brain\"  isn't this what the @HSEAS connecteome project is? http://t.co/R9W37V9S9j",
  "id" : 319300931189633025,
  "created_at" : "Wed Apr 03 04:10:48 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 14, 22 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "319298430864355328",
  "text" : "Seriously wtf @mailbox? Now I have to check the gmail app out of paranoia bc almost half a day's worth of email didn't show up.",
  "id" : 319298430864355328,
  "created_at" : "Wed Apr 03 04:00:52 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Wegener",
      "screen_name" : "jwegener",
      "indices" : [ 0, 9 ],
      "id_str" : "3187821",
      "id" : 3187821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319295066160132097",
  "geo" : {
  },
  "id_str" : "319295370716913665",
  "in_reply_to_user_id" : 3187821,
  "text" : "@jwegener in the card, yes, but not in the text itself.",
  "id" : 319295370716913665,
  "in_reply_to_status_id" : 319295066160132097,
  "created_at" : "Wed Apr 03 03:48:43 +0000 2013",
  "in_reply_to_screen_name" : "jwegener",
  "in_reply_to_user_id_str" : "3187821",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "indices" : [ 3, 19 ],
      "id_str" : "353789193",
      "id" : 353789193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TwitterCards",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "319295168748593152",
  "text" : "RT @StartupLJackson: All closed networks eventually reinvent HTML, poorly. #TwitterCards",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TwitterCards",
        "indices" : [ 54, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "319287945389539329",
    "text" : "All closed networks eventually reinvent HTML, poorly. #TwitterCards",
    "id" : 319287945389539329,
    "created_at" : "Wed Apr 03 03:19:12 +0000 2013",
    "user" : {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "protected" : false,
      "id_str" : "353789193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1491792938/Screen_shot_2011-08-12_at_9.54.22_AM_normal.png",
      "id" : 353789193,
      "verified" : false
    }
  },
  "id" : 319295168748593152,
  "created_at" : "Wed Apr 03 03:47:55 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 3, 7 ],
      "id_str" : "19494411",
      "id" : 19494411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http://t.co/NfanaEITxF",
      "expanded_url" : "http://mashable.com/2013/04/02/3d-printed-face/",
      "display_url" : "mashable.com/2013/04/02/3d-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "319294447324131329",
  "text" : "RT @RRE: 3D printing reconstructs a mans face - and his life. Truly an amazing technology. http://t.co/NfanaEITxF",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http://t.co/NfanaEITxF",
        "expanded_url" : "http://mashable.com/2013/04/02/3d-printed-face/",
        "display_url" : "mashable.com/2013/04/02/3d-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "319291885560664064",
    "text" : "3D printing reconstructs a mans face - and his life. Truly an amazing technology. http://t.co/NfanaEITxF",
    "id" : 319291885560664064,
    "created_at" : "Wed Apr 03 03:34:52 +0000 2013",
    "user" : {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "protected" : false,
      "id_str" : "19494411",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2781036073/47c8a2806a89312e9882b4aa968aead4_normal.png",
      "id" : 19494411,
      "verified" : false
    }
  },
  "id" : 319294447324131329,
  "created_at" : "Wed Apr 03 03:45:03 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 3, 11 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "319289785648807936",
  "text" : "My @mailbox is 8 hours out of sync with gmail! Unusable right now.",
  "id" : 319289785648807936,
  "created_at" : "Wed Apr 03 03:26:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 0, 7 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319277212027211779",
  "geo" : {
  },
  "id_str" : "319287775990018049",
  "in_reply_to_user_id" : 204789792,
  "text" : "@etaooo try StubHub",
  "id" : 319287775990018049,
  "in_reply_to_status_id" : 319277212027211779,
  "created_at" : "Wed Apr 03 03:18:32 +0000 2013",
  "in_reply_to_screen_name" : "etaooo",
  "in_reply_to_user_id_str" : "204789792",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/0piJ0ejoQP",
      "expanded_url" : "http://www.theverge.com/2013/4/2/4176914/ios-7-behind-schedule-new-look",
      "display_url" : "theverge.com/2013/4/2/41769\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "319283126843088896",
  "text" : "Good to see that the Apple rumor mill is running smoothly as ever.  http://t.co/0piJ0ejoQP",
  "id" : 319283126843088896,
  "created_at" : "Wed Apr 03 03:00:04 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Wegener",
      "screen_name" : "jwegener",
      "indices" : [ 0, 9 ],
      "id_str" : "3187821",
      "id" : 3187821
    }, {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 53, 61 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "319276921194160128",
  "in_reply_to_user_id" : 3187821,
  "text" : "@jwegener I'm surprised you guys don't append a \"via @timehop\" to things shared on twitter thru the app!",
  "id" : 319276921194160128,
  "created_at" : "Wed Apr 03 02:35:24 +0000 2013",
  "in_reply_to_screen_name" : "jwegener",
  "in_reply_to_user_id_str" : "3187821",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http://t.co/pZL7OJvzTQ",
      "expanded_url" : "http://t.imehop.com/10ohcyO",
      "display_url" : "t.imehop.com/10ohcyO"
    } ]
  },
  "geo" : {
  },
  "id_str" : "319276618608697345",
  "text" : "Ironically, I'm tweeting this from an iPhone. http://t.co/pZL7OJvzTQ",
  "id" : 319276618608697345,
  "created_at" : "Wed Apr 03 02:34:12 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "indices" : [ 0, 6 ],
      "id_str" : "14782518",
      "id" : 14782518
    }, {
      "name" : "Sadly, not The Onion",
      "screen_name" : "theon1on",
      "indices" : [ 58, 67 ],
      "id_str" : "1209526525",
      "id" : 1209526525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319274966174547969",
  "geo" : {
  },
  "id_str" : "319275858571431939",
  "in_reply_to_user_id" : 14782518,
  "text" : "@cltom this sounds like something for Sadly Not the Onion @theon1on",
  "id" : 319275858571431939,
  "in_reply_to_status_id" : 319274966174547969,
  "created_at" : "Wed Apr 03 02:31:11 +0000 2013",
  "in_reply_to_screen_name" : "cltom",
  "in_reply_to_user_id_str" : "14782518",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amrit Richmond",
      "screen_name" : "amrit",
      "indices" : [ 0, 6 ],
      "id_str" : "19561116",
      "id" : 19561116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319200831675179008",
  "geo" : {
  },
  "id_str" : "319250035072188417",
  "in_reply_to_user_id" : 19561116,
  "text" : "@amrit sure!",
  "id" : 319250035072188417,
  "in_reply_to_status_id" : 319200831675179008,
  "created_at" : "Wed Apr 03 00:48:34 +0000 2013",
  "in_reply_to_screen_name" : "amrit",
  "in_reply_to_user_id_str" : "19561116",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319200571989057538",
  "geo" : {
  },
  "id_str" : "319200692973744128",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil :(",
  "id" : 319200692973744128,
  "in_reply_to_status_id" : 319200571989057538,
  "created_at" : "Tue Apr 02 21:32:30 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 0, 8 ],
      "id_str" : "38399009",
      "id" : 38399009
    }, {
      "name" : "University Symposium",
      "screen_name" : "usymposium",
      "indices" : [ 9, 20 ],
      "id_str" : "370243659",
      "id" : 370243659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319157294782885889",
  "geo" : {
  },
  "id_str" : "319197583568412672",
  "in_reply_to_user_id" : 38399009,
  "text" : "@bznotes @usymposium really bummed I'm missing this...",
  "id" : 319197583568412672,
  "in_reply_to_status_id" : 319157294782885889,
  "created_at" : "Tue Apr 02 21:20:08 +0000 2013",
  "in_reply_to_screen_name" : "bznotes",
  "in_reply_to_user_id_str" : "38399009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arjun Reddy",
      "screen_name" : "atreddy",
      "indices" : [ 0, 8 ],
      "id_str" : "29041063",
      "id" : 29041063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319196577627533312",
  "geo" : {
  },
  "id_str" : "319197294895460354",
  "in_reply_to_user_id" : 29041063,
  "text" : "@atreddy yea, Engadget is in my Feedly, but still a lot of shorter breaking stories (which I'm not against - I just want introspection).",
  "id" : 319197294895460354,
  "in_reply_to_status_id" : 319196577627533312,
  "created_at" : "Tue Apr 02 21:19:00 +0000 2013",
  "in_reply_to_screen_name" : "atreddy",
  "in_reply_to_user_id_str" : "29041063",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    }, {
      "name" : "Amrit Richmond",
      "screen_name" : "amrit",
      "indices" : [ 7, 13 ],
      "id_str" : "19561116",
      "id" : 19561116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319170671995408384",
  "geo" : {
  },
  "id_str" : "319196167760134146",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil @amrit any Zynga game has in-app purchases. Strava, Spotify, and WhatsApp for subscriptions. Letterpress for upgrade.",
  "id" : 319196167760134146,
  "in_reply_to_status_id" : 319170671995408384,
  "created_at" : "Tue Apr 02 21:14:31 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "319195371349884928",
  "text" : "I would like to see an Economist-style, long-form analytical blog/magazine for tech to complement the ADHD blogging that exists today.",
  "id" : 319195371349884928,
  "created_at" : "Tue Apr 02 21:11:21 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http://t.co/7tH3kiERXT",
      "expanded_url" : "http://t.imehop.com/12cGqQT",
      "display_url" : "t.imehop.com/12cGqQT"
    } ]
  },
  "geo" : {
  },
  "id_str" : "319131331273584640",
  "text" : "How do you generate a random string? http://t.co/7tH3kiERXT",
  "id" : 319131331273584640,
  "created_at" : "Tue Apr 02 16:56:53 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318977158846480384",
  "text" : "Somehow I just spent $30 on Amazon Instant Video in $1.99 chunks. Damn you consumer psychology.",
  "id" : 318977158846480384,
  "created_at" : "Tue Apr 02 06:44:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 67, 79 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "Fancy",
      "screen_name" : "thefancy",
      "indices" : [ 81, 90 ],
      "id_str" : "21711511",
      "id" : 21711511
    }, {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 96, 101 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "318873307078356992",
  "text" : "I used to browse Amazon on iPhone for retail therapy; now I browse @Kickstarter, @TheFancy, and @Etsy.",
  "id" : 318873307078356992,
  "created_at" : "Mon Apr 01 23:51:35 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 3, 13 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "USV",
      "screen_name" : "usv",
      "indices" : [ 82, 86 ],
      "id_str" : "14946614",
      "id" : 14946614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http://t.co/HngQxJqVeU",
      "expanded_url" : "http://4sq.com/YOPaNm",
      "display_url" : "4sq.com/YOPaNm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.739481956, -73.9898943901 ]
  },
  "id_str" : "318864311378382849",
  "text" : "At @jenny8lee's excellent NY digital publishing talks. (@ Union Square Ventures - @usv w/ 5 others) http://t.co/HngQxJqVeU",
  "id" : 318864311378382849,
  "created_at" : "Mon Apr 01 23:15:50 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Carney",
      "screen_name" : "mcarney",
      "indices" : [ 0, 8 ],
      "id_str" : "23666890",
      "id" : 23666890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318836028196659200",
  "geo" : {
  },
  "id_str" : "318837788009172993",
  "in_reply_to_user_id" : 23666890,
  "text" : "@mcarney I was just being a pedantic asshole, but that's awesome.",
  "id" : 318837788009172993,
  "in_reply_to_status_id" : 318836028196659200,
  "created_at" : "Mon Apr 01 21:30:27 +0000 2013",
  "in_reply_to_screen_name" : "mcarney",
  "in_reply_to_user_id_str" : "23666890",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Carney",
      "screen_name" : "mcarney",
      "indices" : [ 0, 8 ],
      "id_str" : "23666890",
      "id" : 23666890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318833728992468992",
  "geo" : {
  },
  "id_str" : "318834862293393408",
  "in_reply_to_user_id" : 23666890,
  "text" : "@mcarney isn't every breakfast after midnight?",
  "id" : 318834862293393408,
  "in_reply_to_status_id" : 318833728992468992,
  "created_at" : "Mon Apr 01 21:18:49 +0000 2013",
  "in_reply_to_screen_name" : "mcarney",
  "in_reply_to_user_id_str" : "23666890",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    }, {
      "name" : "Amy Diaz",
      "screen_name" : "amybessdiaz",
      "indices" : [ 11, 23 ],
      "id_str" : "118762933",
      "id" : 118762933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318760979775225856",
  "geo" : {
  },
  "id_str" : "318764727922733059",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick @amybessdiaz Quora took a while to get on that boat.",
  "id" : 318764727922733059,
  "in_reply_to_status_id" : 318760979775225856,
  "created_at" : "Mon Apr 01 16:40:08 +0000 2013",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iFixit",
      "screen_name" : "iFixit",
      "indices" : [ 0, 7 ],
      "id_str" : "15339201",
      "id" : 15339201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http://t.co/JQs1s15GQU",
      "expanded_url" : "http://www.ifixit.com/Tools/Magnetic-Project-Mat/IF145-167",
      "display_url" : "ifixit.com/Tools/Magnetic\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "318757008356552705",
  "in_reply_to_user_id" : 15339201,
  "text" : "@iFixit is the magnetic project mat safe for mechanical watch projects? http://t.co/JQs1s15GQU?",
  "id" : 318757008356552705,
  "created_at" : "Mon Apr 01 16:09:27 +0000 2013",
  "in_reply_to_screen_name" : "iFixit",
  "in_reply_to_user_id_str" : "15339201",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]