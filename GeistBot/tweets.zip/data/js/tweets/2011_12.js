Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152972677861212162",
  "text" : "Katy Perry's marriage lasted 5.8 Kardashians. That's slightly more than 1 Solar Year for those of you that use metric.",
  "id" : 152972677861212162,
  "created_at" : "Sat Dec 31 04:41:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chenglin Yuan",
      "screen_name" : "chenglinnn",
      "indices" : [ 0, 11 ],
      "id_str" : "49660090",
      "id" : 49660090
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 98, 110 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9911954329, -78.7192683388 ]
  },
  "id_str" : "152929701369888768",
  "in_reply_to_user_id" : 49660090,
  "text" : "@chenglinnn Re: perfumes, same principle applies to everything. Watches, drinks, clothes, etc. cc @badboyboyce",
  "id" : 152929701369888768,
  "created_at" : "Sat Dec 31 01:50:56 +0000 2011",
  "in_reply_to_screen_name" : "chenglinnn",
  "in_reply_to_user_id_str" : "49660090",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celena Chan",
      "screen_name" : "celenachan",
      "indices" : [ 0, 11 ],
      "id_str" : "18780101",
      "id" : 18780101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152687007800377344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9493876314, -78.7445500866 ]
  },
  "id_str" : "152926245691199489",
  "in_reply_to_user_id" : 18780101,
  "text" : "@celenachan the old school Razr is still one of my favorite phones, against all reason. I bust it out for international SIMs",
  "id" : 152926245691199489,
  "in_reply_to_status_id" : 152687007800377344,
  "created_at" : "Sat Dec 31 01:37:12 +0000 2011",
  "in_reply_to_screen_name" : "celenachan",
  "in_reply_to_user_id_str" : "18780101",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9281678377, -78.7477044483 ]
  },
  "id_str" : "152900123666558976",
  "text" : "Just tried to type on a Kinesis keyboard that was set on Dvorak and in Chinese pinyin. Mega struggle.",
  "id" : 152900123666558976,
  "created_at" : "Fri Dec 30 23:53:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drunk Predator Drone",
      "screen_name" : "drunkenpredator",
      "indices" : [ 16, 32 ],
      "id_str" : "252787550",
      "id" : 252787550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152781382391832577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0070541613, -78.6997490656 ]
  },
  "id_str" : "152816631653994496",
  "in_reply_to_user_id" : 252787550,
  "text" : "Just discovered @drunkenpredator. Worth a few chuckles.",
  "id" : 152816631653994496,
  "in_reply_to_status_id" : 152781382391832577,
  "created_at" : "Fri Dec 30 18:21:38 +0000 2011",
  "in_reply_to_screen_name" : "drunkenpredator",
  "in_reply_to_user_id_str" : "252787550",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AW Asia",
      "screen_name" : "AWASIA",
      "indices" : [ 3, 10 ],
      "id_str" : "22698057",
      "id" : 22698057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/TW136Bkq",
      "expanded_url" : "http://www.shanghaidaily.com/nsp/Metro/2011/12/27/Changing%2Bcultural%2Blandscape%2Bfor%2Bcity/",
      "display_url" : "shanghaidaily.com/nsp/Metro/2011\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "152816234596007938",
  "text" : "RT @AWASIA: Groundbreaking ceremonies for the China Art Palace, China Contemporary Art Museum in Shanghai http://t.co/TW136Bkq",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http://t.co/TW136Bkq",
        "expanded_url" : "http://www.shanghaidaily.com/nsp/Metro/2011/12/27/Changing%2Bcultural%2Blandscape%2Bfor%2Bcity/",
        "display_url" : "shanghaidaily.com/nsp/Metro/2011\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "152780084703526913",
    "text" : "Groundbreaking ceremonies for the China Art Palace, China Contemporary Art Museum in Shanghai http://t.co/TW136Bkq",
    "id" : 152780084703526913,
    "created_at" : "Fri Dec 30 15:56:25 +0000 2011",
    "user" : {
      "name" : "AW Asia",
      "screen_name" : "AWASIA",
      "protected" : false,
      "id_str" : "22698057",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/535668456/QZL_OilPainting_2009_YoungIntellectualsNo1_220x180cm_AW6_lowres_normal.jpg",
      "id" : 22698057,
      "verified" : false
    }
  },
  "id" : 152816234596007938,
  "created_at" : "Fri Dec 30 18:20:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Motley Fool",
      "screen_name" : "themotleyfool",
      "indices" : [ 3, 17 ],
      "id_str" : "15568127",
      "id" : 15568127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152816203365220352",
  "text" : "RT @themotleyfool: Betamax. MiniDisc. Memory Stick. UMD. And now, PlayStation Vita. The lesson Sony ($SNE) never learns: http://t.co/1sF ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http://t.co/1sFNv59T",
        "expanded_url" : "http://mot.ly/rvnzDr",
        "display_url" : "mot.ly/rvnzDr"
      } ]
    },
    "geo" : {
    },
    "id_str" : "152778633218506752",
    "text" : "Betamax. MiniDisc. Memory Stick. UMD. And now, PlayStation Vita. The lesson Sony ($SNE) never learns: http://t.co/1sFNv59T",
    "id" : 152778633218506752,
    "created_at" : "Fri Dec 30 15:50:39 +0000 2011",
    "user" : {
      "name" : "The Motley Fool",
      "screen_name" : "themotleyfool",
      "protected" : false,
      "id_str" : "15568127",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1119788045/tmf_normal.png",
      "id" : 15568127,
      "verified" : true
    }
  },
  "id" : 152816203365220352,
  "created_at" : "Fri Dec 30 18:19:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breaking News",
      "screen_name" : "BreakingNews",
      "indices" : [ 38, 51 ],
      "id_str" : "6017542",
      "id" : 6017542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GM",
      "indices" : [ 52, 55 ]
    }, {
      "text" : "Chevy",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/zJkq2w0c",
      "expanded_url" : "http://reut.rs/sVM8Zt",
      "display_url" : "reut.rs/sVM8Zt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0068812007, -78.7000909635 ]
  },
  "id_str" : "152816046166908928",
  "text" : "The Sonic was doing so well too... RT @BreakingNews #GM recalls 4,873 #Chevy Sonics for possible missing brake pads http://t.co/zJkq2w0c",
  "id" : 152816046166908928,
  "created_at" : "Fri Dec 30 18:19:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Uttley",
      "screen_name" : "22u",
      "indices" : [ 0, 4 ],
      "id_str" : "24180129",
      "id" : 24180129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152770105359609856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0068254192, -78.6999197212 ]
  },
  "id_str" : "152815395915563008",
  "in_reply_to_user_id" : 24180129,
  "text" : "@22u where are you working now?",
  "id" : 152815395915563008,
  "in_reply_to_status_id" : 152770105359609856,
  "created_at" : "Fri Dec 30 18:16:44 +0000 2011",
  "in_reply_to_screen_name" : "22u",
  "in_reply_to_user_id_str" : "24180129",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/wLVtuRnz",
      "expanded_url" : "http://instagr.am/p/c2S6s/",
      "display_url" : "instagr.am/p/c2S6s/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "152667113654452224",
  "text" : "Ready to roll. http://t.co/wLVtuRnz",
  "id" : 152667113654452224,
  "created_at" : "Fri Dec 30 08:27:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dragon ",
      "screen_name" : "dragoninnovate",
      "indices" : [ 3, 18 ],
      "id_str" : "421859846",
      "id" : 421859846
    }, {
      "name" : "HAXLR8R",
      "screen_name" : "haxlr8r",
      "indices" : [ 55, 63 ],
      "id_str" : "355428046",
      "id" : 355428046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/7C4u3VnE",
      "expanded_url" : "http://www.haxlr8r.com/",
      "display_url" : "haxlr8r.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "152435173106003969",
  "text" : "RT @dragoninnovate: World's first hardware accelerator @haxlr8r in Shenzhen and Bay area in March 2012. More info: http://t.co/7C4u3VnE  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HAXLR8R",
        "screen_name" : "haxlr8r",
        "indices" : [ 35, 43 ],
        "id_str" : "355428046",
        "id" : 355428046
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http://t.co/7C4u3VnE",
        "expanded_url" : "http://www.haxlr8r.com/",
        "display_url" : "haxlr8r.com"
      }, {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/Y9gTTKYp",
        "expanded_url" : "http://twitpic.com/7mduur",
        "display_url" : "twitpic.com/7mduur"
      } ]
    },
    "geo" : {
    },
    "id_str" : "147756027025166336",
    "text" : "World's first hardware accelerator @haxlr8r in Shenzhen and Bay area in March 2012. More info: http://t.co/7C4u3VnE & http://t.co/Y9gTTKYp",
    "id" : 147756027025166336,
    "created_at" : "Fri Dec 16 19:12:36 +0000 2011",
    "user" : {
      "name" : "Dragon ",
      "screen_name" : "dragoninnovate",
      "protected" : false,
      "id_str" : "421859846",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2226528205/DI_gear_normal.jpg",
      "id" : 421859846,
      "verified" : false
    }
  },
  "id" : 152435173106003969,
  "created_at" : "Thu Dec 29 17:05:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celena Chan",
      "screen_name" : "celenachan",
      "indices" : [ 0, 11 ],
      "id_str" : "18780101",
      "id" : 18780101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152298142379950080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0070508086, -78.6999985949 ]
  },
  "id_str" : "152300502846160896",
  "in_reply_to_user_id" : 18780101,
  "text" : "@celenachan how about individual and composite scores? HK v. Taiwan",
  "id" : 152300502846160896,
  "in_reply_to_status_id" : 152298142379950080,
  "created_at" : "Thu Dec 29 08:10:44 +0000 2011",
  "in_reply_to_screen_name" : "celenachan",
  "in_reply_to_user_id_str" : "18780101",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Font Game",
      "screen_name" : "fontgame",
      "indices" : [ 28, 37 ],
      "id_str" : "68224790",
      "id" : 68224790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152287876627959808",
  "text" : "Got bored today, downloaded @fontgame. Learning about typography!",
  "id" : 152287876627959808,
  "created_at" : "Thu Dec 29 07:20:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celena Chan",
      "screen_name" : "celenachan",
      "indices" : [ 0, 11 ],
      "id_str" : "18780101",
      "id" : 18780101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152250046732173314",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0066490639, -78.699665079 ]
  },
  "id_str" : "152260732640169984",
  "in_reply_to_user_id" : 18780101,
  "text" : "@celenachan your verdict: Taiwan or HK?",
  "id" : 152260732640169984,
  "in_reply_to_status_id" : 152250046732173314,
  "created_at" : "Thu Dec 29 05:32:42 +0000 2011",
  "in_reply_to_screen_name" : "celenachan",
  "in_reply_to_user_id_str" : "18780101",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 0, 9 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152117742298861568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.006743989, -78.7001103257 ]
  },
  "id_str" : "152212720031244288",
  "in_reply_to_user_id" : 340545195,
  "text" : "@Romotive unfortunately I'm not back til late January. But it'll be a nice belated Xmas gift to myself :)",
  "id" : 152212720031244288,
  "in_reply_to_status_id" : 152117742298861568,
  "created_at" : "Thu Dec 29 02:21:55 +0000 2011",
  "in_reply_to_screen_name" : "Romotive",
  "in_reply_to_user_id_str" : "340545195",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9367685086, -78.7066777983 ]
  },
  "id_str" : "152156127071711233",
  "text" : "Best part of living in middle of nowhere? Unlocked iPhone 4S's aplenty. I feel like Santa, distributing to friends in metro areas sold out.",
  "id" : 152156127071711233,
  "created_at" : "Wed Dec 28 22:37:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 19, 30 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/AxGTep7m",
      "expanded_url" : "http://tcrn.ch/st64yO",
      "display_url" : "tcrn.ch/st64yO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9364106013, -78.710910827 ]
  },
  "id_str" : "152155607623925761",
  "text" : "The plot thickens. @TechCrunch: \"New York Times\" Email You Received Isn't Actually From the NYT http://t.co/AxGTep7m",
  "id" : 152155607623925761,
  "created_at" : "Wed Dec 28 22:34:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 75, 86 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9146773029, -78.7619020915 ]
  },
  "id_str" : "152146276371267585",
  "text" : "Google Reader is still much better for organizing and reading longform. RT @parislemon: ...Twitter killed [RSS] a while back, no?",
  "id" : 152146276371267585,
  "created_at" : "Wed Dec 28 21:57:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9143369012, -78.759729378 ]
  },
  "id_str" : "152139849892245504",
  "text" : "I left music playing at home: \"hey Kane can you check the amp I think there's a short somewhere on the board.\" \"no mom that's just dubstep\"",
  "id" : 152139849892245504,
  "created_at" : "Wed Dec 28 21:32:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 9, 18 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 30, 38 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152070062306631682",
  "text" : "I had my @romotive shipped to @harvard but I'm going to be in Taiwan til February. Terrible planning on my part.",
  "id" : 152070062306631682,
  "created_at" : "Wed Dec 28 16:55:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/o8DSmbbt",
      "expanded_url" : "http://www.stratfor.com",
      "display_url" : "stratfor.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "152056180385124353",
  "text" : "Protip for Stratfor: if you're going to run a company specializing in security, at least encrypt your passwords. http://t.co/o8DSmbbt",
  "id" : 152056180385124353,
  "created_at" : "Wed Dec 28 15:59:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/pcMfZ8Gy",
      "expanded_url" : "http://penny-arcade.com/resources/just-wow1.html",
      "display_url" : "penny-arcade.com/resources/just\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151959941387780096",
  "text" : "I just read up on this Ocean Marketing fiasco... it's kind of mindblowing http://t.co/pcMfZ8Gy",
  "id" : 151959941387780096,
  "created_at" : "Wed Dec 28 09:37:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 0, 6 ],
      "id_str" : "14208617",
      "id" : 14208617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151821622129606656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0070060545, -78.6999654047 ]
  },
  "id_str" : "151822618859810816",
  "in_reply_to_user_id" : 14208617,
  "text" : "@robgo let's build that app.",
  "id" : 151822618859810816,
  "in_reply_to_status_id" : 151821622129606656,
  "created_at" : "Wed Dec 28 00:31:47 +0000 2011",
  "in_reply_to_screen_name" : "robgo",
  "in_reply_to_user_id_str" : "14208617",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 6, 14 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Classie Briant",
      "screen_name" : "ClassieBriant49",
      "indices" : [ 47, 63 ],
      "id_str" : "343871414",
      "id" : 343871414
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 65, 72 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.747189832, -79.3934615237 ]
  },
  "id_str" : "151483211711651840",
  "text" : "First @twitter spambot caught and reported! RT @ClassieBriant49: @khsieh We're giving away a Free macbook! [link removed]",
  "id" : 151483211711651840,
  "created_at" : "Tue Dec 27 02:03:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flights",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "insurance",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "viagra",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "banks",
      "indices" : [ 47, 53 ]
    }, {
      "text" : "macbookpro",
      "indices" : [ 54, 65 ]
    }, {
      "text" : "macbookair",
      "indices" : [ 66, 77 ]
    }, {
      "text" : "mp3",
      "indices" : [ 78, 82 ]
    }, {
      "text" : "download",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "watches",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "loans",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "creditcards",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7472466194, -79.3936204445 ]
  },
  "id_str" : "151482363774369792",
  "text" : "More spambot bait: #flights #insurance #viagra #banks #macbookpro #macbookair #mp3 #download #watches #loans #creditcards",
  "id" : 151482363774369792,
  "created_at" : "Tue Dec 27 01:59:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apple",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "iPhone",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "iPad",
      "indices" : [ 68, 73 ]
    }, {
      "text" : "iPod",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "stocks",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "xbox",
      "indices" : [ 88, 93 ]
    }, {
      "text" : "playstation",
      "indices" : [ 94, 106 ]
    }, {
      "text" : "canon",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "nikon",
      "indices" : [ 114, 120 ]
    }, {
      "text" : "dell",
      "indices" : [ 121, 126 ]
    }, {
      "text" : "Rolex",
      "indices" : [ 127, 133 ]
    }, {
      "text" : "sex",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.747321805, -79.3936072011 ]
  },
  "id_str" : "151479157791010816",
  "text" : "Time for the annual baiting of the twitter spambots: #apple #iPhone #iPad #iPod #stocks #xbox #playstation #canon #nikon #dell #Rolex #sex",
  "id" : 151479157791010816,
  "created_at" : "Tue Dec 27 01:47:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151219278794862593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0069174525, -78.6998476368 ]
  },
  "id_str" : "151222426183798784",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj I have a later-gen Kinect that draws power thru Xbox, and I've been loathe to buy the $35 power adapter needed for computer.",
  "id" : 151222426183798784,
  "in_reply_to_status_id" : 151219278794862593,
  "created_at" : "Mon Dec 26 08:46:50 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celena Chan",
      "screen_name" : "celenachan",
      "indices" : [ 0, 11 ],
      "id_str" : "18780101",
      "id" : 18780101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151151612990197760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.006944614, -78.6998142859 ]
  },
  "id_str" : "151217561407717376",
  "in_reply_to_user_id" : 18780101,
  "text" : "@celenachan looking at your Asian adventure pics makes me really jealous!",
  "id" : 151217561407717376,
  "in_reply_to_status_id" : 151151612990197760,
  "created_at" : "Mon Dec 26 08:27:30 +0000 2011",
  "in_reply_to_screen_name" : "celenachan",
  "in_reply_to_user_id_str" : "18780101",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bna",
      "screen_name" : "workingbrian",
      "indices" : [ 0, 13 ],
      "id_str" : "27444157",
      "id" : 27444157
    }, {
      "name" : "Danielle Kim",
      "screen_name" : "daniellekim",
      "indices" : [ 14, 26 ],
      "id_str" : "17025576",
      "id" : 17025576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151134196688093184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9548787, -78.6956657377 ]
  },
  "id_str" : "151137945968066560",
  "in_reply_to_user_id" : 27444157,
  "text" : "@workingbrian @daniellekim 2009 was still the best year.",
  "id" : 151137945968066560,
  "in_reply_to_status_id" : 151134196688093184,
  "created_at" : "Mon Dec 26 03:11:08 +0000 2011",
  "in_reply_to_screen_name" : "workingbrian",
  "in_reply_to_user_id_str" : "27444157",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/v3ZDvJeJ",
      "expanded_url" : "http://djearworm.com/",
      "display_url" : "djearworm.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151124117813342209",
  "text" : "DJ Earworm's United State of Pop 2011 is up! \"World Go Boom\" http://t.co/v3ZDvJeJ",
  "id" : 151124117813342209,
  "created_at" : "Mon Dec 26 02:16:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/WwzbMQe3",
      "expanded_url" : "http://openkinect.org/wiki/Main_Page",
      "display_url" : "openkinect.org/wiki/Main_Page"
    } ]
  },
  "in_reply_to_status_id_str" : "151073716476985344",
  "geo" : {
  },
  "id_str" : "151074082228682754",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj the Kinect SDK is in beta if you want to use the official one, but there's always libfreenect too http://t.co/WwzbMQe3",
  "id" : 151074082228682754,
  "in_reply_to_status_id" : 151073716476985344,
  "created_at" : "Sun Dec 25 22:57:22 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 25, 38 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0067698891, -78.6999496446 ]
  },
  "id_str" : "151067344016375810",
  "text" : "Play with an SDK yet? RT @sunilnagaraj: The XBox Kinect is absolutely amazing -- core tech, user experience, thoughtful games",
  "id" : 151067344016375810,
  "created_at" : "Sun Dec 25 22:30:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/jyONCcH7",
      "expanded_url" : "http://kanehsieh.com/#aa2/custom_plain",
      "display_url" : "kanehsieh.com/#aa2/custom_pl\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151027043734257664",
  "text" : "\"On Orchids:\" a winter break book restoration project with mom. http://t.co/jyONCcH7",
  "id" : 151027043734257664,
  "created_at" : "Sun Dec 25 19:50:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150742856070479872",
  "text" : "RT @neiltyson: According to the song, Rudolph's nose is shiny, which means it reflects rather than emits light. Useless for navigating fog.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "150737457388863489",
    "text" : "According to the song, Rudolph's nose is shiny, which means it reflects rather than emits light. Useless for navigating fog.",
    "id" : 150737457388863489,
    "created_at" : "Sun Dec 25 00:39:45 +0000 2011",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/74188698/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 150742856070479872,
  "created_at" : "Sun Dec 25 01:01:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Tseng",
      "screen_name" : "BenjaminTseng",
      "indices" : [ 0, 14 ],
      "id_str" : "15876871",
      "id" : 15876871
    }, {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 15, 21 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150655568066002944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9816329386, -78.6503172108 ]
  },
  "id_str" : "150717950226214912",
  "in_reply_to_user_id" : 15876871,
  "text" : "@BenjaminTseng @jluan how do you guys know each other?",
  "id" : 150717950226214912,
  "in_reply_to_status_id" : 150655568066002944,
  "created_at" : "Sat Dec 24 23:22:14 +0000 2011",
  "in_reply_to_screen_name" : "BenjaminTseng",
  "in_reply_to_user_id_str" : "15876871",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Citizens Bank",
      "screen_name" : "CitizensBank",
      "indices" : [ 0, 13 ],
      "id_str" : "210953833",
      "id" : 210953833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150646475993522176",
  "in_reply_to_user_id" : 210953833,
  "text" : "@citizensbank takes new top spot for terrible customer service.",
  "id" : 150646475993522176,
  "created_at" : "Sat Dec 24 18:38:13 +0000 2011",
  "in_reply_to_screen_name" : "CitizensBank",
  "in_reply_to_user_id_str" : "210953833",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 0, 13 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0069124233, -78.6998983473 ]
  },
  "id_str" : "150496106189557761",
  "in_reply_to_user_id" : 5988062,
  "text" : "@TheEconomist on America's immigration policy: \"self destructive foolishness.\"",
  "id" : 150496106189557761,
  "created_at" : "Sat Dec 24 08:40:42 +0000 2011",
  "in_reply_to_screen_name" : "TheEconomist",
  "in_reply_to_user_id_str" : "5988062",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.95309472, -78.69480508 ]
  },
  "id_str" : "150402502175625216",
  "text" : "I love that the OSX terminal in Girl with the Dragon Tattoo beeps when people type. Is there a plugin that does that?",
  "id" : 150402502175625216,
  "created_at" : "Sat Dec 24 02:28:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.96496176, -78.69516324 ]
  },
  "id_str" : "150379762450313217",
  "text" : "If I had blinked, I probably wouldn't have noticed that the Batman, GI Joe, and The Avengers trailers were for different movies.",
  "id" : 150379762450313217,
  "created_at" : "Sat Dec 24 00:58:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Tseng",
      "screen_name" : "BenjaminTseng",
      "indices" : [ 3, 17 ],
      "id_str" : "15876871",
      "id" : 15876871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150368932983869440",
  "text" : "RT @BenjaminTseng: Why UC Berkeley chose Google Apps over Microsoft Office 365: interesting to see who was better at what (not obvious)  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/vpzqpvko",
        "expanded_url" : "http://technology.berkeley.edu/productivity-suite/google/matrix.html",
        "display_url" : "technology.berkeley.edu/productivity-s\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "150360259008012288",
    "text" : "Why UC Berkeley chose Google Apps over Microsoft Office 365: interesting to see who was better at what (not obvious) http://t.co/vpzqpvko",
    "id" : 150360259008012288,
    "created_at" : "Fri Dec 23 23:40:53 +0000 2011",
    "user" : {
      "name" : "Benjamin Tseng",
      "screen_name" : "BenjaminTseng",
      "protected" : false,
      "id_str" : "15876871",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2355557182/n0mQ0SQp_normal",
      "id" : 15876871,
      "verified" : false
    }
  },
  "id" : 150368932983869440,
  "created_at" : "Sat Dec 24 00:15:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150333085920133120",
  "text" : "Is it me, or is every movie out now the self-proclaimed \"Movie of the Year?\"",
  "id" : 150333085920133120,
  "created_at" : "Fri Dec 23 21:52:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 9, 21 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 22, 30 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "indices" : [ 34, 50 ],
      "id_str" : "263122363",
      "id" : 263122363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0070446898, -78.7005656306 ]
  },
  "id_str" : "150294688665051136",
  "text" : "That us! @badboyboyce @digitil RT @HarvardAsianGuy: Fun fact: Black & Yellow is a song about me and my black roommate.",
  "id" : 150294688665051136,
  "created_at" : "Fri Dec 23 19:20:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 3, 13 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/YX4Zn6HP",
      "expanded_url" : "http://Amazon.com",
      "display_url" : "Amazon.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "150294041328750593",
  "text" : "RT @johnhcook: Unable to hire all of the engineers in Seattle, http://t.co/YX4Zn6HP picks Boston for new development center: http://t.co ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http://t.co/YX4Zn6HP",
        "expanded_url" : "http://Amazon.com",
        "display_url" : "Amazon.com"
      }, {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/H0kAClnb",
        "expanded_url" : "http://www.geekwire.com/2011/growth-continues-amazoncom-picks-boston-engineering-center",
        "display_url" : "geekwire.com/2011/growth-co\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "150263090020220928",
    "text" : "Unable to hire all of the engineers in Seattle, http://t.co/YX4Zn6HP picks Boston for new development center: http://t.co/H0kAClnb",
    "id" : 150263090020220928,
    "created_at" : "Fri Dec 23 17:14:47 +0000 2011",
    "user" : {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "protected" : false,
      "id_str" : "14326765",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/403089484/john-headshot_normal.jpg",
      "id" : 14326765,
      "verified" : false
    }
  },
  "id" : 150294041328750593,
  "created_at" : "Fri Dec 23 19:17:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 8, 18 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0069190788, -78.6998280654 ]
  },
  "id_str" : "150151353400958978",
  "text" : "Asa! RT @jenny8lee: Good guy names beginning with A? I know Adam and Andrew, but prefer something more distinctive.",
  "id" : 150151353400958978,
  "created_at" : "Fri Dec 23 09:50:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DreamHost",
      "screen_name" : "DreamHost",
      "indices" : [ 80, 90 ],
      "id_str" : "14217022",
      "id" : 14217022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0068320828, -78.7000631355 ]
  },
  "id_str" : "150147819905359872",
  "text" : "People are flocking away from GoDaddy bc of the SOPA thing, but I've been using @DreamHost for years bc GoDaddys interface blows.",
  "id" : 150147819905359872,
  "created_at" : "Fri Dec 23 09:36:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150133187320889345",
  "text" : "The Historic Coin Mint and other sleazy companies that profiteer on tragedy such as 9/11 sicken me.",
  "id" : 150133187320889345,
  "created_at" : "Fri Dec 23 08:38:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celena Chan",
      "screen_name" : "celenachan",
      "indices" : [ 0, 11 ],
      "id_str" : "18780101",
      "id" : 18780101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149816439887499264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0234417459, -78.6973826867 ]
  },
  "id_str" : "149958338208215041",
  "in_reply_to_user_id" : 18780101,
  "text" : "@celenachan when are you in Taipei?",
  "id" : 149958338208215041,
  "in_reply_to_status_id" : 149816439887499264,
  "created_at" : "Thu Dec 22 21:03:48 +0000 2011",
  "in_reply_to_screen_name" : "celenachan",
  "in_reply_to_user_id_str" : "18780101",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Wong",
      "screen_name" : "mbwong",
      "indices" : [ 48, 55 ],
      "id_str" : "18406275",
      "id" : 18406275
    }, {
      "name" : "Kevin Lee",
      "screen_name" : "kevineriklee",
      "indices" : [ 60, 73 ],
      "id_str" : "38612181",
      "id" : 38612181
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 102, 110 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nostalgia",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0069412152, -78.699796591 ]
  },
  "id_str" : "149767185022189569",
  "text" : "Back in Buffalo. Packing for HK and Taipei with @mbwong and @kevineriklee before one last semester at @Harvard. #nostalgia",
  "id" : 149767185022189569,
  "created_at" : "Thu Dec 22 08:24:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 0, 9 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3736566632, -71.1186193955 ]
  },
  "id_str" : "149251698483929091",
  "in_reply_to_user_id" : 340545195,
  "text" : "@Romotive customer support is truly epic! Especially since the management, engineers, and PR team are all the same people.",
  "id" : 149251698483929091,
  "created_at" : "Tue Dec 20 22:15:52 +0000 2011",
  "in_reply_to_screen_name" : "Romotive",
  "in_reply_to_user_id_str" : "340545195",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 30, 38 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/BDsw3ByO",
      "expanded_url" : "http://j.mp/ul4CM0",
      "display_url" : "j.mp/ul4CM0"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3682640819, -71.1156044249 ]
  },
  "id_str" : "148693239862530048",
  "text" : "Saudi Prince invests $300M in @twitter http://t.co/BDsw3ByO",
  "id" : 148693239862530048,
  "created_at" : "Mon Dec 19 09:16:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Shields",
      "screen_name" : "sdshields",
      "indices" : [ 3, 13 ],
      "id_str" : "15883528",
      "id" : 15883528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148632968397733889",
  "text" : "RT @sdshields: Kim Jong Il is dead? Wow, 2011 was a terrible year to be a dictator. Alternately, an awesome year for the rest of us.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "148602546657832960",
    "text" : "Kim Jong Il is dead? Wow, 2011 was a terrible year to be a dictator. Alternately, an awesome year for the rest of us.",
    "id" : 148602546657832960,
    "created_at" : "Mon Dec 19 03:16:22 +0000 2011",
    "user" : {
      "name" : "Scott Shields",
      "screen_name" : "sdshields",
      "protected" : false,
      "id_str" : "15883528",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1251141234/lilhat_normal.jpg",
      "id" : 15883528,
      "verified" : false
    }
  },
  "id" : 148632968397733889,
  "created_at" : "Mon Dec 19 05:17:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3681860045, -71.1153240503 ]
  },
  "id_str" : "148605206094036992",
  "text" : "Kim Jong Il has died! Stuffs about to\nget really interesting on the Korean peninsula.",
  "id" : 148605206094036992,
  "created_at" : "Mon Dec 19 03:26:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 28, 34 ],
      "id_str" : "1344951",
      "id" : 1344951
    }, {
      "name" : "tim leong",
      "screen_name" : "timleong",
      "indices" : [ 64, 73 ],
      "id_str" : "20487008",
      "id" : 20487008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147794059304501248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3687809642, -71.1155631668 ]
  },
  "id_str" : "147872930259406849",
  "in_reply_to_user_id" : 20487008,
  "text" : "Hot new look in this months @wired, but it feels a little thin! @timleong",
  "id" : 147872930259406849,
  "in_reply_to_status_id" : 147794059304501248,
  "created_at" : "Sat Dec 17 02:57:08 +0000 2011",
  "in_reply_to_screen_name" : "timleong",
  "in_reply_to_user_id_str" : "20487008",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3691461515, -71.1164007895 ]
  },
  "id_str" : "147661881711144960",
  "text" : "I wish my camera phone could capture the full dynamic range of this sunrise over the Charles River.",
  "id" : 147661881711144960,
  "created_at" : "Fri Dec 16 12:58:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 0, 7 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/iA64qD0N",
      "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=SAIEamakLoY",
      "display_url" : "youtube.com/watch?feature=\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "147484039538937857",
  "in_reply_to_user_id" : 20536157,
  "text" : "@google's Year in Review video is out for 2011. I always tear up to these. http://t.co/iA64qD0N",
  "id" : 147484039538937857,
  "created_at" : "Fri Dec 16 01:11:49 +0000 2011",
  "in_reply_to_screen_name" : "google",
  "in_reply_to_user_id_str" : "20536157",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 15, 20 ],
      "id_str" : "19103481",
      "id" : 19103481
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 32, 40 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3712907872, -71.1189019494 ]
  },
  "id_str" : "147444162772484096",
  "text" : "Pow-wowed with @uber today as a @Harvard ambassador and got a sweet promo code for everyone! $15 credit - sign up and use harvard2011",
  "id" : 147444162772484096,
  "created_at" : "Thu Dec 15 22:33:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Googletest",
      "screen_name" : "googledocs",
      "indices" : [ 34, 45 ],
      "id_str" : "488683847",
      "id" : 488683847
    }, {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 56, 62 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smart",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145939854394523648",
  "text" : "Wow, spammers sending messages in @googledocs to bypass @gmail filters now. #smart",
  "id" : 145939854394523648,
  "created_at" : "Sun Dec 11 18:55:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.368166768, -71.1155090389 ]
  },
  "id_str" : "145793510786867200",
  "text" : "One of these days my sleep schedule is going to get pushed so far back it's considered normal again.",
  "id" : 145793510786867200,
  "created_at" : "Sun Dec 11 09:14:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 64, 72 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145614702368653312",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce has locked himself in to work. Bet is if he checks @twitter he burns the cash in his wallet. It's on.",
  "id" : 145614702368653312,
  "created_at" : "Sat Dec 10 21:23:45 +0000 2011",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 5, 17 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 22, 28 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/H86Lj8eK",
      "expanded_url" : "http://bit.ly/usFDj1",
      "display_url" : "bit.ly/usFDj1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3682829831, -71.1154382118 ]
  },
  "id_str" : "145238591184973824",
  "text" : "Boom @badboyboyce. RT @hseas: Peter Boyce '13 is helping turn Harvard into an \"engine of innovation\" http://t.co/H86Lj8eK",
  "id" : 145238591184973824,
  "created_at" : "Fri Dec 09 20:29:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 123, 129 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3677027019, -71.1154103347 ]
  },
  "id_str" : "144986160756826113",
  "text" : "Built a lesson plan analyzer in python + map reduce last week. Building a glass optics simulator in OpenGL now. Life as an @hseas student.",
  "id" : 144986160756826113,
  "created_at" : "Fri Dec 09 03:46:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 9, 17 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144903187869089792",
  "text" : "whoa new @twitter wut",
  "id" : 144903187869089792,
  "created_at" : "Thu Dec 08 22:16:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 55, 67 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Alex Taussig",
      "screen_name" : "ataussig",
      "indices" : [ 72, 81 ],
      "id_str" : "22097962",
      "id" : 22097962
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/144897843990245376/photo/1",
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/K4ZtoZkY",
      "media_url" : "http://pbs.twimg.com/media/AgLH0kgCMAALipj.jpg",
      "id_str" : "144897843994439680",
      "id" : 144897843994439680,
      "media_url_https" : "https://pbs.twimg.com/media/AgLH0kgCMAALipj.jpg",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com/K4ZtoZkY"
    } ],
    "hashtags" : [ {
      "text" : "eveningofventures",
      "indices" : [ 18, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144897843990245376",
  "text" : "Photographing the #eveningofventures event at HBS with @badboyboyce and @ataussig http://t.co/K4ZtoZkY",
  "id" : 144897843990245376,
  "created_at" : "Thu Dec 08 21:55:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AW Asia",
      "screen_name" : "AWASIA",
      "indices" : [ 9, 16 ],
      "id_str" : "22698057",
      "id" : 22698057
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/144890768434270209/photo/1",
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/eUcs7Rv9",
      "media_url" : "http://pbs.twimg.com/media/AgLBYuACEAAbIaM.jpg",
      "id_str" : "144890768438464512",
      "id" : 144890768438464512,
      "media_url_https" : "https://pbs.twimg.com/media/AgLBYuACEAAbIaM.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/eUcs7Rv9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3683890097, -71.1152701419 ]
  },
  "id_str" : "144890768434270209",
  "text" : "Just got @AWASIA's journal. Can't wait to settle back with some cocoa and read. http://t.co/eUcs7Rv9",
  "id" : 144890768434270209,
  "created_at" : "Thu Dec 08 21:27:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wikipedia ",
      "screen_name" : "Wikipedia",
      "indices" : [ 47, 57 ],
      "id_str" : "86390214",
      "id" : 86390214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mindblown",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144152507894079489",
  "text" : "Someone in CS205 built a script that plays the @Wikipedia game on an Nvidia GPU. #mindblown",
  "id" : 144152507894079489,
  "created_at" : "Tue Dec 06 20:33:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard i-lab",
      "screen_name" : "innovationlab",
      "indices" : [ 0, 14 ],
      "id_str" : "246493616",
      "id" : 246493616
    }, {
      "name" : "Arduino",
      "screen_name" : "arduino",
      "indices" : [ 78, 86 ],
      "id_str" : "266400754",
      "id" : 266400754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/pwiSQ0Db",
      "expanded_url" : "http://twitter.com/khsieh/status/143893557483282432/photo/1",
      "display_url" : "pic.twitter.com/pwiSQ0Db"
    } ]
  },
  "in_reply_to_status_id_str" : "143892898725896193",
  "geo" : {
  },
  "id_str" : "143893811888795648",
  "in_reply_to_user_id" : 246493616,
  "text" : "@innovationlab Besides the standard electronics and materials tools, a box of @arduino and shields! http://t.co/pwiSQ0Db",
  "id" : 143893811888795648,
  "in_reply_to_status_id" : 143892898725896193,
  "created_at" : "Tue Dec 06 03:25:32 +0000 2011",
  "in_reply_to_screen_name" : "innovationlab",
  "in_reply_to_user_id_str" : "246493616",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard i-lab",
      "screen_name" : "innovationlab",
      "indices" : [ 0, 14 ],
      "id_str" : "246493616",
      "id" : 246493616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3681913228, -71.1154779114 ]
  },
  "id_str" : "143875344938696704",
  "in_reply_to_user_id" : 246493616,
  "text" : "@innovationlab Sculptures are cool but we need some tools and materials to actually build stuff!",
  "id" : 143875344938696704,
  "created_at" : "Tue Dec 06 02:12:09 +0000 2011",
  "in_reply_to_screen_name" : "innovationlab",
  "in_reply_to_user_id_str" : "246493616",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 56, 68 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 73, 82 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.368196527, -71.1155135453 ]
  },
  "id_str" : "143874954717433856",
  "text" : "I stopped using foursquare. I concede all mayorships to @badboyboyce and @thepunit",
  "id" : 143874954717433856,
  "created_at" : "Tue Dec 06 02:10:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 29, 40 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/S5Jxfhyt",
      "expanded_url" : "http://onforb.es/vbprBI",
      "display_url" : "onforb.es/vbprBI"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3704349313, -71.1210688979 ]
  },
  "id_str" : "142833686906281985",
  "text" : "This makes me really sad. RT @ForbesTech: Electric Car Startup Aptera Closes Shop.  http://t.co/S5Jxfhyt",
  "id" : 142833686906281985,
  "created_at" : "Sat Dec 03 05:12:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.370470044, -71.1213220769 ]
  },
  "id_str" : "142832609444110336",
  "text" : "The Subaru BRZ looks like hot hot fun.",
  "id" : 142832609444110336,
  "created_at" : "Sat Dec 03 05:08:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 30, 37 ],
      "id_str" : "17307429",
      "id" : 17307429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.368287787, -71.1154212588 ]
  },
  "id_str" : "142382195091312640",
  "text" : "After threat of legal action, @lenovo's \"two week estimate\" conveniently dropped to 48 hours. Making this repair turnaround a tidy 7 weeks.",
  "id" : 142382195091312640,
  "created_at" : "Thu Dec 01 23:18:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 0, 9 ],
      "id_str" : "20568189",
      "id" : 20568189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142360351932035072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3684184595, -71.1150025993 ]
  },
  "id_str" : "142370336346865664",
  "in_reply_to_user_id" : 20568189,
  "text" : "@HODINKEE any way to buy from the pop-up shop remotely?",
  "id" : 142370336346865664,
  "in_reply_to_status_id" : 142360351932035072,
  "created_at" : "Thu Dec 01 22:31:47 +0000 2011",
  "in_reply_to_screen_name" : "HODINKEE",
  "in_reply_to_user_id_str" : "20568189",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]