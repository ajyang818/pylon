Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 0, 9 ],
      "id_str" : "20568189",
      "id" : 20568189
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/142051419871129600/photo/1",
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/aYUqoVoD",
      "media_url" : "http://pbs.twimg.com/media/AfirA4WCMAAjEHk.jpg",
      "id_str" : "142051419875323904",
      "id" : 142051419875323904,
      "media_url_https" : "https://pbs.twimg.com/media/AfirA4WCMAAjEHk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com/aYUqoVoD"
    } ],
    "hashtags" : [ {
      "text" : "womw",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3703384651, -71.1210138323 ]
  },
  "id_str" : "142051419871129600",
  "in_reply_to_user_id" : 20568189,
  "text" : "@HODINKEE orange Planet Ocean on orange NATO. #womw http://t.co/aYUqoVoD",
  "id" : 142051419871129600,
  "created_at" : "Thu Dec 01 01:24:33 +0000 2011",
  "in_reply_to_screen_name" : "HODINKEE",
  "in_reply_to_user_id_str" : "20568189",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 14, 25 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/SUqwdktJ",
      "expanded_url" : "http://onforb.es/vBChAV",
      "display_url" : "onforb.es/vBChAV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3679925083, -71.1153460947 ]
  },
  "id_str" : "142010799970459648",
  "text" : "Called it. RT @ForbesTech: RIM now offering security for iPhone and Android... to gain back some enterprise market. http://t.co/SUqwdktJ",
  "id" : 142010799970459648,
  "created_at" : "Wed Nov 30 22:43:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kirsner",
      "screen_name" : "ScottKirsner",
      "indices" : [ 3, 16 ],
      "id_str" : "896221",
      "id" : 896221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142009764476502016",
  "text" : "RT @ScottKirsner: Secretary Chu laugh line: \"Since we're at MIT, I'll remind you how a transformer works. If we were at Harvard, I'd hav ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "141938707375730688",
    "text" : "Secretary Chu laugh line: \"Since we're at MIT, I'll remind you how a transformer works. If we were at Harvard, I'd have to teach you...\"",
    "id" : 141938707375730688,
    "created_at" : "Wed Nov 30 17:56:39 +0000 2011",
    "user" : {
      "name" : "Scott Kirsner",
      "screen_name" : "ScottKirsner",
      "protected" : false,
      "id_str" : "896221",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3592108693/b8a17719310987060e30775fe93f9854_normal.jpeg",
      "id" : 896221,
      "verified" : false
    }
  },
  "id" : 142009764476502016,
  "created_at" : "Wed Nov 30 22:39:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cult of Mac",
      "screen_name" : "cultofmac",
      "indices" : [ 3, 13 ],
      "id_str" : "9688342",
      "id" : 9688342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/3RukAZeJ",
      "expanded_url" : "http://cultm.ac/u8ER5T",
      "display_url" : "cultm.ac/u8ER5T"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141552455279316992",
  "text" : "RT @cultofmac: New post: RIM Admits Defeat, Releases iOS Software http://t.co/3RukAZeJ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.cultofmac.com\" rel=\"nofollow\">Cult of Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http://t.co/3RukAZeJ",
        "expanded_url" : "http://cultm.ac/u8ER5T",
        "display_url" : "cultm.ac/u8ER5T"
      } ]
    },
    "geo" : {
    },
    "id_str" : "141550925549551616",
    "text" : "New post: RIM Admits Defeat, Releases iOS Software http://t.co/3RukAZeJ",
    "id" : 141550925549551616,
    "created_at" : "Tue Nov 29 16:15:45 +0000 2011",
    "user" : {
      "name" : "Cult of Mac",
      "screen_name" : "cultofmac",
      "protected" : false,
      "id_str" : "9688342",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1827297831/tinsy_normal.jpg",
      "id" : 9688342,
      "verified" : false
    }
  },
  "id" : 141552455279316992,
  "created_at" : "Tue Nov 29 16:21:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3775167941, -71.1175009464 ]
  },
  "id_str" : "141548956881661953",
  "text" : "The professor of this Shinto class has just put a giant purple penis on the projector. Oh Gen Ed, you so silly.",
  "id" : 141548956881661953,
  "created_at" : "Tue Nov 29 16:07:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 105, 116 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/hCx8rc8W",
      "expanded_url" : "http://ow.ly/7I9QF",
      "display_url" : "ow.ly/7I9QF"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3775096976, -71.117497425 ]
  },
  "id_str" : "141548220881977344",
  "text" : "I find Prof. Hedges' (Div) jab at engineering bewildering... He implies engineering is \"distressing.\" RT @thecrimson: http://t.co/hCx8rc8W",
  "id" : 141548220881977344,
  "created_at" : "Tue Nov 29 16:05:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 7, 14 ],
      "id_str" : "17307429",
      "id" : 17307429
    }, {
      "name" : "Dell ",
      "screen_name" : "Dell",
      "indices" : [ 113, 118 ],
      "id_str" : "58561993",
      "id" : 58561993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3779458627, -71.1168136828 ]
  },
  "id_str" : "141241192821174272",
  "text" : "Protip @lenovo: 8 weeks is a bit long to wait for a working laptop. Esp the flagship \"business\" x220. I've heard @dell has on site service.",
  "id" : 141241192821174272,
  "created_at" : "Mon Nov 28 19:44:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skype",
      "screen_name" : "Skype",
      "indices" : [ 49, 55 ],
      "id_str" : "2459371",
      "id" : 2459371
    }, {
      "name" : "LivingSocial",
      "screen_name" : "LivingSocial",
      "indices" : [ 67, 80 ],
      "id_str" : "14773982",
      "id" : 14773982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/gvWmnCnn",
      "expanded_url" : "https://share.livingsocial.com/deals/178306?ref=conf-jp&rpi=37742170",
      "display_url" : "share.livingsocial.com/deals/178306?r\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141236033940500480",
  "text" : "Perfect for winter travels. $10 for $20 worth of @skype credit via @livingsocial http://t.co/gvWmnCnn",
  "id" : 141236033940500480,
  "created_at" : "Mon Nov 28 19:24:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TinyTower",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "addictive",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3680959829, -71.1154190172 ]
  },
  "id_str" : "141099532925673472",
  "text" : "#TinyTower sucked 4 hours from me today until, in a moment of strength, I deleted it from my phone. This must be how Frodo felt. #addictive",
  "id" : 141099532925673472,
  "created_at" : "Mon Nov 28 10:22:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "indices" : [ 3, 19 ],
      "id_str" : "263122363",
      "id" : 263122363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141095629588926464",
  "text" : "RT @HarvardAsianGuy: Winter is confusing. Is it 5 AM or PM? All I know is that it's dark and I'm still working.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "141087741545947136",
    "text" : "Winter is confusing. Is it 5 AM or PM? All I know is that it's dark and I'm still working.",
    "id" : 141087741545947136,
    "created_at" : "Mon Nov 28 09:35:13 +0000 2011",
    "user" : {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "protected" : false,
      "id_str" : "263122363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1713903417/asian_normal.jpg",
      "id" : 263122363,
      "verified" : false
    }
  },
  "id" : 141095629588926464,
  "created_at" : "Mon Nov 28 10:06:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/140758559892836352/photo/1",
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/BHXoztt0",
      "media_url" : "http://pbs.twimg.com/media/AfQTKhnCEAA9luA.jpg",
      "id_str" : "140758559897030656",
      "id" : 140758559897030656,
      "media_url_https" : "https://pbs.twimg.com/media/AfQTKhnCEAA9luA.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/BHXoztt0"
    } ],
    "hashtags" : [ {
      "text" : "whoosh",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9379211404, -78.7474074699 ]
  },
  "id_str" : "140758559892836352",
  "text" : "Puddle jumper! #whoosh http://t.co/BHXoztt0",
  "id" : 140758559892836352,
  "created_at" : "Sun Nov 27 11:47:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lies",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9329396552, -78.7339831051 ]
  },
  "id_str" : "140753425536253952",
  "text" : "Actually scratch that, apparently Buffalo International does not fly internationally. There is no customs and immigration here. #lies",
  "id" : 140753425536253952,
  "created_at" : "Sun Nov 27 11:26:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worldly",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9843832506, -78.6970485003 ]
  },
  "id_str" : "140742343241371648",
  "text" : "Off to Buffalo International Airport. \"International\" because it flies to Canada. Which is a 15 min drive away. #worldly",
  "id" : 140742343241371648,
  "created_at" : "Sun Nov 27 10:42:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140671291098271744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0068886606, -78.7002583501 ]
  },
  "id_str" : "140673175435481088",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow Is tweeting again :D",
  "id" : 140673175435481088,
  "in_reply_to_status_id" : 140671291098271744,
  "created_at" : "Sun Nov 27 06:07:53 +0000 2011",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140620339523764226",
  "geo" : {
  },
  "id_str" : "140620630763634688",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha me too! re: 6 AM flight. What's your ETA? split cab?",
  "id" : 140620630763634688,
  "in_reply_to_status_id" : 140620339523764226,
  "created_at" : "Sun Nov 27 02:39:05 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/140605606645084160/photo/1",
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/JnaFhT3U",
      "media_url" : "http://pbs.twimg.com/media/AfOIDeYCMAAunVm.jpg",
      "id_str" : "140605606653472768",
      "id" : 140605606653472768,
      "media_url_https" : "https://pbs.twimg.com/media/AfOIDeYCMAAunVm.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/JnaFhT3U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0064951414, -78.6996943913 ]
  },
  "id_str" : "140605606645084160",
  "text" : "Best nerd gift ever. Mechanically switched Apple IIGS keyboard. http://t.co/JnaFhT3U",
  "id" : 140605606645084160,
  "created_at" : "Sun Nov 27 01:39:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    }, {
      "name" : "The Relevant Organs",
      "screen_name" : "relevantorgans",
      "indices" : [ 118, 133 ],
      "id_str" : "86975611",
      "id" : 86975611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/r2nlk8Wt",
      "expanded_url" : "http://on.wsj.com/tacV8C",
      "display_url" : "on.wsj.com/tacV8C"
    } ]
  },
  "geo" : {
  },
  "id_str" : "140593520112173056",
  "text" : "RT @HarvardCSA: China's 'Princelings' Drive up in red Ferraris and pose issues for the party http://t.co/r2nlk8Wt via @relevantorgans",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Relevant Organs",
        "screen_name" : "relevantorgans",
        "indices" : [ 102, 117 ],
        "id_str" : "86975611",
        "id" : 86975611
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http://t.co/r2nlk8Wt",
        "expanded_url" : "http://on.wsj.com/tacV8C",
        "display_url" : "on.wsj.com/tacV8C"
      } ]
    },
    "geo" : {
    },
    "id_str" : "140507681155850240",
    "text" : "China's 'Princelings' Drive up in red Ferraris and pose issues for the party http://t.co/r2nlk8Wt via @relevantorgans",
    "id" : 140507681155850240,
    "created_at" : "Sat Nov 26 19:10:16 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 140593520112173056,
  "created_at" : "Sun Nov 27 00:51:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 32, 40 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140549079146049536",
  "text" : "Does anyone know how I can gift @spotify Premium in the US? Gift cards not for sale stateside.",
  "id" : 140549079146049536,
  "created_at" : "Sat Nov 26 21:54:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 0, 6 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0069358315, -78.699820246 ]
  },
  "id_str" : "140252015816216576",
  "in_reply_to_user_id" : 15333079,
  "text" : "@cklee your Kinect is broken? I have an extra one kicking around if you promise to do something cool.",
  "id" : 140252015816216576,
  "created_at" : "Sat Nov 26 02:14:20 +0000 2011",
  "in_reply_to_screen_name" : "chriskelvinlee",
  "in_reply_to_user_id_str" : "15333079",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffaloBlues",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "GetMeOutOfHere",
      "indices" : [ 14, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9932975794, -78.7356093174 ]
  },
  "id_str" : "140223932253999105",
  "text" : "#BuffaloBlues #GetMeOutOfHere",
  "id" : 140223932253999105,
  "created_at" : "Sat Nov 26 00:22:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9369680817, -78.7296349929 ]
  },
  "id_str" : "139793283902734336",
  "text" : "Back in Buffalo, NY. Jewel of upstate NY.",
  "id" : 139793283902734336,
  "created_at" : "Thu Nov 24 19:51:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia",
      "screen_name" : "NataliaZarina",
      "indices" : [ 0, 14 ],
      "id_str" : "74196868",
      "id" : 74196868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139157000754966529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3639157864, -71.0236046066 ]
  },
  "id_str" : "139730962840961024",
  "in_reply_to_user_id" : 74196868,
  "text" : "@NataliaZarina thanks for the birthday wishes :) hope you have a good Thanksgiving in Hanoi.",
  "id" : 139730962840961024,
  "in_reply_to_status_id" : 139157000754966529,
  "created_at" : "Thu Nov 24 15:43:52 +0000 2011",
  "in_reply_to_screen_name" : "NataliaZarina",
  "in_reply_to_user_id_str" : "74196868",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Humble Bundle",
      "screen_name" : "humble",
      "indices" : [ 12, 19 ],
      "id_str" : "11167502",
      "id" : 11167502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139199547158167553",
  "text" : "Just bought @humble bundle! Nice way to get some R&R at home this Thanksgiving.",
  "id" : 139199547158167553,
  "created_at" : "Wed Nov 23 04:32:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3721097964, -71.1189931086 ]
  },
  "id_str" : "139163999806816256",
  "text" : "Does anyone else think it's dumb that you have to waterproof some boots? You think it'd be standard.",
  "id" : 139163999806816256,
  "created_at" : "Wed Nov 23 02:10:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Core77",
      "screen_name" : "core77",
      "indices" : [ 3, 10 ],
      "id_str" : "20236725",
      "id" : 20236725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139041754597957633",
  "text" : "RT @core77: Colani: \"Nature had 100s of millions of years to refine their things, we have only stupid 100 years of aerodynamics\" http:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.exacttarget.com/social\" rel=\"nofollow\">SocialEngage</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/DmOdMsWH",
        "expanded_url" : "http://bit.ly/uKHOs1",
        "display_url" : "bit.ly/uKHOs1"
      } ]
    },
    "geo" : {
    },
    "id_str" : "139016626933739520",
    "text" : "Colani: \"Nature had 100s of millions of years to refine their things, we have only stupid 100 years of aerodynamics\" http://t.co/DmOdMsWH",
    "id" : 139016626933739520,
    "created_at" : "Tue Nov 22 16:25:21 +0000 2011",
    "user" : {
      "name" : "Core77",
      "screen_name" : "core77",
      "protected" : false,
      "id_str" : "20236725",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2706662093/6d6e3a2ac48b0d4a077a39bba1f03fc5_normal.jpeg",
      "id" : 20236725,
      "verified" : false
    }
  },
  "id" : 139041754597957633,
  "created_at" : "Tue Nov 22 18:05:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hobby",
      "screen_name" : "strobist",
      "indices" : [ 3, 12 ],
      "id_str" : "14305530",
      "id" : 14305530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138730982873378817",
  "text" : "RT @strobist: Playing w/Google's keyword tool, I see that people google 'google' 755MM times a month. To be fair, I just googled people  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "138730133291937792",
    "text" : "Playing w/Google's keyword tool, I see that people google 'google' 755MM times a month. To be fair, I just googled people who google google.",
    "id" : 138730133291937792,
    "created_at" : "Mon Nov 21 21:26:55 +0000 2011",
    "user" : {
      "name" : "David Hobby",
      "screen_name" : "strobist",
      "protected" : false,
      "id_str" : "14305530",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1771314706/image1327173868_normal.png",
      "id" : 14305530,
      "verified" : true
    }
  },
  "id" : 138730982873378817,
  "created_at" : "Mon Nov 21 21:30:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenovo ",
      "screen_name" : "lenovo",
      "indices" : [ 0, 7 ],
      "id_str" : "17307429",
      "id" : 17307429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/cF8rFLlT",
      "expanded_url" : "http://www.youtube.com/watch?v=Z7I7j6ixe9k",
      "display_url" : "youtube.com/watch?v=Z7I7j6\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "138728806662934529",
  "in_reply_to_user_id" : 17307429,
  "text" : "@lenovo sent me a replacement X220 with a new feature: it turns off whenever I touch it. http://t.co/cF8rFLlT",
  "id" : 138728806662934529,
  "created_at" : "Mon Nov 21 21:21:39 +0000 2011",
  "in_reply_to_screen_name" : "lenovo",
  "in_reply_to_user_id_str" : "17307429",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/Z9VXc79u",
      "expanded_url" : "http://bit.ly/sHlbEc",
      "display_url" : "bit.ly/sHlbEc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "137353800515190784",
  "text" : "RT @wired: Utterly clueless CIO at Google Atmosphere: \"So 'cloud' is Gmail, right?\" http://t.co/Z9VXc79u",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/Z9VXc79u",
        "expanded_url" : "http://bit.ly/sHlbEc",
        "display_url" : "bit.ly/sHlbEc"
      } ]
    },
    "geo" : {
    },
    "id_str" : "137251903515009024",
    "text" : "Utterly clueless CIO at Google Atmosphere: \"So 'cloud' is Gmail, right?\" http://t.co/Z9VXc79u",
    "id" : 137251903515009024,
    "created_at" : "Thu Nov 17 19:32:58 +0000 2011",
    "user" : {
      "name" : "Wired",
      "screen_name" : "wired",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2958887633/eab60d838d5c4bb20fa52f0577a2c698_normal.jpeg",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 137353800515190784,
  "created_at" : "Fri Nov 18 02:17:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 29, 36 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/136870784881790976/photo/1",
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/gDER7YyY",
      "media_url" : "http://pbs.twimg.com/media/AeZDQPFCEAAx0w7.jpg",
      "id_str" : "136870784885985280",
      "id" : 136870784885985280,
      "media_url_https" : "https://pbs.twimg.com/media/AeZDQPFCEAAx0w7.jpg",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com/gDER7YyY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136870784881790976",
  "text" : "Every student group is using @square to sell their Harvard-Yale shirts. http://t.co/gDER7YyY",
  "id" : 136870784881790976,
  "created_at" : "Wed Nov 16 18:18:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136608885934010368",
  "text" : "RT @ForbesTech: Nearly One Year After The Start Of Arab Uprisings, Few Arab Leaders Understand The Power Of Social Media http://t.co/NZw ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http://t.co/NZwrgRlv",
        "expanded_url" : "http://onforb.es/rQ8p9B",
        "display_url" : "onforb.es/rQ8p9B"
      } ]
    },
    "geo" : {
    },
    "id_str" : "136546533872123905",
    "text" : "Nearly One Year After The Start Of Arab Uprisings, Few Arab Leaders Understand The Power Of Social Media http://t.co/NZwrgRlv",
    "id" : 136546533872123905,
    "created_at" : "Tue Nov 15 20:50:05 +0000 2011",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 136608885934010368,
  "created_at" : "Wed Nov 16 00:57:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xinerz",
      "screen_name" : "xinerz",
      "indices" : [ 12, 19 ],
      "id_str" : "17416592",
      "id" : 17416592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136537866707795969",
  "text" : "Just mailed @xinerz her Harvard Yale shirt.",
  "id" : 136537866707795969,
  "created_at" : "Tue Nov 15 20:15:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 6, 13 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/2nntHbfV",
      "expanded_url" : "http://twitter.com/khsieh/status/136484762440310785/photo/1",
      "display_url" : "pic.twitter.com/2nntHbfV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3760928464, -71.1167283633 ]
  },
  "id_str" : "136484981408153600",
  "text" : "Using @square to process Harvard-Yale Game tshirt sales. http://t.co/2nntHbfV",
  "id" : 136484981408153600,
  "created_at" : "Tue Nov 15 16:45:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134117749625597953",
  "text" : "Why does Adobe Acrobat still create a desktop shortcut??",
  "id" : 134117749625597953,
  "created_at" : "Wed Nov 09 03:58:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 25, 33 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133992488863154176",
  "text" : "the new Activity feed in @twitter is great for discovering new people to follow!",
  "id" : 133992488863154176,
  "created_at" : "Tue Nov 08 19:41:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133697211895783424",
  "text" : "Why is it so hard to migrate from HDD to SSD? Annoyed by lack of one-click solution.",
  "id" : 133697211895783424,
  "created_at" : "Tue Nov 08 00:07:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audemars Piguet",
      "screen_name" : "Audemars_Piguet",
      "indices" : [ 21, 37 ],
      "id_str" : "1092078991",
      "id" : 1092078991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133627858336743424",
  "text" : "It's flattering that @audemars_piguet is following me, but they still don't make a watch small enough for me to wear.",
  "id" : 133627858336743424,
  "created_at" : "Mon Nov 07 19:32:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/0RNsWe4k",
      "expanded_url" : "http://www.wpcentral.com/nokia-lumia-800-tops-sales-charts-france",
      "display_url" : "wpcentral.com/nokia-lumia-80\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "132519616487505920",
  "text" : "Whoa, Nokia 800 outselling iOS and Android devices in France??http://t.co/0RNsWe4k",
  "id" : 132519616487505920,
  "created_at" : "Fri Nov 04 18:08:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/XGmR6ib9",
      "expanded_url" : "http://onforb.es/sbGT2r",
      "display_url" : "onforb.es/sbGT2r"
    } ]
  },
  "geo" : {
  },
  "id_str" : "132172468138934272",
  "text" : "RT @ForbesTech: Ford Prices Focus Electric at $39,995, Takes Reservations. http://t.co/XGmR6ib9",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http://t.co/XGmR6ib9",
        "expanded_url" : "http://onforb.es/sbGT2r",
        "display_url" : "onforb.es/sbGT2r"
      } ]
    },
    "geo" : {
    },
    "id_str" : "132128662697947136",
    "text" : "Ford Prices Focus Electric at $39,995, Takes Reservations. http://t.co/XGmR6ib9",
    "id" : 132128662697947136,
    "created_at" : "Thu Nov 03 16:15:02 +0000 2011",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 132172468138934272,
  "created_at" : "Thu Nov 03 19:09:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "indices" : [ 3, 19 ],
      "id_str" : "263122363",
      "id" : 263122363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131992135988813824",
  "text" : "RT @HarvardAsianGuy: As long as my life expectancy decreases by less than a day for every three all-nighters, I'm all set.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "131991401306140672",
    "text" : "As long as my life expectancy decreases by less than a day for every three all-nighters, I'm all set.",
    "id" : 131991401306140672,
    "created_at" : "Thu Nov 03 07:09:37 +0000 2011",
    "user" : {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "protected" : false,
      "id_str" : "263122363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1713903417/asian_normal.jpg",
      "id" : 263122363,
      "verified" : false
    }
  },
  "id" : 131992135988813824,
  "created_at" : "Thu Nov 03 07:12:32 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131779438802243584",
  "text" : "Official iOS gmail app doesn't handle nested labels as well as the native Mail app.",
  "id" : 131779438802243584,
  "created_at" : "Wed Nov 02 17:07:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131778643121807360",
  "text" : "Downloaded iOS gmail app!",
  "id" : 131778643121807360,
  "created_at" : "Wed Nov 02 17:04:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131555684251734016",
  "text" : "Why are there no laptops with semi-ergo keyboards?",
  "id" : 131555684251734016,
  "created_at" : "Wed Nov 02 02:18:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]