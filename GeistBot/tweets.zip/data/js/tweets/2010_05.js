Grailbird.data.tweets_2010_05 = 
 [ {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15080838386",
  "text" : "Sorry MoMA, I'm going to have to call BS on this one http://nyti.ms/b1LXBc",
  "id" : 15080838386,
  "created_at" : "Mon May 31 02:52:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlene A. Lee",
      "screen_name" : "charlenealee",
      "indices" : [ 0, 13 ],
      "id_str" : "15451148",
      "id" : 15451148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15077676763",
  "geo" : {
  },
  "id_str" : "15078309573",
  "in_reply_to_user_id" : 15451148,
  "text" : "@charlenealee I had to sell my Boston tickets :(",
  "id" : 15078309573,
  "in_reply_to_status_id" : 15077676763,
  "created_at" : "Mon May 31 02:02:18 +0000 2010",
  "in_reply_to_screen_name" : "charlenealee",
  "in_reply_to_user_id_str" : "15451148",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15077176037",
  "text" : "The harvard square CVS is really nice now!",
  "id" : 15077176037,
  "created_at" : "Mon May 31 01:39:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15064599099",
  "geo" : {
  },
  "id_str" : "15064907416",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil I put her in the HSA office!  There's like four bikes up there now",
  "id" : 15064907416,
  "in_reply_to_status_id" : 15064599099,
  "created_at" : "Sun May 30 21:17:47 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15058352960",
  "text" : "Its a beautiful day just chilling in the yard, watching tourists",
  "id" : 15058352960,
  "created_at" : "Sun May 30 18:47:23 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14951689651",
  "text" : "Midnight bike ride!  So many people out and about",
  "id" : 14951689651,
  "created_at" : "Sat May 29 03:31:08 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    }, {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 9, 21 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14881330265",
  "geo" : {
  },
  "id_str" : "14881882902",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern @alishalisha no lie, it's on my list too!",
  "id" : 14881882902,
  "in_reply_to_status_id" : 14881330265,
  "created_at" : "Fri May 28 03:53:22 +0000 2010",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14879710198",
  "text" : "Now bumming in Winthrop instead of Mather!",
  "id" : 14879710198,
  "created_at" : "Fri May 28 03:20:44 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 0, 13 ],
      "id_str" : "101114131",
      "id" : 101114131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14867610567",
  "in_reply_to_user_id" : 101114131,
  "text" : "@Blueasiacafe again for dinner!",
  "id" : 14867610567,
  "created_at" : "Thu May 27 23:49:10 +0000 2010",
  "in_reply_to_screen_name" : "Blueasiacafe",
  "in_reply_to_user_id_str" : "101114131",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 15, 23 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14819400398",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow @digitil hooray for no improvements in sleep schedules!",
  "id" : 14819400398,
  "created_at" : "Thu May 27 07:22:51 +0000 2010",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 41, 49 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14814647654",
  "text" : "that's I  don't like suburban life :) RT @aistern: I am bored. Bored bored bored.",
  "id" : 14814647654,
  "created_at" : "Thu May 27 05:14:32 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14793268230",
  "text" : "10 black cadillacs and big guys with suits and earpieces all around Lamont!",
  "id" : 14793268230,
  "created_at" : "Wed May 26 22:46:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14732851728",
  "text" : "Glee is incredibly overrated.",
  "id" : 14732851728,
  "created_at" : "Wed May 26 01:56:53 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14724338241",
  "geo" : {
  },
  "id_str" : "14731605060",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern  $.70 bubble tea was the best! !",
  "id" : 14731605060,
  "in_reply_to_status_id" : 14724338241,
  "created_at" : "Wed May 26 01:36:04 +0000 2010",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 81, 94 ],
      "id_str" : "101114131",
      "id" : 101114131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14707004899",
  "geo" : {
  },
  "id_str" : "14714730177",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha today was definitely smoothee weather!  I opted for bubble tea from @Blueasiacafe",
  "id" : 14714730177,
  "in_reply_to_status_id" : 14707004899,
  "created_at" : "Tue May 25 20:08:59 +0000 2010",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14668012832",
  "text" : "Lying in Mather courtyard, looking at the stars.",
  "id" : 14668012832,
  "created_at" : "Tue May 25 03:26:42 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14620100195",
  "text" : "First day of work!  Back to a normal sleep schedule too.",
  "id" : 14620100195,
  "created_at" : "Mon May 24 12:33:37 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14596844856",
  "geo" : {
  },
  "id_str" : "14606668118",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil  you can't be a professional video game character because no one can pronounce your last name right.",
  "id" : 14606668118,
  "in_reply_to_status_id" : 14596844856,
  "created_at" : "Mon May 24 06:27:15 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14562687888",
  "text" : "Touched down in Boston. Work begins tomorrow!",
  "id" : 14562687888,
  "created_at" : "Sun May 23 15:27:19 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14554413562",
  "text" : "Wheels up from Buffalo!",
  "id" : 14554413562,
  "created_at" : "Sun May 23 12:43:09 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 78, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14534880740",
  "text" : "MacGruber: necrophilia, a naked old lady, mullets, poop jokes, and soft rock. #wtf",
  "id" : 14534880740,
  "created_at" : "Sun May 23 03:56:26 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hellyes",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14516455332",
  "text" : "Today: launched a new boat.  Flipped a new boat.  Scuba diving.  Scuba scootering.  Shooting.  I declare this day conquered. #hellyes",
  "id" : 14516455332,
  "created_at" : "Sat May 22 21:07:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 3, 11 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14451204120",
  "text" : "RT @digitil IRL: this semester has made me really efficient at the most mundane and sad things",
  "id" : 14451204120,
  "created_at" : "Fri May 21 20:35:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14450670196",
  "text" : "This is incredibly cute http://bit.ly/chZg5l",
  "id" : 14450670196,
  "created_at" : "Fri May 21 20:23:51 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14448195676",
  "geo" : {
  },
  "id_str" : "14449053445",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern jealous!  Excited to return on Sunday.",
  "id" : 14449053445,
  "in_reply_to_status_id" : 14448195676,
  "created_at" : "Fri May 21 19:48:45 +0000 2010",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackberry",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14378246042",
  "text" : "Tweeting from RIM's new blackberry app. Much sleeker!  I'm a convert from openbeak and ubertwitter. #blackberry",
  "id" : 14378246042,
  "created_at" : "Thu May 20 18:29:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14377708376",
  "text" : "Google, at least make sure your own APPS work within your own BROWSER.",
  "id" : 14377708376,
  "created_at" : "Thu May 20 18:18:13 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14346932987",
  "text" : "Man saved by ninjas... for real http://bit.ly/aTI7tQ",
  "id" : 14346932987,
  "created_at" : "Thu May 20 07:37:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 3, 16 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14338427899",
  "text" : "RT @kevinmitnick: Government social engineering at its best... http://tinyurl.com/2d5hgpq",
  "id" : 14338427899,
  "created_at" : "Thu May 20 03:55:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 10, 18 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14315912259",
  "text" : "cosign RT @digitil: RT @themonkeychow: i worked so FUCKING HARD this semester and this is what i get fuck",
  "id" : 14315912259,
  "created_at" : "Wed May 19 20:54:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14266710832",
  "text" : "So desperately bored I'm watching weekday Comedy Central.",
  "id" : 14266710832,
  "created_at" : "Wed May 19 02:17:05 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    }, {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 7, 15 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14187550003",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin @aistern I'll be in Beijing in August!  And Taiwan :D  no Shanghai though :(",
  "id" : 14187550003,
  "created_at" : "Mon May 17 22:31:31 +0000 2010",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14177884838",
  "text" : "Got new glasses.  Napped.  Sat in a hammock.  Yet another day at home.  GET ME OUT OF HERE.",
  "id" : 14177884838,
  "created_at" : "Mon May 17 19:02:32 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14140236119",
  "text" : "Ass handed to me by grades this semester.  Gotta GMST for next semester.",
  "id" : 14140236119,
  "created_at" : "Mon May 17 04:06:51 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "home",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14098679042",
  "text" : "Wheels up. Next stop, Buffalo #home",
  "id" : 14098679042,
  "created_at" : "Sun May 16 13:41:22 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14094534437",
  "text" : "Tweeting from Boston-Logan, en route to Buffalo",
  "id" : 14094534437,
  "created_at" : "Sun May 16 12:02:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 0, 13 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "asian",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14058720185",
  "geo" : {
  },
  "id_str" : "14063191598",
  "in_reply_to_user_id" : 112919587,
  "text" : "@vcruzcontrol we're invading everything. Get used to it :) #asian",
  "id" : 14063191598,
  "in_reply_to_status_id" : 14058720185,
  "created_at" : "Sat May 15 23:04:31 +0000 2010",
  "in_reply_to_screen_name" : "vcruzcontrol",
  "in_reply_to_user_id_str" : "112919587",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14053376281",
  "text" : "Just saw the new NY license plates. SO UGLY.",
  "id" : 14053376281,
  "created_at" : "Sat May 15 18:57:55 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "14048199371",
  "text" : "Playing the Indie Pack on Steam for Mac.  What a beautiful set of games!",
  "id" : 14048199371,
  "created_at" : "Sat May 15 17:04:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13948500144",
  "text" : "SUPER STRESSFUL episode of Burn Notice OMG I can't take this",
  "id" : 13948500144,
  "created_at" : "Fri May 14 01:52:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13919610813",
  "text" : "Done with exams. Yea, I'm going to tweet about it. Sue me.",
  "id" : 13919610813,
  "created_at" : "Thu May 13 15:25:56 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scary",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13899324925",
  "geo" : {
  },
  "id_str" : "13902761825",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil we are also half done with college. #scary",
  "id" : 13902761825,
  "in_reply_to_status_id" : 13899324925,
  "created_at" : "Thu May 13 08:36:42 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13898627765",
  "text" : "Someone ate a bunch of skittles and sh!t on my gcal.",
  "id" : 13898627765,
  "created_at" : "Thu May 13 06:24:07 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 25, 33 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13891290906",
  "text" : "I want a lightmeter app! @digitil",
  "id" : 13891290906,
  "created_at" : "Thu May 13 03:27:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13876860409",
  "text" : "Steam is out for OSX.  In related news, projected final grades plummet.",
  "id" : 13876860409,
  "created_at" : "Wed May 12 22:52:30 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 3, 11 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canILive",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13827402576",
  "text" : "RT @digitil - yes, i am a computer science major, no, that does not mean i *want* to fix your computer #canILive",
  "id" : 13827402576,
  "created_at" : "Wed May 12 03:03:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13803851916",
  "text" : "Moving out!  Where did I aggregate all this stuff??",
  "id" : 13803851916,
  "created_at" : "Tue May 11 18:59:38 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 48, 54 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13793672180",
  "text" : "ironic, considering the fun time at Cafe Sushi! @l_jin",
  "id" : 13793672180,
  "created_at" : "Tue May 11 15:18:30 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13745671730",
  "text" : "Banksy's in Toronto??",
  "id" : 13745671730,
  "created_at" : "Mon May 10 20:15:59 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13708079930",
  "text" : "Check out the new website :) http://kanehsieh.com",
  "id" : 13708079930,
  "created_at" : "Mon May 10 04:36:41 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Ye",
      "screen_name" : "thepapaya",
      "indices" : [ 0, 10 ],
      "id_str" : "27233671",
      "id" : 27233671
    }, {
      "name" : "Kim Gandy",
      "screen_name" : "Kim_Gandy",
      "indices" : [ 11, 21 ],
      "id_str" : "16021468",
      "id" : 16021468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13708070701",
  "in_reply_to_user_id" : 27233671,
  "text" : "@thepapaya @Kim_Gandy - Why wouldn't conservatives allow three women on the Court?  Conservatism isn't synonymous with sexism...",
  "id" : 13708070701,
  "created_at" : "Mon May 10 04:36:27 +0000 2010",
  "in_reply_to_screen_name" : "thepapaya",
  "in_reply_to_user_id_str" : "27233671",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13706379045",
  "text" : "Watching Burn Notice and lounging at bed.  This is awesome.",
  "id" : 13706379045,
  "created_at" : "Mon May 10 03:56:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13684484974",
  "text" : "I really really want a Verizon Android phone with a SIM slot",
  "id" : 13684484974,
  "created_at" : "Sun May 09 19:44:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13641697852",
  "text" : "ETA on new wheel - two days!!",
  "id" : 13641697852,
  "created_at" : "Sun May 09 02:10:37 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fmlfmlfml",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13607063140",
  "text" : "Woke up with 10 minutes to exam. #fmlfmlfml",
  "id" : 13607063140,
  "created_at" : "Sat May 08 13:05:44 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allnighter",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13595298544",
  "text" : "T-minus 6 hours until exam #allnighter",
  "id" : 13595298544,
  "created_at" : "Sat May 08 06:52:15 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13576658489",
  "text" : "lol my bank was just robbed http://bit.ly/c4QLIU",
  "id" : 13576658489,
  "created_at" : "Fri May 07 23:49:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 3, 10 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13560444980",
  "text" : "RT @cnnbrk: New York's Times Square evacuated.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "13559890000",
    "text" : "New York's Times Square evacuated.",
    "id" : 13559890000,
    "created_at" : "Fri May 07 17:23:08 +0000 2010",
    "user" : {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "protected" : false,
      "id_str" : "428333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1762504301/128x128_cnnbrk_avatar_normal.gif",
      "id" : 428333,
      "verified" : true
    }
  },
  "id" : 13560444980,
  "created_at" : "Fri May 07 17:34:52 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13537487309",
  "text" : "Why am I so ineffectual at studying??",
  "id" : 13537487309,
  "created_at" : "Fri May 07 08:37:11 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13507636537",
  "text" : "40 more hours.  Saturday night party anyone?",
  "id" : 13507636537,
  "created_at" : "Thu May 06 20:57:11 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13459201015",
  "text" : "People in review sessions make me want to head desk in frustration.",
  "id" : 13459201015,
  "created_at" : "Thu May 06 01:15:42 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13452606906",
  "text" : "The bottle openers under my flipflops engaged my pedal clips somehow.  Hilarious accident ensued.",
  "id" : 13452606906,
  "created_at" : "Wed May 05 23:02:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13340782349",
  "text" : "DJ'ing Fete!  Last formal of 2010... then finals!",
  "id" : 13340782349,
  "created_at" : "Tue May 04 02:18:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13282278070",
  "geo" : {
  },
  "id_str" : "13282917890",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin whooo!  Solidarity :D",
  "id" : 13282917890,
  "in_reply_to_status_id" : 13282278070,
  "created_at" : "Mon May 03 03:02:50 +0000 2010",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13259312063",
  "text" : "Why is it so hooooot",
  "id" : 13259312063,
  "created_at" : "Sun May 02 18:27:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13227859901",
  "text" : "Helping DJ Mather formal! Rest tomorrow, then Fete",
  "id" : 13227859901,
  "created_at" : "Sun May 02 04:31:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]