Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17430010604",
  "text" : "Lady GaGa at the MIT museum!",
  "id" : 17430010604,
  "created_at" : "Wed Jun 30 17:31:00 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17361665440",
  "text" : "TheCrimson.com is down too...",
  "id" : 17361665440,
  "created_at" : "Tue Jun 29 20:45:49 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17361452480",
  "text" : "Amazon is down!  Whoa.",
  "id" : 17361452480,
  "created_at" : "Tue Jun 29 20:41:13 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17349288770",
  "geo" : {
  },
  "id_str" : "17355162835",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil Sunkist is so overwhelmingly sweet that it has to be watered down to taste like normal soda...",
  "id" : 17355162835,
  "in_reply_to_status_id" : 17349288770,
  "created_at" : "Tue Jun 29 18:47:35 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 0, 11 ],
      "id_str" : "21061803",
      "id" : 21061803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17313538575",
  "geo" : {
  },
  "id_str" : "17314031889",
  "in_reply_to_user_id" : 21061803,
  "text" : "@_Eric_Chen I've started making a list potential names already!",
  "id" : 17314031889,
  "in_reply_to_status_id" : 17313538575,
  "created_at" : "Tue Jun 29 06:56:41 +0000 2010",
  "in_reply_to_screen_name" : "_Eric_Chen",
  "in_reply_to_user_id_str" : "21061803",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17312000496",
  "text" : "I want to start a club in Beijing when I graduate.  Who's in?",
  "id" : 17312000496,
  "created_at" : "Tue Jun 29 06:10:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nook",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17266748966",
  "text" : "How useful is a #Nook?",
  "id" : 17266748966,
  "created_at" : "Mon Jun 28 17:27:45 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17224457476",
  "geo" : {
  },
  "id_str" : "17231304995",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil Hey man, the food was spoiled!  Just watching out for you.",
  "id" : 17231304995,
  "in_reply_to_status_id" : 17224457476,
  "created_at" : "Mon Jun 28 06:05:34 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 31, 43 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17018869846",
  "text" : "Definitely \"dog's bollocks\" - \"@alishalisha: What is my favorite Britishism so far?\"",
  "id" : 17018869846,
  "created_at" : "Fri Jun 25 14:41:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16997069964",
  "text" : "iOS4 on the iPod, OS 5 on the Blackberry. Disappointed by both so far. Maybe a jailbreak will change things up.",
  "id" : 16997069964,
  "created_at" : "Fri Jun 25 07:30:07 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIM",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16992574905",
  "text" : "Why are Blackberries so easy to brick?! #RIM",
  "id" : 16992574905,
  "created_at" : "Fri Jun 25 05:51:50 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 51, 57 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16931764922",
  "text" : "6 weeks 'til I can hangout with @themonkeychow and @l_jin and everyone else in China!",
  "id" : 16931764922,
  "created_at" : "Thu Jun 24 14:09:14 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 0, 11 ],
      "id_str" : "21061803",
      "id" : 21061803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16908854397",
  "geo" : {
  },
  "id_str" : "16910118952",
  "in_reply_to_user_id" : 21061803,
  "text" : "@_Eric_Chen scandalous!!",
  "id" : 16910118952,
  "in_reply_to_status_id" : 16908854397,
  "created_at" : "Thu Jun 24 06:36:14 +0000 2010",
  "in_reply_to_screen_name" : "_Eric_Chen",
  "in_reply_to_user_id_str" : "21061803",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 0, 11 ],
      "id_str" : "21061803",
      "id" : 21061803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16903498834",
  "geo" : {
  },
  "id_str" : "16908506413",
  "in_reply_to_user_id" : 21061803,
  "text" : "@_Eric_Chen I'm glad I don't have to enforce curfew!",
  "id" : 16908506413,
  "in_reply_to_status_id" : 16903498834,
  "created_at" : "Thu Jun 24 06:01:03 +0000 2010",
  "in_reply_to_screen_name" : "_Eric_Chen",
  "in_reply_to_user_id_str" : "21061803",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16900993650",
  "text" : "There needs to be about... 4 extra hours a day.",
  "id" : 16900993650,
  "created_at" : "Thu Jun 24 03:43:27 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "applesucks",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16882947922",
  "text" : "iPhone 4 experiencing screen, plate, and antenna issues.  Fail #applesucks",
  "id" : 16882947922,
  "created_at" : "Wed Jun 23 22:49:04 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16859040857",
  "text" : "I keep track of World Cup results by listening to the cheers of the office next door.",
  "id" : 16859040857,
  "created_at" : "Wed Jun 23 15:51:27 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16751261288",
  "text" : "To those you that Tumblr: http://bit.ly/9CVUFw thnx :)",
  "id" : 16751261288,
  "created_at" : "Tue Jun 22 05:46:07 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16751071048",
  "text" : "Picture: Scandalous - onesixtieth.net",
  "id" : 16751071048,
  "created_at" : "Tue Jun 22 05:42:07 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16745028537",
  "text" : "Day 2 as a proctor: lockouts and alarmed doors",
  "id" : 16745028537,
  "created_at" : "Tue Jun 22 03:50:34 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Bing",
      "screen_name" : "bing",
      "indices" : [ 28, 33 ],
      "id_str" : "14874480",
      "id" : 14874480
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 53, 57 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BingforGulf",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16744885114",
  "text" : "RT @twitter: Retweet this & @Bing will donate $10 to @CNN's Gulf Telethon up to $100K. More at http://bit.ly/howtodonate. #BingforGulf",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hope140.org\" rel=\"nofollow\">Hope140</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bing",
        "screen_name" : "bing",
        "indices" : [ 15, 20 ],
        "id_str" : "14874480",
        "id" : 14874480
      }, {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 40, 44 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BingforGulf",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "16732798635",
    "text" : "Retweet this & @Bing will donate $10 to @CNN's Gulf Telethon up to $100K. More at http://bit.ly/howtodonate. #BingforGulf",
    "id" : 16732798635,
    "created_at" : "Tue Jun 22 00:29:51 +0000 2010",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284174758/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 16744885114,
  "created_at" : "Tue Jun 22 03:48:10 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16547690252",
  "text" : "Summer students moving into the Yard!",
  "id" : 16547690252,
  "created_at" : "Sat Jun 19 14:00:22 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16492627866",
  "text" : "There is nothing as inefficient in the world as Harvard administration.",
  "id" : 16492627866,
  "created_at" : "Fri Jun 18 19:25:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16471542846",
  "text" : "Planning high school dances is more awkward than I imagined...",
  "id" : 16471542846,
  "created_at" : "Fri Jun 18 13:50:37 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16416309130",
  "text" : "Obama = Bush with a much better marketing team and oration skills",
  "id" : 16416309130,
  "created_at" : "Thu Jun 17 20:40:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16393244971",
  "text" : "I wonder if HUPD has SWAT team?",
  "id" : 16393244971,
  "created_at" : "Thu Jun 17 14:34:08 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 0, 11 ],
      "id_str" : "21061803",
      "id" : 21061803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16391395226",
  "geo" : {
  },
  "id_str" : "16391868487",
  "in_reply_to_user_id" : 21061803,
  "text" : "@_Eric_Chen ugh this needs to end!",
  "id" : 16391868487,
  "in_reply_to_status_id" : 16391395226,
  "created_at" : "Thu Jun 17 14:14:17 +0000 2010",
  "in_reply_to_screen_name" : "_Eric_Chen",
  "in_reply_to_user_id_str" : "21061803",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16362590305",
  "geo" : {
  },
  "id_str" : "16368688077",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil I find that Tumblr is unfortunately saturated with 15 year old hipsters",
  "id" : 16368688077,
  "in_reply_to_status_id" : 16362590305,
  "created_at" : "Thu Jun 17 06:26:34 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GRE",
      "indices" : [ 12, 16 ]
    }, {
      "text" : "GMAT",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16339811328",
  "text" : "Recommend a #GRE and #GMAT book!",
  "id" : 16339811328,
  "created_at" : "Wed Jun 16 22:24:42 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIM",
      "indices" : [ 57, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16314366189",
  "text" : "The 83xx keyboards are much better than the 9*** series. #RIM",
  "id" : 16314366189,
  "created_at" : "Wed Jun 16 15:26:30 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIM",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16284348457",
  "text" : "It's a problem if I can break my phone's OS... #RIM fail",
  "id" : 16284348457,
  "created_at" : "Wed Jun 16 05:24:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16192091384",
  "text" : "So I'm a little late but... wtf new Scrubs actors??",
  "id" : 16192091384,
  "created_at" : "Tue Jun 15 01:44:07 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 28, 36 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16126517201",
  "text" : "haha talking about Kobe? RT @digitil: asian girls secretly love minorities",
  "id" : 16126517201,
  "created_at" : "Mon Jun 14 05:45:59 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16084827044",
  "text" : "Dragon boat festival @ The Charles! http://twitpic.com/1wigsu",
  "id" : 16084827044,
  "created_at" : "Sun Jun 13 17:11:12 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baller",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "16024630077",
  "text" : "Talking with a F/A-18 pilot. What a #baller",
  "id" : 16024630077,
  "created_at" : "Sat Jun 12 19:26:55 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15966124917",
  "text" : "\"England has never won a war against us. They won't win a soccer game.\" - US and British friends bickering",
  "id" : 15966124917,
  "created_at" : "Sat Jun 12 00:32:49 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gmail",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15963654416",
  "text" : "Gmail is down?? #gmail",
  "id" : 15963654416,
  "created_at" : "Fri Jun 11 23:47:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15899753197",
  "geo" : {
  },
  "id_str" : "15900735864",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha I jumped Blogger waaaay back because of their crappy templating control!  &lt;3 the Google integration though",
  "id" : 15900735864,
  "in_reply_to_status_id" : 15899753197,
  "created_at" : "Fri Jun 11 03:27:50 +0000 2010",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15896503150",
  "text" : "Blackberry freezing up all the time - I wish VZW had an unlockable Droid phone so I wouldn't have to use this :(",
  "id" : 15896503150,
  "created_at" : "Fri Jun 11 02:20:51 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15752091941",
  "text" : "Looking for a new rear wheel.  Thinking Surly + DT Swiss.  Build recommendations?",
  "id" : 15752091941,
  "created_at" : "Wed Jun 09 02:50:31 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15643938239",
  "text" : "Bike in repairs for a week after this past weekend's shenanigans!",
  "id" : 15643938239,
  "created_at" : "Mon Jun 07 17:24:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15580823391",
  "text" : "Why are there so many small useless dogs in this city?",
  "id" : 15580823391,
  "created_at" : "Sun Jun 06 21:16:24 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15577565801",
  "text" : "Coffee and magazines in the NYC barnes and noble!",
  "id" : 15577565801,
  "created_at" : "Sun Jun 06 20:11:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15511279897",
  "text" : "Eating my way through NYC with all the interns!  4th meal at 730",
  "id" : 15511279897,
  "created_at" : "Sat Jun 05 21:05:01 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15438698334",
  "text" : "2/3 of the way to Connecticut!",
  "id" : 15438698334,
  "created_at" : "Fri Jun 04 19:49:12 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15428106929",
  "text" : "Lost in the beautiful country roads http://twitpic.com/1tv6y8",
  "id" : 15428106929,
  "created_at" : "Fri Jun 04 16:39:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielsuo",
      "screen_name" : "danielsuo",
      "indices" : [ 31, 41 ],
      "id_str" : "18029822",
      "id" : 18029822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15388316029",
  "text" : "Boston -&gt; NYC via bike with @danielsuo !  Follow our progress. http://twitpic.com/1tpl0p",
  "id" : 15388316029,
  "created_at" : "Fri Jun 04 03:22:04 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15232742149",
  "text" : "Overwhelmed in summertime. #wtf",
  "id" : 15232742149,
  "created_at" : "Wed Jun 02 06:01:27 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "15209361197",
  "text" : "Not only is art dead, but people are urinating on its corpse http://bit.ly/9J00N3",
  "id" : 15209361197,
  "created_at" : "Tue Jun 01 23:00:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]