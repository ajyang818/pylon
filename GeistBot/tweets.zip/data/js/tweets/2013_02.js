Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drones",
      "screen_name" : "drones",
      "indices" : [ 21, 28 ],
      "id_str" : "582233100",
      "id" : 582233100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http://t.co/dYvVlXZtHH",
      "expanded_url" : "http://www.sentinelsource.com/news/state_regional/n-h-bill-would-curtail-use-of-drones-for-surveillance/article_17736a38-ccf0-5981-9989-4b2b64633948.html",
      "display_url" : "sentinelsource.com/news/state_reg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "307214701182464000",
  "geo" : {
  },
  "id_str" : "307217545444851713",
  "in_reply_to_user_id" : 582233100,
  "text" : "Dr. Evil is pissed. \u201C@drones: This New Hampshire bill explicitly prohibits mounting \"laser-rays\" on drones. http://t.co/dYvVlXZtHH\u201D",
  "id" : 307217545444851713,
  "in_reply_to_status_id" : 307214701182464000,
  "created_at" : "Thu Feb 28 19:55:45 +0000 2013",
  "in_reply_to_screen_name" : "drones",
  "in_reply_to_user_id_str" : "582233100",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 0, 9 ],
      "id_str" : "20568189",
      "id" : 20568189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306980772043173888",
  "geo" : {
  },
  "id_str" : "307197501180612608",
  "in_reply_to_user_id" : 20568189,
  "text" : "@HODINKEE I've worn Subs and even Gshocks w/ suit. People should just wear what they like, don't mind the haters.",
  "id" : 307197501180612608,
  "in_reply_to_status_id" : 306980772043173888,
  "created_at" : "Thu Feb 28 18:36:06 +0000 2013",
  "in_reply_to_screen_name" : "HODINKEE",
  "in_reply_to_user_id_str" : "20568189",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TSA",
      "screen_name" : "TSA",
      "indices" : [ 14, 18 ],
      "id_str" : "414331122",
      "id" : 414331122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6145189116, -122.3835320213 ]
  },
  "id_str" : "306765045147246592",
  "text" : "Actually, SFO @TSA, I *am* allowed to request a hand-check for film. Just like it says on the massive TV screen right behind you.",
  "id" : 306765045147246592,
  "created_at" : "Wed Feb 27 13:57:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "306680496291708930",
  "text" : "I must say, WebOS is *really* an unmatched refrigerator OS.",
  "id" : 306680496291708930,
  "created_at" : "Wed Feb 27 08:21:42 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Rabois",
      "screen_name" : "rabois",
      "indices" : [ 0, 7 ],
      "id_str" : "20263710",
      "id" : 20263710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306657938255253504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7752393938, -122.39437035 ]
  },
  "id_str" : "306669503461343232",
  "in_reply_to_user_id" : 20263710,
  "text" : "@rabois awesome news. Hope we get to co-op on deals in the future!",
  "id" : 306669503461343232,
  "in_reply_to_status_id" : 306657938255253504,
  "created_at" : "Wed Feb 27 07:38:01 +0000 2013",
  "in_reply_to_screen_name" : "rabois",
  "in_reply_to_user_id_str" : "20263710",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 8, 13 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4351038132, -122.1332986002 ]
  },
  "id_str" : "306613050608324609",
  "text" : "Coolest @uber driver story so far: Steve Jobs driver.",
  "id" : 306613050608324609,
  "created_at" : "Wed Feb 27 03:53:42 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 3, 9 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "306591948142161920",
  "text" : "RT @sacca: I pay undeserved amounts of attention to anything using the Futura font.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "306591247718567937",
    "text" : "I pay undeserved amounts of attention to anything using the Futura font.",
    "id" : 306591247718567937,
    "created_at" : "Wed Feb 27 02:27:04 +0000 2013",
    "user" : {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "protected" : false,
      "id_str" : "586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1771648774/Sacca_profile_normal.jpg",
      "id" : 586,
      "verified" : true
    }
  },
  "id" : 306591948142161920,
  "created_at" : "Wed Feb 27 02:29:51 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 16, 30 ],
      "id_str" : "128968036",
      "id" : 128968036
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 35, 44 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "TEDTalks Updates",
      "screen_name" : "tedtalks",
      "indices" : [ 65, 74 ],
      "id_str" : "15492359",
      "id" : 15492359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http://t.co/a0wXgfHKkh",
      "expanded_url" : "http://blog.ted.com/2013/02/26/make-your-smartphone-a-personal-robot-keller-rinaudo-at-ted2013",
      "display_url" : "blog.ted.com/2013/02/26/mak\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "306549408412086272",
  "text" : "So happy to see @KellerRinaudo and @Romotive taking the stage at @TEDTalks 2013! http://t.co/a0wXgfHKkh",
  "id" : 306549408412086272,
  "created_at" : "Tue Feb 26 23:40:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Incident",
      "screen_name" : "IncidentTech",
      "indices" : [ 7, 20 ],
      "id_str" : "175174627",
      "id" : 175174627
    }, {
      "name" : "Project One",
      "screen_name" : "p1sf",
      "indices" : [ 26, 31 ],
      "id_str" : "26424102",
      "id" : 26424102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http://t.co/YYwBBgscgK",
      "expanded_url" : "http://4sq.com/YwzmMZ",
      "display_url" : "4sq.com/YwzmMZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7667030274, -122.402832559 ]
  },
  "id_str" : "306479577847443456",
  "text" : "Hello, @IncidentTech! (at @p1sf) [pic]: http://t.co/YYwBBgscgK",
  "id" : 306479577847443456,
  "created_at" : "Tue Feb 26 19:03:20 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SAI",
      "screen_name" : "SAI",
      "indices" : [ 19, 23 ],
      "id_str" : "8841372",
      "id" : 8841372
    }, {
      "name" : "Vinicius Vacanti",
      "screen_name" : "vacanti",
      "indices" : [ 113, 121 ],
      "id_str" : "14424445",
      "id" : 14424445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http://t.co/fv4YgVTx16",
      "expanded_url" : "http://read.bi/XWNZqA",
      "display_url" : "read.bi/XWNZqA"
    } ]
  },
  "in_reply_to_status_id_str" : "306132166612492288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7845884568, -122.4017714086 ]
  },
  "id_str" : "306133856694726656",
  "in_reply_to_user_id" : 14424445,
  "text" : "\"Camera strapped\" \u201C@SAI: Shutterstock Founder Took 100K Photos To Get Company Going: http://t.co/fv4YgVTx16\u201D via @vacanti",
  "id" : 306133856694726656,
  "in_reply_to_status_id" : 306132166612492288,
  "created_at" : "Mon Feb 25 20:09:33 +0000 2013",
  "in_reply_to_screen_name" : "vacanti",
  "in_reply_to_user_id_str" : "14424445",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RSA Conference",
      "screen_name" : "RSAConference",
      "indices" : [ 52, 66 ],
      "id_str" : "7381532",
      "id" : 7381532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7845908787, -122.4017558108 ]
  },
  "id_str" : "306113430274834432",
  "text" : "If I were a Chinese hacker, I would totally be this @RSAConference to see what everyone is thinking and do exactly the opposite.",
  "id" : 306113430274834432,
  "created_at" : "Mon Feb 25 18:48:23 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CloudSecurityAllianc",
      "screen_name" : "cloudsa",
      "indices" : [ 19, 27 ],
      "id_str" : "26565989",
      "id" : 26565989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http://t.co/06J4239Ftd",
      "expanded_url" : "http://4sq.com/13i7rWk",
      "display_url" : "4sq.com/13i7rWk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7839096912, -122.4018359184 ]
  },
  "id_str" : "306085045330915328",
  "text" : "RSA Conference and @CloudSA Summit time! (@ Moscone Center w/ 19 others) [pic]: http://t.co/06J4239Ftd",
  "id" : 306085045330915328,
  "created_at" : "Mon Feb 25 16:55:36 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/07eQaldIDN",
      "expanded_url" : "http://on.wsj.com/YpNTKh",
      "display_url" : "on.wsj.com/YpNTKh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "305880678703185920",
  "text" : "RT @WSJ: The median age for the #Oscars TV audience is 52.8, compared with 46.7 a decade ago and 39.9 in 1992. http://t.co/07eQaldIDN",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oscars",
        "indices" : [ 23, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http://t.co/07eQaldIDN",
        "expanded_url" : "http://on.wsj.com/YpNTKh",
        "display_url" : "on.wsj.com/YpNTKh"
      } ]
    },
    "geo" : {
    },
    "id_str" : "305877076983037954",
    "text" : "The median age for the #Oscars TV audience is 52.8, compared with 46.7 a decade ago and 39.9 in 1992. http://t.co/07eQaldIDN",
    "id" : 305877076983037954,
    "created_at" : "Mon Feb 25 03:09:12 +0000 2013",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 305880678703185920,
  "created_at" : "Mon Feb 25 03:23:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Brusilovsky",
      "screen_name" : "danielbru",
      "indices" : [ 44, 54 ],
      "id_str" : "2148071",
      "id" : 2148071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/YTRQaaz3OD",
      "expanded_url" : "http://4sq.com/Xv9LWm",
      "display_url" : "4sq.com/Xv9LWm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6007214739, -122.3824435472 ]
  },
  "id_str" : "305867689346338816",
  "text" : "Learning how to eat like a Californian with @danielbru. (@ In-N-Out Burger w/ 2 others) http://t.co/YTRQaaz3OD",
  "id" : 305867689346338816,
  "created_at" : "Mon Feb 25 02:31:54 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CloudSecurityAllianc",
      "screen_name" : "cloudsa",
      "indices" : [ 13, 21 ],
      "id_str" : "26565989",
      "id" : 26565989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http://t.co/0QIIxh7rUV",
      "expanded_url" : "http://4sq.com/XVmz4g",
      "display_url" : "4sq.com/XVmz4g"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6164240527, -122.3862791061 ]
  },
  "id_str" : "305859462399422464",
  "text" : "Here for the @CloudSA Summit! (@ San Francisco International Airport (SFO) w/ 148 others) http://t.co/0QIIxh7rUV",
  "id" : 305859462399422464,
  "created_at" : "Mon Feb 25 01:59:13 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eugenia Koo",
      "screen_name" : "itwentviral",
      "indices" : [ 42, 54 ],
      "id_str" : "261491851",
      "id" : 261491851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305827324299972609",
  "geo" : {
  },
  "id_str" : "305845007741485057",
  "in_reply_to_user_id" : 261491851,
  "text" : "Was your name at least in the same font? \u201C@itwentviral: if you're going to send me standard investor copy, at least remove the \"Fwd\".\u201D",
  "id" : 305845007741485057,
  "in_reply_to_status_id" : 305827324299972609,
  "created_at" : "Mon Feb 25 01:01:46 +0000 2013",
  "in_reply_to_screen_name" : "itwentviral",
  "in_reply_to_user_id_str" : "261491851",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 3, 10 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "305842482762088448",
  "text" : "RT @jdrive: I have a ridiculous number of emails and calls to return. Think I'll watch tv.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "305837279782506497",
    "text" : "I have a ridiculous number of emails and calls to return. Think I'll watch tv.",
    "id" : 305837279782506497,
    "created_at" : "Mon Feb 25 00:31:04 +0000 2013",
    "user" : {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "protected" : false,
      "id_str" : "15137329",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3458237744/7f6dc83d6d93ff6347730211a9e34430_normal.jpeg",
      "id" : 15137329,
      "verified" : false
    }
  },
  "id" : 305842482762088448,
  "created_at" : "Mon Feb 25 00:51:44 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305814287673344000",
  "geo" : {
  },
  "id_str" : "305823312095899648",
  "in_reply_to_user_id" : 111999960,
  "text" : "@kshsieh How'd the nyack ride go?",
  "id" : 305823312095899648,
  "in_reply_to_status_id" : 305814287673344000,
  "created_at" : "Sun Feb 24 23:35:34 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 16, 29 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/305735045056966656/photo/1",
      "indices" : [ 47, 69 ],
      "url" : "http://t.co/OI5JZIhOsT",
      "media_url" : "http://pbs.twimg.com/media/BD4wZ1RCMAEYZ7U.jpg",
      "id_str" : "305735045061160961",
      "id" : 305735045061160961,
      "media_url_https" : "https://pbs.twimg.com/media/BD4wZ1RCMAEYZ7U.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com/OI5JZIhOsT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "305735045056966656",
  "text" : "Full page ad in @TheEconomist for 3D printing. http://t.co/OI5JZIhOsT",
  "id" : 305735045056966656,
  "created_at" : "Sun Feb 24 17:44:50 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drones",
      "screen_name" : "drones",
      "indices" : [ 3, 10 ],
      "id_str" : "582233100",
      "id" : 582233100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "305395914850328576",
  "text" : "RT @drones: Government plans for drastic expansion of domestic mini-drones, FAA projects 10,000 flying over US skies by 2017 http://t.co ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http://t.co/VVL2itZwm3",
        "expanded_url" : "http://fxn.ws/YK94Xi",
        "display_url" : "fxn.ws/YK94Xi"
      } ]
    },
    "geo" : {
    },
    "id_str" : "305395243283533825",
    "text" : "Government plans for drastic expansion of domestic mini-drones, FAA projects 10,000 flying over US skies by 2017 http://t.co/VVL2itZwm3",
    "id" : 305395243283533825,
    "created_at" : "Sat Feb 23 19:14:34 +0000 2013",
    "user" : {
      "name" : "Drones",
      "screen_name" : "drones",
      "protected" : false,
      "id_str" : "582233100",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2586488654/vk5lwolvre7b7m2iro49_normal.jpeg",
      "id" : 582233100,
      "verified" : false
    }
  },
  "id" : 305395914850328576,
  "created_at" : "Sat Feb 23 19:17:14 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drones",
      "screen_name" : "drones",
      "indices" : [ 0, 7 ],
      "id_str" : "582233100",
      "id" : 582233100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305377414513557506",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7184891793, -74.0087800692 ]
  },
  "id_str" : "305378782078971904",
  "in_reply_to_user_id" : 582233100,
  "text" : "@drones is it a \"spy\" drone if we know it's there?",
  "id" : 305378782078971904,
  "in_reply_to_status_id" : 305377414513557506,
  "created_at" : "Sat Feb 23 18:09:09 +0000 2013",
  "in_reply_to_screen_name" : "drones",
  "in_reply_to_user_id_str" : "582233100",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Mielczarek",
      "screen_name" : "TedMielczarek",
      "indices" : [ 3, 17 ],
      "id_str" : "17462502",
      "id" : 17462502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "305352959997378563",
  "text" : "RT @TedMielczarek: I propose that we repurpose \u2318 as the emoticon for a quadrotor drone.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "305127604896296961",
    "text" : "I propose that we repurpose \u2318 as the emoticon for a quadrotor drone.",
    "id" : 305127604896296961,
    "created_at" : "Sat Feb 23 01:31:04 +0000 2013",
    "user" : {
      "name" : "Ted Mielczarek",
      "screen_name" : "TedMielczarek",
      "protected" : false,
      "id_str" : "17462502",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1554600842/6153443122_af12f46694_z_normal.jpg",
      "id" : 17462502,
      "verified" : false
    }
  },
  "id" : 305352959997378563,
  "created_at" : "Sat Feb 23 16:26:33 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walt Mossberg",
      "screen_name" : "waltmossberg",
      "indices" : [ 3, 16 ],
      "id_str" : "5746452",
      "id" : 5746452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http://t.co/m9eEVr0HZ4",
      "expanded_url" : "http://dthin.gs/YjtPuQ",
      "display_url" : "dthin.gs/YjtPuQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "305352725858758656",
  "text" : "RT @waltmossberg: The Google Store Experience (Comic) -- the store knows what you want.  http://t.co/m9eEVr0HZ4",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http://t.co/m9eEVr0HZ4",
        "expanded_url" : "http://dthin.gs/YjtPuQ",
        "display_url" : "dthin.gs/YjtPuQ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "305282570269110273",
    "text" : "The Google Store Experience (Comic) -- the store knows what you want.  http://t.co/m9eEVr0HZ4",
    "id" : 305282570269110273,
    "created_at" : "Sat Feb 23 11:46:51 +0000 2013",
    "user" : {
      "name" : "Walt Mossberg",
      "screen_name" : "waltmossberg",
      "protected" : false,
      "id_str" : "5746452",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3569270561/e95260439557ec04c7979ad1c2202b41_normal.jpeg",
      "id" : 5746452,
      "verified" : true
    }
  },
  "id" : 305352725858758656,
  "created_at" : "Sat Feb 23 16:25:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 1, 7 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305147227393912832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7168038935, -73.9976630733 ]
  },
  "id_str" : "305147456046387200",
  "in_reply_to_user_id" : 15227849,
  "text" : ".@semil back in school we prototyped an interface for the Starbucks app that allowed people to bid for their place in the drink queue.",
  "id" : 305147456046387200,
  "in_reply_to_status_id" : 305147227393912832,
  "created_at" : "Sat Feb 23 02:49:57 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 1, 9 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7188009657, -73.9947046806 ]
  },
  "id_str" : "305146870295035904",
  "text" : ".@mailbox should have made their reservation line placement biddable and cashed in on the hype.",
  "id" : 305146870295035904,
  "created_at" : "Sat Feb 23 02:47:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 13, 23 ],
      "id_str" : "22745680",
      "id" : 22745680
    }, {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 24, 31 ],
      "id_str" : "9544202",
      "id" : 9544202
    }, {
      "name" : "Copious Apps",
      "screen_name" : "CopiousApps",
      "indices" : [ 32, 44 ],
      "id_str" : "477382459",
      "id" : 477382459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305145089544581121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7216249546, -73.9934467246 ]
  },
  "id_str" : "305146337370963968",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce @besvinick @schlaf @copiousapps appit - git for app icon placement!",
  "id" : 305146337370963968,
  "in_reply_to_status_id" : 305145089544581121,
  "created_at" : "Sat Feb 23 02:45:30 +0000 2013",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305144907205595136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7298601517, -73.9902464096 ]
  },
  "id_str" : "305145158180147202",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick ah I see. I still do all my contact mgmt in Gmail and Google Contacts - grandfathered into Google Activesync support.",
  "id" : 305145158180147202,
  "in_reply_to_status_id" : 305144907205595136,
  "created_at" : "Sat Feb 23 02:40:49 +0000 2013",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305140658212061184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7349619791, -73.9860316443 ]
  },
  "id_str" : "305144400814686208",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick interesting that you still have contacts on homescreen - why not swipe-n-search?",
  "id" : 305144400814686208,
  "in_reply_to_status_id" : 305140658212061184,
  "created_at" : "Sat Feb 23 02:37:49 +0000 2013",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 62, 69 ],
      "id_str" : "9544202",
      "id" : 9544202
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/305143963273265153/photo/1",
      "indices" : [ 70, 92 ],
      "url" : "http://t.co/jGjizLATMJ",
      "media_url" : "http://pbs.twimg.com/media/BDwW0WDCAAAAfqr.jpg",
      "id_str" : "305143963281653760",
      "id" : 305143963281653760,
      "media_url_https" : "https://pbs.twimg.com/media/BDwW0WDCAAAAfqr.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/jGjizLATMJ"
    } ],
    "hashtags" : [ {
      "text" : "homescreen",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305140024171700225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7415064448, -73.9833737215 ]
  },
  "id_str" : "305143963273265153",
  "in_reply_to_user_id" : 9544202,
  "text" : "Here's my iPhone #homescreen. Still prefer Cue to Sunrise. cc @schlaf http://t.co/jGjizLATMJ",
  "id" : 305143963273265153,
  "in_reply_to_status_id" : 305140024171700225,
  "created_at" : "Sat Feb 23 02:36:05 +0000 2013",
  "in_reply_to_screen_name" : "schlaf",
  "in_reply_to_user_id_str" : "9544202",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7510661851, -73.9913651694 ]
  },
  "id_str" : "305057552390045697",
  "text" : "Trying to troubleshoot wifi connection in the Cisco office. Really? Really??",
  "id" : 305057552390045697,
  "created_at" : "Fri Feb 22 20:52:42 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Chou",
      "screen_name" : "markdchou",
      "indices" : [ 0, 10 ],
      "id_str" : "67686145",
      "id" : 67686145
    }, {
      "name" : "IWC Watches",
      "screen_name" : "IWC",
      "indices" : [ 49, 53 ],
      "id_str" : "44571430",
      "id" : 44571430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305055599836684289",
  "geo" : {
  },
  "id_str" : "305055764316303360",
  "in_reply_to_user_id" : 67686145,
  "text" : "@markdchou I hope you walk away with a beautiful @iwc.",
  "id" : 305055764316303360,
  "in_reply_to_status_id" : 305055599836684289,
  "created_at" : "Fri Feb 22 20:45:36 +0000 2013",
  "in_reply_to_screen_name" : "markdchou",
  "in_reply_to_user_id_str" : "67686145",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luxi",
      "screen_name" : "LuxiMeter",
      "indices" : [ 9, 19 ],
      "id_str" : "1172811512",
      "id" : 1172811512
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 63, 75 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http://t.co/y1LfQGuoQ3",
      "expanded_url" : "http://kck.st/Xr55h9",
      "display_url" : "kck.st/Xr55h9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304974342406684673",
  "text" : "I backed @LuxiMeter Incident light meter adapter for iPhone on @kickstarter: http://t.co/y1LfQGuoQ3",
  "id" : 304974342406684673,
  "created_at" : "Fri Feb 22 15:22:04 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 3, 16 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304971377163788288",
  "text" : "RT @Horse_ebooks: Where did you got",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "304875709485158400",
    "text" : "Where did you got",
    "id" : 304875709485158400,
    "created_at" : "Fri Feb 22 08:50:08 +0000 2013",
    "user" : {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "protected" : false,
      "id_str" : "174958347",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1096005346/1_normal.jpg",
      "id" : 174958347,
      "verified" : false
    }
  },
  "id" : 304971377163788288,
  "created_at" : "Fri Feb 22 15:10:17 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://itunes.apple.com/us/app/kickstarter-for-iphone/id596961532?mt=8&uo=4\" rel=\"nofollow\">Kickstarter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http://t.co/y1LfQGuoQ3",
      "expanded_url" : "http://kck.st/Xr55h9",
      "display_url" : "kck.st/Xr55h9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304837992919478272",
  "text" : "FINALLY. I've been trying to use the iPhone as a light meter for years now. http://t.co/y1LfQGuoQ3",
  "id" : 304837992919478272,
  "created_at" : "Fri Feb 22 06:20:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http://t.co/Hh2mpybOuk",
      "expanded_url" : "http://thedoghousediaries.com/4898",
      "display_url" : "thedoghousediaries.com/4898"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304836871891079168",
  "text" : "Great primer on tweet etiquette by Doghouse Diaries. http://t.co/Hh2mpybOuk",
  "id" : 304836871891079168,
  "created_at" : "Fri Feb 22 06:15:48 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Catherine Shu",
      "screen_name" : "CatherineShu",
      "indices" : [ 116, 129 ],
      "id_str" : "7389732",
      "id" : 7389732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http://t.co/h0XDmu4EHo",
      "expanded_url" : "http://techcrunch.com/2013/02/21/apple-shares-slip-2-8-on-foxconn-hiring-freeze-but-it-may-be-because-of-robots-not-slack-iphone-5-demand/",
      "display_url" : "techcrunch.com/2013/02/21/app\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304810663702839296",
  "text" : "RT @TechCrunch: Foxconn Hiring Freeze May Be Because Of Robots, Not Slack iPhone 5 Demand http://t.co/h0XDmu4EHo by @catherineshu",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Catherine Shu",
        "screen_name" : "CatherineShu",
        "indices" : [ 100, 113 ],
        "id_str" : "7389732",
        "id" : 7389732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http://t.co/h0XDmu4EHo",
        "expanded_url" : "http://techcrunch.com/2013/02/21/apple-shares-slip-2-8-on-foxconn-hiring-freeze-but-it-may-be-because-of-robots-not-slack-iphone-5-demand/",
        "display_url" : "techcrunch.com/2013/02/21/app\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "304794363953836034",
    "text" : "Foxconn Hiring Freeze May Be Because Of Robots, Not Slack iPhone 5 Demand http://t.co/h0XDmu4EHo by @catherineshu",
    "id" : 304794363953836034,
    "created_at" : "Fri Feb 22 03:26:53 +0000 2013",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2176846885/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 304810663702839296,
  "created_at" : "Fri Feb 22 04:31:39 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 8, 20 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 37, 49 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http://t.co/C9ICWvt3kU",
      "expanded_url" : "http://4sq.com/XoDkZH",
      "display_url" : "4sq.com/XoDkZH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.719179, -73.985599 ]
  },
  "id_str" : "304786986059833345",
  "text" : "Awesome @kickstarter Open House! (at @kickstarter w/ 14 others) [pic]: http://t.co/C9ICWvt3kU",
  "id" : 304786986059833345,
  "created_at" : "Fri Feb 22 02:57:34 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    }, {
      "name" : "Albumatic",
      "screen_name" : "albumatic",
      "indices" : [ 12, 22 ],
      "id_str" : "988029458",
      "id" : 988029458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304734248861044736",
  "geo" : {
  },
  "id_str" : "304734398824185856",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin @albumatic but not friction for core functionality - only for extra feature.",
  "id" : 304734398824185856,
  "in_reply_to_status_id" : 304734248861044736,
  "created_at" : "Thu Feb 21 23:28:37 +0000 2013",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    }, {
      "name" : "Albumatic",
      "screen_name" : "albumatic",
      "indices" : [ 12, 22 ],
      "id_str" : "988029458",
      "id" : 988029458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304732872940613632",
  "geo" : {
  },
  "id_str" : "304733700057354242",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin @albumatic or allow every contributor to deselect ones they don't want and only publish unanimous approved pics.",
  "id" : 304733700057354242,
  "in_reply_to_status_id" : 304732872940613632,
  "created_at" : "Thu Feb 21 23:25:50 +0000 2013",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    }, {
      "name" : "Albumatic",
      "screen_name" : "albumatic",
      "indices" : [ 12, 22 ],
      "id_str" : "988029458",
      "id" : 988029458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304732872940613632",
  "geo" : {
  },
  "id_str" : "304733288914886656",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin @albumatic why not ask them? Hit publish to fb -&gt; ask contributors via app for sign off.",
  "id" : 304733288914886656,
  "in_reply_to_status_id" : 304732872940613632,
  "created_at" : "Thu Feb 21 23:24:12 +0000 2013",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Albumatic",
      "screen_name" : "albumatic",
      "indices" : [ 47, 57 ],
      "id_str" : "988029458",
      "id" : 988029458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304732720569925632",
  "text" : "Would love a \"publish to Facebook\" feature for @albumatic.",
  "id" : 304732720569925632,
  "created_at" : "Thu Feb 21 23:21:56 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 16, 20 ],
      "id_str" : "19494411",
      "id" : 19494411
    }, {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 43, 51 ],
      "id_str" : "586671909",
      "id" : 586671909
    }, {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 67, 78 ],
      "id_str" : "6568422",
      "id" : 6568422
    }, {
      "name" : "Albumatic",
      "screen_name" : "albumatic",
      "indices" : [ 92, 102 ],
      "id_str" : "988029458",
      "id" : 988029458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http://t.co/3roa0FkjOa",
      "expanded_url" : "http://allthingsd.com/20130221/albumatic-is-a-photo-sharing-app-with-vine-credentials-and-you-might-use-it/",
      "display_url" : "allthingsd.com/20130221/album\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304644896801832960",
  "geo" : {
  },
  "id_str" : "304645386595872769",
  "in_reply_to_user_id" : 19494411,
  "text" : "Congrats Adam! \u201C@RRE: Hot off the heels of @VineApp, our principal @AdamLudwin is launching @albumatic today. http://t.co/3roa0FkjOa\u201D",
  "id" : 304645386595872769,
  "in_reply_to_status_id" : 304644896801832960,
  "created_at" : "Thu Feb 21 17:34:54 +0000 2013",
  "in_reply_to_screen_name" : "RRE",
  "in_reply_to_user_id_str" : "19494411",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Makin it Wayne",
      "screen_name" : "ballerwayne",
      "indices" : [ 3, 15 ],
      "id_str" : "1113227906",
      "id" : 1113227906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304341117166555137",
  "text" : "RT @ballerwayne: My competitors hate me, my employees celebrate me, ain't no sucka gonna out-innovate me.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "304329642834288641",
    "text" : "My competitors hate me, my employees celebrate me, ain't no sucka gonna out-innovate me.",
    "id" : 304329642834288641,
    "created_at" : "Wed Feb 20 20:40:15 +0000 2013",
    "user" : {
      "name" : "Makin it Wayne",
      "screen_name" : "ballerwayne",
      "protected" : false,
      "id_str" : "1113227906",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3150752736/135a45359640ee28d64cebe277f77930_normal.jpeg",
      "id" : 1113227906,
      "verified" : false
    }
  },
  "id" : 304341117166555137,
  "created_at" : "Wed Feb 20 21:25:51 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 35, 39 ],
      "id_str" : "19494411",
      "id" : 19494411
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/304310062107738113/photo/1",
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/XzztUMm3",
      "media_url" : "http://pbs.twimg.com/media/BDkgY6HCQAAzXwi.jpg",
      "id_str" : "304310062111932416",
      "id" : 304310062111932416,
      "media_url_https" : "https://pbs.twimg.com/media/BDkgY6HCQAAzXwi.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/XzztUMm3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304310062107738113",
  "text" : "Someone's having a ruff day at the @RRE office. http://t.co/XzztUMm3",
  "id" : 304310062107738113,
  "created_at" : "Wed Feb 20 19:22:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica",
      "screen_name" : "Schmoodles",
      "indices" : [ 3, 14 ],
      "id_str" : "274524028",
      "id" : 274524028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304308563390656512",
  "text" : "RT @Schmoodles: Someone at work said \"hashtag, just kidding\" at the end of a sentence, and now I've got a body to dispose of.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "304239247446134785",
    "text" : "Someone at work said \"hashtag, just kidding\" at the end of a sentence, and now I've got a body to dispose of.",
    "id" : 304239247446134785,
    "created_at" : "Wed Feb 20 14:41:03 +0000 2013",
    "user" : {
      "name" : "Jessica",
      "screen_name" : "Schmoodles",
      "protected" : false,
      "id_str" : "274524028",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2794721409/dbf8ec283e2acadb51e12a3eabd983db_normal.jpeg",
      "id" : 274524028,
      "verified" : false
    }
  },
  "id" : 304308563390656512,
  "created_at" : "Wed Feb 20 19:16:29 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/304283526973505537/photo/1",
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/aZ4tLMY0",
      "media_url" : "http://pbs.twimg.com/media/BDkIQXDCQAAVJDK.jpg",
      "id_str" : "304283526981894144",
      "id" : 304283526981894144,
      "media_url_https" : "https://pbs.twimg.com/media/BDkIQXDCQAAVJDK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/aZ4tLMY0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304283526973505537",
  "text" : "A picture of someone that started randomly drawing my portrait on the subway. http://t.co/aZ4tLMY0",
  "id" : 304283526973505537,
  "created_at" : "Wed Feb 20 17:37:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 0, 11 ],
      "id_str" : "6568422",
      "id" : 6568422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304279638463610880",
  "geo" : {
  },
  "id_str" : "304280129050390528",
  "in_reply_to_user_id" : 6568422,
  "text" : "@adamludwin until we find out you can only share on G+",
  "id" : 304280129050390528,
  "in_reply_to_status_id" : 304279638463610880,
  "created_at" : "Wed Feb 20 17:23:30 +0000 2013",
  "in_reply_to_screen_name" : "adamludwin",
  "in_reply_to_user_id_str" : "6568422",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Business",
      "screen_name" : "HarvardHBS",
      "indices" : [ 41, 52 ],
      "id_str" : "19606528",
      "id" : 19606528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meta",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "HBSfitb",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304278016278818817",
  "geo" : {
  },
  "id_str" : "304279306098577409",
  "in_reply_to_user_id" : 19606528,
  "text" : "to know how to fill in this blank #meta \u201C@HarvardHBS: FILL-IN-THE-BLANK: An entrepreneur needs ____ to be successful. #HBSfitb\u201D",
  "id" : 304279306098577409,
  "in_reply_to_status_id" : 304278016278818817,
  "created_at" : "Wed Feb 20 17:20:14 +0000 2013",
  "in_reply_to_screen_name" : "HarvardHBS",
  "in_reply_to_user_id_str" : "19606528",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Yankovic",
      "screen_name" : "alyankovic",
      "indices" : [ 3, 14 ],
      "id_str" : "22461427",
      "id" : 22461427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/W4eFgIHL",
      "expanded_url" : "http://twitpic.com/c5e3tw",
      "display_url" : "twitpic.com/c5e3tw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304278558690381825",
  "text" : "RT @alyankovic: Just started giving my daughter piano lessons.  No pressure. http://t.co/W4eFgIHL",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/W4eFgIHL",
        "expanded_url" : "http://twitpic.com/c5e3tw",
        "display_url" : "twitpic.com/c5e3tw"
      } ]
    },
    "geo" : {
    },
    "id_str" : "304266640437157888",
    "text" : "Just started giving my daughter piano lessons.  No pressure. http://t.co/W4eFgIHL",
    "id" : 304266640437157888,
    "created_at" : "Wed Feb 20 16:29:54 +0000 2013",
    "user" : {
      "name" : "Al Yankovic",
      "screen_name" : "alyankovic",
      "protected" : false,
      "id_str" : "22461427",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/246073324/IL2_normal.jpg",
      "id" : 22461427,
      "verified" : true
    }
  },
  "id" : 304278558690381825,
  "created_at" : "Wed Feb 20 17:17:16 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://itunes.apple.com/us/app/reeder/id325502379?mt=8&uo=4\" rel=\"nofollow\">Reeder on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/P9MgXK96",
      "expanded_url" : "http://www.youtube.com/embed/IGH2HEgWppc?version=3&rel=1&fs=1&showsearch=0&showinfo=1&iv_load_policy=1&wmode=transparent",
      "display_url" : "youtube.com/embed/IGH2HEgW\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304271275247927296",
  "text" : "\"I know the Harlem Shake but that ain't it.\" - Harlem residents' reactions to Harlem Shake vids. http://t.co/P9MgXK96",
  "id" : 304271275247927296,
  "created_at" : "Wed Feb 20 16:48:19 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Einstein",
      "screen_name" : "BenEinstein",
      "indices" : [ 12, 24 ],
      "id_str" : "45914046",
      "id" : 45914046
    }, {
      "name" : "Bolt",
      "screen_name" : "BoltBoston",
      "indices" : [ 33, 44 ],
      "id_str" : "360775122",
      "id" : 360775122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/k7tuq785",
      "expanded_url" : "http://www.xconomy.com/boston/2013/02/20/bolt-emerges-with-3-5m-fund-to-support-hardware-startups-in-boston/",
      "display_url" : "xconomy.com/boston/2013/02\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304262262368120832",
  "text" : "Congrats to @BenEinstein and the @BoltBoston team - looking forward to the hardware innovation. http://t.co/k7tuq785",
  "id" : 304262262368120832,
  "created_at" : "Wed Feb 20 16:12:30 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Solnet",
      "screen_name" : "jfsolnet",
      "indices" : [ 3, 12 ],
      "id_str" : "24945651",
      "id" : 24945651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ifihadglass",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304256464841752577",
  "text" : "RT @jfsolnet: #ifihadglass I would be blind, because I wouldn't be wearing my glasses. Also, I would probably be mugged.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ifihadglass",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "304255772014034944",
    "text" : "#ifihadglass I would be blind, because I wouldn't be wearing my glasses. Also, I would probably be mugged.",
    "id" : 304255772014034944,
    "created_at" : "Wed Feb 20 15:46:43 +0000 2013",
    "user" : {
      "name" : "Jeff Solnet",
      "screen_name" : "jfsolnet",
      "protected" : false,
      "id_str" : "24945651",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3209267302/c8de6b003e71f9c340d454f0bace7447_normal.png",
      "id" : 24945651,
      "verified" : false
    }
  },
  "id" : 304256464841752577,
  "created_at" : "Wed Feb 20 15:49:28 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ifihadglass",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304252125184151552",
  "text" : "#ifihadglass I would build a light meter HUD to facilitate shooting with vintage analog cameras.",
  "id" : 304252125184151552,
  "created_at" : "Wed Feb 20 15:32:14 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The 3Doodler",
      "screen_name" : "3Doodler",
      "indices" : [ 14, 23 ],
      "id_str" : "968836284",
      "id" : 968836284
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 62, 74 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/iJGbdfHZ",
      "expanded_url" : "http://kck.st/Y4PXHr",
      "display_url" : "kck.st/Y4PXHr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304251003828596737",
  "text" : "I just backed @3Doodler: The World's First 3D Printing Pen on @Kickstarter http://t.co/iJGbdfHZ",
  "id" : 304251003828596737,
  "created_at" : "Wed Feb 20 15:27:46 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Persson",
      "screen_name" : "notch",
      "indices" : [ 0, 6 ],
      "id_str" : "63485337",
      "id" : 63485337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304231018011971585",
  "geo" : {
  },
  "id_str" : "304246919612469248",
  "in_reply_to_user_id" : 63485337,
  "text" : "@notch what assumptions may we make about the material properties of the belt?",
  "id" : 304246919612469248,
  "in_reply_to_status_id" : 304231018011971585,
  "created_at" : "Wed Feb 20 15:11:32 +0000 2013",
  "in_reply_to_screen_name" : "notch",
  "in_reply_to_user_id_str" : "63485337",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Edwards",
      "screen_name" : "UnderTheLoupe",
      "indices" : [ 23, 37 ],
      "id_str" : "61065591",
      "id" : 61065591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304246351519154177",
  "text" : "Today I learned... \"RT @UnderTheLoupe: A second is so called because it is the second division of an hour.\u201D",
  "id" : 304246351519154177,
  "created_at" : "Wed Feb 20 15:09:17 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    }, {
      "name" : "Eugenia Koo",
      "screen_name" : "itwentviral",
      "indices" : [ 8, 20 ],
      "id_str" : "261491851",
      "id" : 261491851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304055376612032514",
  "geo" : {
  },
  "id_str" : "304107660805013504",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive @itwentviral I've been waiting for a nano-tragedy ever since Prey was published in 2002.",
  "id" : 304107660805013504,
  "in_reply_to_status_id" : 304055376612032514,
  "created_at" : "Wed Feb 20 05:58:11 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moves",
      "screen_name" : "movesapp",
      "indices" : [ 0, 9 ],
      "id_str" : "888379981",
      "id" : 888379981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304094200658546690",
  "in_reply_to_user_id" : 888379981,
  "text" : "@movesapp would love to see foursquare account integration to autocorrelate locations!",
  "id" : 304094200658546690,
  "created_at" : "Wed Feb 20 05:04:41 +0000 2013",
  "in_reply_to_screen_name" : "movesapp",
  "in_reply_to_user_id_str" : "888379981",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 39, 45 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304077363845664768",
  "text" : "\"Want a cheap but radioactive lens?\" - @jluan knows exactly what to get me.",
  "id" : 304077363845664768,
  "created_at" : "Wed Feb 20 03:57:47 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kim",
      "screen_name" : "pushingatoms",
      "indices" : [ 33, 46 ],
      "id_str" : "19954028",
      "id" : 19954028
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/304033047475531776/photo/1",
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/ArycTKCi",
      "media_url" : "http://pbs.twimg.com/media/BDgkciMCMAAg7Ep.jpg",
      "id_str" : "304033047479726080",
      "id" : 304033047479726080,
      "media_url_https" : "https://pbs.twimg.com/media/BDgkciMCMAAg7Ep.jpg",
      "sizes" : [ {
        "h" : 412,
        "resize" : "fit",
        "w" : 870
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 870
      } ],
      "display_url" : "pic.twitter.com/ArycTKCi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304033047475531776",
  "text" : "The new HTC One looks a lot like @pushingatoms's concept art from 2010. http://t.co/ArycTKCi",
  "id" : 304033047475531776,
  "created_at" : "Wed Feb 20 01:01:42 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amiigo",
      "screen_name" : "GoAmiigo",
      "indices" : [ 0, 9 ],
      "id_str" : "578059268",
      "id" : 578059268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "303984287445815296",
  "in_reply_to_user_id" : 578059268,
  "text" : "@GoAmiigo hey, would love to chat with you guys if you have a free moment!",
  "id" : 303984287445815296,
  "created_at" : "Tue Feb 19 21:47:56 +0000 2013",
  "in_reply_to_screen_name" : "GoAmiigo",
  "in_reply_to_user_id_str" : "578059268",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 20, 28 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "BurgerKing",
      "screen_name" : "BurgerKing",
      "indices" : [ 69, 80 ],
      "id_str" : "167421802",
      "id" : 167421802
    }, {
      "name" : "Jeep",
      "screen_name" : "Jeep",
      "indices" : [ 89, 94 ],
      "id_str" : "98955572",
      "id" : 98955572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/yaQIUlAy",
      "expanded_url" : "http://mobile.theverge.com/2013/2/19/4005604/jeep-twitter-account-hacked",
      "display_url" : "mobile.theverge.com/2013/2/19/4005\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303974890040614912",
  "text" : "Two major corporate @twitter accounts compromised in two days: first @BurgerKing and now @Jeep. http://t.co/yaQIUlAy",
  "id" : 303974890040614912,
  "created_at" : "Tue Feb 19 21:10:36 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "303920353837735936",
  "in_reply_to_user_id" : 75079616,
  "text" : "@IFTTT I can't get the trigger email to work when using forwarding rules from O365! Any idea why?",
  "id" : 303920353837735936,
  "created_at" : "Tue Feb 19 17:33:53 +0000 2013",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 44, 50 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "303920266294210562",
  "text" : "Today I created an infinite email loop with @IFTTT.",
  "id" : 303920266294210562,
  "created_at" : "Tue Feb 19 17:33:32 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yonatan Kogan",
      "screen_name" : "yjkogan",
      "indices" : [ 0, 8 ],
      "id_str" : "29844377",
      "id" : 29844377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303767073354555392",
  "geo" : {
  },
  "id_str" : "303767380184690688",
  "in_reply_to_user_id" : 29844377,
  "text" : "@yjkogan didn't work!",
  "id" : 303767380184690688,
  "in_reply_to_status_id" : 303767073354555392,
  "created_at" : "Tue Feb 19 07:26:01 +0000 2013",
  "in_reply_to_screen_name" : "yjkogan",
  "in_reply_to_user_id_str" : "29844377",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 19, 27 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/W9xjN5vS",
      "expanded_url" : "http://techcrunch.com/2013/02/18/hackers-turn-burger-kings-tweet-stream-into-a-whopper-of-a-mess/",
      "display_url" : "techcrunch.com/2013/02/18/hac\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303766757649297408",
  "text" : "Given how valuable @twitter accounts have become, I'm surprised by the lack of two-factor authentication. http://t.co/W9xjN5vS",
  "id" : 303766757649297408,
  "created_at" : "Tue Feb 19 07:23:33 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/LhZJtNYH",
      "expanded_url" : "http://betabeat.com/2013/02/drunk-naked-alphaboost-founder-matt-monahan-is-also-currently-trying-to-sell-his-company-jess-thomas-alphaboost-500-startups-geeks-on-a-plane/",
      "display_url" : "betabeat.com/2013/02/drunk-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303765388804644864",
  "text" : "Startups are becoming the new Wall Street in all the worst ways... http://t.co/LhZJtNYH",
  "id" : 303765388804644864,
  "created_at" : "Tue Feb 19 07:18:07 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 3, 9 ],
      "id_str" : "14208617",
      "id" : 14208617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "303698634782961665",
  "text" : "RT @robgo: Cool to see Oblong industries opening an office in Boston!",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "303698518462308352",
    "text" : "Cool to see Oblong industries opening an office in Boston!",
    "id" : 303698518462308352,
    "created_at" : "Tue Feb 19 02:52:23 +0000 2013",
    "user" : {
      "name" : "robgo",
      "screen_name" : "robgo",
      "protected" : false,
      "id_str" : "14208617",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3241642821/156e47ff84158bdcb7ddcdee8573c9f0_normal.jpeg",
      "id" : 14208617,
      "verified" : false
    }
  },
  "id" : 303698634782961665,
  "created_at" : "Tue Feb 19 02:52:51 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 46, 52 ],
      "id_str" : "183749519",
      "id" : 183749519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/eYIbLqnp",
      "expanded_url" : "http://news.ycombinator.com/item?id=5239673",
      "display_url" : "news.ycombinator.com/item?id=5239673"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303696060751151104",
  "text" : "\"Damn code abstractions, full steam ahead!\" - @paulg. http://t.co/eYIbLqnp",
  "id" : 303696060751151104,
  "created_at" : "Tue Feb 19 02:42:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 3, 7 ],
      "id_str" : "19494411",
      "id" : 19494411
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 28, 37 ],
      "id_str" : "5695632",
      "id" : 5695632
    }, {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 59, 63 ],
      "id_str" : "19494411",
      "id" : 19494411
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 81, 89 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/ySEtPHC0",
      "expanded_url" : "http://www.nytimes.com/2013/02/17/fashion/ben-smith-the-boy-wonder-of-buzzfeed.html?_r=0",
      "display_url" : "nytimes.com/2013/02/17/fas\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303264171531853824",
  "text" : "RT @RRE: \"The Boy Wonder of @BuzzFeed\" - great piece on an @RRE portfolio co. by @NYTimes. http://t.co/ySEtPHC0",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 19, 28 ],
        "id_str" : "5695632",
        "id" : 5695632
      }, {
        "name" : "RRE Ventures",
        "screen_name" : "RRE",
        "indices" : [ 50, 54 ],
        "id_str" : "19494411",
        "id" : 19494411
      }, {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 72, 80 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http://t.co/ySEtPHC0",
        "expanded_url" : "http://www.nytimes.com/2013/02/17/fashion/ben-smith-the-boy-wonder-of-buzzfeed.html?_r=0",
        "display_url" : "nytimes.com/2013/02/17/fas\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "303264111947575296",
    "text" : "\"The Boy Wonder of @BuzzFeed\" - great piece on an @RRE portfolio co. by @NYTimes. http://t.co/ySEtPHC0",
    "id" : 303264111947575296,
    "created_at" : "Sun Feb 17 22:06:13 +0000 2013",
    "user" : {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "protected" : false,
      "id_str" : "19494411",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2781036073/47c8a2806a89312e9882b4aa968aead4_normal.png",
      "id" : 19494411,
      "verified" : false
    }
  },
  "id" : 303264171531853824,
  "created_at" : "Sun Feb 17 22:06:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "303261072096374784",
  "text" : "Friend doing biz in China: \"a lot of communication is still done over IM with emoticons. It feels like middle school flirting.\"",
  "id" : 303261072096374784,
  "created_at" : "Sun Feb 17 21:54:08 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/303001860762136576/photo/1",
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/svKiaKiS",
      "media_url" : "http://pbs.twimg.com/media/BDR6lkWCcAAx_Zc.jpg",
      "id_str" : "303001860770525184",
      "id" : 303001860770525184,
      "media_url_https" : "https://pbs.twimg.com/media/BDR6lkWCcAAx_Zc.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      } ],
      "display_url" : "pic.twitter.com/svKiaKiS"
    } ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "saturdaynight",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.710402, -74.006412 ]
  },
  "id_str" : "303001860762136576",
  "text" : "NBD, just walking down the street compiling Julia. #yolo #saturdaynight http://t.co/svKiaKiS",
  "id" : 303001860762136576,
  "created_at" : "Sun Feb 17 04:44:07 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302812413374369792",
  "text" : "Explosions in Chelyabinsk? The news says meteors; I say Metal Gear.",
  "id" : 302812413374369792,
  "created_at" : "Sat Feb 16 16:11:19 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/302534105998958592/photo/1",
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/z6df9wjh",
      "media_url" : "http://pbs.twimg.com/media/BDLRKqECIAAAu07.jpg",
      "id_str" : "302534106007347200",
      "id" : 302534106007347200,
      "media_url_https" : "https://pbs.twimg.com/media/BDLRKqECIAAAu07.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      } ],
      "display_url" : "pic.twitter.com/z6df9wjh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302534105998958592",
  "text" : "This is terrible, terrible bathroom design. http://t.co/z6df9wjh",
  "id" : 302534105998958592,
  "created_at" : "Fri Feb 15 21:45:26 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302187414317842432",
  "text" : "Secondary brake should *always* be mechanical in case cars electronics fail. Re: Tesla S using electric parking brake.",
  "id" : 302187414317842432,
  "created_at" : "Thu Feb 14 22:47:48 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 58, 67 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/tH4lU6BC",
      "expanded_url" : "http://jalopnik.com/towing-company-the-nyt-tesla-model-s-was-dead-when-it-196100064",
      "display_url" : "jalopnik.com/towing-company\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "302183241257984001",
  "geo" : {
  },
  "id_str" : "302187055398653952",
  "in_reply_to_user_id" : 817386,
  "text" : "An *electric* parking brake is a terrible design choice! \u201C@Techmeme: NYT Tesla Model S Was Dead... http://t.co/tH4lU6BC\"",
  "id" : 302187055398653952,
  "in_reply_to_status_id" : 302183241257984001,
  "created_at" : "Thu Feb 14 22:46:23 +0000 2013",
  "in_reply_to_screen_name" : "Techmeme",
  "in_reply_to_user_id_str" : "817386",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302087707524468736",
  "text" : "RT @hseas: Dung Ba Nguyen '83, now a radiation oncologist, teaches engineering to neighborhood kids. He also teaches them to dream http: ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/W85sYApO",
        "expanded_url" : "http://hvrd.me/ZaCSki",
        "display_url" : "hvrd.me/ZaCSki"
      } ]
    },
    "geo" : {
    },
    "id_str" : "302085272206716928",
    "text" : "Dung Ba Nguyen '83, now a radiation oncologist, teaches engineering to neighborhood kids. He also teaches them to dream http://t.co/W85sYApO",
    "id" : 302085272206716928,
    "created_at" : "Thu Feb 14 16:01:56 +0000 2013",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 302087707524468736,
  "created_at" : "Thu Feb 14 16:11:36 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krzysztof Gajos",
      "screen_name" : "kgajos",
      "indices" : [ 1, 8 ],
      "id_str" : "21803567",
      "id" : 21803567
    }, {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 44, 50 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engineering",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/zy2tnPfO",
      "expanded_url" : "http://hvrd.me/12LXxMu",
      "display_url" : "hvrd.me/12LXxMu"
    } ]
  },
  "in_reply_to_status_id_str" : "301906336516558849",
  "geo" : {
  },
  "id_str" : "301923731419312128",
  "in_reply_to_user_id" : 236921052,
  "text" : ".@kgajos' design class was my fav at SEAS. \"@hseas: RIP J. Karlin... who put human factors in #engineering. http://t.co/zy2tnPfO\u201D",
  "id" : 301923731419312128,
  "in_reply_to_status_id" : 301906336516558849,
  "created_at" : "Thu Feb 14 05:20:01 +0000 2013",
  "in_reply_to_screen_name" : "hseas",
  "in_reply_to_user_id_str" : "236921052",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 0, 7 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301915189866008576",
  "geo" : {
  },
  "id_str" : "301921419229536256",
  "in_reply_to_user_id" : 15137329,
  "text" : "@jdrive I'm so sorry for your loss Jim...",
  "id" : 301921419229536256,
  "in_reply_to_status_id" : 301915189866008576,
  "created_at" : "Thu Feb 14 05:10:50 +0000 2013",
  "in_reply_to_screen_name" : "jdrive",
  "in_reply_to_user_id_str" : "15137329",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 3, 13 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "Plympton",
      "screen_name" : "plympton",
      "indices" : [ 19, 28 ],
      "id_str" : "316727597",
      "id" : 316727597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301920992865959936",
  "text" : "RT @jenny8lee: How @plympton got early programming done. Bartering w MIT student in exchange for helping on OKCupid profile. http://t.co ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Plympton",
        "screen_name" : "plympton",
        "indices" : [ 4, 13 ],
        "id_str" : "316727597",
        "id" : 316727597
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/ayfX9kJj",
        "expanded_url" : "http://bit.ly/12fRdNj",
        "display_url" : "bit.ly/12fRdNj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "301918936755232768",
    "text" : "How @plympton got early programming done. Bartering w MIT student in exchange for helping on OKCupid profile. http://t.co/ayfX9kJj",
    "id" : 301918936755232768,
    "created_at" : "Thu Feb 14 05:00:58 +0000 2013",
    "user" : {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "protected" : false,
      "id_str" : "1976841",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1842465869/jenny_baby_graduation_cap_cropped_normal.jpg",
      "id" : 1976841,
      "verified" : true
    }
  },
  "id" : 301920992865959936,
  "created_at" : "Thu Feb 14 05:09:08 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Contreras",
      "screen_name" : "DanaDanger",
      "indices" : [ 23, 34 ],
      "id_str" : "821958",
      "id" : 821958
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/DanaDanger/status/301841175659286528/photo/1",
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/c9UKyy5K",
      "media_url" : "http://pbs.twimg.com/media/BDBa8zZCEAE0USL.png",
      "id_str" : "301841175667675137",
      "id" : 301841175667675137,
      "media_url_https" : "https://pbs.twimg.com/media/BDBa8zZCEAE0USL.png",
      "sizes" : [ {
        "h" : 366,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 558
      } ],
      "display_url" : "pic.twitter.com/c9UKyy5K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301841175659286528",
  "geo" : {
  },
  "id_str" : "301849428350881793",
  "in_reply_to_user_id" : 821958,
  "text" : "Why PMs are valuable! \u201C@DanaDanger: A day in the life of an engineer who has meetings: http://t.co/c9UKyy5K\u201D",
  "id" : 301849428350881793,
  "in_reply_to_status_id" : 301841175659286528,
  "created_at" : "Thu Feb 14 00:24:46 +0000 2013",
  "in_reply_to_screen_name" : "DanaDanger",
  "in_reply_to_user_id_str" : "821958",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301845473755545601",
  "text" : "Asking if design or engineering is more important in a product is like asking if axles or wheels are more important in a car...",
  "id" : 301845473755545601,
  "created_at" : "Thu Feb 14 00:09:03 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ribbon",
      "screen_name" : "ribbon",
      "indices" : [ 7, 14 ],
      "id_str" : "179352121",
      "id" : 179352121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/dSizzDIk",
      "expanded_url" : "http://rbn.co/a25c85",
      "display_url" : "rbn.co/a25c85"
    } ]
  },
  "geo" : {
  },
  "id_str" : "301820383219294209",
  "text" : "Giving @Ribbon a try! I'm selling a brand new Verizon Droid Charge. http://t.co/dSizzDIk",
  "id" : 301820383219294209,
  "created_at" : "Wed Feb 13 22:29:21 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/301758300280733696/photo/1",
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/ysp6Bc8n",
      "media_url" : "http://pbs.twimg.com/media/BDAPk0jCQAA7BVI.jpg",
      "id_str" : "301758300289122304",
      "id" : 301758300289122304,
      "media_url_https" : "https://pbs.twimg.com/media/BDAPk0jCQAA7BVI.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 395
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 131
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 231
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 395
      } ],
      "display_url" : "pic.twitter.com/ysp6Bc8n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301758300280733696",
  "text" : "Why isn't the USB plug circularly symmetric? Why does it have to be a rectangle? http://t.co/ysp6Bc8n",
  "id" : 301758300280733696,
  "created_at" : "Wed Feb 13 18:22:40 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ribbon",
      "screen_name" : "ribbon",
      "indices" : [ 0, 7 ],
      "id_str" : "179352121",
      "id" : 179352121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301429132263301120",
  "in_reply_to_user_id" : 179352121,
  "text" : "@ribbon if I make an account with Twitter, I can't set my password in my account settings!",
  "id" : 301429132263301120,
  "created_at" : "Tue Feb 12 20:34:40 +0000 2013",
  "in_reply_to_screen_name" : "ribbon",
  "in_reply_to_user_id_str" : "179352121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsMoreExpensiveThanNKoreaNuclearTest",
      "indices" : [ 23, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301331325330264067",
  "text" : "Super Bowl commercial. #ThingsMoreExpensiveThanNKoreaNuclearTest",
  "id" : 301331325330264067,
  "created_at" : "Tue Feb 12 14:06:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsMoreExpensiveThanNKoreaNuclearTest",
      "indices" : [ 11, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301330571056013312",
  "text" : "Instagram. #ThingsMoreExpensiveThanNKoreaNuclearTest",
  "id" : 301330571056013312,
  "created_at" : "Tue Feb 12 14:03:01 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301329905956831233",
  "text" : "RT @parislemon: Few things compare to the Top Gun volleyball scene in 3D IMAX. Actually, nothing compares.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "301210743506870272",
    "text" : "Few things compare to the Top Gun volleyball scene in 3D IMAX. Actually, nothing compares.",
    "id" : 301210743506870272,
    "created_at" : "Tue Feb 12 06:06:52 +0000 2013",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3336694463/99718483afb19d6d441290afccb72772_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 301329905956831233,
  "created_at" : "Tue Feb 12 14:00:22 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 51, 67 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/tH42tJaE",
      "expanded_url" : "http://j.mp/14PdX5q",
      "display_url" : "j.mp/14PdX5q"
    } ]
  },
  "in_reply_to_status_id_str" : "301255586547376128",
  "geo" : {
  },
  "id_str" : "301327977738825728",
  "in_reply_to_user_id" : 14335498,
  "text" : "Dominoes had always been surprisingly tech savvy. \u201C@newsycombinator: Bitcoins can now be used to pay for Dominos http://t.co/tH42tJaE\u201D",
  "id" : 301327977738825728,
  "in_reply_to_status_id" : 301255586547376128,
  "created_at" : "Tue Feb 12 13:52:42 +0000 2013",
  "in_reply_to_screen_name" : "newsycombinator",
  "in_reply_to_user_id_str" : "14335498",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HN from Y Combinator",
      "screen_name" : "hnycombinator",
      "indices" : [ 67, 81 ],
      "id_str" : "15042473",
      "id" : 15042473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/Wn3j5Oa3",
      "expanded_url" : "http://goo.gl/fb/TM6Jj",
      "display_url" : "goo.gl/fb/TM6Jj"
    } ]
  },
  "in_reply_to_status_id_str" : "301299853517004800",
  "geo" : {
  },
  "id_str" : "301327199741566976",
  "in_reply_to_user_id" : 15042473,
  "text" : "Completely agree. Never lose the sense of wonder about the world. \u201C@hnycombinator: Think Like a 5-Year Old http://t.co/Wn3j5Oa3\u201D",
  "id" : 301327199741566976,
  "in_reply_to_status_id" : 301299853517004800,
  "created_at" : "Tue Feb 12 13:49:37 +0000 2013",
  "in_reply_to_screen_name" : "hnycombinator",
  "in_reply_to_user_id_str" : "15042473",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Loukides",
      "screen_name" : "mikeloukides",
      "indices" : [ 3, 16 ],
      "id_str" : "12984202",
      "id" : 12984202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301326474496057344",
  "text" : "RT @mikeloukides: This is prophetic: Punch cartoon from 1906: couple engrossed in their wireless devices, ignoring each other. http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.flipboard.com\" rel=\"nofollow\">Flipboard</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/xRipcemW",
        "expanded_url" : "http://flip.it/mBAzl",
        "display_url" : "flip.it/mBAzl"
      } ]
    },
    "geo" : {
    },
    "id_str" : "301302910728409089",
    "text" : "This is prophetic: Punch cartoon from 1906: couple engrossed in their wireless devices, ignoring each other. http://t.co/xRipcemW",
    "id" : 301302910728409089,
    "created_at" : "Tue Feb 12 12:13:06 +0000 2013",
    "user" : {
      "name" : "Mike Loukides",
      "screen_name" : "mikeloukides",
      "protected" : false,
      "id_str" : "12984202",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/422107375/CIMG0917_normal.jpg",
      "id" : 12984202,
      "verified" : false
    }
  },
  "id" : 301326474496057344,
  "created_at" : "Tue Feb 12 13:46:44 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 30, 36 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301187293878812672",
  "geo" : {
  },
  "id_str" : "301188143732908032",
  "in_reply_to_user_id" : 3840,
  "text" : "Cheaper than some Series As. \u201C@Jason: NK just tested a nuke... thanks to our allies in Pakistan for getting them up to speed for only $3m.\u201D",
  "id" : 301188143732908032,
  "in_reply_to_status_id" : 301187293878812672,
  "created_at" : "Tue Feb 12 04:37:03 +0000 2013",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/dfDJqANF",
      "expanded_url" : "http://t.imehop.com/Wgnm28",
      "display_url" : "t.imehop.com/Wgnm28"
    } ]
  },
  "geo" : {
  },
  "id_str" : "301183457139240960",
  "text" : "This is funnier without the context, which I forgot. http://t.co/dfDJqANF",
  "id" : 301183457139240960,
  "created_at" : "Tue Feb 12 04:18:26 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConfirmAmexGiftCard25",
      "indices" : [ 56, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301177392423108609",
  "text" : "Free monies from Amex with the new Twitter integration! #ConfirmAmexGiftCard25",
  "id" : 301177392423108609,
  "created_at" : "Tue Feb 12 03:54:20 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Express",
      "screen_name" : "AmericanExpress",
      "indices" : [ 8, 24 ],
      "id_str" : "42712551",
      "id" : 42712551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuyAmexGiftCard25",
      "indices" : [ 83, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301104011849912321",
  "geo" : {
  },
  "id_str" : "301176058890289154",
  "in_reply_to_user_id" : 42712551,
  "text" : "Sweet. \u201C@AmericanExpress: Get $25 Amex Gift Card for $15 w/synced Amex Card. Tweet #BuyAmexGiftCard25 to start purchase!\"",
  "id" : 301176058890289154,
  "in_reply_to_status_id" : 301104011849912321,
  "created_at" : "Tue Feb 12 03:49:02 +0000 2013",
  "in_reply_to_screen_name" : "AmericanExpress",
  "in_reply_to_user_id_str" : "42712551",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept. of Irony",
      "screen_name" : "IronyDept",
      "indices" : [ 3, 13 ],
      "id_str" : "562401327",
      "id" : 562401327
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pope",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301098103195447296",
  "text" : "RT @IronyDept: With a new #Pope, the Catholic Church has the opportunity to move its thinking and teaching into the 17th century.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Pope",
        "indices" : [ 11, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "301055326327808000",
    "text" : "With a new #Pope, the Catholic Church has the opportunity to move its thinking and teaching into the 17th century.",
    "id" : 301055326327808000,
    "created_at" : "Mon Feb 11 19:49:17 +0000 2013",
    "user" : {
      "name" : "US Dept. of Irony",
      "screen_name" : "IronyDept",
      "protected" : false,
      "id_str" : "562401327",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2695752020/d6fb44b4d393a579105b88b49c0ba82f_normal.png",
      "id" : 562401327,
      "verified" : false
    }
  },
  "id" : 301098103195447296,
  "created_at" : "Mon Feb 11 22:39:16 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 55, 64 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OccupyLinkedIn",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/V0xfsK8y",
      "expanded_url" : "http://www.linkedin.com/pub/profile/10/553/b35?trk=200tw",
      "display_url" : "linkedin.com/pub/profile/10\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "301010156794281984",
  "text" : "#OccupyLinkedIn! \"I have one of the top 1% most viewed @LinkedIn profiles for 2012. http://t.co/V0xfsK8y\"",
  "id" : 301010156794281984,
  "created_at" : "Mon Feb 11 16:49:48 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300791891216195584",
  "text" : "Things you didn't expect you'd learn as a hardware startup: major Chinese holidays.",
  "id" : 300791891216195584,
  "created_at" : "Mon Feb 11 02:22:29 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToyFairNY",
      "screen_name" : "ToyFairNY",
      "indices" : [ 18, 28 ],
      "id_str" : "80911728",
      "id" : 80911728
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/300743211322863616/photo/1",
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/B7V0zt8L",
      "media_url" : "http://pbs.twimg.com/media/BCx0W3fCcAAoOL4.jpg",
      "id_str" : "300743211327057920",
      "id" : 300743211327057920,
      "media_url_https" : "https://pbs.twimg.com/media/BCx0W3fCcAAoOL4.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/B7V0zt8L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300743211322863616",
  "text" : "Demo day tools at @ToyFairNY. http://t.co/B7V0zt8L",
  "id" : 300743211322863616,
  "created_at" : "Sun Feb 10 23:09:03 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/300724144285286400/photo/1",
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/v3rJjyTh",
      "media_url" : "http://pbs.twimg.com/media/BCxjBBPCAAAm4F0.jpg",
      "id_str" : "300724144289480704",
      "id" : 300724144289480704,
      "media_url_https" : "https://pbs.twimg.com/media/BCxjBBPCAAAm4F0.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/v3rJjyTh"
    } ],
    "hashtags" : [ {
      "text" : "toyfair",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300724144285286400",
  "text" : "I need this, but full size. #toyfair http://t.co/v3rJjyTh",
  "id" : 300724144285286400,
  "created_at" : "Sun Feb 10 21:53:18 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 14, 23 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/300710056163409920/photo/1",
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/h9iOJQbS",
      "media_url" : "http://pbs.twimg.com/media/BCxWM-6CAAEU7jC.jpg",
      "id_str" : "300710056171798529",
      "id" : 300710056171798529,
      "media_url_https" : "https://pbs.twimg.com/media/BCxWM-6CAAEU7jC.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/h9iOJQbS"
    } ],
    "hashtags" : [ {
      "text" : "ToyFair",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.757973, -74.000532 ]
  },
  "id_str" : "300710056163409920",
  "text" : "People loving @Romotive at #ToyFair! http://t.co/h9iOJQbS",
  "id" : 300710056163409920,
  "created_at" : "Sun Feb 10 20:57:19 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 23, 28 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300451305527316480",
  "text" : "Highlight of my night: @uber driver kept pronouncing my name \"Kanye.\"",
  "id" : 300451305527316480,
  "created_at" : "Sun Feb 10 03:49:08 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 0, 7 ],
      "id_str" : "9544202",
      "id" : 9544202
    }, {
      "name" : "maxstoller",
      "screen_name" : "maxstoller",
      "indices" : [ 8, 19 ],
      "id_str" : "15337726",
      "id" : 15337726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300048236905897984",
  "geo" : {
  },
  "id_str" : "300107371089367040",
  "in_reply_to_user_id" : 9544202,
  "text" : "@schlaf @maxstoller let me know if you guys need beta testers for that idea.",
  "id" : 300107371089367040,
  "in_reply_to_status_id" : 300048236905897984,
  "created_at" : "Sat Feb 09 05:02:27 +0000 2013",
  "in_reply_to_screen_name" : "schlaf",
  "in_reply_to_user_id_str" : "9544202",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/300027080505180161/photo/1",
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/v6euQvQ8",
      "media_url" : "http://pbs.twimg.com/media/BCnpCkUCQAAOUsY.jpg",
      "id_str" : "300027080513568768",
      "id" : 300027080513568768,
      "media_url_https" : "https://pbs.twimg.com/media/BCnpCkUCQAAOUsY.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com/v6euQvQ8"
    } ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300027080505180161",
  "text" : "Yo NYC I'm really happy for you, imma let you finish, but #Buffalo has the best blizzards. http://t.co/v6euQvQ8",
  "id" : 300027080505180161,
  "created_at" : "Fri Feb 08 23:43:25 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://plancast.com\" rel=\"nofollow\">Plancast</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/nZp9zRaQ",
      "expanded_url" : "http://planca.st/i1N7",
      "display_url" : "planca.st/i1N7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "299980744640577537",
  "text" : "I've made plans for TechCrunch NYC Meetup http://t.co/nZp9zRaQ",
  "id" : 299980744640577537,
  "created_at" : "Fri Feb 08 20:39:17 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM",
      "screen_name" : "IBM",
      "indices" : [ 44, 48 ],
      "id_str" : "18994444",
      "id" : 18994444
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/299890425819459584/photo/1",
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/4d3R1ug8",
      "media_url" : "http://pbs.twimg.com/media/BClswN8CcAIcDGN.jpg",
      "id_str" : "299890425827848194",
      "id" : 299890425827848194,
      "media_url_https" : "https://pbs.twimg.com/media/BClswN8CcAIcDGN.jpg",
      "sizes" : [ {
        "h" : 769,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 769,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/4d3R1ug8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "299890425819459584",
  "text" : "Excited to see Memorial Sloan-Kettering and @IBM partnering to unleash Waston on the menace of cancer! http://t.co/4d3R1ug8",
  "id" : 299890425819459584,
  "created_at" : "Fri Feb 08 14:40:24 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299715057816834048",
  "geo" : {
  },
  "id_str" : "299716861724090368",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce oops fixed!",
  "id" : 299716861724090368,
  "in_reply_to_status_id" : 299715057816834048,
  "created_at" : "Fri Feb 08 03:10:42 +0000 2013",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GQ Fashion",
      "screen_name" : "GQFashion",
      "indices" : [ 58, 68 ],
      "id_str" : "102446093",
      "id" : 102446093
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/299716294071156736/photo/1",
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/uO2dXQvq",
      "media_url" : "http://pbs.twimg.com/media/BCjOYaoCAAAVX_5.jpg",
      "id_str" : "299716294079545344",
      "id" : 299716294079545344,
      "media_url_https" : "https://pbs.twimg.com/media/BCjOYaoCAAAVX_5.jpg",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com/uO2dXQvq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "299716294071156736",
  "text" : "The Fairchild Semiconductor team in the 70s looked like a @GQFashion photoshoot. Daaaang. http://t.co/uO2dXQvq",
  "id" : 299716294071156736,
  "created_at" : "Fri Feb 08 03:08:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/299635418163445760/photo/1",
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/54aiyydx",
      "media_url" : "http://pbs.twimg.com/media/BCiE00YCAAEqb5R.jpg",
      "id_str" : "299635418167640065",
      "id" : 299635418167640065,
      "media_url_https" : "https://pbs.twimg.com/media/BCiE00YCAAEqb5R.jpg",
      "sizes" : [ {
        "h" : 452,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 854
      } ],
      "display_url" : "pic.twitter.com/54aiyydx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "299635418163445760",
  "text" : "This is *probably* two computers too many. http://t.co/54aiyydx",
  "id" : 299635418163445760,
  "created_at" : "Thu Feb 07 21:47:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "299632841921265664",
  "text" : "Being in the sys admins office with 7 phones around when the weather warning came through was like an air raid siren.",
  "id" : 299632841921265664,
  "created_at" : "Thu Feb 07 21:36:51 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    }, {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 23, 31 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lesserfilms",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299556925631254529",
  "geo" : {
  },
  "id_str" : "299563464857362432",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil The Land Before @Timehop. #lesserfilms",
  "id" : 299563464857362432,
  "in_reply_to_status_id" : 299556925631254529,
  "created_at" : "Thu Feb 07 17:01:10 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lesserfilms",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299556925631254529",
  "geo" : {
  },
  "id_str" : "299563160220889088",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil Tuck Evernote. #lesserfilms",
  "id" : 299563160220889088,
  "in_reply_to_status_id" : 299556925631254529,
  "created_at" : "Thu Feb 07 16:59:57 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lesserfilms",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299556925631254529",
  "geo" : {
  },
  "id_str" : "299562962295873537",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil Facebook Off. #lesserfilms",
  "id" : 299562962295873537,
  "in_reply_to_status_id" : 299556925631254529,
  "created_at" : "Thu Feb 07 16:59:10 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Chou",
      "screen_name" : "markdchou",
      "indices" : [ 3, 13 ],
      "id_str" : "67686145",
      "id" : 67686145
    }, {
      "name" : "VentureBeat",
      "screen_name" : "VentureBeat",
      "indices" : [ 106, 118 ],
      "id_str" : "60642052",
      "id" : 60642052
    }, {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 123, 130 ],
      "id_str" : "15137329",
      "id" : 15137329
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 131, 138 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/TxUp49RE",
      "expanded_url" : "http://venturebeat.com/2013/02/07/richard-iii-3d-printing/#KlAO3RiOobM8DOXL.02",
      "display_url" : "venturebeat.com/2013/02/07/ric\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "299562588621135872",
  "text" : "RT @markdchou: Ha! \"Researchers revive King Richard III\u2019s face with 3D printing\" http://t.co/TxUp49RE via @VentureBeat cc: @jdrive @khsieh",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VentureBeat",
        "screen_name" : "VentureBeat",
        "indices" : [ 91, 103 ],
        "id_str" : "60642052",
        "id" : 60642052
      }, {
        "name" : "@jdrive",
        "screen_name" : "jdrive",
        "indices" : [ 108, 115 ],
        "id_str" : "15137329",
        "id" : 15137329
      }, {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 116, 123 ],
        "id_str" : "111999960",
        "id" : 111999960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http://t.co/TxUp49RE",
        "expanded_url" : "http://venturebeat.com/2013/02/07/richard-iii-3d-printing/#KlAO3RiOobM8DOXL.02",
        "display_url" : "venturebeat.com/2013/02/07/ric\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "299559893503971328",
    "text" : "Ha! \"Researchers revive King Richard III\u2019s face with 3D printing\" http://t.co/TxUp49RE via @VentureBeat cc: @jdrive @khsieh",
    "id" : 299559893503971328,
    "created_at" : "Thu Feb 07 16:46:58 +0000 2013",
    "user" : {
      "name" : "Mark Chou",
      "screen_name" : "markdchou",
      "protected" : false,
      "id_str" : "67686145",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1774751274/image1327295547_normal.png",
      "id" : 67686145,
      "verified" : false
    }
  },
  "id" : 299562588621135872,
  "created_at" : "Thu Feb 07 16:57:41 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "History Vines",
      "screen_name" : "HistoryVines",
      "indices" : [ 3, 16 ],
      "id_str" : "1155502964",
      "id" : 1155502964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/LKgNBbyz",
      "expanded_url" : "http://vine.co/v/bngr7EniIeT",
      "display_url" : "vine.co/v/bngr7EniIeT"
    } ]
  },
  "geo" : {
  },
  "id_str" : "299311533933092865",
  "text" : "RT @HistoryVines: 07/20/1969 http://t.co/LKgNBbyz",
  "retweeted_status" : {
    "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http://t.co/LKgNBbyz",
        "expanded_url" : "http://vine.co/v/bngr7EniIeT",
        "display_url" : "vine.co/v/bngr7EniIeT"
      } ]
    },
    "geo" : {
    },
    "id_str" : "299311422784040961",
    "text" : "07/20/1969 http://t.co/LKgNBbyz",
    "id" : 299311422784040961,
    "created_at" : "Thu Feb 07 00:19:38 +0000 2013",
    "user" : {
      "name" : "History Vines",
      "screen_name" : "HistoryVines",
      "protected" : false,
      "id_str" : "1155502964",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3218120526/11b4f7b2eb8d043445ea2b20f5b2a9c6_normal.jpeg",
      "id" : 1155502964,
      "verified" : false
    }
  },
  "id" : 299311533933092865,
  "created_at" : "Thu Feb 07 00:20:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 0, 15 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299294868340084736",
  "geo" : {
  },
  "id_str" : "299300236365557761",
  "in_reply_to_user_id" : 18107808,
  "text" : "@NaveenSrivatsa we've successfully outsourced our brains to our smartphones.",
  "id" : 299300236365557761,
  "in_reply_to_status_id" : 299294868340084736,
  "created_at" : "Wed Feb 06 23:35:11 +0000 2013",
  "in_reply_to_screen_name" : "NaveenSrivatsa",
  "in_reply_to_user_id_str" : "18107808",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Business",
      "screen_name" : "nytimesbusiness",
      "indices" : [ 48, 64 ],
      "id_str" : "1754641",
      "id" : 1754641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/g9GWNoRp",
      "expanded_url" : "http://nyti.ms/WzktJu",
      "display_url" : "nyti.ms/WzktJu"
    } ]
  },
  "in_reply_to_status_id_str" : "299289864069869568",
  "geo" : {
  },
  "id_str" : "299300019016704000",
  "in_reply_to_user_id" : 1754641,
  "text" : "Isn't that the same as \"not necessarily safe?\" \u201C@nytimesbusiness: Lithium Batteries Are Not Necessarily Unsafe http://t.co/g9GWNoRp\u201D",
  "id" : 299300019016704000,
  "in_reply_to_status_id" : 299289864069869568,
  "created_at" : "Wed Feb 06 23:34:19 +0000 2013",
  "in_reply_to_screen_name" : "nytimesbusiness",
  "in_reply_to_user_id_str" : "1754641",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 9, 16 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299231787639513088",
  "geo" : {
  },
  "id_str" : "299232405359824897",
  "in_reply_to_user_id" : 111999960,
  "text" : "@kshsieh @etaooo Bryan Cranston would be a PERFECT Gordon Freeman.",
  "id" : 299232405359824897,
  "in_reply_to_status_id" : 299231787639513088,
  "created_at" : "Wed Feb 06 19:05:39 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Tao",
      "screen_name" : "etaooo",
      "indices" : [ 9, 16 ],
      "id_str" : "204789792",
      "id" : 204789792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "asianproblems",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299226019838189568",
  "geo" : {
  },
  "id_str" : "299231743670616065",
  "in_reply_to_user_id" : 111999960,
  "text" : "@kshsieh @etaooo #asianproblems",
  "id" : 299231743670616065,
  "in_reply_to_status_id" : 299226019838189568,
  "created_at" : "Wed Feb 06 19:03:01 +0000 2013",
  "in_reply_to_screen_name" : "khsieh",
  "in_reply_to_user_id_str" : "111999960",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "indices" : [ 3, 7 ],
      "id_str" : "19494411",
      "id" : 19494411
    }, {
      "name" : "MakerBot",
      "screen_name" : "makerbot",
      "indices" : [ 10, 19 ],
      "id_str" : "22021097",
      "id" : 22021097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/jwgY3vMo",
      "expanded_url" : "http://techcrunch.com/2013/02/04/two-global-makers-come-together-to-make-a-robotic-han-for-a-boy-in-south-africa/",
      "display_url" : "techcrunch.com/2013/02/04/two\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "299008939012521985",
  "text" : "RT @RRE: .@MakerBot helped make a prosthetic hand. Great use of 3D printing or greatest use of 3D printing? http://t.co/jwgY3vMo",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MakerBot",
        "screen_name" : "makerbot",
        "indices" : [ 1, 10 ],
        "id_str" : "22021097",
        "id" : 22021097
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http://t.co/jwgY3vMo",
        "expanded_url" : "http://techcrunch.com/2013/02/04/two-global-makers-come-together-to-make-a-robotic-han-for-a-boy-in-south-africa/",
        "display_url" : "techcrunch.com/2013/02/04/two\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "299008691062059008",
    "text" : ".@MakerBot helped make a prosthetic hand. Great use of 3D printing or greatest use of 3D printing? http://t.co/jwgY3vMo",
    "id" : 299008691062059008,
    "created_at" : "Wed Feb 06 04:16:41 +0000 2013",
    "user" : {
      "name" : "RRE Ventures",
      "screen_name" : "RRE",
      "protected" : false,
      "id_str" : "19494411",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2781036073/47c8a2806a89312e9882b4aa968aead4_normal.png",
      "id" : 19494411,
      "verified" : false
    }
  },
  "id" : 299008939012521985,
  "created_at" : "Wed Feb 06 04:17:41 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298982870838558720",
  "text" : "Startups have it easy now. \"We didn't have bathrooms. We used the gas station down the street.\" - the founding of Fairchild Semiconductor.",
  "id" : 298982870838558720,
  "created_at" : "Wed Feb 06 02:34:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 43, 47 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/298975815469780992/photo/1",
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/wepmF9zt",
      "media_url" : "http://pbs.twimg.com/media/BCYs644CUAAUaFd.jpg",
      "id_str" : "298975815478169600",
      "id" : 298975815478169600,
      "media_url_https" : "https://pbs.twimg.com/media/BCYs644CUAAUaFd.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com/wepmF9zt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298975815469780992",
  "text" : "Watching the Silicon Valley documentary on @PBS! http://t.co/wepmF9zt",
  "id" : 298975815469780992,
  "created_at" : "Wed Feb 06 02:06:03 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 13, 22 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TFNY",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298964203564314624",
  "text" : "Can't wait! \u201C@Romotive: packing up 16+ robots to head to #TFNY! It's our first Toy Fair and Romo's first trip to the Big Apple :)\u201D",
  "id" : 298964203564314624,
  "created_at" : "Wed Feb 06 01:19:55 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Valve",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/5VRiUSb1",
      "expanded_url" : "http://www.polygon.com/2013/2/1/3941274/gabe-newell-steam-box-talk-ut",
      "display_url" : "polygon.com/2013/2/1/39412\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "298921535727603712",
  "text" : "\"Pre-internet thinking in terms of direct communication with consumers is harmful.\" - GabeN+#Valve dropping knowledge. http://t.co/5VRiUSb1",
  "id" : 298921535727603712,
  "created_at" : "Tue Feb 05 22:30:22 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/zxztltxT",
      "expanded_url" : "http://open.spotify.com/album/0GJJrpQhiIY33JJeSSnKnK",
      "display_url" : "open.spotify.com/album/0GJJrpQh\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "298807570343268352",
  "text" : "Working to the new Shanghai Restoration Project album today. http://t.co/zxztltxT",
  "id" : 298807570343268352,
  "created_at" : "Tue Feb 05 14:57:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinicius Vacanti",
      "screen_name" : "vacanti",
      "indices" : [ 0, 8 ],
      "id_str" : "14424445",
      "id" : 14424445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298793018281037824",
  "geo" : {
  },
  "id_str" : "298805113420664832",
  "in_reply_to_user_id" : 14424445,
  "text" : "@vacanti I think \"features\" is a better term here than \"functionality.\" Additional functionality is emergent from reduced features.",
  "id" : 298805113420664832,
  "in_reply_to_status_id" : 298793018281037824,
  "created_at" : "Tue Feb 05 14:47:45 +0000 2013",
  "in_reply_to_screen_name" : "vacanti",
  "in_reply_to_user_id_str" : "14424445",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Liang",
      "screen_name" : "daveliang",
      "indices" : [ 0, 10 ],
      "id_str" : "20615976",
      "id" : 20615976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298446951853211649",
  "geo" : {
  },
  "id_str" : "298459890538651648",
  "in_reply_to_user_id" : 20615976,
  "text" : "@daveliang cannot wait for the new album!",
  "id" : 298459890538651648,
  "in_reply_to_status_id" : 298446951853211649,
  "created_at" : "Mon Feb 04 15:55:57 +0000 2013",
  "in_reply_to_screen_name" : "daveliang",
  "in_reply_to_user_id_str" : "20615976",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 3, 14 ],
      "id_str" : "2384071",
      "id" : 2384071
    }, {
      "name" : "Nat Torkington",
      "screen_name" : "gnat",
      "indices" : [ 26, 31 ],
      "id_str" : "898691",
      "id" : 898691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298459192782622720",
  "text" : "RT @timoreilly: Irony. RT @gnat: Greater chance of 3D-printed guns (deaths from: 0) being banned than real guns (deaths from: &gt;0) htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nat Torkington",
        "screen_name" : "gnat",
        "indices" : [ 10, 15 ],
        "id_str" : "898691",
        "id" : 898691
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/TeiEntIe",
        "expanded_url" : "http://techcrunch.com/2013/01/18/like-it-or-not-i-think-3d-printing-is-about-to-get-legislated/",
        "display_url" : "techcrunch.com/2013/01/18/lik\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "298449341641805824",
    "text" : "Irony. RT @gnat: Greater chance of 3D-printed guns (deaths from: 0) being banned than real guns (deaths from: &gt;0) http://t.co/TeiEntIe",
    "id" : 298449341641805824,
    "created_at" : "Mon Feb 04 15:14:02 +0000 2013",
    "user" : {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "protected" : false,
      "id_str" : "2384071",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2823681988/f4f6f2bed8ab4d5a48dea4b9ea85d5f1_normal.jpeg",
      "id" : 2384071,
      "verified" : true
    }
  },
  "id" : 298459192782622720,
  "created_at" : "Mon Feb 04 15:53:11 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amol Sarva",
      "screen_name" : "_amol",
      "indices" : [ 3, 9 ],
      "id_str" : "76946830",
      "id" : 76946830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298281225435627520",
  "text" : "RT @_amol: The Wire beats Wired",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "298276246796763136",
    "text" : "The Wire beats Wired",
    "id" : 298276246796763136,
    "created_at" : "Mon Feb 04 03:46:13 +0000 2013",
    "user" : {
      "name" : "Amol Sarva",
      "screen_name" : "amol",
      "protected" : false,
      "id_str" : "91283",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1554680412/00Amol_NYPost_thumb1000_normal.jpg",
      "id" : 91283,
      "verified" : false
    }
  },
  "id" : 298281225435627520,
  "created_at" : "Mon Feb 04 04:06:00 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298244825675857920",
  "text" : "Expecting Bane any second now.",
  "id" : 298244825675857920,
  "created_at" : "Mon Feb 04 01:41:22 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298238806971277314",
  "text" : "Being the lighting designer for this half time show must have been BOSS.",
  "id" : 298238806971277314,
  "created_at" : "Mon Feb 04 01:17:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drunk Nate Silver",
      "screen_name" : "drunknatesilver",
      "indices" : [ 7, 23 ],
      "id_str" : "868245612",
      "id" : 868245612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298190026561421313",
  "text" : "Dream: @drunknatesilver doing predictive commentary on the Puppy Bowl.",
  "id" : 298190026561421313,
  "created_at" : "Sun Feb 03 22:03:37 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 8, 13 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297882869706141696",
  "text" : "The new @Uber app *devours* iPhone batteries.",
  "id" : 297882869706141696,
  "created_at" : "Sun Feb 03 01:43:05 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297507098449813504",
  "geo" : {
  },
  "id_str" : "297529415787757570",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick cash or stock?",
  "id" : 297529415787757570,
  "in_reply_to_status_id" : 297507098449813504,
  "created_at" : "Sat Feb 02 02:18:35 +0000 2013",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Gore",
      "screen_name" : "algore",
      "indices" : [ 1, 8 ],
      "id_str" : "17220934",
      "id" : 17220934
    }, {
      "name" : "Zach Klein",
      "screen_name" : "zachklein",
      "indices" : [ 9, 19 ],
      "id_str" : "11969",
      "id" : 11969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297472195372929024",
  "geo" : {
  },
  "id_str" : "297505362158968834",
  "in_reply_to_user_id" : 17220934,
  "text" : ".@algore @zachklein a more interesting stat would be % of new USAF pilots that fly UAVs versus manned aircraft.",
  "id" : 297505362158968834,
  "in_reply_to_status_id" : 297472195372929024,
  "created_at" : "Sat Feb 02 00:43:00 +0000 2013",
  "in_reply_to_screen_name" : "algore",
  "in_reply_to_user_id_str" : "17220934",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Gore",
      "screen_name" : "algore",
      "indices" : [ 37, 44 ],
      "id_str" : "17220934",
      "id" : 17220934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297505058222903296",
  "text" : "Fighter jets are small % of AF tho. \u201C@algore: The USAF now trains more pilots for unmanned vehicles than for manned fighter jets.\u201D",
  "id" : 297505058222903296,
  "created_at" : "Sat Feb 02 00:41:47 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Gallagher",
      "screen_name" : "davidfg",
      "indices" : [ 3, 11 ],
      "id_str" : "14763721",
      "id" : 14763721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifehacks",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297473729741594624",
  "text" : "RT @davidfg: One quick way to achieve Inbox Zero at work is to quit your job. #lifehacks",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lifehacks",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "297472823524483072",
    "text" : "One quick way to achieve Inbox Zero at work is to quit your job. #lifehacks",
    "id" : 297472823524483072,
    "created_at" : "Fri Feb 01 22:33:42 +0000 2013",
    "user" : {
      "name" : "David Gallagher",
      "screen_name" : "davidfg",
      "protected" : false,
      "id_str" : "14763721",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2593854785/ps4vhulyifukkmfdvo4h_normal.jpeg",
      "id" : 14763721,
      "verified" : true
    }
  },
  "id" : 297473729741594624,
  "created_at" : "Fri Feb 01 22:37:18 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 1, 13 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "props",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/2mjt4afg",
      "expanded_url" : "http://alisharamos.com/women-vc-funding/#",
      "display_url" : "alisharamos.com/women-vc-fundi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "297465089357905920",
  "text" : ".@alishalisha has made her awesome thesis on women in VC culture available to the public. #props http://t.co/2mjt4afg",
  "id" : 297465089357905920,
  "created_at" : "Fri Feb 01 22:02:58 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297443938283974656",
  "geo" : {
  },
  "id_str" : "297445659156545536",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil or they could just by Cue.",
  "id" : 297445659156545536,
  "in_reply_to_status_id" : 297443938283974656,
  "created_at" : "Fri Feb 01 20:45:46 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 52, 66 ],
      "id_str" : "16005250",
      "id" : 16005250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/kylFEsrT",
      "expanded_url" : "http://boingboing.net/2013/02/01/no-asians-cornering-a-ra.html",
      "display_url" : "boingboing.net/2013/02/01/no-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "297431366189076482",
  "text" : "\"No Asians\" newspaper ad ends surprisingly well. cc @angryasianman http://t.co/kylFEsrT",
  "id" : 297431366189076482,
  "created_at" : "Fri Feb 01 19:48:58 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mannyanekal",
      "screen_name" : "mannyanekal",
      "indices" : [ 0, 12 ],
      "id_str" : "14535376",
      "id" : 14535376
    }, {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 13, 20 ],
      "id_str" : "9544202",
      "id" : 9544202
    }, {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 21, 27 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297412407964356608",
  "geo" : {
  },
  "id_str" : "297425839400816641",
  "in_reply_to_user_id" : 14535376,
  "text" : "@mannyanekal @schlaf @semil Alfred Lin used to arbitrage Tony Hsieh\u2019s pizzas in college. I sold Pokemon cards back in grade school.",
  "id" : 297425839400816641,
  "in_reply_to_status_id" : 297412407964356608,
  "created_at" : "Fri Feb 01 19:27:00 +0000 2013",
  "in_reply_to_screen_name" : "mannyanekal",
  "in_reply_to_user_id_str" : "14535376",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StillSkeptical",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297421748931026944",
  "text" : "All this BlackBerry press sounds like the Palm press from 2010, except they replaced \"Palm Pre\" with \"BlackBerry Z10.\" #StillSkeptical",
  "id" : 297421748931026944,
  "created_at" : "Fri Feb 01 19:10:45 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]