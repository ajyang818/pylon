Grailbird.data.tweets_2011_03 = 
 [ {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53641620385574912",
  "text" : "It's beginning to look a lot like Christmas...",
  "id" : 53641620385574912,
  "created_at" : "Fri Apr 01 02:15:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdvictory",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http://t.co/oCicQHZ",
      "expanded_url" : "http://twitpic.com/4f68sj",
      "display_url" : "twitpic.com/4f68sj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "53297394825166848",
  "text" : "Ubuntu supports touchscreens with generic drivers! #nerdvictory http://t.co/oCicQHZ",
  "id" : 53297394825166848,
  "created_at" : "Thu Mar 31 03:27:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 3, 15 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 23, 31 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "Brandon Liu",
      "screen_name" : "branliu",
      "indices" : [ 57, 65 ],
      "id_str" : "269717557",
      "id" : 269717557
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 66, 73 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 74, 82 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Winston",
      "screen_name" : "WWisMM",
      "indices" : [ 83, 90 ],
      "id_str" : "117857902",
      "id" : 117857902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53291983992651776",
  "text" : "RT @badboyboyce: First @Harvard HackNight w/ @melchiorda @branliu @khsieh @digitil @WWisMM & Harvard's Tech Crew!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 6, 14 ],
        "id_str" : "39585367",
        "id" : 39585367
      }, {
        "name" : "Brandon Liu",
        "screen_name" : "branliu",
        "indices" : [ 40, 48 ],
        "id_str" : "269717557",
        "id" : 269717557
      }, {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 49, 56 ],
        "id_str" : "111999960",
        "id" : 111999960
      }, {
        "name" : "\u265A Calvin McEachron",
        "screen_name" : "digitil",
        "indices" : [ 57, 65 ],
        "id_str" : "142513192",
        "id" : 142513192
      }, {
        "name" : "Winston",
        "screen_name" : "WWisMM",
        "indices" : [ 66, 73 ],
        "id_str" : "117857902",
        "id" : 117857902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "53278918085586944",
    "text" : "First @Harvard HackNight w/ @melchiorda @branliu @khsieh @digitil @WWisMM & Harvard's Tech Crew!",
    "id" : 53278918085586944,
    "created_at" : "Thu Mar 31 02:14:18 +0000 2011",
    "user" : {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "protected" : false,
      "id_str" : "110823121",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1736585624/HaLongBay_Profile_Thumbnail_normal.jpg",
      "id" : 110823121,
      "verified" : false
    }
  },
  "id" : 53291983992651776,
  "created_at" : "Thu Mar 31 03:06:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 30 ],
      "url" : "http://t.co/n2X9x4f",
      "expanded_url" : "http://twitpic.com/4f5uiz",
      "display_url" : "twitpic.com/4f5uiz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "53286859836633088",
  "text" : "HackNight! http://t.co/n2X9x4f",
  "id" : 53286859836633088,
  "created_at" : "Thu Mar 31 02:45:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53238176889839616",
  "geo" : {
  },
  "id_str" : "53239175067074560",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha You can set your Gmail to open instead!",
  "id" : 53239175067074560,
  "in_reply_to_status_id" : 53238176889839616,
  "created_at" : "Wed Mar 30 23:36:23 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "indices" : [ 3, 7 ],
      "id_str" : "105192845",
      "id" : 105192845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52994793822896128",
  "text" : "RT @TNW: Analysts: Windows Phone 7 to grab 2nd spot by 2015 http://tnw.co/fIeZn7",
  "retweeted_status" : {
    "source" : "<a href=\"http://dlvr.it\" rel=\"nofollow\">dlvr.it</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "52922100423462913",
    "text" : "Analysts: Windows Phone 7 to grab 2nd spot by 2015 http://tnw.co/fIeZn7",
    "id" : 52922100423462913,
    "created_at" : "Wed Mar 30 02:36:26 +0000 2011",
    "user" : {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "protected" : false,
      "id_str" : "105192845",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1135834058/tnw-top-stories_normal.jpg",
      "id" : 105192845,
      "verified" : false
    }
  },
  "id" : 52994793822896128,
  "created_at" : "Wed Mar 30 07:25:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven",
      "screen_name" : "mash_daddy",
      "indices" : [ 0, 11 ],
      "id_str" : "193150867",
      "id" : 193150867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52618389948088320",
  "geo" : {
  },
  "id_str" : "52628014458093568",
  "in_reply_to_user_id" : 193150867,
  "text" : "@Mash_Daddy search attribute \"has:attachment\" - delete",
  "id" : 52628014458093568,
  "in_reply_to_status_id" : 52618389948088320,
  "created_at" : "Tue Mar 29 07:07:51 +0000 2011",
  "in_reply_to_screen_name" : "mash_daddy",
  "in_reply_to_user_id_str" : "193150867",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http://t.co/a2d4Y5l",
      "expanded_url" : "http://www.groths.org/?p=308",
      "display_url" : "groths.org/?p=308"
    } ]
  },
  "geo" : {
  },
  "id_str" : "52611516461092865",
  "text" : "Enabled TRIM in Snow Leopard! Could be the placebo affect, but prolonged use seems snappier on the MBP http://t.co/a2d4Y5l",
  "id" : 52611516461092865,
  "created_at" : "Tue Mar 29 06:02:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Pahlka",
      "screen_name" : "pahlkadot",
      "indices" : [ 3, 13 ],
      "id_str" : "74543",
      "id" : 74543
    }, {
      "name" : "Color",
      "screen_name" : "color",
      "indices" : [ 39, 45 ],
      "id_str" : "271024785",
      "id" : 271024785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52430572118749184",
  "text" : "RT @pahlkadot: I have figured out what @color is for. To tell you what us happening around you when you are too busy looking at your pho ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Color",
        "screen_name" : "color",
        "indices" : [ 24, 30 ],
        "id_str" : "271024785",
        "id" : 271024785
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "51466264694099968",
    "text" : "I have figured out what @color is for. To tell you what us happening around you when you are too busy looking at your phone to know.",
    "id" : 51466264694099968,
    "created_at" : "Sat Mar 26 02:11:28 +0000 2011",
    "user" : {
      "name" : "Jennifer Pahlka",
      "screen_name" : "pahlkadot",
      "protected" : false,
      "id_str" : "74543",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3443904569/4f03ac6ed3d8ed68227bb296c2bd6cb5_normal.jpeg",
      "id" : 74543,
      "verified" : false
    }
  },
  "id" : 52430572118749184,
  "created_at" : "Mon Mar 28 18:03:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weiqi",
      "screen_name" : "zhangweiqi",
      "indices" : [ 10, 21 ],
      "id_str" : "26522070",
      "id" : 26522070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 78 ],
      "url" : "http://t.co/pQZ3yNH",
      "expanded_url" : "http://bit.ly/fCusYt",
      "display_url" : "bit.ly/fCusYt"
    } ]
  },
  "geo" : {
  },
  "id_str" : "52319884100636672",
  "text" : "YESSS RT: @zhangweiqi: Sushi Restaurant To Open in Allston http://t.co/pQZ3yNH - Sushi buffet comes to Harvard!!",
  "id" : 52319884100636672,
  "created_at" : "Mon Mar 28 10:43:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52311373056716800",
  "text" : "I \u2665 http://www.posterbrain.com - printing all posters to sell for the Harvard for Japan initiative!",
  "id" : 52311373056716800,
  "created_at" : "Mon Mar 28 10:09:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52287944421146624",
  "text" : "Writing this from a Droid X running a fresh Gingerbread install!",
  "id" : 52287944421146624,
  "created_at" : "Mon Mar 28 08:36:32 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http://t.co/G6Ptw86",
      "expanded_url" : "http://www.droid-life.com/2011/03/27/gingerbread-released-for-droid-x-and-2-downloads-and-instructions-provided/",
      "display_url" : "droid-life.com/2011/03/27/gin\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "52277044125499393",
  "text" : "Gingerbread for Droid X! Installing now - looking forward to snappier Blur #nerdtweet http://t.co/G6Ptw86",
  "id" : 52277044125499393,
  "created_at" : "Mon Mar 28 07:53:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Park",
      "screen_name" : "donpdonp",
      "indices" : [ 3, 12 ],
      "id_str" : "608093",
      "id" : 608093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51724532712620032",
  "text" : "RT @donpdonp: RT: \"Your cell phone has more computing power than all of NASA in 1969. NASA launched a man to the moon. We launch birds i ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "51341741323857920",
    "text" : "RT: \"Your cell phone has more computing power than all of NASA in 1969. NASA launched a man to the moon. We launch birds into pigs.\"",
    "id" : 51341741323857920,
    "created_at" : "Fri Mar 25 17:56:39 +0000 2011",
    "user" : {
      "name" : "Don Park",
      "screen_name" : "donpdonp",
      "protected" : false,
      "id_str" : "608093",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3389256806/c1c9d9a8bef0e46afff945b88c646940_normal.jpeg",
      "id" : 608093,
      "verified" : false
    }
  },
  "id" : 51724532712620032,
  "created_at" : "Sat Mar 26 19:17:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Taussig",
      "screen_name" : "ataussig",
      "indices" : [ 0, 9 ],
      "id_str" : "22097962",
      "id" : 22097962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51416136989941760",
  "geo" : {
  },
  "id_str" : "51417015302356992",
  "in_reply_to_user_id" : 22097962,
  "text" : "@ataussig If the most computationally intensive thing you use is MS Office, then the Air. Otherwise, the Pro.",
  "id" : 51417015302356992,
  "in_reply_to_status_id" : 51416136989941760,
  "created_at" : "Fri Mar 25 22:55:46 +0000 2011",
  "in_reply_to_screen_name" : "ataussig",
  "in_reply_to_user_id_str" : "22097962",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Color",
      "screen_name" : "color",
      "indices" : [ 29, 35 ],
      "id_str" : "271024785",
      "id" : 271024785
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 41, 53 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 58, 64 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51346300700082177",
  "text" : "Consensus after playing with @color with @badboyboyce and @cklee - cool idea, poor execution. Also, high risk of phallic photobombing.",
  "id" : 51346300700082177,
  "created_at" : "Fri Mar 25 18:14:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truth",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http://t.co/z3mxR5Y",
      "expanded_url" : "http://twitpic.com/4d6l5x",
      "display_url" : "twitpic.com/4d6l5x"
    } ]
  },
  "geo" : {
  },
  "id_str" : "51336971913670656",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose &gt; harvard Chinatown truck #truth http://t.co/z3mxR5Y",
  "id" : 51336971913670656,
  "created_at" : "Fri Mar 25 17:37:42 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 0, 10 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50965454549811200",
  "geo" : {
  },
  "id_str" : "50966237416669184",
  "in_reply_to_user_id" : 14326765,
  "text" : "@johnhcook I switched from swype to SwiftKey recently. Still trying to decide if I prefer swyping or intelligent tapping.",
  "id" : 50966237416669184,
  "in_reply_to_status_id" : 50965454549811200,
  "created_at" : "Thu Mar 24 17:04:32 +0000 2011",
  "in_reply_to_screen_name" : "johnhcook",
  "in_reply_to_user_id_str" : "14326765",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Color",
      "screen_name" : "color",
      "indices" : [ 0, 6 ],
      "id_str" : "271024785",
      "id" : 271024785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50962614209085440",
  "in_reply_to_user_id" : 271024785,
  "text" : "@color is cool, but the android app is laggy buggy (on moto DX) and has a counterintuitive interface. Waiting for an update.",
  "id" : 50962614209085440,
  "created_at" : "Thu Mar 24 16:50:08 +0000 2011",
  "in_reply_to_screen_name" : "color",
  "in_reply_to_user_id_str" : "271024785",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50817837421436928",
  "text" : "Rumor has it that the verizon WP7 phone will be a world phone. Fingers crossed.",
  "id" : 50817837421436928,
  "created_at" : "Thu Mar 24 07:14:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mae",
      "screen_name" : "mxhuo",
      "indices" : [ 3, 9 ],
      "id_str" : "21170404",
      "id" : 21170404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50762191359582208",
  "text" : "RT @mxhuo: http://onesixtieth.net/post/4055986156/harvard-for-japan\ncheck it, pretty awesome photography/posters by kane hsieh.  proceed ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "50759364918788096",
    "text" : "http://onesixtieth.net/post/4055986156/harvard-for-japan\ncheck it, pretty awesome photography/posters by kane hsieh.  proceeds go to japan",
    "id" : 50759364918788096,
    "created_at" : "Thu Mar 24 03:22:30 +0000 2011",
    "user" : {
      "name" : "Mae",
      "screen_name" : "mxhuo",
      "protected" : false,
      "id_str" : "21170404",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2244133311/25f923e_normal.jpg",
      "id" : 21170404,
      "verified" : false
    }
  },
  "id" : 50762191359582208,
  "created_at" : "Thu Mar 24 03:33:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 27, 36 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http://t.co/EEQaLtu",
      "expanded_url" : "https://www.aestages.org/Online/default.asp?doWork::WScontent::loadArticle=Load&BOparam::WScontent::loadArticle::article_id=A4803550-77F0-44A6-8B79-B70DC9079065",
      "display_url" : "aestages.org/Online/default\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "50761515883708416",
  "text" : "I REALLY want to go to MIT @medialab Death and the Powers performance this Friday! http://t.co/EEQaLtu",
  "id" : 50761515883708416,
  "created_at" : "Thu Mar 24 03:31:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Gaiss",
      "screen_name" : "MichaelGaiss",
      "indices" : [ 26, 39 ],
      "id_str" : "14653432",
      "id" : 14653432
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 47, 59 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http://t.co/eMJO62Y",
      "expanded_url" : "http://twitpic.com/4ck3ic",
      "display_url" : "twitpic.com/4ck3ic"
    } ]
  },
  "geo" : {
  },
  "id_str" : "50673694774796288",
  "text" : "Looking sharp at harvard, @michaelgaiss. Also, @badboyboyce's afro. http://t.co/eMJO62Y",
  "id" : 50673694774796288,
  "created_at" : "Wed Mar 23 21:42:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50673000021889024",
  "text" : "WP7 supported on CDMA now, but still no hint of a verizon release :(",
  "id" : 50673000021889024,
  "created_at" : "Wed Mar 23 21:39:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    }, {
      "name" : "chris dixon",
      "screen_name" : "cdixon",
      "indices" : [ 19, 26 ],
      "id_str" : "2529971",
      "id" : 2529971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50638165643505664",
  "text" : "RT @bznotes: +1 RT @cdixon: MIT is a national treasure http://post.ly/1n5t7",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "chris dixon",
        "screen_name" : "cdixon",
        "indices" : [ 6, 13 ],
        "id_str" : "2529971",
        "id" : 2529971
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "50595095044571136",
    "text" : "+1 RT @cdixon: MIT is a national treasure http://post.ly/1n5t7",
    "id" : 50595095044571136,
    "created_at" : "Wed Mar 23 16:29:45 +0000 2011",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 50638165643505664,
  "created_at" : "Wed Mar 23 19:20:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvardforjapan",
      "indices" : [ 26, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50228325574131712",
  "text" : "Selling poster prints for #harvardforjapan! Check them out at http://onesixtieth.net - then order here: http://goo.gl/CGcQx",
  "id" : 50228325574131712,
  "created_at" : "Tue Mar 22 16:12:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50113733325889536",
  "text" : "Blackberry Playbook announced. The Tablet Wars get another entrant.",
  "id" : 50113733325889536,
  "created_at" : "Tue Mar 22 08:36:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sendoid",
      "screen_name" : "Sendoid",
      "indices" : [ 18, 26 ],
      "id_str" : "267524314",
      "id" : 267524314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50072966804930560",
  "text" : "absolutely LOVING @sendoid for moving large files!",
  "id" : 50072966804930560,
  "created_at" : "Tue Mar 22 05:55:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndarKness",
      "screen_name" : "Alex_IndarKness",
      "indices" : [ 23, 39 ],
      "id_str" : "90575128",
      "id" : 90575128
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 41, 48 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49766943158304768",
  "text" : "Bad news in China...  \"@Alex_IndarKness: @khsieh not only Gmail. Almost all the HTTPS packages to Google Servers are blocked.\"",
  "id" : 49766943158304768,
  "created_at" : "Mon Mar 21 09:38:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "indices" : [ 3, 7 ],
      "id_str" : "105192845",
      "id" : 105192845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49747697896402945",
  "text" : "RT @TNW: Google confirms China is blocking access to Gmail http://tnw.co/fENbkn",
  "retweeted_status" : {
    "source" : "<a href=\"http://dlvr.it\" rel=\"nofollow\">dlvr.it</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "49742305715961856",
    "text" : "Google confirms China is blocking access to Gmail http://tnw.co/fENbkn",
    "id" : 49742305715961856,
    "created_at" : "Mon Mar 21 08:01:04 +0000 2011",
    "user" : {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "protected" : false,
      "id_str" : "105192845",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1135834058/tnw-top-stories_normal.jpg",
      "id" : 105192845,
      "verified" : false
    }
  },
  "id" : 49747697896402945,
  "created_at" : "Mon Mar 21 08:22:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49712236389867520",
  "text" : "United Airline's sales funnel online is full of dirty tricks. Almost dropped an extra $400 for 'options.'",
  "id" : 49712236389867520,
  "created_at" : "Mon Mar 21 06:01:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 39, 49 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49253274146189312",
  "text" : "Was in a rush and didn't get my weekly @momogoose food! This is upsetting.",
  "id" : 49253274146189312,
  "created_at" : "Sat Mar 19 23:37:50 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chrome",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49177600484052992",
  "text" : "I love that the google #chrome maintains fullscreen Flash on an external monitor when I'm focused on other program windows.",
  "id" : 49177600484052992,
  "created_at" : "Sat Mar 19 18:37:08 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 3, 10 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49162091717869568",
  "text" : "RT @cnnbrk: French official confirms that French fighter jets are flying over #Libya. http://on.cnn.com/grO2Tz",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Libya",
        "indices" : [ 66, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "49119179055448064",
    "text" : "French official confirms that French fighter jets are flying over #Libya. http://on.cnn.com/grO2Tz",
    "id" : 49119179055448064,
    "created_at" : "Sat Mar 19 14:44:59 +0000 2011",
    "user" : {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "protected" : false,
      "id_str" : "428333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1762504301/128x128_cnnbrk_avatar_normal.gif",
      "id" : 428333,
      "verified" : true
    }
  },
  "id" : 49162091717869568,
  "created_at" : "Sat Mar 19 17:35:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Red Cross",
      "screen_name" : "RedCross",
      "indices" : [ 84, 93 ],
      "id_str" : "6519522",
      "id" : 6519522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "japan",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 49 ],
      "url" : "http://t.co/uTAn8TG",
      "expanded_url" : "http://onesixtieth.net",
      "display_url" : "onesixtieth.net"
    }, {
      "indices" : [ 118, 137 ],
      "url" : "http://t.co/dm395b7",
      "expanded_url" : "http://yfrog.com/h3b19ynj",
      "display_url" : "yfrog.com/h3b19ynj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "49039477749977088",
  "text" : "If anyone wants a poster from http://t.co/uTAn8TG I will be donating all profits to @redcross for #japan. Message me. http://t.co/dm395b7",
  "id" : 49039477749977088,
  "created_at" : "Sat Mar 19 09:28:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "indices" : [ 3, 19 ],
      "id_str" : "263122363",
      "id" : 263122363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brilliant",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49006118231474176",
  "text" : "RT @HarvardAsianGuy: Making my ramen with coffee to save time. #brilliant",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brilliant",
        "indices" : [ 42, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "48829622405705728",
    "text" : "Making my ramen with coffee to save time. #brilliant",
    "id" : 48829622405705728,
    "created_at" : "Fri Mar 18 19:34:23 +0000 2011",
    "user" : {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "protected" : false,
      "id_str" : "263122363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1713903417/asian_normal.jpg",
      "id" : 263122363,
      "verified" : false
    }
  },
  "id" : 49006118231474176,
  "created_at" : "Sat Mar 19 07:15:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "microsoft",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http://t.co/HV5jYCA",
      "expanded_url" : "http://www.techflash.com/seattle/2011/03/microsoft-lands-on-most-ethical-list.html",
      "display_url" : "techflash.com/seattle/2011/0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "48673061397995520",
  "text" : "This makes me happy I'll be working at #microsoft this summer http://t.co/HV5jYCA",
  "id" : 48673061397995520,
  "created_at" : "Fri Mar 18 09:12:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 58 ],
      "url" : "http://t.co/unmue2P",
      "expanded_url" : "http://yfrog.com/gzuyrpuj",
      "display_url" : "yfrog.com/gzuyrpuj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.378098, -71.11588 ]
  },
  "id_str" : "48456265529176064",
  "text" : "A beautiful spring day in Harvard Yard http://t.co/unmue2P",
  "id" : 48456265529176064,
  "created_at" : "Thu Mar 17 18:50:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48421858168676352",
  "text" : "50s and sunny? Time to go biking.",
  "id" : 48421858168676352,
  "created_at" : "Thu Mar 17 16:34:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48129513678323712",
  "text" : "RT @bznotes: Ppl will pontificate on the nuclear issue that they can't understand or influence, but ignore massacres in Libya/Bahrain wh ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "48015832680378368",
    "text" : "Ppl will pontificate on the nuclear issue that they can't understand or influence, but ignore massacres in Libya/Bahrain where we can help.",
    "id" : 48015832680378368,
    "created_at" : "Wed Mar 16 13:40:41 +0000 2011",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 48129513678323712,
  "created_at" : "Wed Mar 16 21:12:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47926476540088320",
  "text" : "Jcrew 24 hour customer service is phenomenal. And people as me why I shop there as much as I do...",
  "id" : 47926476540088320,
  "created_at" : "Wed Mar 16 07:45:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 62 ],
      "url" : "http://t.co/oeOhCzI",
      "expanded_url" : "http://yfrog.com/h3f4uenj",
      "display_url" : "yfrog.com/h3f4uenj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3539275, -71.1246585 ]
  },
  "id_str" : "47718638567948288",
  "text" : "Banh mi and bubble tea for lunch! Omnomnon http://t.co/oeOhCzI",
  "id" : 47718638567948288,
  "created_at" : "Tue Mar 15 17:59:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3566745, -71.1257125 ]
  },
  "id_str" : "47716054318841856",
  "text" : "\"It's dangerous to read the NYT on a laptop. You want to punch the screen\" - on nuclear reporting inaccuracies",
  "id" : 47716054318841856,
  "created_at" : "Tue Mar 15 17:49:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre",
      "screen_name" : "dre2889",
      "indices" : [ 0, 8 ],
      "id_str" : "28261062",
      "id" : 28261062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47561054716309504",
  "geo" : {
  },
  "id_str" : "47614139136348160",
  "in_reply_to_user_id" : 28261062,
  "text" : "@dre2889 You can always make something faster, better, stronger. Never stop improving!",
  "id" : 47614139136348160,
  "in_reply_to_status_id" : 47561054716309504,
  "created_at" : "Tue Mar 15 11:04:30 +0000 2011",
  "in_reply_to_screen_name" : "dre2889",
  "in_reply_to_user_id_str" : "28261062",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zune",
      "indices" : [ 4, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47426522713296898",
  "text" : "RIP #zune, some of the most under-appreciated hardware and UXUI design ever.",
  "id" : 47426522713296898,
  "created_at" : "Mon Mar 14 22:38:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spring",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.36833155, -71.115638225 ]
  },
  "id_str" : "47421520246607872",
  "text" : "Rebuilt the bike today. Getting ready for #spring in cambridge!",
  "id" : 47421520246607872,
  "created_at" : "Mon Mar 14 22:19:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Hsieh",
      "screen_name" : "khsieh_",
      "indices" : [ 6, 14 ],
      "id_str" : "170093320",
      "id" : 170093320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47181247822299136",
  "text" : "sorry @khsieh_ for taking your username!",
  "id" : 47181247822299136,
  "created_at" : "Mon Mar 14 06:24:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3683336333, -71.1156321833 ]
  },
  "id_str" : "46884057593819136",
  "text" : "Is facebook app for android eating my battery? Uninstalling to find out",
  "id" : 46884057593819136,
  "created_at" : "Sun Mar 13 10:43:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thai Tran",
      "screen_name" : "thait",
      "indices" : [ 61, 67 ],
      "id_str" : "133333419",
      "id" : 133333419
    }, {
      "name" : "Nilesh Patel",
      "screen_name" : "nilzvpatel",
      "indices" : [ 68, 79 ],
      "id_str" : "130835184",
      "id" : 130835184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46872469826580480",
  "text" : "Signed up for Lightbox beta. Looking forward to great things @thait @nilzvpatel",
  "id" : 46872469826580480,
  "created_at" : "Sun Mar 13 09:57:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Bills",
      "screen_name" : "brandonbillsy",
      "indices" : [ 3, 17 ],
      "id_str" : "72801851",
      "id" : 72801851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46712525982674944",
  "text" : "RT @brandonbillsy: Watching the Princeton vs. Harvard game right now. They are so bad that their combined team scores is lower than thei ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "46706488164626432",
    "text" : "Watching the Princeton vs. Harvard game right now. They are so bad that their combined team scores is lower than their individual iq's.",
    "id" : 46706488164626432,
    "created_at" : "Sat Mar 12 22:57:49 +0000 2011",
    "user" : {
      "name" : "Brandon Bills",
      "screen_name" : "brandonbillsy",
      "protected" : false,
      "id_str" : "72801851",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3280189492/29db3ba0a5603a8b5216231c754281ee_normal.jpeg",
      "id" : 72801851,
      "verified" : false
    }
  },
  "id" : 46712525982674944,
  "created_at" : "Sat Mar 12 23:21:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46288374671228928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.352438, -71.092041 ]
  },
  "id_str" : "46294657579220992",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose thanks for remembering! I'm on break but I will see you next week for some omnomnom",
  "id" : 46294657579220992,
  "in_reply_to_status_id" : 46288374671228928,
  "created_at" : "Fri Mar 11 19:41:21 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "45552322633416704",
  "text" : "#android almost at 1/3 of smartphone marketshare in the US! Too bad vzw still doesn't have one with a decent camera.",
  "id" : 45552322633416704,
  "created_at" : "Wed Mar 09 18:31:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "United",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "Continentals",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "45211876728119297",
  "text" : "Of the two logos, #United chooses #Continentals?! That's just silly.",
  "id" : 45211876728119297,
  "created_at" : "Tue Mar 08 19:58:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http://t.co/GxImrKl",
      "expanded_url" : "http://youarelisteningtolosangeles.com/",
      "display_url" : "youarelisteningtolosangeles.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "44931335743225856",
  "text" : "Police scanner + ambient music = amazing. http://t.co/GxImrKl",
  "id" : 44931335743225856,
  "created_at" : "Tue Mar 08 01:23:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "indices" : [ 3, 9 ],
      "id_str" : "14782518",
      "id" : 14782518
    }, {
      "name" : "Alll",
      "screen_name" : "Alll",
      "indices" : [ 131, 136 ],
      "id_str" : "7991712",
      "id" : 7991712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44705462683312129",
  "text" : "RT @cltom: STUDIES\n\n1 in 3 Art Students Can\u2019t Tell Famous Paintings from paintings by monkeys (Gawker) http://cltom.com/i5Zco9 /cc @alll ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allie R",
        "screen_name" : "alllllie5Ls",
        "indices" : [ 120, 132 ],
        "id_str" : "20650638",
        "id" : 20650638
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "44276969466109952",
    "text" : "STUDIES\n\n1 in 3 Art Students Can\u2019t Tell Famous Paintings from paintings by monkeys (Gawker) http://cltom.com/i5Zco9 /cc @alllllie5Ls",
    "id" : 44276969466109952,
    "created_at" : "Sun Mar 06 06:03:46 +0000 2011",
    "user" : {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "protected" : false,
      "id_str" : "14782518",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2908096260/d10e7982fa92f0bf560a50a76d76e392_normal.png",
      "id" : 14782518,
      "verified" : false
    }
  },
  "id" : 44705462683312129,
  "created_at" : "Mon Mar 07 10:26:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.36843315, -71.1155643833 ]
  },
  "id_str" : "44354988687896576",
  "text" : "It's kind of scary how good SwiftKey on android has gotten at prediction",
  "id" : 44354988687896576,
  "created_at" : "Sun Mar 06 11:13:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 3, 11 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "Sec. of the Navy",
      "screen_name" : "SECNAV",
      "indices" : [ 61, 68 ],
      "id_str" : "117821354",
      "id" : 117821354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROTC",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44302662212132864",
  "text" : "RT @Harvard: Photo journal: Harvard President Drew Faust and @secnav Ray Mabus sign an agreement to re-establish #ROTC on campus http:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sec. of the Navy",
        "screen_name" : "SECNAV",
        "indices" : [ 48, 55 ],
        "id_str" : "117821354",
        "id" : 117821354
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROTC",
        "indices" : [ 100, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "44261067366481920",
    "text" : "Photo journal: Harvard President Drew Faust and @secnav Ray Mabus sign an agreement to re-establish #ROTC on campus http://bit.ly/fcPMHv",
    "id" : 44261067366481920,
    "created_at" : "Sun Mar 06 05:00:35 +0000 2011",
    "user" : {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "protected" : false,
      "id_str" : "39585367",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3349317264/1954930211e08d2ba39bb6a670049eb3_normal.png",
      "id" : 39585367,
      "verified" : true
    }
  },
  "id" : 44302662212132864,
  "created_at" : "Sun Mar 06 07:45:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.368438125, -71.1155532375 ]
  },
  "id_str" : "43969854436425728",
  "text" : "Fallon and Stewart both on Colbert. Funny, but since when did these shows become so slapstick??",
  "id" : 43969854436425728,
  "created_at" : "Sat Mar 05 09:43:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 30, 40 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43951073446215680",
  "text" : "the power of social networks! @momogoose recognized me today when I was paying them back for the awesome meal last week.",
  "id" : 43951073446215680,
  "created_at" : "Sat Mar 05 08:28:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43950951396159488",
  "text" : "new CR48 update makes it SO MUCH BETTER - esp the trackpad",
  "id" : 43950951396159488,
  "created_at" : "Sat Mar 05 08:28:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.352438, -71.092041 ]
  },
  "id_str" : "43764778417655808",
  "text" : "\"Its such a slap in the face that the American shuttle has a Canadian scanner\" - mit media lab #nerdtweet",
  "id" : 43764778417655808,
  "created_at" : "Fri Mar 04 20:08:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROTC",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http://t.co/q7XDTLv",
      "expanded_url" : "http://news.harvard.edu/gazette/story/2011/03/harvard-welcomes-back-rotc/",
      "display_url" : "news.harvard.edu/gazette/story/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "43512492462317568",
  "text" : "#ROTC is back at Harvard! Happy day. \nhttp://t.co/q7XDTLv",
  "id" : 43512492462317568,
  "created_at" : "Fri Mar 04 03:26:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gadget Lab",
      "screen_name" : "gadgetlab",
      "indices" : [ 99, 109 ],
      "id_str" : "11518842",
      "id" : 11518842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apple",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http://t.co/XHFdzn6",
      "expanded_url" : "http://tinyurl.com/4psjqc2",
      "display_url" : "tinyurl.com/4psjqc2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.365778, -71.021766 ]
  },
  "id_str" : "43418611083259904",
  "text" : "\"Its a piece of plastic with magnets, people.\" Strong reality distortion field detected. #apple RT @gadgetlab: http://t.co/XHFdzn6",
  "id" : 43418611083259904,
  "created_at" : "Thu Mar 03 21:12:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 28, 44 ],
      "id_str" : "228489296",
      "id" : 228489296
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 90, 97 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Travel",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "photography",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http://t.co/OlfyBEW",
      "expanded_url" : "http://onesixtieth.net/",
      "display_url" : "onesixtieth.net"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.378098, -71.11588 ]
  },
  "id_str" : "43410924618526721",
  "text" : "Thanks for the shoutout! RT @GlobalAsianista: Young and talented. #Travel #photography by @khsieh http://t.co/OlfyBEW",
  "id" : 43410924618526721,
  "created_at" : "Thu Mar 03 20:42:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.368438125, -71.1155532375 ]
  },
  "id_str" : "43373358775156736",
  "text" : "Android, I love you, but iPad 2 is helluva lot more appealing than xoom...",
  "id" : 43373358775156736,
  "created_at" : "Thu Mar 03 18:13:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 53 ],
      "url" : "http://t.co/hrqiAkL",
      "expanded_url" : "http://www.bgr.com/2011/03/03/exclusive-blackberry-messenger-will-launch-on-android-and-ios/",
      "display_url" : "bgr.com/2011/03/03/exc\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "43365360166113280",
  "text" : "BBM coming to android? say what?! http://t.co/hrqiAkL",
  "id" : 43365360166113280,
  "created_at" : "Thu Mar 03 17:41:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43345066391117824",
  "text" : "My TF's are throwing lizards at each other in evo bio section. CS now seems incredibly dull as a major.",
  "id" : 43345066391117824,
  "created_at" : "Thu Mar 03 16:20:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43273900209078272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.379194, -71.116941 ]
  },
  "id_str" : "43331565824126976",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha good luck in Seattle!!",
  "id" : 43331565824126976,
  "in_reply_to_status_id" : 43273900209078272,
  "created_at" : "Thu Mar 03 15:27:05 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 0, 8 ],
      "id_str" : "86144785",
      "id" : 86144785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3684233429, -71.1155543714 ]
  },
  "id_str" : "43266567286431744",
  "in_reply_to_user_id" : 86144785,
  "text" : "@xobabyb This. Is. HARVARD. (Read in voice of Gerard Butler as Leonidas)",
  "id" : 43266567286431744,
  "created_at" : "Thu Mar 03 11:08:48 +0000 2011",
  "in_reply_to_screen_name" : "xobabyb",
  "in_reply_to_user_id_str" : "86144785",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana ",
      "screen_name" : "FireEscape",
      "indices" : [ 3, 14 ],
      "id_str" : "17796779",
      "id" : 17796779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43263295913869312",
  "text" : "RT @FireEscape: there's nothing bubble tea can't cure",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "42018729776775168",
    "text" : "there's nothing bubble tea can't cure",
    "id" : 42018729776775168,
    "created_at" : "Mon Feb 28 00:30:20 +0000 2011",
    "user" : {
      "name" : "Alana ",
      "screen_name" : "FireEscape",
      "protected" : false,
      "id_str" : "17796779",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/66044937/us_normal.jpg",
      "id" : 17796779,
      "verified" : false
    }
  },
  "id" : 43263295913869312,
  "created_at" : "Thu Mar 03 10:55:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Springpad Team",
      "screen_name" : "springpad",
      "indices" : [ 16, 26 ],
      "id_str" : "15383497",
      "id" : 15383497
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 69, 81 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3684158222, -71.1155511778 ]
  },
  "id_str" : "43252009415094272",
  "text" : "Starting to use @Springpad to organize my absent-mindedness. Thanks, @badboyboyce",
  "id" : 43252009415094272,
  "created_at" : "Thu Mar 03 10:10:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 52, 60 ]
    }, {
      "text" : "midterms",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.378098, -71.11588 ]
  },
  "id_str" : "43055926365794304",
  "text" : "I just saw someone pour Red Bull into a fruit salad #harvard #midterms",
  "id" : 43055926365794304,
  "created_at" : "Wed Mar 02 21:11:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodspotting",
      "screen_name" : "foodspotting",
      "indices" : [ 21, 34 ],
      "id_str" : "38883394",
      "id" : 38883394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43041863682359296",
  "text" : "Excited to play with @foodspotting app this weekend. Need an excuse to binge on awesome asian food in allston.",
  "id" : 43041863682359296,
  "created_at" : "Wed Mar 02 20:15:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    }, {
      "name" : "JesseSchell",
      "screen_name" : "jesseschell",
      "indices" : [ 70, 82 ],
      "id_str" : "11591662",
      "id" : 11591662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42883364168015872",
  "text" : "RT @amyjokim: \"Words are crap. We should all shut up and make stuff.\" @jesseschell on #gamification http://bit.ly/gUbyor Right on, Jesse!",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JesseSchell",
        "screen_name" : "jesseschell",
        "indices" : [ 56, 68 ],
        "id_str" : "11591662",
        "id" : 11591662
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gamification",
        "indices" : [ 72, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "42837991483375616",
    "text" : "\"Words are crap. We should all shut up and make stuff.\" @jesseschell on #gamification http://bit.ly/gUbyor Right on, Jesse!",
    "id" : 42837991483375616,
    "created_at" : "Wed Mar 02 06:45:47 +0000 2011",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1789001732/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 42883364168015872,
  "created_at" : "Wed Mar 02 09:46:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42760500680982529",
  "text" : "Rocking new etymotic MC5's with Comply tips. Going to see if the Droid's battery can last as an MP3 player tmrw",
  "id" : 42760500680982529,
  "created_at" : "Wed Mar 02 01:37:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 3, 14 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gomes",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42450065163419648",
  "text" : "RT @thecrimson: \"#Gomes died after suffering a brain aneurysm and heart attack\"",
  "id" : 42450065163419648,
  "created_at" : "Tue Mar 01 05:04:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]