Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gmail",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http://t.co/oULLfws",
      "expanded_url" : "http://gmailblog.blogspot.com/2011/02/gmail-back-soon-for-everyone.html",
      "display_url" : "gmailblog.blogspot.com/2011/02/gmail-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "42433315222990848",
  "text" : "Google handles #gmail outage like a champ http://t.co/oULLfws",
  "id" : 42433315222990848,
  "created_at" : "Tue Mar 01 03:57:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.backupify.com\" rel=\"nofollow\">Backupify Backup</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Backupify",
      "screen_name" : "backupify",
      "indices" : [ 50, 60 ],
      "id_str" : "75049601",
      "id" : 75049601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42350866136707073",
  "text" : "backing-up the crap out of my digital presence w/ @Backupify after the gmail crash!",
  "id" : 42350866136707073,
  "created_at" : "Mon Feb 28 22:30:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 0, 15 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42291598503063552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.379194, -71.116941 ]
  },
  "id_str" : "42314735563182080",
  "in_reply_to_user_id" : 18107808,
  "text" : "@NaveenSrivatsa race CNN to see who implements first!",
  "id" : 42314735563182080,
  "in_reply_to_status_id" : 42291598503063552,
  "created_at" : "Mon Feb 28 20:06:33 +0000 2011",
  "in_reply_to_screen_name" : "NaveenSrivatsa",
  "in_reply_to_user_id_str" : "18107808",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 0, 7 ],
      "id_str" : "428333",
      "id" : 428333
    }, {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 12, 23 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3684210667, -71.1155339667 ]
  },
  "id_str" : "42291327706206209",
  "in_reply_to_user_id" : 428333,
  "text" : "@cnnbrk and @thecrimson - why don't you have mobile-optimized sites??",
  "id" : 42291327706206209,
  "created_at" : "Mon Feb 28 18:33:32 +0000 2011",
  "in_reply_to_screen_name" : "cnnbrk",
  "in_reply_to_user_id_str" : "428333",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob May",
      "screen_name" : "robmay",
      "indices" : [ 3, 10 ],
      "id_str" : "8819662",
      "id" : 8819662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42288265520361472",
  "text" : "RT @robmay: Worried about gmail data loss?, Backupify offers a free Pro100 account for the next 24 hrs w/ code \"savegmail\"  http://bit.l ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "42262493489410048",
    "text" : "Worried about gmail data loss?, Backupify offers a free Pro100 account for the next 24 hrs w/ code \"savegmail\"  http://bit.ly/fN7qnm",
    "id" : 42262493489410048,
    "created_at" : "Mon Feb 28 16:38:58 +0000 2011",
    "user" : {
      "name" : "Rob May",
      "screen_name" : "robmay",
      "protected" : false,
      "id_str" : "8819662",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1138221677/rob_normal.png",
      "id" : 8819662,
      "verified" : false
    }
  },
  "id" : 42288265520361472,
  "created_at" : "Mon Feb 28 18:21:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chrome",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "41773855978700800",
  "text" : "I just realized that the new #chrome doesn't shrink fullscreen flash when I focus on another window. So useful!",
  "id" : 41773855978700800,
  "created_at" : "Sun Feb 27 08:17:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 3, 8 ],
      "id_str" : "132319630",
      "id" : 132319630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "41657876468469760",
  "text" : "RT @sidd: Thinking about all the startups that are gonna go bankrupt when the hipsters die.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "41597205366308864",
    "text" : "Thinking about all the startups that are gonna go bankrupt when the hipsters die.",
    "id" : 41597205366308864,
    "created_at" : "Sat Feb 26 20:35:21 +0000 2011",
    "user" : {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "protected" : false,
      "id_str" : "132319630",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2627932894/9fnx2ah1rulk5mlp4rqb_normal.png",
      "id" : 132319630,
      "verified" : false
    }
  },
  "id" : 41657876468469760,
  "created_at" : "Sun Feb 27 00:36:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iou",
      "indices" : [ 90, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.352438, -71.092041 ]
  },
  "id_str" : "41210168062652416",
  "in_reply_to_user_id" : 182074162,
  "text" : "@Momogoose at Kendall square made my day by giving me lunch despite not having my wallet. #iou",
  "id" : 41210168062652416,
  "created_at" : "Fri Feb 25 18:57:24 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 3, 10 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Boeing",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40904135423430656",
  "text" : "RT @cnnbrk: Air Force awards an initial $3.5 billion-plus contract to #Boeing to produce\n18  aerial refueling tankers.http://on.cnn.com/ ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Boeing",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "40900208552460289",
    "text" : "Air Force awards an initial $3.5 billion-plus contract to #Boeing to produce\n18  aerial refueling tankers.http://on.cnn.com/gbGv8d",
    "id" : 40900208552460289,
    "created_at" : "Thu Feb 24 22:25:44 +0000 2011",
    "user" : {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "protected" : false,
      "id_str" : "428333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1762504301/128x128_cnnbrk_avatar_normal.gif",
      "id" : 428333,
      "verified" : true
    }
  },
  "id" : 40904135423430656,
  "created_at" : "Thu Feb 24 22:41:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anonymous",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "win",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.378098, -71.11588 ]
  },
  "id_str" : "40891682257903617",
  "text" : "It seems that #anonymous has taken down Westboro Baptist. #win",
  "id" : 40891682257903617,
  "created_at" : "Thu Feb 24 21:51:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Motorola Mobility",
      "screen_name" : "Motorola",
      "indices" : [ 3, 12 ],
      "id_str" : "49753110",
      "id" : 49753110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "motoxoom",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40507181744783360",
  "text" : "RT @Motorola: We gifted movie star nominees w/ special gold Motorola XOOM tablets. RT for chance to win 1! http://moto.ly/xrules #motoxoom",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "motoxoom",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "40471237238980608",
    "text" : "We gifted movie star nominees w/ special gold Motorola XOOM tablets. RT for chance to win 1! http://moto.ly/xrules #motoxoom",
    "id" : 40471237238980608,
    "created_at" : "Wed Feb 23 18:01:09 +0000 2011",
    "user" : {
      "name" : "Motorola Mobility",
      "screen_name" : "Motorola",
      "protected" : false,
      "id_str" : "49753110",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1093872264/Screen_shot_2010-08-02_at_12.22.43_PM_normal.png",
      "id" : 49753110,
      "verified" : true
    }
  },
  "id" : 40507181744783360,
  "created_at" : "Wed Feb 23 20:23:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 3, 14 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "honeycomb",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40185236490948608",
  "text" : "RT @droid_life: Full Android 3.0 Honeycomb SDK Is Now Available! - http://goo.gl/8fli5  #android #honeycomb",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "android",
        "indices" : [ 72, 80 ]
      }, {
        "text" : "honeycomb",
        "indices" : [ 81, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "40174537702113280",
    "text" : "Full Android 3.0 Honeycomb SDK Is Now Available! - http://goo.gl/8fli5  #android #honeycomb",
    "id" : 40174537702113280,
    "created_at" : "Tue Feb 22 22:22:10 +0000 2011",
    "user" : {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "protected" : false,
      "id_str" : "96501375",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1639322866/dl_square_normal.jpg",
      "id" : 96501375,
      "verified" : true
    }
  },
  "id" : 40185236490948608,
  "created_at" : "Tue Feb 22 23:04:41 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipad",
      "indices" : [ 9, 14 ]
    }, {
      "text" : "xoom",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40157347661873152",
  "text" : "It seems #ipad 2 announcement is timed to crap all over the #xoom launch",
  "id" : 40157347661873152,
  "created_at" : "Tue Feb 22 21:13:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39912235937701888",
  "geo" : {
  },
  "id_str" : "39980304269574144",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha Ten Ren bubble tea in China Town!",
  "id" : 39980304269574144,
  "in_reply_to_status_id" : 39912235937701888,
  "created_at" : "Tue Feb 22 09:30:21 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Delight",
      "screen_name" : "GlobalDelight",
      "indices" : [ 10, 24 ],
      "id_str" : "20301481",
      "id" : 20301481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39980071372587008",
  "text" : "installed @GlobalDelight's Boom app and rocking out on the Macbook Pro. Does it also work for USB output?",
  "id" : 39980071372587008,
  "created_at" : "Tue Feb 22 09:29:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.361803, -71.097542 ]
  },
  "id_str" : "39772942757920768",
  "text" : "\"Photography is just an excuse to live\" - Pablo Vega, natgeo photog and Neiman fellow",
  "id" : 39772942757920768,
  "created_at" : "Mon Feb 21 19:46:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 3, 10 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39772695663087616",
  "text" : "RT @cnnbrk: 2 #Libya air force pilots defect to Malta after being asked to bomb Libyan citizens, Maltese gov't source says. http://on.cn ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Libya",
        "indices" : [ 2, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "39766251936940032",
    "text" : "2 #Libya air force pilots defect to Malta after being asked to bomb Libyan citizens, Maltese gov't source says. http://on.cnn.com/emQH5v",
    "id" : 39766251936940032,
    "created_at" : "Mon Feb 21 19:19:47 +0000 2011",
    "user" : {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "protected" : false,
      "id_str" : "428333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1762504301/128x128_cnnbrk_avatar_normal.gif",
      "id" : 428333,
      "verified" : true
    }
  },
  "id" : 39772695663087616,
  "created_at" : "Mon Feb 21 19:45:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39149189510201345",
  "text" : "Intel to build 14nm fab plant. I remember when 45nm was new and sexy.",
  "id" : 39149189510201345,
  "created_at" : "Sun Feb 20 02:27:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "murakami",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.36842938, -71.11553551 ]
  },
  "id_str" : "38882892327157761",
  "text" : "Reading #murakami by flashlight and getting shivers",
  "id" : 38882892327157761,
  "created_at" : "Sat Feb 19 08:49:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 0, 13 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "38682965248712705",
  "in_reply_to_user_id" : 112919587,
  "text" : "@vcruzcontrol use the official blackberry twitter app!",
  "id" : 38682965248712705,
  "created_at" : "Fri Feb 18 19:35:12 +0000 2011",
  "in_reply_to_screen_name" : "vcruzcontrol",
  "in_reply_to_user_id_str" : "112919587",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mit",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "medialab",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "38682559810510849",
  "text" : "\"We need to get away from the notion that pervasive imaging is the same as surveillance\" - #mit #medialab",
  "id" : 38682559810510849,
  "created_at" : "Fri Feb 18 19:33:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twidroyd",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.352438, -71.092041 ]
  },
  "id_str" : "38681686514466816",
  "text" : "Oh snap, #twidroyd shut down for violating twitter policy",
  "id" : 38681686514466816,
  "created_at" : "Fri Feb 18 19:30:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "38185519670247424",
  "text" : "RT @TheEconomist: The growth of Chinese mega-cities can only help America fix its problem of chronic infrastructure underinvestment http ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "38138414717083648",
    "text" : "The growth of Chinese mega-cities can only help America fix its problem of chronic infrastructure underinvestment http://econ.st/ifGOUH",
    "id" : 38138414717083648,
    "created_at" : "Thu Feb 17 07:31:21 +0000 2011",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 38185519670247424,
  "created_at" : "Thu Feb 17 10:38:32 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cr48",
      "indices" : [ 4, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "37975270610829313",
  "text" : "The #cr48 is just about useless for developing. Learning this the hard way in class",
  "id" : 37975270610829313,
  "created_at" : "Wed Feb 16 20:43:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "education",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "37954161953738752",
  "text" : "\"Expensive bat testicle hypothesis\" - the negative correlation of testicle to brain size #harvard #education",
  "id" : 37954161953738752,
  "created_at" : "Wed Feb 16 19:19:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http://t.co/MHrSt7b",
      "expanded_url" : "http://politicalhumor.about.com/library/bl-glenn-beck-conspiracy.htm?PS=683,601,701,242:13",
      "display_url" : "politicalhumor.about.com/library/bl-gle\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "37682818716798976",
  "text" : "The Glenn Beck conspiracy generator. Its accuracy is simultaneously hilarious and depressing http://t.co/MHrSt7b",
  "id" : 37682818716798976,
  "created_at" : "Wed Feb 16 01:20:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "watson",
      "indices" : [ 4, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "37678520134008832",
  "text" : "IBM #watson beats Ken Jennings by an order of magnitude!",
  "id" : 37678520134008832,
  "created_at" : "Wed Feb 16 01:03:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3684263857, -71.1155563571 ]
  },
  "id_str" : "37424785499754496",
  "text" : "What is the purpose of the spoof hardware option under #android mms options? Seems sketchy to me",
  "id" : 37424785499754496,
  "created_at" : "Tue Feb 15 08:15:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tmobile",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "apple",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3684263857, -71.1155563571 ]
  },
  "id_str" : "37424021062692864",
  "text" : "#tmobile just made fun of #apple using a \"im a pc\"-style commercial",
  "id" : 37424021062692864,
  "created_at" : "Tue Feb 15 08:12:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swype",
      "screen_name" : "Swype",
      "indices" : [ 34, 40 ],
      "id_str" : "33967973",
      "id" : 33967973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "droid",
      "indices" : [ 48, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3684263857, -71.1155563571 ]
  },
  "id_str" : "37374410977452032",
  "text" : "Split testing @swiftkeyapp versus @swype on the #droid at the moment.  Results pending.",
  "id" : 37374410977452032,
  "created_at" : "Tue Feb 15 04:55:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 116, 131 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cr48",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "37263902878203904",
  "text" : "First full day of class with the #cr48. Great battery, super convenient to carry. Trackpad really is garbage though @NaveenSrivatsa",
  "id" : 37263902878203904,
  "created_at" : "Mon Feb 14 21:36:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 21, 28 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "androidify",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http://t.co/ZS1R2HD",
      "expanded_url" : "http://yfrog.com/hswnsfp",
      "display_url" : "yfrog.com/hswnsfp"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.366707, -71.115128 ]
  },
  "id_str" : "37052656228765698",
  "text" : "Playing with the new @google #androidify app http://t.co/ZS1R2HD",
  "id" : 37052656228765698,
  "created_at" : "Mon Feb 14 07:36:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36706171498795008",
  "text" : "Today, I found out on facebook about the engagement of two friends. We truly are the digital generation.",
  "id" : 36706171498795008,
  "created_at" : "Sun Feb 13 08:40:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 17, 25 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 26, 38 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36597234850078720",
  "text" : "By that argument @digitil @badboyboyce, amazon mp3 would also be more successful than itunes.",
  "id" : 36597234850078720,
  "created_at" : "Sun Feb 13 01:27:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CR48",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36352454429777921",
  "text" : "Tweeting from a #CR48. Going to use the Chromebook as my primary notebook now!",
  "id" : 36352454429777921,
  "created_at" : "Sat Feb 12 09:14:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 18, 31 ],
      "id_str" : "101114131",
      "id" : 101114131
    }, {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 75, 86 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36352263161126912",
  "text" : "Thanks so much to @Blueasiacafe for providing 400 delicious bubble tea for @HarvardCSA's Chinese New Year celebration!",
  "id" : 36352263161126912,
  "created_at" : "Sat Feb 12 09:13:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 3, 16 ],
      "id_str" : "101114131",
      "id" : 101114131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36350273106612224",
  "text" : "RT @Blueasiacafe: has completed and set the 400 boba tea record today! (from last year Wellesley College's 350 Boba Tea record!)... http ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "36286496046727168",
    "text" : "has completed and set the 400 boba tea record today! (from last year Wellesley College's 350 Boba Tea record!)... http://fb.me/O1nMky0F",
    "id" : 36286496046727168,
    "created_at" : "Sat Feb 12 04:52:29 +0000 2011",
    "user" : {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "protected" : false,
      "id_str" : "101114131",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/604737097/LOGO_normal.jpg",
      "id" : 101114131,
      "verified" : false
    }
  },
  "id" : 36350273106612224,
  "created_at" : "Sat Feb 12 09:05:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 30, 38 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.36510935, -71.02206975 ]
  },
  "id_str" : "35992112264650752",
  "text" : "Playing with the new #android @twitter app. Glad it finally defaults to timeline view; colorway matches gingerbread quite nicely too",
  "id" : 35992112264650752,
  "created_at" : "Fri Feb 11 09:22:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft News",
      "screen_name" : "MSFTnews",
      "indices" : [ 3, 12 ],
      "id_str" : "24741685",
      "id" : 24741685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wp7",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35984216269258753",
  "text" : "RT @MSFTnews: Nokia & Microsoft announce plans for strategic partnership to build new global mobile ecosystem http://bit.ly/eCqpbK #wp7",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.exacttarget.com/social\" rel=\"nofollow\">SocialEngage</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wp7",
        "indices" : [ 117, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "35964783064907776",
    "text" : "Nokia & Microsoft announce plans for strategic partnership to build new global mobile ecosystem http://bit.ly/eCqpbK #wp7",
    "id" : 35964783064907776,
    "created_at" : "Fri Feb 11 07:34:07 +0000 2011",
    "user" : {
      "name" : "Microsoft News",
      "screen_name" : "MSFTnews",
      "protected" : false,
      "id_str" : "24741685",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1536324742/72x72_msftnews_normal.png",
      "id" : 24741685,
      "verified" : true
    }
  },
  "id" : 35984216269258753,
  "created_at" : "Fri Feb 11 08:51:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "verizon",
      "indices" : [ 3, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35790041133359104",
  "text" : "At #verizon for iphone launch day. Going to stick it out with the moto until the next product cycle though.",
  "id" : 35790041133359104,
  "created_at" : "Thu Feb 10 19:59:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 15, 22 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35637189966561280",
  "text" : "excited for my @google CR48 to come on Friday. Will be using it exclusively and docking the macbook pro as a desktop for a bit.",
  "id" : 35637189966561280,
  "created_at" : "Thu Feb 10 09:52:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esquire Magazine",
      "screen_name" : "Esquiremag",
      "indices" : [ 3, 14 ],
      "id_str" : "20455625",
      "id" : 20455625
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 60, 66 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35402679735812097",
  "text" : "RT @Esquiremag: We got: \"Triumph of the green.\" Stoners. RT @Slate A fun new toy: The Obama slogan generator. http://slate.me/eesMEv",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 44, 50 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "35378651235090434",
    "text" : "We got: \"Triumph of the green.\" Stoners. RT @Slate A fun new toy: The Obama slogan generator. http://slate.me/eesMEv",
    "id" : 35378651235090434,
    "created_at" : "Wed Feb 09 16:45:02 +0000 2011",
    "user" : {
      "name" : "Esquire Magazine",
      "screen_name" : "Esquiremag",
      "protected" : false,
      "id_str" : "20455625",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2971372450/5c46b6f0dea1bb02cec3a5ead6ef9cc8_normal.jpeg",
      "id" : 20455625,
      "verified" : true
    }
  },
  "id" : 35402679735812097,
  "created_at" : "Wed Feb 09 18:20:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Super Mash Bros.",
      "screen_name" : "SuperMashBros",
      "indices" : [ 17, 31 ],
      "id_str" : "25930428",
      "id" : 25930428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35225806603173888",
  "text" : "grading psets to @supermashbros discography. Great for burning the midnight oil.",
  "id" : 35225806603173888,
  "created_at" : "Wed Feb 09 06:37:41 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Voice",
      "screen_name" : "googlevoice",
      "indices" : [ 16, 28 ],
      "id_str" : "22193651",
      "id" : 22193651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35144983908593664",
  "text" : "Free calls with @googlevoice through 2011! Most convenient.",
  "id" : 35144983908593664,
  "created_at" : "Wed Feb 09 01:16:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Office",
      "screen_name" : "Office",
      "indices" : [ 3, 10 ],
      "id_str" : "22209176",
      "id" : 22209176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneNote",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "iPhone",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35125850953359360",
  "text" : "RT @Office: Like taking notes on the go? Get #OneNote for your #iPhone. FREE download for a limited time.\u00A0http://cot.ag/dXMmce ^AG",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.exacttarget.com/social\" rel=\"nofollow\">SocialEngage</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneNote",
        "indices" : [ 33, 41 ]
      }, {
        "text" : "iPhone",
        "indices" : [ 51, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "35121951748001792",
    "text" : "Like taking notes on the go? Get #OneNote for your #iPhone. FREE download for a limited time.\u00A0http://cot.ag/dXMmce ^AG",
    "id" : 35121951748001792,
    "created_at" : "Tue Feb 08 23:45:00 +0000 2011",
    "user" : {
      "name" : "Office",
      "screen_name" : "Office",
      "protected" : false,
      "id_str" : "22209176",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2944394491/c57acc37a1be44dc922d678dcfd6fe3f_normal.png",
      "id" : 22209176,
      "verified" : true
    }
  },
  "id" : 35125850953359360,
  "created_at" : "Wed Feb 09 00:00:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilad Lotan",
      "screen_name" : "gilgul",
      "indices" : [ 0, 7 ],
      "id_str" : "3183721",
      "id" : 3183721
    }, {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 133, 139 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34806940509020160",
  "in_reply_to_user_id" : 3183721,
  "text" : "@gilgul: \"statistician will be the sexiest [job]. data's widely available, but ability to extract wisdom is scarce\" - bodes well for @l_jin",
  "id" : 34806940509020160,
  "created_at" : "Tue Feb 08 02:53:15 +0000 2011",
  "in_reply_to_screen_name" : "gilgul",
  "in_reply_to_user_id_str" : "3183721",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34514916836642816",
  "text" : "RT @hotdogsladies: Buying HuffPo is a brilliant strategic move for a company struggling to suck at scale.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "34489664987467776",
    "text" : "Buying HuffPo is a brilliant strategic move for a company struggling to suck at scale.",
    "id" : 34489664987467776,
    "created_at" : "Mon Feb 07 05:52:31 +0000 2011",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/51857279/merlin_icon_184-1_normal.png",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 34514916836642816,
  "created_at" : "Mon Feb 07 07:32:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "guiltypleasure",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34352803581394944",
  "text" : "Enrique Iglesias is so catchy #guiltypleasure",
  "id" : 34352803581394944,
  "created_at" : "Sun Feb 06 20:48:41 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34021855723659264",
  "text" : "Above freezing. Time to bike.",
  "id" : 34021855723659264,
  "created_at" : "Sat Feb 05 22:53:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Koenigsegg",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33931512445403136",
  "text" : "Some people name their kids after cars. Mine would be #Koenigsegg.",
  "id" : 33931512445403136,
  "created_at" : "Sat Feb 05 16:54:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33791217170915331",
  "text" : "tweeple, I need a &lt;13\" laptop. Emphasis on battery life and build. Eyeing macbook air and thinkpad x201i. thoughts?",
  "id" : 33791217170915331,
  "created_at" : "Sat Feb 05 07:37:08 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canon",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33583050965123072",
  "text" : "Rumors about a #canon mirrorless system. Trying to imagine how huge L glass would look on it.",
  "id" : 33583050965123072,
  "created_at" : "Fri Feb 04 17:49:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lenovo",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33566527726821377",
  "text" : "#lenovo's website is down...",
  "id" : 33566527726821377,
  "created_at" : "Fri Feb 04 16:44:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 84, 93 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mit",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33560221452345344",
  "text" : "\"I bought a 3D printer. I wake up make coffee and print objects\" - Ken Perlin, #mit @medialab",
  "id" : 33560221452345344,
  "created_at" : "Fri Feb 04 16:19:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33555016719536129",
  "text" : "QR coded ads in the #mbta trains are cool... But there's no data signal on the trains.",
  "id" : 33555016719536129,
  "created_at" : "Fri Feb 04 15:58:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boston",
      "indices" : [ 7, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33548268378140672",
  "text" : "Why is #boston mass transit so bad?",
  "id" : 33548268378140672,
  "created_at" : "Fri Feb 04 15:31:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snow",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http://t.co/AhAlLQs",
      "expanded_url" : "http://yfrog.com/h4ewroj",
      "display_url" : "yfrog.com/h4ewroj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "33547632198696960",
  "text" : "These little Bobcat #snow plows can do a zero-point turn! Very clever. http://t.co/AhAlLQs",
  "id" : 33547632198696960,
  "created_at" : "Fri Feb 04 15:29:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JER",
      "screen_name" : "STRANGERDANGER",
      "indices" : [ 3, 18 ],
      "id_str" : "10268372",
      "id" : 10268372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33539607299768320",
  "text" : "RT @STRANGERDANGER: Q-GUIDE TO BE REPLACED: New Measure is Asian to Backwards Hat Ratio",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "33426888613429248",
    "text" : "Q-GUIDE TO BE REPLACED: New Measure is Asian to Backwards Hat Ratio",
    "id" : 33426888613429248,
    "created_at" : "Fri Feb 04 07:29:25 +0000 2011",
    "user" : {
      "name" : "JER",
      "screen_name" : "STRANGERDANGER",
      "protected" : true,
      "id_str" : "10268372",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3434275157/c2c458f8d83f7c16a057f0e417f72ab1_normal.png",
      "id" : 10268372,
      "verified" : false
    }
  },
  "id" : 33539607299768320,
  "created_at" : "Fri Feb 04 14:57:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Wang",
      "screen_name" : "annie_wang",
      "indices" : [ 0, 11 ],
      "id_str" : "29599103",
      "id" : 29599103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33237796156080128",
  "geo" : {
  },
  "id_str" : "33281634836946944",
  "in_reply_to_user_id" : 29599103,
  "text" : "@annie_wang software updates already cost money!",
  "id" : 33281634836946944,
  "in_reply_to_status_id" : 33237796156080128,
  "created_at" : "Thu Feb 03 21:52:14 +0000 2011",
  "in_reply_to_screen_name" : "annie_wang",
  "in_reply_to_user_id_str" : "29599103",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ogilvy & Mather",
      "screen_name" : "Ogilvy",
      "indices" : [ 3, 10 ],
      "id_str" : "5894902",
      "id" : 5894902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33174134309523456",
  "text" : "RT @OGILVY: A tribute to the UX designer: \nWho doesn\u2019t love a good UX design, and who doesn\u2019t get totally frustrated with ba... http://b ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "33114888763088896",
    "text" : "A tribute to the UX designer: \nWho doesn\u2019t love a good UX design, and who doesn\u2019t get totally frustrated with ba... http://bit.ly/eY0hbW",
    "id" : 33114888763088896,
    "created_at" : "Thu Feb 03 10:49:39 +0000 2011",
    "user" : {
      "name" : "Ogilvy & Mather",
      "screen_name" : "Ogilvy",
      "protected" : false,
      "id_str" : "5894902",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3267564150/b81430f20e920c626ef78662da3563ef_normal.jpeg",
      "id" : 5894902,
      "verified" : false
    }
  },
  "id" : 33174134309523456,
  "created_at" : "Thu Feb 03 14:45:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33062512672899072",
  "text" : "The real Michael Steele doing quite well on the Daily Show after Stewart ripping on him for months!",
  "id" : 33062512672899072,
  "created_at" : "Thu Feb 03 07:21:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http://t.co/OTsDd28",
      "expanded_url" : "http://techcrunch.com/2011/02/02/google-tried-to-buy-path-for-100-million-path-said-no/",
      "display_url" : "techcrunch.com/2011/02/02/goo\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "32887871719346176",
  "text" : "google offer rebuffed again. path joins the groupon club. http://t.co/OTsDd28",
  "id" : 32887871719346176,
  "created_at" : "Wed Feb 02 19:47:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swappa",
      "screen_name" : "swappa",
      "indices" : [ 3, 10 ],
      "id_str" : "232409384",
      "id" : 232409384
    }, {
      "name" : "cyanogen",
      "screen_name" : "cyanogen",
      "indices" : [ 100, 109 ],
      "id_str" : "8131122",
      "id" : 8131122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http://t.co/n63gno9",
      "expanded_url" : "http://swappa.com/cyanogenmod",
      "display_url" : "swappa.com/cyanogenmod"
    } ]
  },
  "geo" : {
  },
  "id_str" : "32864019643633664",
  "text" : "RT @swappa: Each Android device with CyanogenMod sold on Swappa sends a donation to its developers. @cyanogen http://t.co/n63gno9",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "cyanogen",
        "screen_name" : "cyanogen",
        "indices" : [ 88, 97 ],
        "id_str" : "8131122",
        "id" : 8131122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 117 ],
        "url" : "http://t.co/n63gno9",
        "expanded_url" : "http://swappa.com/cyanogenmod",
        "display_url" : "swappa.com/cyanogenmod"
      } ]
    },
    "geo" : {
    },
    "id_str" : "32835127662878720",
    "text" : "Each Android device with CyanogenMod sold on Swappa sends a donation to its developers. @cyanogen http://t.co/n63gno9",
    "id" : 32835127662878720,
    "created_at" : "Wed Feb 02 16:17:59 +0000 2011",
    "user" : {
      "name" : "Swappa",
      "screen_name" : "swappa",
      "protected" : false,
      "id_str" : "232409384",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2702765940/7d7635a6b2c5875470ff674752fd42ab_normal.png",
      "id" : 232409384,
      "verified" : false
    }
  },
  "id" : 32864019643633664,
  "created_at" : "Wed Feb 02 18:12:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Gao",
      "screen_name" : "jasongao",
      "indices" : [ 0, 9 ],
      "id_str" : "11829482",
      "id" : 11829482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32855231796613120",
  "in_reply_to_user_id" : 11829482,
  "text" : "@jasongao I see your ad campaign but I think the math notation is confusing people.",
  "id" : 32855231796613120,
  "created_at" : "Wed Feb 02 17:37:52 +0000 2011",
  "in_reply_to_screen_name" : "jasongao",
  "in_reply_to_user_id_str" : "11829482",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 0, 8 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32842153113690113",
  "in_reply_to_user_id" : 39585367,
  "text" : "@Harvard closes support facilities such as the ID office but doesn't cancel classes. Logistics fail.",
  "id" : 32842153113690113,
  "created_at" : "Wed Feb 02 16:45:54 +0000 2011",
  "in_reply_to_screen_name" : "Harvard",
  "in_reply_to_user_id_str" : "39585367",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 23, 30 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32565396573790208",
  "text" : "I pay all orders on an @amazon card w/ perfect credit, and customer service won't tell me why I'm on hold.",
  "id" : 32565396573790208,
  "created_at" : "Tue Feb 01 22:26:10 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 0, 7 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32564917047402496",
  "in_reply_to_user_id" : 20793816,
  "text" : "@amazon put my account on hold, immediately AFTER they removed the hold, after 4 months of saying \"you will get a result in 48 hours\" #wtf",
  "id" : 32564917047402496,
  "created_at" : "Tue Feb 01 22:24:15 +0000 2011",
  "in_reply_to_screen_name" : "amazon",
  "in_reply_to_user_id_str" : "20793816",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 3, 14 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "iphone",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32542402493288449",
  "text" : "RT @droid_life: Nielsen: Android, Blackberry And IPhone End 2010 Tied For Mobile Market Share - http://goo.gl/sqIcV #android #iphone",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "android",
        "indices" : [ 100, 108 ]
      }, {
        "text" : "iphone",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "32539465452888064",
    "text" : "Nielsen: Android, Blackberry And IPhone End 2010 Tied For Mobile Market Share - http://goo.gl/sqIcV #android #iphone",
    "id" : 32539465452888064,
    "created_at" : "Tue Feb 01 20:43:07 +0000 2011",
    "user" : {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "protected" : false,
      "id_str" : "96501375",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1639322866/dl_square_normal.jpg",
      "id" : 96501375,
      "verified" : true
    }
  },
  "id" : 32542402493288449,
  "created_at" : "Tue Feb 01 20:54:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jalopnik",
      "screen_name" : "Jalopnik",
      "indices" : [ 7, 16 ],
      "id_str" : "3060631",
      "id" : 3060631
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 51, 59 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32489911747612673",
  "text" : "Loving @jalopnik's new landing page. Reminds me of @twitter's redesign.",
  "id" : 32489911747612673,
  "created_at" : "Tue Feb 01 17:26:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 7, 13 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http://t.co/zghea3P",
      "expanded_url" : "http://www.wired.com/epicenter/2011/02/behind-the-scenes-of-wired-uk-magazines-personalized-covers/",
      "display_url" : "wired.com/epicenter/2011\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "32464554512355328",
  "text" : "I LOVE @wired's personalized UK covers: http://t.co/zghea3P",
  "id" : 32464554512355328,
  "created_at" : "Tue Feb 01 15:45:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Gao",
      "screen_name" : "jasongao",
      "indices" : [ 0, 9 ],
      "id_str" : "11829482",
      "id" : 11829482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32203659022434304",
  "geo" : {
  },
  "id_str" : "32457411193212928",
  "in_reply_to_user_id" : 11829482,
  "text" : "@jasongao How are you aggregating MIT and Harvard emails securely?",
  "id" : 32457411193212928,
  "in_reply_to_status_id" : 32203659022434304,
  "created_at" : "Tue Feb 01 15:17:04 +0000 2011",
  "in_reply_to_screen_name" : "jasongao",
  "in_reply_to_user_id_str" : "11829482",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stocks",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "sex",
      "indices" : [ 34, 38 ]
    }, {
      "text" : "beiber",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "ipad",
      "indices" : [ 47, 52 ]
    }, {
      "text" : "ebay",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "money",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "amazon",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "xbox",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "iphone",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "diploma",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "apple",
      "indices" : [ 97, 103 ]
    }, {
      "text" : "hotels",
      "indices" : [ 104, 111 ]
    }, {
      "text" : "money",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32456664997175296",
  "text" : "How many bots can I bait? #stocks #sex #beiber #ipad #ebay #money #amazon #xbox #iphone #diploma #apple #hotels #money",
  "id" : 32456664997175296,
  "created_at" : "Tue Feb 01 15:14:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]