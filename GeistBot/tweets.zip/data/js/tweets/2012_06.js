Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218886077484765184",
  "in_reply_to_user_id" : 36772968,
  "text" : "@kenyanwanderer unfortunately our guy in charge of manufacturing is out for the weekend! But we'll get stripe some discount codes.",
  "id" : 218886077484765184,
  "created_at" : "Sat Jun 30 01:58:02 +0000 2012",
  "in_reply_to_screen_name" : "thairu",
  "in_reply_to_user_id_str" : "36772968",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 28, 40 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Downtown Project",
      "screen_name" : "DowntownProjLV",
      "indices" : [ 44, 59 ],
      "id_str" : "490968947",
      "id" : 490968947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/kuO5qunq",
      "expanded_url" : "http://downtownproject.com/?p=1958",
      "display_url" : "downtownproject.com/?p=1958"
    } ]
  },
  "geo" : {
  },
  "id_str" : "218853664847175681",
  "text" : "Happy to start teaching. cc @badboyboyce RT @DowntownProjLV: New Story: Vegas--The Skillshare School http://t.co/kuO5qunq",
  "id" : 218853664847175681,
  "created_at" : "Fri Jun 29 23:49:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 2, 11 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Stripe",
      "screen_name" : "stripe",
      "indices" : [ 16, 23 ],
      "id_str" : "102812444",
      "id" : 102812444
    }, {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 35, 40 ],
      "id_str" : "132319630",
      "id" : 132319630
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 55, 62 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/3KnjxdRy",
      "expanded_url" : "http://4sq.com/OJZ4Ns",
      "display_url" : "4sq.com/OJZ4Ns"
    } ]
  },
  "geo" : {
  },
  "id_str" : "218786745163055104",
  "text" : "A @romotive and @stripe collab! RT @sidd: Hacking with @khsieh (@ Romotive HQ) http://t.co/3KnjxdRy",
  "id" : 218786745163055104,
  "created_at" : "Fri Jun 29 19:23:19 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218763233669033984",
  "text" : "Not even Kinesis keyboard users known how to use Kinesis keyboards.",
  "id" : 218763233669033984,
  "created_at" : "Fri Jun 29 17:49:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto Pepe",
      "screen_name" : "albertopepe",
      "indices" : [ 13, 25 ],
      "id_str" : "4142571",
      "id" : 4142571
    }, {
      "name" : "Berkman Center",
      "screen_name" : "berkmancenter",
      "indices" : [ 63, 77 ],
      "id_str" : "14706139",
      "id" : 14706139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/nixh12Ef",
      "expanded_url" : "http://cyber.law.harvard.edu/newsroom/2012_2013_fellows",
      "display_url" : "cyber.law.harvard.edu/newsroom/2012_\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "218595332748099584",
  "text" : "Congrats! RT @albertopepe: Honored and thrilled that I'll be a @berkmancenter fellow next year http://t.co/nixh12Ef",
  "id" : 218595332748099584,
  "created_at" : "Fri Jun 29 06:42:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 3, 9 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218454521700032513",
  "text" : "RT @levie: Google is focused. On everything.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "218427778314403840",
    "text" : "Google is focused. On everything.",
    "id" : 218427778314403840,
    "created_at" : "Thu Jun 28 19:36:55 +0000 2012",
    "user" : {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "protected" : false,
      "id_str" : "914061",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1626898956/twitter_normal.png",
      "id" : 914061,
      "verified" : false
    }
  },
  "id" : 218454521700032513,
  "created_at" : "Thu Jun 28 21:23:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThatAwkwardMoment",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218429086543003648",
  "text" : "#ThatAwkwardMoment when you realize there's a security camera in the elevator you've been dancing alone in.",
  "id" : 218429086543003648,
  "created_at" : "Thu Jun 28 19:42:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1713584, -115.1387288 ]
  },
  "id_str" : "218051383448973312",
  "text" : "Google just said \"and one more thing...\"",
  "id" : 218051383448973312,
  "created_at" : "Wed Jun 27 18:41:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1713584, -115.1387288 ]
  },
  "id_str" : "218045841880006657",
  "text" : "Keynote presenter dress code at Google IO is apparently baggy Lacoste and/or all black.",
  "id" : 218045841880006657,
  "created_at" : "Wed Jun 27 18:19:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1713584, -115.1387288 ]
  },
  "id_str" : "218034153843720192",
  "text" : "Aaaannnd Nexus 7 just killed Kindle Fire at the $199 price point.",
  "id" : 218034153843720192,
  "created_at" : "Wed Jun 27 17:32:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sublime HQ",
      "screen_name" : "sublimehq",
      "indices" : [ 0, 10 ],
      "id_str" : "138034438",
      "id" : 138034438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "217884702378426369",
  "in_reply_to_user_id" : 138034438,
  "text" : "@SublimeHQ has replaced Notepad++ for me. It's... sublime.",
  "id" : 217884702378426369,
  "created_at" : "Wed Jun 27 07:38:55 +0000 2012",
  "in_reply_to_screen_name" : "sublimehq",
  "in_reply_to_user_id_str" : "138034438",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "/usr/lib",
      "screen_name" : "usrlib",
      "indices" : [ 21, 28 ],
      "id_str" : "325160882",
      "id" : 325160882
    }, {
      "name" : "Skillshare",
      "screen_name" : "skillshare",
      "indices" : [ 45, 56 ],
      "id_str" : "171613435",
      "id" : 171613435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/44ADZlnV",
      "expanded_url" : "http://www.skillshare.com/Upgrading-your-Camera/1937839319",
      "display_url" : "skillshare.com/Upgrading-your\u2026"
    }, {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/g0uTPklc",
      "expanded_url" : "http://www.skillshare.com/Fundamentals-of-Photography/1180228559/2036544919",
      "display_url" : "skillshare.com/Fundamentals-o\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1763255, -115.1511615 ]
  },
  "id_str" : "217717127342338049",
  "text" : "Excited to teach. RT @usrlib: Two cool photo @skillshare classes coming up this weekend: http://t.co/44ADZlnV and http://t.co/g0uTPklc",
  "id" : 217717127342338049,
  "created_at" : "Tue Jun 26 20:33:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 3, 12 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "217434374319251458",
  "text" : "RT @Romotive: Know any excellent electrical engineers, designers, or iOS devs? Let us know, we're looking!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "217432092403974146",
    "text" : "Know any excellent electrical engineers, designers, or iOS devs? Let us know, we're looking!",
    "id" : 217432092403974146,
    "created_at" : "Tue Jun 26 01:40:25 +0000 2012",
    "user" : {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "protected" : false,
      "id_str" : "340545195",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2180791949/romo_normal.jpg",
      "id" : 340545195,
      "verified" : false
    }
  },
  "id" : 217434374319251458,
  "created_at" : "Tue Jun 26 01:49:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phu Nguyen",
      "screen_name" : "phun",
      "indices" : [ 28, 33 ],
      "id_str" : "777411",
      "id" : 777411
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/217061279930654720/photo/1",
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/HeG58C3y",
      "media_url" : "http://pbs.twimg.com/media/AwMoFYUCIAI4zsy.jpg",
      "id_str" : "217061279934849026",
      "id" : 217061279934849026,
      "media_url_https" : "https://pbs.twimg.com/media/AwMoFYUCIAI4zsy.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/HeG58C3y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1784464773, -115.2557851933 ]
  },
  "id_str" : "217061279930654720",
  "text" : "New biking kit, courtesy of @phun. http://t.co/HeG58C3y",
  "id" : 217061279930654720,
  "created_at" : "Mon Jun 25 01:06:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swappa",
      "screen_name" : "swappa",
      "indices" : [ 76, 83 ],
      "id_str" : "232409384",
      "id" : 232409384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/jjHf1SsP",
      "expanded_url" : "http://swappa.com/listing/AGK408/view",
      "display_url" : "swappa.com/listing/AGK408\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217030785969045504",
  "text" : "Selling my Galaxy Nexus because it's too damn big. http://t.co/jjHf1SsP via @swappa",
  "id" : 217030785969045504,
  "created_at" : "Sun Jun 24 23:05:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 41 ],
      "url" : "https://t.co/Fccgvz46",
      "expanded_url" : "https://github.com/mattdiamond/fuckitjs",
      "display_url" : "github.com/mattdiamond/fu\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "216655315259768832",
  "text" : "FuckItJS on github. https://t.co/Fccgvz46",
  "id" : 216655315259768832,
  "created_at" : "Sat Jun 23 22:13:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216643381277888513",
  "text" : "Happy Birthday, Dr. Turing.",
  "id" : 216643381277888513,
  "created_at" : "Sat Jun 23 21:26:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Conner",
      "screen_name" : "adamconner",
      "indices" : [ 3, 14 ],
      "id_str" : "1933161",
      "id" : 1933161
    }, {
      "name" : "Drunk Predator Drone",
      "screen_name" : "drunkenpredator",
      "indices" : [ 16, 32 ],
      "id_str" : "252787550",
      "id" : 252787550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216635198295654401",
  "text" : "RT @adamconner: @drunkenpredator \"the aliens have infrared sensors\" the resistance says IN FRONT OF THEIR GIANT BONFIRE",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Drunk Predator Drone",
        "screen_name" : "drunkenpredator",
        "indices" : [ 0, 16 ],
        "id_str" : "252787550",
        "id" : 252787550
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "216633298166878211",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.904334163, -77.0259912872 ]
    },
    "id_str" : "216633587435454464",
    "in_reply_to_user_id" : 252787550,
    "text" : "@drunkenpredator \"the aliens have infrared sensors\" the resistance says IN FRONT OF THEIR GIANT BONFIRE",
    "id" : 216633587435454464,
    "in_reply_to_status_id" : 216633298166878211,
    "created_at" : "Sat Jun 23 20:47:26 +0000 2012",
    "in_reply_to_screen_name" : "drunkenpredator",
    "in_reply_to_user_id_str" : "252787550",
    "user" : {
      "name" : "Adam Conner",
      "screen_name" : "adamconner",
      "protected" : false,
      "id_str" : "1933161",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2652598837/3533d4f975edc03c96db669a0fb8d362_normal.jpeg",
      "id" : 1933161,
      "verified" : false
    }
  },
  "id" : 216635198295654401,
  "created_at" : "Sat Jun 23 20:53:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216615411314200576",
  "text" : "Internet Explorer y u no load javascript?!",
  "id" : 216615411314200576,
  "created_at" : "Sat Jun 23 19:35:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/iZURlEkE",
      "expanded_url" : "http://romotive.com/about",
      "display_url" : "romotive.com/about"
    } ]
  },
  "geo" : {
  },
  "id_str" : "216392328481488896",
  "text" : "Put up some new team pics at http://t.co/iZURlEkE",
  "id" : 216392328481488896,
  "created_at" : "Sat Jun 23 04:48:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cenciotti",
      "screen_name" : "cencio4",
      "indices" : [ 24, 32 ],
      "id_str" : "53138772",
      "id" : 53138772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/pkd4VCfh",
      "expanded_url" : "http://wp.me/pEfC-34g",
      "display_url" : "wp.me/pEfC-34g"
    } ]
  },
  "geo" : {
  },
  "id_str" : "216303251413401601",
  "text" : "This could get ugly. RT @cencio4: Turkish RF-4E Phantom shot down by Syrian Air Defense. Known and unknown facts. http://t.co/pkd4VCfh",
  "id" : 216303251413401601,
  "created_at" : "Fri Jun 22 22:54:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216292645784395776",
  "text" : "\"The only time I would speak [when Apple started] was to introduce the Apple I &amp; II boards bc Jobs didn't know enough about comps.\" - Woz",
  "id" : 216292645784395776,
  "created_at" : "Fri Jun 22 22:12:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeannie Cho Lee",
      "screen_name" : "JeannieChoLee",
      "indices" : [ 49, 63 ],
      "id_str" : "47807522",
      "id" : 47807522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/2wn76fpD",
      "expanded_url" : "http://yfrog.com/mn22umej",
      "display_url" : "yfrog.com/mn22umej"
    } ]
  },
  "geo" : {
  },
  "id_str" : "216290180598988800",
  "text" : "I hope you didn't rub it. Students pee on it. RT @JeannieChoLee: Harvard statue w toe rubbed until gold... http://t.co/2wn76fpD",
  "id" : 216290180598988800,
  "created_at" : "Fri Jun 22 22:02:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Yang",
      "screen_name" : "originalspin",
      "indices" : [ 3, 16 ],
      "id_str" : "14278608",
      "id" : 14278608
    }, {
      "name" : "Speakeasy",
      "screen_name" : "WSJspeakeasy",
      "indices" : [ 61, 74 ],
      "id_str" : "41204528",
      "id" : 41204528
    }, {
      "name" : "The AAWW",
      "screen_name" : "aaww",
      "indices" : [ 86, 91 ],
      "id_str" : "29524628",
      "id" : 29524628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216287950001029120",
  "text" : "RT @originalspin: Can you hack China's SATs? New contest via @WSJSpeakeasy's TaoJones/@AAWW's flagship webmag TheMargins\u2014HAO NAO GAOKAO? ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Speakeasy",
        "screen_name" : "WSJspeakeasy",
        "indices" : [ 43, 56 ],
        "id_str" : "41204528",
        "id" : 41204528
      }, {
        "name" : "The AAWW",
        "screen_name" : "aaww",
        "indices" : [ 68, 73 ],
        "id_str" : "29524628",
        "id" : 29524628
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/cXnPo8BC",
        "expanded_url" : "http://orsp.in/NsNe7A",
        "display_url" : "orsp.in/NsNe7A"
      } ]
    },
    "geo" : {
    },
    "id_str" : "216271026999398401",
    "text" : "Can you hack China's SATs? New contest via @WSJSpeakeasy's TaoJones/@AAWW's flagship webmag TheMargins\u2014HAO NAO GAOKAO? http://t.co/cXnPo8BC",
    "id" : 216271026999398401,
    "created_at" : "Fri Jun 22 20:46:45 +0000 2012",
    "user" : {
      "name" : "Jeff Yang",
      "screen_name" : "originalspin",
      "protected" : false,
      "id_str" : "14278608",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3436100051/ea1b03b64529f2bb026830f39ad57ce0_normal.png",
      "id" : 14278608,
      "verified" : false
    }
  },
  "id" : 216287950001029120,
  "created_at" : "Fri Jun 22 21:54:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Wozniak",
      "screen_name" : "stevewoz",
      "indices" : [ 9, 18 ],
      "id_str" : "22938914",
      "id" : 22938914
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 38, 47 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/216280895462715392/photo/1",
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/DFjQ0stb",
      "media_url" : "http://pbs.twimg.com/media/AwBiVBoCMAAre_w.jpg",
      "id_str" : "216280895466909696",
      "id" : 216280895466909696,
      "media_url_https" : "https://pbs.twimg.com/media/AwBiVBoCMAAre_w.jpg",
      "sizes" : [ {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/DFjQ0stb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216280895462715392",
  "text" : "Ran into @stevewoz backstage with the @romotive team. Rocking the vacuum tube watch. http://t.co/DFjQ0stb",
  "id" : 216280895462715392,
  "created_at" : "Fri Jun 22 21:26:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/216094315024355328/photo/1",
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/mqaC5iTm",
      "media_url" : "http://pbs.twimg.com/media/Av-4onVCEAAXuML.jpg",
      "id_str" : "216094315028549632",
      "id" : 216094315028549632,
      "media_url_https" : "https://pbs.twimg.com/media/Av-4onVCEAAXuML.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/mqaC5iTm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216094315024355328",
  "text" : "3D printer running in the dark. http://t.co/mqaC5iTm",
  "id" : 216094315024355328,
  "created_at" : "Fri Jun 22 09:04:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Zarick",
      "screen_name" : "DanielZarick",
      "indices" : [ 3, 16 ],
      "id_str" : "16145710",
      "id" : 16145710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "216057178904211456",
  "text" : "RT @DanielZarick: I'm glad that OKC can finally go back to meaning OkCupid. (Sorry Oklahoma City)",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 41.9260603459, -87.6504584871 ]
    },
    "id_str" : "216023130328662017",
    "text" : "I'm glad that OKC can finally go back to meaning OkCupid. (Sorry Oklahoma City)",
    "id" : 216023130328662017,
    "created_at" : "Fri Jun 22 04:21:42 +0000 2012",
    "user" : {
      "name" : "Daniel Zarick",
      "screen_name" : "DanielZarick",
      "protected" : false,
      "id_str" : "16145710",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1541780054/dz-profile-image_normal.png",
      "id" : 16145710,
      "verified" : false
    }
  },
  "id" : 216057178904211456,
  "created_at" : "Fri Jun 22 06:37:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215993062839697409",
  "text" : "Overheard at tech startup: \"I forgot my iPad so I had to take a legacy poop.\"",
  "id" : 215993062839697409,
  "created_at" : "Fri Jun 22 02:22:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Bieber",
      "screen_name" : "justinbieber",
      "indices" : [ 63, 76 ],
      "id_str" : "27260086",
      "id" : 27260086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/82gS8zD4",
      "expanded_url" : "http://www.directlyrics.com/justin-bieber-boyfriend-lyrics.html",
      "display_url" : "directlyrics.com/justin-bieber-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "215970913747877889",
  "text" : "How's this for some unintentional sexism: imagine Boyfriend by @JustinBieber sung by a girl. You'll be creeped out. http://t.co/82gS8zD4",
  "id" : 215970913747877889,
  "created_at" : "Fri Jun 22 00:54:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215902374441664512",
  "text" : "Blackberry 10 won't have hardware keyboard. So instead of a better Blackberry, it's now a shittier iphone. Good job RIM.",
  "id" : 215902374441664512,
  "created_at" : "Thu Jun 21 20:21:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215900368654172160",
  "text" : "The new Swiftkey 3 keyboard finally makes the space bar large enough to hit without surgical precision.",
  "id" : 215900368654172160,
  "created_at" : "Thu Jun 21 20:13:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215872596439347202",
  "text" : "Twitter was down earlier, but I couldn't tweet about it.",
  "id" : 215872596439347202,
  "created_at" : "Thu Jun 21 18:23:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakerBot",
      "screen_name" : "makerbot",
      "indices" : [ 9, 18 ],
      "id_str" : "22021097",
      "id" : 22021097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215689609336733697",
  "text" : "Having a @MakerBot in the office is really cutting into my sleep obligations.",
  "id" : 215689609336733697,
  "created_at" : "Thu Jun 21 06:16:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/fHIlEZde",
      "expanded_url" : "http://www.thecrimson.com/article/2012/6/20/amc-loews-square-closing/",
      "display_url" : "thecrimson.com/article/2012/6\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "215643523049984000",
  "text" : "This is a damn tragedy! Closing of the Harvard Sq movie theater. http://t.co/fHIlEZde",
  "id" : 215643523049984000,
  "created_at" : "Thu Jun 21 03:13:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/yo978pn4",
      "expanded_url" : "http://makerfaire.com/newyork/2012/",
      "display_url" : "makerfaire.com/newyork/2012/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "215627789959827457",
  "text" : "Anyone want to join me for MakerFaire 2012 in NY this Sept? http://t.co/yo978pn4",
  "id" : 215627789959827457,
  "created_at" : "Thu Jun 21 02:10:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Helfferich",
      "screen_name" : "JoshHelfferich",
      "indices" : [ 3, 18 ],
      "id_str" : "563200400",
      "id" : 563200400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215622840232321024",
  "text" : "RT @JoshHelfferich: I don't like babies. They're like beta people.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "215622180715765762",
    "text" : "I don't like babies. They're like beta people.",
    "id" : 215622180715765762,
    "created_at" : "Thu Jun 21 01:48:28 +0000 2012",
    "user" : {
      "name" : "Josh Helfferich",
      "screen_name" : "JoshHelfferich",
      "protected" : false,
      "id_str" : "563200400",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2735503490/380fa0452d92f9dd814e8aa079799783_normal.jpeg",
      "id" : 563200400,
      "verified" : false
    }
  },
  "id" : 215622840232321024,
  "created_at" : "Thu Jun 21 01:51:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontsueme",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/GEtmfSbD",
      "expanded_url" : "http://arstechnica.com/tech-policy/2012/06/doubling-down-funnyjunk-lawyer-to-subpoena-ars-twitter/",
      "display_url" : "arstechnica.com/tech-policy/20\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "215617305252605952",
  "text" : "Internet joke of the week: @charlescarreon #dontsueme http://t.co/GEtmfSbD",
  "id" : 215617305252605952,
  "created_at" : "Thu Jun 21 01:29:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/TtC9k7wS",
      "expanded_url" : "http://blog.makezine.com/2012/06/20/lego-turing-machine-2",
      "display_url" : "blog.makezine.com/2012/06/20/leg\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "215587557436702720",
  "text" : "Lego Turing machine blowing my mind. http://t.co/TtC9k7wS",
  "id" : 215587557436702720,
  "created_at" : "Wed Jun 20 23:30:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215354910315778050",
  "text" : "Thiel has launched Palantir,  &lt;20 Fellowship, and now Mithril Fund. I'm going to cut to the chase and start The One Fund.",
  "id" : 215354910315778050,
  "created_at" : "Wed Jun 20 08:06:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 31, 40 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/c7JGsvAR",
      "expanded_url" : "http://gizmodo.com/5919521",
      "display_url" : "gizmodo.com/5919521"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1707429, -115.1397036 ]
  },
  "id_str" : "215142070761963520",
  "text" : "That's quite the hyperbole. RT @Techmeme: Microsoft Surface Just Made the MacBook Air and the iPad Look Obsolete http://t.co/c7JGsvAR",
  "id" : 215142070761963520,
  "created_at" : "Tue Jun 19 18:00:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 55, 61 ],
      "id_str" : "14208617",
      "id" : 14208617
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/robgo/status/215126073480986625/photo/1",
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/6Sp3DKFn",
      "media_url" : "http://pbs.twimg.com/media/AvxIBigCQAApVGo.jpg",
      "id_str" : "215126073485180928",
      "id" : 215126073485180928,
      "media_url_https" : "https://pbs.twimg.com/media/AvxIBigCQAApVGo.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/6Sp3DKFn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1707666, -115.1396756 ]
  },
  "id_str" : "215138050890674176",
  "text" : "Camry is still most popular car among millionaires. RT @robgo: Glad I didn't drive my Camry to this event http://t.co/6Sp3DKFn",
  "id" : 215138050890674176,
  "created_at" : "Tue Jun 19 17:44:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215130412534603777",
  "text" : "Over a year later and Verizon STILL has no good Windows Phone.",
  "id" : 215130412534603777,
  "created_at" : "Tue Jun 19 17:14:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 27, 36 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/HaLBk4ae",
      "expanded_url" : "http://instagr.am/p/MEBYQ6PAxV/",
      "display_url" : "instagr.am/p/MEBYQ6PAxV/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "215125078818557952",
  "text" : "Prototype to product, with @romotive. http://t.co/HaLBk4ae",
  "id" : 215125078818557952,
  "created_at" : "Tue Jun 19 16:53:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Lombardi",
      "screen_name" : "threefour",
      "indices" : [ 3, 13 ],
      "id_str" : "6163",
      "id" : 6163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "214920565310500864",
  "text" : "RT @threefour: \"We're guessing MSFT will push the UX instead of specs, and it's about time the industry moved in that direction.\" http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/fj5LXiea",
        "expanded_url" : "http://m.engadget.com/2012/06/18/microsoft-surface-tablets-the-differences-between-rt-and-window/",
        "display_url" : "m.engadget.com/2012/06/18/mic\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "214893913964675072",
    "text" : "\"We're guessing MSFT will push the UX instead of specs, and it's about time the industry moved in that direction.\" http://t.co/fj5LXiea",
    "id" : 214893913964675072,
    "created_at" : "Tue Jun 19 01:34:36 +0000 2012",
    "user" : {
      "name" : "Victor Lombardi",
      "screen_name" : "threefour",
      "protected" : false,
      "id_str" : "6163",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/683921634/Victor.Lombardi.250px.crop_normal.jpg",
      "id" : 6163,
      "verified" : false
    }
  },
  "id" : 214920565310500864,
  "created_at" : "Tue Jun 19 03:20:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/214920210975698944/photo/1",
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/2QlyWZR5",
      "media_url" : "http://pbs.twimg.com/media/AvuMyw7CMAAJ9nT.jpg",
      "id_str" : "214920210984087552",
      "id" : 214920210984087552,
      "media_url_https" : "https://pbs.twimg.com/media/AvuMyw7CMAAJ9nT.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com/2QlyWZR5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "214920210975698944",
  "text" : "It looks like Apple's designers didn't have any f!cks left to give when they designed the iOS 6 stopwatch... http://t.co/2QlyWZR5",
  "id" : 214920210975698944,
  "created_at" : "Tue Jun 19 03:19:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/214915228259983361/photo/1",
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/1jz61Gcx",
      "media_url" : "http://pbs.twimg.com/media/AvuIQu2CIAEoO8E.jpg",
      "id_str" : "214915228264177665",
      "id" : 214915228264177665,
      "media_url_https" : "https://pbs.twimg.com/media/AvuIQu2CIAEoO8E.jpg",
      "sizes" : [ {
        "h" : 423,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/1jz61Gcx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "214915228259983361",
  "text" : "Congrats to China and the taikonauts aboard the Shenzhou/Tiangong docking. http://t.co/1jz61Gcx",
  "id" : 214915228259983361,
  "created_at" : "Tue Jun 19 02:59:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikhil Kalghatgi",
      "screen_name" : "NikhilKal",
      "indices" : [ 0, 10 ],
      "id_str" : "13369702",
      "id" : 13369702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "214800111035879424",
  "in_reply_to_user_id" : 13369702,
  "text" : "@NikhilKal nice to finally meet you in person!",
  "id" : 214800111035879424,
  "created_at" : "Mon Jun 18 19:21:51 +0000 2012",
  "in_reply_to_screen_name" : "NikhilKal",
  "in_reply_to_user_id_str" : "13369702",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/214780635070472192/photo/1",
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/Dp6HlRuU",
      "media_url" : "http://pbs.twimg.com/media/AvsN2YJCIAAZ9Kb.jpg",
      "id_str" : "214780635074666496",
      "id" : 214780635074666496,
      "media_url_https" : "https://pbs.twimg.com/media/AvsN2YJCIAAZ9Kb.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/Dp6HlRuU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1712493, -115.1369733 ]
  },
  "id_str" : "214780635070472192",
  "text" : "The desk of a mobile developer. http://t.co/Dp6HlRuU",
  "id" : 214780635070472192,
  "created_at" : "Mon Jun 18 18:04:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9313876, -78.7475583 ]
  },
  "id_str" : "214669961589825536",
  "text" : "Back-to-front is clearly a nonoptimal airplane boarding order. Shouldn't it be window-to-aisle?",
  "id" : 214669961589825536,
  "created_at" : "Mon Jun 18 10:44:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/TTph1E3J",
      "expanded_url" : "http://www.nytimes.com/2012/06/17/magazine/who-made-that-soy-sauce-dispenser.html?_r=1",
      "display_url" : "nytimes.com/2012/06/17/mag\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "214603237418999808",
  "text" : "The origin of an enduring piece of industrial design: the Kikkoman bottle. http://t.co/TTph1E3J",
  "id" : 214603237418999808,
  "created_at" : "Mon Jun 18 06:19:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Rumennik",
      "screen_name" : "djdan85",
      "indices" : [ 9, 17 ],
      "id_str" : "22803575",
      "id" : 22803575
    }, {
      "name" : "Life should bcalm\u2122",
      "screen_name" : "bcalm",
      "indices" : [ 22, 28 ],
      "id_str" : "449232786",
      "id" : 449232786
    }, {
      "name" : "Harvard i-lab",
      "screen_name" : "innovationlab",
      "indices" : [ 90, 104 ],
      "id_str" : "246493616",
      "id" : 246493616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "214519945021763585",
  "text" : "Congrats @djdan85! RT @bcalm: Great news to share with you: bcalm is now available in the @innovationlab",
  "id" : 214519945021763585,
  "created_at" : "Mon Jun 18 00:48:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Chun",
      "screen_name" : "msjchun",
      "indices" : [ 3, 11 ],
      "id_str" : "245036646",
      "id" : 245036646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "214432701292359683",
  "text" : "RT @msjchun: Art critics get together and talk about Form and Structure and Meaning. Artists get together to talk about where to buy che ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "214428997755469824",
    "text" : "Art critics get together and talk about Form and Structure and Meaning. Artists get together to talk about where to buy cheap turpentine.",
    "id" : 214428997755469824,
    "created_at" : "Sun Jun 17 18:47:11 +0000 2012",
    "user" : {
      "name" : "Jane Chun",
      "screen_name" : "msjchun",
      "protected" : false,
      "id_str" : "245036646",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3509493052/fde86a1eb910bab0db0a76a023102eb9_normal.jpeg",
      "id" : 245036646,
      "verified" : false
    }
  },
  "id" : 214432701292359683,
  "created_at" : "Sun Jun 17 19:01:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 23, 29 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "213809293747699715",
  "text" : "RT @hugovanvuuren: RT \u201C@levie: Instagram: $1B. Yammer: $1.2B.  And that, my friends, is why you do enterprise software.\u201D",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aaron Levie",
        "screen_name" : "levie",
        "indices" : [ 4, 10 ],
        "id_str" : "914061",
        "id" : 914061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "213807990103474176",
    "text" : "RT \u201C@levie: Instagram: $1B. Yammer: $1.2B.  And that, my friends, is why you do enterprise software.\u201D",
    "id" : 213807990103474176,
    "created_at" : "Sat Jun 16 01:39:31 +0000 2012",
    "user" : {
      "name" : "Hugo Van Vuuren",
      "screen_name" : "hvgo",
      "protected" : false,
      "id_str" : "18413446",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3363715470/f4303415b415b9f80a8081bb8d9ffcfd_normal.jpeg",
      "id" : 18413446,
      "verified" : false
    }
  },
  "id" : 213809293747699715,
  "created_at" : "Sat Jun 16 01:44:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/213154969287794688/photo/1",
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/usAqdKYM",
      "media_url" : "http://pbs.twimg.com/media/AvVHULLCIAIcBem.jpg",
      "id_str" : "213154969291988994",
      "id" : 213154969291988994,
      "media_url_https" : "https://pbs.twimg.com/media/AvVHULLCIAIcBem.jpg",
      "sizes" : [ {
        "h" : 1936,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/usAqdKYM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0074098, -78.6998368 ]
  },
  "id_str" : "213154969287794688",
  "text" : "C130's spotted flying low over Buffalo, NY. http://t.co/usAqdKYM",
  "id" : 213154969287794688,
  "created_at" : "Thu Jun 14 06:24:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9919461, -78.7250704 ]
  },
  "id_str" : "212969634503208962",
  "text" : "No conversation is quite as awkward as small talk with a dental hygienist during a cleaning.",
  "id" : 212969634503208962,
  "created_at" : "Wed Jun 13 18:08:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 4, 12 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0072687, -78.6995427 ]
  },
  "id_str" : "212682383680475136",
  "text" : "New @spotify app for android has 320kbps streaming. Eargasm.",
  "id" : 212682383680475136,
  "created_at" : "Tue Jun 12 23:06:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Zittrain",
      "screen_name" : "zittrain",
      "indices" : [ 3, 12 ],
      "id_str" : "1039531",
      "id" : 1039531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/P1Bp4JO8",
      "expanded_url" : "http://theoatmeal.com/blog/funnyjunk_letter",
      "display_url" : "theoatmeal.com/blog/funnyjunk\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "212582654497923072",
  "text" : "RT @zittrain: Funnyjunk v. Oatmeal may become a real case. Funnyjunk appears to be junk, but funny-strange, not ha-ha.  http://t.co/P1Bp4JO8",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http://t.co/P1Bp4JO8",
        "expanded_url" : "http://theoatmeal.com/blog/funnyjunk_letter",
        "display_url" : "theoatmeal.com/blog/funnyjunk\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "212547831611920385",
    "text" : "Funnyjunk v. Oatmeal may become a real case. Funnyjunk appears to be junk, but funny-strange, not ha-ha.  http://t.co/P1Bp4JO8",
    "id" : 212547831611920385,
    "created_at" : "Tue Jun 12 14:12:06 +0000 2012",
    "user" : {
      "name" : "Jonathan Zittrain",
      "screen_name" : "zittrain",
      "protected" : false,
      "id_str" : "1039531",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1091786753/weird_expression_medium_normal.jpg",
      "id" : 1039531,
      "verified" : false
    }
  },
  "id" : 212582654497923072,
  "created_at" : "Tue Jun 12 16:30:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 3, 18 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "212427143622303745",
  "text" : "RT @NaveenSrivatsa: The disappearance of mozzarella sticks from the Burger King menu deserves at least as much attention as the Commerce ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "212380787457277952",
    "text" : "The disappearance of mozzarella sticks from the Burger King menu deserves at least as much attention as the Commerce Secretary's leave.",
    "id" : 212380787457277952,
    "created_at" : "Tue Jun 12 03:08:20 +0000 2012",
    "user" : {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "protected" : true,
      "id_str" : "18107808",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1745313225/IMG_0625edited2_normal.jpg",
      "id" : 18107808,
      "verified" : false
    }
  },
  "id" : 212427143622303745,
  "created_at" : "Tue Jun 12 06:12:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/6J2CMT6R",
      "expanded_url" : "http://dvice.com/archives/2012/06/check-out-airbu.php",
      "display_url" : "dvice.com/archives/2012/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.968075, -78.6950486 ]
  },
  "id_str" : "212356936614686720",
  "text" : "Airbus' crazy double fuselage biplane patent is approved. http://t.co/6J2CMT6R",
  "id" : 212356936614686720,
  "created_at" : "Tue Jun 12 01:33:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSJ Life & Style",
      "screen_name" : "WSJLife",
      "indices" : [ 22, 30 ],
      "id_str" : "28182280",
      "id" : 28182280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/5BipO8VA",
      "expanded_url" : "http://blogs.wsj.com/scene/2012/05/29/an-unappreciated-scene-starts-to-shine/",
      "display_url" : "blogs.wsj.com/scene/2012/05/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "209663228425416704",
  "text" : "Some Taipei love from @WSJlife. Although I can't recommend it in the summertime. http://t.co/5BipO8VA",
  "id" : 209663228425416704,
  "created_at" : "Mon Jun 04 15:09:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life should bcalm\u2122",
      "screen_name" : "bcalm",
      "indices" : [ 31, 37 ],
      "id_str" : "449232786",
      "id" : 449232786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/WUjlO4Yl",
      "expanded_url" : "http://simplynoise.com",
      "display_url" : "simplynoise.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "209661006622900225",
  "text" : "This got me through finals! RT @bcalm: We've started using the excellent white noise generator http://t.co/WUjlO4Yl to relax and focus.",
  "id" : 209661006622900225,
  "created_at" : "Mon Jun 04 15:00:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life should bcalm\u2122",
      "screen_name" : "bcalm",
      "indices" : [ 18, 24 ],
      "id_str" : "449232786",
      "id" : 449232786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bevnetlive",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/1PX37Nty",
      "expanded_url" : "http://livestream.com/bevnetcom",
      "display_url" : "livestream.com/bevnetcom"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0073, -78.6994135 ]
  },
  "id_str" : "209503956953600000",
  "text" : "Good luck Dan! RT @bcalm: We are in the #bevnetlive New Beverage Showdown Monday at 140pm EST. Tune in to http://t.co/1PX37Nty",
  "id" : 209503956953600000,
  "created_at" : "Mon Jun 04 04:36:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Mao",
      "screen_name" : "isaac",
      "indices" : [ 3, 9 ],
      "id_str" : "56833",
      "id" : 56833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "209500084289810432",
  "text" : "RT @isaac: Wei8o cens*rship t0tally chan&amp;ed lingu!stic p@ttern of Chinese #8964",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "209452685336911873",
    "text" : "Wei8o cens*rship t0tally chan&amp;ed lingu!stic p@ttern of Chinese #8964",
    "id" : 209452685336911873,
    "created_at" : "Mon Jun 04 01:13:06 +0000 2012",
    "user" : {
      "name" : "Isaac Mao",
      "screen_name" : "isaac",
      "protected" : false,
      "id_str" : "56833",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2507894059/lefpj52q9fkv7cgmlqc8_normal.jpeg",
      "id" : 56833,
      "verified" : false
    }
  },
  "id" : 209500084289810432,
  "created_at" : "Mon Jun 04 04:21:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/06mHKTka",
      "expanded_url" : "http://www.theverge.com/2012/6/3/3061524/hp-envy-spectre-xt-pre-order-availability-date",
      "display_url" : "theverge.com/2012/6/3/30615\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "209433244964364288",
  "text" : "Wow, HP isn't even trying to pretend to not copy MacBooks anymore. http://t.co/06mHKTka",
  "id" : 209433244964364288,
  "created_at" : "Sun Jun 03 23:55:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean",
      "screen_name" : "deanshu",
      "indices" : [ 0, 8 ],
      "id_str" : "231525350",
      "id" : 231525350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209116797373399042",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0073009, -78.6994142 ]
  },
  "id_str" : "209224792715444224",
  "in_reply_to_user_id" : 231525350,
  "text" : "@deanshu HTC One X is probably as close as you'll get to iPhone build quality.",
  "id" : 209224792715444224,
  "in_reply_to_status_id" : 209116797373399042,
  "created_at" : "Sun Jun 03 10:07:32 +0000 2012",
  "in_reply_to_screen_name" : "deanshu",
  "in_reply_to_user_id_str" : "231525350",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 20, 25 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0072997, -78.6994137 ]
  },
  "id_str" : "209224463504506880",
  "text" : "I should have taken @kane when I had the chance. \"Hsieh\" is damn hard to spell phonetically.",
  "id" : 209224463504506880,
  "created_at" : "Sun Jun 03 10:06:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/209061258404704256/photo/1",
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/Rd5PnO4p",
      "media_url" : "http://pbs.twimg.com/media/Aua8G1vCMAE_UqH.jpg",
      "id_str" : "209061258408898561",
      "id" : 209061258408898561,
      "media_url_https" : "https://pbs.twimg.com/media/Aua8G1vCMAE_UqH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/Rd5PnO4p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0072997, -78.6994137 ]
  },
  "id_str" : "209061258404704256",
  "text" : "Dinner at home. Fresh baozi! http://t.co/Rd5PnO4p",
  "id" : 209061258404704256,
  "created_at" : "Sat Jun 02 23:17:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keller Rinaudo",
      "screen_name" : "KellerRinaudo",
      "indices" : [ 71, 85 ],
      "id_str" : "128968036",
      "id" : 128968036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/8QbXTz3b",
      "expanded_url" : "http://www.theogdenst.com/",
      "display_url" : "theogdenst.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "209039460510351360",
  "in_reply_to_user_id" : 36772968,
  "text" : "@kenyanwanderer Romo's based in The Ogden, downtown. Hopefully you and @KellerRinaudo can meet up halfway http://t.co/8QbXTz3b",
  "id" : 209039460510351360,
  "created_at" : "Sat Jun 02 21:51:05 +0000 2012",
  "in_reply_to_screen_name" : "thairu",
  "in_reply_to_user_id_str" : "36772968",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stripe",
      "screen_name" : "stripe",
      "indices" : [ 61, 68 ],
      "id_str" : "102812444",
      "id" : 102812444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209023975672643587",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0072799, -78.6993968 ]
  },
  "id_str" : "209025580253978624",
  "in_reply_to_user_id" : 36772968,
  "text" : "@kenyanwanderer you'll love that we're moving from paypal to @stripe for Romo sales!",
  "id" : 209025580253978624,
  "in_reply_to_status_id" : 209023975672643587,
  "created_at" : "Sat Jun 02 20:55:56 +0000 2012",
  "in_reply_to_screen_name" : "thairu",
  "in_reply_to_user_id_str" : "36772968",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 59, 68 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208792259909521409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0072997, -78.6994137 ]
  },
  "id_str" : "208833102661951488",
  "in_reply_to_user_id" : 36772968,
  "text" : "@kenyanwanderer while you're in Vegas have you checked out @Romotive?",
  "id" : 208833102661951488,
  "in_reply_to_status_id" : 208792259909521409,
  "created_at" : "Sat Jun 02 08:11:06 +0000 2012",
  "in_reply_to_screen_name" : "thairu",
  "in_reply_to_user_id_str" : "36772968",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "208740960765607936",
  "text" : "Help twitterverse! Who are the biggest contract web dev companies? Where is this info available?",
  "id" : 208740960765607936,
  "created_at" : "Sat Jun 02 02:04:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/5VoIbRZD",
      "expanded_url" : "http://cargocollective.com/jayse/Avengers",
      "display_url" : "cargocollective.com/jayse/Avengers"
    } ]
  },
  "geo" : {
  },
  "id_str" : "208651136243216385",
  "text" : "The GUIs of The Avengers. Done in Illustrator, After Effects, and Cinema 4D. http://t.co/5VoIbRZD",
  "id" : 208651136243216385,
  "created_at" : "Fri Jun 01 20:08:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9921176, -78.6975156 ]
  },
  "id_str" : "208644080887017472",
  "text" : "East Amherst, NY now has a Five Guys AND a Chipotles. Moving on up in the world.",
  "id" : 208644080887017472,
  "created_at" : "Fri Jun 01 19:39:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Liu",
      "screen_name" : "eliseliu",
      "indices" : [ 24, 33 ],
      "id_str" : "14458332",
      "id" : 14458332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0073, -78.6994138 ]
  },
  "id_str" : "208505410892742658",
  "text" : "A metalist of lists! RT @eliseliu: Realized I've begun to think in lists: to make, to buy, to toss, to eat, to say, to remember, to forget",
  "id" : 208505410892742658,
  "created_at" : "Fri Jun 01 10:28:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle Team",
      "screen_name" : "AmazonKindle",
      "indices" : [ 1, 14 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.007299, -78.6994127 ]
  },
  "id_str" : "208504066215657472",
  "text" : ".@AmazonKindle I don't mind the ads, but how about some relevance? Oil change ad for a non car owner in the wrong state? Awkward.",
  "id" : 208504066215657472,
  "created_at" : "Fri Jun 01 10:23:37 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 3, 12 ],
      "id_str" : "817386",
      "id" : 817386
    }, {
      "name" : "Nate Anderson",
      "screen_name" : "NateXAnderson",
      "indices" : [ 73, 87 ],
      "id_str" : "27675722",
      "id" : 27675722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/q0akNRs2",
      "expanded_url" : "http://arstechnica.com/tech-policy/2012/06/confirmed-us-israel-created-stuxnet-lost-control-of-it/",
      "display_url" : "arstechnica.com/tech-policy/20\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "208502416914661376",
  "text" : "RT @Techmeme: Confirmed: US, Israel created Stuxnet, lost control of it (@natexanderson / Ars Technica) http://t.co/q0akNRs2 http://t.co ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://techmeme.com/\" rel=\"nofollow\">Techmeme</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nate Anderson",
        "screen_name" : "NateXAnderson",
        "indices" : [ 59, 73 ],
        "id_str" : "27675722",
        "id" : 27675722
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/q0akNRs2",
        "expanded_url" : "http://arstechnica.com/tech-policy/2012/06/confirmed-us-israel-created-stuxnet-lost-control-of-it/",
        "display_url" : "arstechnica.com/tech-policy/20\u2026"
      }, {
        "indices" : [ 111, 131 ],
        "url" : "http://t.co/zIlzvefW",
        "expanded_url" : "http://www.techmeme.com/120601/p11#a120601p11",
        "display_url" : "techmeme.com/120601/p11#a12\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "208500876342607873",
    "text" : "Confirmed: US, Israel created Stuxnet, lost control of it (@natexanderson / Ars Technica) http://t.co/q0akNRs2 http://t.co/zIlzvefW",
    "id" : 208500876342607873,
    "created_at" : "Fri Jun 01 10:10:57 +0000 2012",
    "user" : {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "protected" : false,
      "id_str" : "817386",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1783187293/techmeme_tw_av_normal",
      "id" : 817386,
      "verified" : false
    }
  },
  "id" : 208502416914661376,
  "created_at" : "Fri Jun 01 10:17:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]