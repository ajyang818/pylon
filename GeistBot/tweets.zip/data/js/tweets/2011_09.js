Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slow",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119493831908528128",
  "text" : "Ohhh I JUST got the Kindle/Fire nomenclature. #slow",
  "id" : 119493831908528128,
  "created_at" : "Thu Sep 29 19:28:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Anderson",
      "screen_name" : "chr1sa",
      "indices" : [ 3, 10 ],
      "id_str" : "17595439",
      "id" : 17595439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119456896288694273",
  "text" : "RT @chr1sa: Why is Switzerland so strong in robotics? Watchmakers looking 4 next mechanical marvels, sez swiss Sabine Hauert (Robots Pod ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "119438792833769472",
    "text" : "Why is Switzerland so strong in robotics? Watchmakers looking 4 next mechanical marvels, sez swiss Sabine Hauert (Robots Podcast) at lunch",
    "id" : 119438792833769472,
    "created_at" : "Thu Sep 29 15:50:01 +0000 2011",
    "user" : {
      "name" : "Chris Anderson",
      "screen_name" : "chr1sa",
      "protected" : false,
      "id_str" : "17595439",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/696043718/chrisanderson_normal.jpg",
      "id" : 17595439,
      "verified" : true
    }
  },
  "id" : 119456896288694273,
  "created_at" : "Thu Sep 29 17:01:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119104565818830848",
  "text" : "Amazon Fire and a touch E-ink kindle? Oh wait, I'm still banned from amazon for no apparent reason...",
  "id" : 119104565818830848,
  "created_at" : "Wed Sep 28 17:41:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "indices" : [ 3, 9 ],
      "id_str" : "14782518",
      "id" : 14782518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/HmDu7vg3",
      "expanded_url" : "http://dthin.gs/oCwSU2",
      "display_url" : "dthin.gs/oCwSU2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "119045207156211713",
  "text" : "RT @cltom: Microsoft Signs Mega-Patent Deal With Samsung, Will Get Royalties on Every Android Device It Sells http://t.co/HmDu7vg3",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.brizzly.com\" rel=\"nofollow\">Brizzly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http://t.co/HmDu7vg3",
        "expanded_url" : "http://dthin.gs/oCwSU2",
        "display_url" : "dthin.gs/oCwSU2"
      } ]
    },
    "geo" : {
    },
    "id_str" : "119037271507877888",
    "text" : "Microsoft Signs Mega-Patent Deal With Samsung, Will Get Royalties on Every Android Device It Sells http://t.co/HmDu7vg3",
    "id" : 119037271507877888,
    "created_at" : "Wed Sep 28 13:14:31 +0000 2011",
    "user" : {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "protected" : false,
      "id_str" : "14782518",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2908096260/d10e7982fa92f0bf560a50a76d76e392_normal.png",
      "id" : 14782518,
      "verified" : false
    }
  },
  "id" : 119045207156211713,
  "created_at" : "Wed Sep 28 13:46:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wp7",
      "indices" : [ 30, 34 ]
    }, {
      "text" : "iPhone5",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118941634435096576",
  "text" : "Is a high end, sturdy, AMOLED #wp7 phone ever going to come out on Verizon?? #iPhone5 is close and tempting...",
  "id" : 118941634435096576,
  "created_at" : "Wed Sep 28 06:54:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Klein",
      "screen_name" : "zachklein",
      "indices" : [ 3, 13 ],
      "id_str" : "11969",
      "id" : 11969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118938838168113152",
  "text" : "RT @zachklein: I own highschoolbandreunion.com. The idea is a TV show for middle-aged bands to compete Idol-style for a record deal. Ori ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "118853919404335104",
    "text" : "I own highschoolbandreunion.com. The idea is a TV show for middle-aged bands to compete Idol-style for a record deal. Originals & covers.",
    "id" : 118853919404335104,
    "created_at" : "Wed Sep 28 01:05:57 +0000 2011",
    "user" : {
      "name" : "Zach Klein",
      "screen_name" : "zachklein",
      "protected" : false,
      "id_str" : "11969",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2811796449/fc89959fc8a6531f0f769203a68a2552_normal.jpeg",
      "id" : 11969,
      "verified" : false
    }
  },
  "id" : 118938838168113152,
  "created_at" : "Wed Sep 28 06:43:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118828340344922112",
  "text" : "Playing with Facebook Timeline. This is blowing my mind. RADICAL new UXUI",
  "id" : 118828340344922112,
  "created_at" : "Tue Sep 27 23:24:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118706405480996864",
  "text" : "iPhone 5- 10/4. Ace Combat Assault Horizon - 10/11. No longer planning to be productive that week.",
  "id" : 118706405480996864,
  "created_at" : "Tue Sep 27 15:19:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118694046746161152",
  "text" : "Flexible AMOLED? Yes, please. http://j.mp/pXoPde",
  "id" : 118694046746161152,
  "created_at" : "Tue Sep 27 14:30:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Google",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "rage",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118529346473431040",
  "text" : "#Google moved the Reader link off of the nav bar again! #rage",
  "id" : 118529346473431040,
  "created_at" : "Tue Sep 27 03:36:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118341682478583811",
  "text" : "If you could somehow attach a turbine to the Apple rumor mill, BAM world energy crisis solved.",
  "id" : 118341682478583811,
  "created_at" : "Mon Sep 26 15:10:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 0, 8 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118127957754642433",
  "geo" : {
  },
  "id_str" : "118222507668029440",
  "in_reply_to_user_id" : 38399009,
  "text" : "@bznotes how long does the HK LED last? I've paid $30 for a US LED bulb.",
  "id" : 118222507668029440,
  "in_reply_to_status_id" : 118127957754642433,
  "created_at" : "Mon Sep 26 07:16:56 +0000 2011",
  "in_reply_to_screen_name" : "bznotes",
  "in_reply_to_user_id_str" : "38399009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118217917627244544",
  "text" : "Oh man, what I wouldn't do for Taiwanese food right now.",
  "id" : 118217917627244544,
  "created_at" : "Mon Sep 26 06:58:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118183785379540992",
  "text" : "It turns out a million (virtual) monkeys CAN produce Shakespeare http://j.mp/qX5iHl",
  "id" : 118183785379540992,
  "created_at" : "Mon Sep 26 04:43:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Klein",
      "screen_name" : "zachklein",
      "indices" : [ 0, 10 ],
      "id_str" : "11969",
      "id" : 11969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118048030443315200",
  "geo" : {
  },
  "id_str" : "118093044846301184",
  "in_reply_to_user_id" : 11969,
  "text" : "@zachklein Buffalo, NY?",
  "id" : 118093044846301184,
  "in_reply_to_status_id" : 118048030443315200,
  "created_at" : "Sun Sep 25 22:42:30 +0000 2011",
  "in_reply_to_screen_name" : "zachklein",
  "in_reply_to_user_id_str" : "11969",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Liao",
      "screen_name" : "beccaliao",
      "indices" : [ 0, 10 ],
      "id_str" : "237599567",
      "id" : 237599567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118092256937914368",
  "in_reply_to_user_id" : 237599567,
  "text" : "@beccaliao I would DM-reply you but I can't since you don't follow me!",
  "id" : 118092256937914368,
  "created_at" : "Sun Sep 25 22:39:22 +0000 2011",
  "in_reply_to_screen_name" : "beccaliao",
  "in_reply_to_user_id_str" : "237599567",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven",
      "screen_name" : "mash_daddy",
      "indices" : [ 0, 11 ],
      "id_str" : "193150867",
      "id" : 193150867
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 21, 33 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117648696618921985",
  "geo" : {
  },
  "id_str" : "117710392855236608",
  "in_reply_to_user_id" : 193150867,
  "text" : "@mash_daddy you know @badboyboyce is getting a Nespresso machine right?",
  "id" : 117710392855236608,
  "in_reply_to_status_id" : 117648696618921985,
  "created_at" : "Sat Sep 24 21:21:59 +0000 2011",
  "in_reply_to_screen_name" : "mash_daddy",
  "in_reply_to_user_id_str" : "193150867",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean",
      "screen_name" : "deanshu",
      "indices" : [ 0, 8 ],
      "id_str" : "231525350",
      "id" : 231525350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117699592887336960",
  "geo" : {
  },
  "id_str" : "117700292904095744",
  "in_reply_to_user_id" : 231525350,
  "text" : "@deanshu my freshman year, the pound sterling crashed so I imported one from the UK. Sold it later. Now I miss it.",
  "id" : 117700292904095744,
  "in_reply_to_status_id" : 117699592887336960,
  "created_at" : "Sat Sep 24 20:41:51 +0000 2011",
  "in_reply_to_screen_name" : "deanshu",
  "in_reply_to_user_id_str" : "231525350",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 31, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117697297512546304",
  "text" : "I really miss my old Leica M8. #firstworldproblems",
  "id" : 117697297512546304,
  "created_at" : "Sat Sep 24 20:29:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 0, 6 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117501832338739200",
  "geo" : {
  },
  "id_str" : "117506943135924224",
  "in_reply_to_user_id" : 27015881,
  "text" : "@jluan tried roommates iPad. Not a fan for reading papers.",
  "id" : 117506943135924224,
  "in_reply_to_status_id" : 117501832338739200,
  "created_at" : "Sat Sep 24 07:53:33 +0000 2011",
  "in_reply_to_screen_name" : "jluan",
  "in_reply_to_user_id_str" : "27015881",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117500486197850112",
  "text" : "I'm still not comfortable reading longform text on a tablet... Just got the semester's PDFs printed and bound for reference.",
  "id" : 117500486197850112,
  "created_at" : "Sat Sep 24 07:27:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117440457063153664",
  "text" : "Quincy house always smells like a wet dog.",
  "id" : 117440457063153664,
  "created_at" : "Sat Sep 24 03:29:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Short",
      "screen_name" : "jason4short",
      "indices" : [ 3, 15 ],
      "id_str" : "25249966",
      "id" : 25249966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArduCopter",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/7EAFi5pE",
      "expanded_url" : "http://vimeo.com/29502926",
      "display_url" : "vimeo.com/29502926"
    } ]
  },
  "geo" : {
  },
  "id_str" : "117388741601005569",
  "text" : "RT @jason4short: #ArduCopter flying at Duboce Park in full autopilot. So close to final release I can taste it. http://t.co/7EAFi5pE",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArduCopter",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http://t.co/7EAFi5pE",
        "expanded_url" : "http://vimeo.com/29502926",
        "display_url" : "vimeo.com/29502926"
      } ]
    },
    "geo" : {
    },
    "id_str" : "117369017014034432",
    "text" : "#ArduCopter flying at Duboce Park in full autopilot. So close to final release I can taste it. http://t.co/7EAFi5pE",
    "id" : 117369017014034432,
    "created_at" : "Fri Sep 23 22:45:28 +0000 2011",
    "user" : {
      "name" : "Jason Short",
      "screen_name" : "jason4short",
      "protected" : false,
      "id_str" : "25249966",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1630792075/Avatar_normal.jpg",
      "id" : 25249966,
      "verified" : false
    }
  },
  "id" : 117388741601005569,
  "created_at" : "Sat Sep 24 00:03:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116935008031219712",
  "text" : "In Gen Ed class on religion. Would rather be at F8",
  "id" : 116935008031219712,
  "created_at" : "Thu Sep 22 18:00:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/6cdNmxzH",
      "expanded_url" : "http://techcrunch.com/2011/09/22/facebook-timeline/",
      "display_url" : "techcrunch.com/2011/09/22/fac\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116934870520963073",
  "text" : "RT @parislemon: Facebook Unveils Timeline: The Story Of Your Life On A Single\u00A0Page http://t.co/6cdNmxzH",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http://t.co/6cdNmxzH",
        "expanded_url" : "http://techcrunch.com/2011/09/22/facebook-timeline/",
        "display_url" : "techcrunch.com/2011/09/22/fac\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "116931740441907200",
    "text" : "Facebook Unveils Timeline: The Story Of Your Life On A Single\u00A0Page http://t.co/6cdNmxzH",
    "id" : 116931740441907200,
    "created_at" : "Thu Sep 22 17:47:54 +0000 2011",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3336694463/99718483afb19d6d441290afccb72772_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 116934870520963073,
  "created_at" : "Thu Sep 22 18:00:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernard Moon",
      "screen_name" : "bernardmoon",
      "indices" : [ 3, 15 ],
      "id_str" : "4541891",
      "id" : 4541891
    }, {
      "name" : "Pete Cashmore",
      "screen_name" : "mashable",
      "indices" : [ 104, 113 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/Cbf4CNnv",
      "expanded_url" : "http://on.mash.to/qN5oSC",
      "display_url" : "on.mash.to/qN5oSC"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116769000838533120",
  "text" : "RT @bernardmoon: Which Country Has the World's Fastest Internet? [INFOGRAPHIC] http://t.co/Cbf4CNnv  RT @mashable",
  "retweeted_status" : {
    "source" : "<a href=\"http://mashable.com\" rel=\"nofollow\">Mashable Follow</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pete Cashmore",
        "screen_name" : "mashable",
        "indices" : [ 87, 96 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http://t.co/Cbf4CNnv",
        "expanded_url" : "http://on.mash.to/qN5oSC",
        "display_url" : "on.mash.to/qN5oSC"
      } ]
    },
    "geo" : {
    },
    "id_str" : "116626078902140928",
    "text" : "Which Country Has the World's Fastest Internet? [INFOGRAPHIC] http://t.co/Cbf4CNnv  RT @mashable",
    "id" : 116626078902140928,
    "created_at" : "Wed Sep 21 21:33:18 +0000 2011",
    "user" : {
      "name" : "Bernard Moon",
      "screen_name" : "bernardmoon",
      "protected" : false,
      "id_str" : "4541891",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/314578875/Bernard_normal.jpg",
      "id" : 4541891,
      "verified" : false
    }
  },
  "id" : 116769000838533120,
  "created_at" : "Thu Sep 22 07:01:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116620639011471360",
  "text" : "\"The short answer is yes and no.\" - prof Gortler in CS175",
  "id" : 116620639011471360,
  "created_at" : "Wed Sep 21 21:11:41 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/QszcIBKQ",
      "expanded_url" : "http://on.wsj.com/nSC6eJ",
      "display_url" : "on.wsj.com/nSC6eJ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116554195007569920",
  "text" : "RT @WSJ: Hewlett-Packard is up 7.6% on Bloomberg's report that H-P's board is mulling the ouster of CEO Leo Apotheker http://t.co/QszcIBKQ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/QszcIBKQ",
        "expanded_url" : "http://on.wsj.com/nSC6eJ",
        "display_url" : "on.wsj.com/nSC6eJ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "116549850102894593",
    "text" : "Hewlett-Packard is up 7.6% on Bloomberg's report that H-P's board is mulling the ouster of CEO Leo Apotheker http://t.co/QszcIBKQ",
    "id" : 116549850102894593,
    "created_at" : "Wed Sep 21 16:30:24 +0000 2011",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 116554195007569920,
  "created_at" : "Wed Sep 21 16:47:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116432405425954816",
  "text" : "Does anyone else think the chorus to Pitbull's \"Give me Everything\" is creepy in an imminent-sexual-assault kind of way?",
  "id" : 116432405425954816,
  "created_at" : "Wed Sep 21 08:43:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean",
      "screen_name" : "deanshu",
      "indices" : [ 0, 8 ],
      "id_str" : "231525350",
      "id" : 231525350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116422321983598592",
  "in_reply_to_user_id" : 231525350,
  "text" : "@deanshu have you ever shot entirely on micro 4/3? All this mirrorless news is making me curious again.",
  "id" : 116422321983598592,
  "created_at" : "Wed Sep 21 08:03:39 +0000 2011",
  "in_reply_to_screen_name" : "deanshu",
  "in_reply_to_user_id_str" : "231525350",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116420097815478272",
  "text" : "Nikon's new 1-series sensor is smaller than Micro 4/3 though... Not really compelling.",
  "id" : 116420097815478272,
  "created_at" : "Wed Sep 21 07:54:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nikon",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/65C0WApA",
      "expanded_url" : "http://www.dpreview.com/news/1109/11092120nikonlaunch.asp",
      "display_url" : "dpreview.com/news/1109/1109\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116417698803613696",
  "text" : "#Nikon announces mirrorless system!! http://t.co/65C0WApA",
  "id" : 116417698803613696,
  "created_at" : "Wed Sep 21 07:45:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116406958097039360",
  "text" : "I am legit the only person in Harvard yard right now.",
  "id" : 116406958097039360,
  "created_at" : "Wed Sep 21 07:02:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116301218040655872",
  "text" : "Coming this week in the mail: tension wrench, 50 wooden cubes, HP reverse polish notation calculator. Whatever could I be up to?!",
  "id" : 116301218040655872,
  "created_at" : "Wed Sep 21 00:02:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 91, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116299873581670400",
  "text" : "I have to trek to the science center to use a computer to complete this OpenGL assignment. #firstworldproblems",
  "id" : 116299873581670400,
  "created_at" : "Tue Sep 20 23:57:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 20, 30 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116299224349556736",
  "text" : "Moar bubble tea! RT @jenny8lee: Am I a fuddy duddy to think that \"moar\" is not an improved way of spelling \"more?\"",
  "id" : 116299224349556736,
  "created_at" : "Tue Sep 20 23:54:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116236273328472064",
  "text" : "I wish they would credit me for the picture though...",
  "id" : 116236273328472064,
  "created_at" : "Tue Sep 20 19:44:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 47, 59 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackHarvard",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/H1SJoNfG",
      "expanded_url" : "http://www.usatoday.com/tech/news/story/2011-09-20/harvard-hack-club/50478740/1",
      "display_url" : "usatoday.com/tech/news/stor\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116236211684769792",
  "text" : "#HackHarvard featured in USA Today, along with @badboyboyce's beautiful face: http://t.co/H1SJoNfG",
  "id" : 116236211684769792,
  "created_at" : "Tue Sep 20 19:44:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116185274492522496",
  "text" : "RT @HarvardCSA: Fun fact: huntun (wontons) is cognate with hundun, \"The undifferentiated soup of primordial chaos.\" Think about that nex ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "116177317998497792",
    "text" : "Fun fact: huntun (wontons) is cognate with hundun, \"The undifferentiated soup of primordial chaos.\" Think about that next time you nosh.",
    "id" : 116177317998497792,
    "created_at" : "Tue Sep 20 15:50:05 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 116185274492522496,
  "created_at" : "Tue Sep 20 16:21:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/M2yXQmty",
      "expanded_url" : "http://www.envirogadget.com/water-saving/evaporation-based-water-purifier-cone/",
      "display_url" : "envirogadget.com/water-saving/e\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116052689909067776",
  "text" : "THIS is the kind of innovation we need. Plastic widget that purifies water on the cheap http://t.co/M2yXQmty",
  "id" : 116052689909067776,
  "created_at" : "Tue Sep 20 07:34:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel P. Rubino",
      "screen_name" : "malatesta77",
      "indices" : [ 0, 12 ],
      "id_str" : "45387210",
      "id" : 45387210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115967205233008640",
  "geo" : {
  },
  "id_str" : "116051843909558273",
  "in_reply_to_user_id" : 37025150,
  "text" : "@malatesta77 I actually cant think of a consumer tech company with a decent naming scheme. Don't worry, I'm a Microsoftie :)",
  "id" : 116051843909558273,
  "in_reply_to_status_id" : 115967205233008640,
  "created_at" : "Tue Sep 20 07:31:30 +0000 2011",
  "in_reply_to_screen_name" : "Daniel_Rubino",
  "in_reply_to_user_id_str" : "37025150",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/JYJe9cDG",
      "expanded_url" : "http://onesixtieth.net",
      "display_url" : "onesixtieth.net"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116022223000711168",
  "text" : "Apparently my computer does not support OpenGL. Looks like I can't do this graphics homework. Updating http://t.co/JYJe9cDG instead",
  "id" : 116022223000711168,
  "created_at" : "Tue Sep 20 05:33:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Liu",
      "screen_name" : "eliseliu",
      "indices" : [ 0, 9 ],
      "id_str" : "14458332",
      "id" : 14458332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 69, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115942938189639680",
  "geo" : {
  },
  "id_str" : "115965245310251009",
  "in_reply_to_user_id" : 14458332,
  "text" : "@eliseliu Ohhh I see. It's so difficult to convey tone over twitter. #firstworldproblems",
  "id" : 115965245310251009,
  "in_reply_to_status_id" : 115942938189639680,
  "created_at" : "Tue Sep 20 01:47:23 +0000 2011",
  "in_reply_to_screen_name" : "eliseliu",
  "in_reply_to_user_id_str" : "14458332",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Liu",
      "screen_name" : "eliseliu",
      "indices" : [ 0, 9 ],
      "id_str" : "14458332",
      "id" : 14458332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115942938189639680",
  "geo" : {
  },
  "id_str" : "115964466709008384",
  "in_reply_to_user_id" : 14458332,
  "text" : "@eliseliu I met someone allergic to chocolate and wheat once. It was so sad :(",
  "id" : 115964466709008384,
  "in_reply_to_status_id" : 115942938189639680,
  "created_at" : "Tue Sep 20 01:44:18 +0000 2011",
  "in_reply_to_screen_name" : "eliseliu",
  "in_reply_to_user_id_str" : "14458332",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel P. Rubino",
      "screen_name" : "malatesta77",
      "indices" : [ 0, 12 ],
      "id_str" : "45387210",
      "id" : 45387210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115899035105239040",
  "geo" : {
  },
  "id_str" : "115928783147646976",
  "in_reply_to_user_id" : 37025150,
  "text" : "@malatesta77 Microsoft Windows &lt;version&gt; &lt;edition&gt; &lt;SP#&gt; nomenclature is hardly better",
  "id" : 115928783147646976,
  "in_reply_to_status_id" : 115899035105239040,
  "created_at" : "Mon Sep 19 23:22:30 +0000 2011",
  "in_reply_to_screen_name" : "Daniel_Rubino",
  "in_reply_to_user_id_str" : "37025150",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Liu",
      "screen_name" : "eliseliu",
      "indices" : [ 47, 56 ],
      "id_str" : "14458332",
      "id" : 14458332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whitewhine",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115925984573800448",
  "text" : "Would you like some cheese with your whine? RT @eliseliu: Expense reports take SO MUCH TIME, guys. #whitewhine",
  "id" : 115925984573800448,
  "created_at" : "Mon Sep 19 23:11:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/1RHfVOIM",
      "expanded_url" : "http://SeniorDesk.tumblr.com",
      "display_url" : "SeniorDesk.tumblr.com"
    }, {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/cXtMYi6P",
      "expanded_url" : "http://SeniorInbox.tumblr.com",
      "display_url" : "SeniorInbox.tumblr.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "115922690086412288",
  "text" : "My roommate liked http://t.co/1RHfVOIM - so he made http://t.co/cXtMYi6P",
  "id" : 115922690086412288,
  "created_at" : "Mon Sep 19 22:58:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thinkgeek",
      "screen_name" : "thinkgeek",
      "indices" : [ 3, 13 ],
      "id_str" : "12611642",
      "id" : 12611642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115850199456428032",
  "text" : "RT @thinkgeek: Earth, you're so pretty. ISS flyby time-lapse made of 600 astronaut photos: http://j.mp/rlwv9Q Wait for the lightning!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "115824906985418752",
    "text" : "Earth, you're so pretty. ISS flyby time-lapse made of 600 astronaut photos: http://j.mp/rlwv9Q Wait for the lightning!",
    "id" : 115824906985418752,
    "created_at" : "Mon Sep 19 16:29:44 +0000 2011",
    "user" : {
      "name" : "thinkgeek",
      "screen_name" : "thinkgeek",
      "protected" : false,
      "id_str" : "12611642",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3522713236/268f433597dc1e82d2eafcfb9c5c5b20_normal.png",
      "id" : 12611642,
      "verified" : true
    }
  },
  "id" : 115850199456428032,
  "created_at" : "Mon Sep 19 18:10:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115849491554369536",
  "text" : "Qwikster and Xfinity can form a Superfluous-Branding Club now.",
  "id" : 115849491554369536,
  "created_at" : "Mon Sep 19 18:07:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Wang",
      "screen_name" : "annie_wang",
      "indices" : [ 53, 64 ],
      "id_str" : "29599103",
      "id" : 29599103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/JICc1mEb",
      "expanded_url" : "http://kanehsieh.com",
      "display_url" : "kanehsieh.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "115694427690893312",
  "text" : "Up late tweaking the website. http://t.co/JICc1mEb - @annie_wang, you make a cameo appearance!",
  "id" : 115694427690893312,
  "created_at" : "Mon Sep 19 07:51:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115605027887923200",
  "text" : "RT @wired: Apple Scrambles To Merge Apple IDs To Stave Off iCloud Sync Mess http://ow.ly/6xK4c",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "115543217344229376",
    "text" : "Apple Scrambles To Merge Apple IDs To Stave Off iCloud Sync Mess http://ow.ly/6xK4c",
    "id" : 115543217344229376,
    "created_at" : "Sun Sep 18 21:50:24 +0000 2011",
    "user" : {
      "name" : "Wired",
      "screen_name" : "wired",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2958887633/eab60d838d5c4bb20fa52f0577a2c698_normal.jpeg",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 115605027887923200,
  "created_at" : "Mon Sep 19 01:56:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114520632460443648",
  "geo" : {
  },
  "id_str" : "114795627703050241",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj finally get a chance to play with Mango build?",
  "id" : 114795627703050241,
  "in_reply_to_status_id" : 114520632460443648,
  "created_at" : "Fri Sep 16 20:19:45 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 0, 8 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114417283937472512",
  "geo" : {
  },
  "id_str" : "114459058127388673",
  "in_reply_to_user_id" : 38399009,
  "text" : "@bznotes bubble tea and snacks in Taiwan, high tea and dim sum in HK is the way to go!",
  "id" : 114459058127388673,
  "in_reply_to_status_id" : 114417283937472512,
  "created_at" : "Thu Sep 15 22:02:20 +0000 2011",
  "in_reply_to_screen_name" : "bznotes",
  "in_reply_to_user_id_str" : "38399009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 17, 26 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114414510294564864",
  "geo" : {
  },
  "id_str" : "114459012489166849",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil talk to @thepunit, apparently Windows 8 not playing nicely in VMs",
  "id" : 114459012489166849,
  "in_reply_to_status_id" : 114414510294564864,
  "created_at" : "Thu Sep 15 22:02:09 +0000 2011",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "indices" : [ 3, 19 ],
      "id_str" : "263122363",
      "id" : 263122363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114405724527919104",
  "text" : "RT @HarvardAsianGuy: I admit, there are a few dropouts that I admire: Bill Gates. Mark Zuckerberg. Ash Ketchum.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "114404484402257920",
    "text" : "I admit, there are a few dropouts that I admire: Bill Gates. Mark Zuckerberg. Ash Ketchum.",
    "id" : 114404484402257920,
    "created_at" : "Thu Sep 15 18:25:29 +0000 2011",
    "user" : {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "protected" : false,
      "id_str" : "263122363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1713903417/asian_normal.jpg",
      "id" : 263122363,
      "verified" : false
    }
  },
  "id" : 114405724527919104,
  "created_at" : "Thu Sep 15 18:30:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http://t.co/hXPNHui",
      "expanded_url" : "http://bit.ly/nV4Vmd",
      "display_url" : "bit.ly/nV4Vmd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "114027596697698304",
  "text" : "RT @medialab: Nine MIT Media Lab Ideas That Are Changing Lives (or Will Soon):  http://t.co/hXPNHui",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 85 ],
        "url" : "http://t.co/hXPNHui",
        "expanded_url" : "http://bit.ly/nV4Vmd",
        "display_url" : "bit.ly/nV4Vmd"
      } ]
    },
    "geo" : {
    },
    "id_str" : "114003333752160256",
    "text" : "Nine MIT Media Lab Ideas That Are Changing Lives (or Will Soon):  http://t.co/hXPNHui",
    "id" : 114003333752160256,
    "created_at" : "Wed Sep 14 15:51:27 +0000 2011",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 114027596697698304,
  "created_at" : "Wed Sep 14 17:27:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilad Lotan",
      "screen_name" : "gilgul",
      "indices" : [ 57, 64 ],
      "id_str" : "3183721",
      "id" : 3183721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113851413179797504",
  "text" : "Spit and prayers, mostly. And tables. Lots of tables. RT @gilgul: how did we ever make websites before jquery??",
  "id" : 113851413179797504,
  "created_at" : "Wed Sep 14 05:47:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 26, 35 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 106 ],
      "url" : "http://t.co/56uM1Mc",
      "expanded_url" : "http://abcn.ws/rnY6vw",
      "display_url" : "abcn.ws/rnY6vw"
    }, {
      "indices" : [ 107, 126 ],
      "url" : "http://t.co/kaHOHji",
      "expanded_url" : "http://techme.me/C3F3",
      "display_url" : "techme.me/C3F3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "113847319316791296",
  "text" : "That's a lot of monies RT @Techmeme Google Raised Motorola Bid by $3B to Get Deal Done http://t.co/56uM1Mc http://t.co/kaHOHji",
  "id" : 113847319316791296,
  "created_at" : "Wed Sep 14 05:31:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/113842608098394112/photo/1",
      "indices" : [ 77, 96 ],
      "url" : "http://t.co/cdMKkAb",
      "media_url" : "http://pbs.twimg.com/media/AZRzP7hCQAErXbj.jpg",
      "id_str" : "113842608102588417",
      "id" : 113842608102588417,
      "media_url_https" : "https://pbs.twimg.com/media/AZRzP7hCQAErXbj.jpg",
      "sizes" : [ {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com/cdMKkAb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113842608098394112",
  "text" : "My 1963 Peoples Liberation Army Air Force chrono on a J.Press Harvard strap! http://t.co/cdMKkAb",
  "id" : 113842608098394112,
  "created_at" : "Wed Sep 14 05:12:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113827660488114176",
  "geo" : {
  },
  "id_str" : "113841522805440512",
  "in_reply_to_user_id" : 110202853,
  "text" : "@maevewang considering, if they are running it again this year",
  "id" : 113841522805440512,
  "in_reply_to_status_id" : 113827660488114176,
  "created_at" : "Wed Sep 14 05:08:28 +0000 2011",
  "in_reply_to_screen_name" : "m_t_wang",
  "in_reply_to_user_id_str" : "110202853",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/113826955555635200/photo/1",
      "indices" : [ 57, 76 ],
      "url" : "http://t.co/zArHgyl",
      "media_url" : "http://pbs.twimg.com/media/AZRlA1QCAAAMLbX.jpg",
      "id_str" : "113826955559829504",
      "id" : 113826955559829504,
      "media_url_https" : "https://pbs.twimg.com/media/AZRlA1QCAAAMLbX.jpg",
      "sizes" : [ {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com/zArHgyl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113826955555635200",
  "text" : "Two weeks in, and I'm already doing IT work for friends. http://t.co/zArHgyl",
  "id" : 113826955555635200,
  "created_at" : "Wed Sep 14 04:10:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113794449066295296",
  "geo" : {
  },
  "id_str" : "113824872295182337",
  "in_reply_to_user_id" : 110202853,
  "text" : "@maevewang HKS actually does a DPRK trip in the Spring! Which I really want to go on.",
  "id" : 113824872295182337,
  "in_reply_to_status_id" : 113794449066295296,
  "created_at" : "Wed Sep 14 04:02:18 +0000 2011",
  "in_reply_to_screen_name" : "m_t_wang",
  "in_reply_to_user_id_str" : "110202853",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http://t.co/kxl8ibI",
      "expanded_url" : "http://www.shopping.hp.com/product/calculator/Scientific/1/storefronts/NW250AA%2523ABA",
      "display_url" : "shopping.hp.com/product/calcul\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "113824344081305601",
  "text" : "The moment HP makes their limited edition 15c available, I'm buying one for my dad. #nerdtweet http://t.co/kxl8ibI",
  "id" : 113824344081305601,
  "created_at" : "Wed Sep 14 04:00:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 12, 21 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "why",
      "indices" : [ 78, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113518581454602240",
  "text" : "My roommate @thepunit has been playing Save The World on loop since midnight. #why",
  "id" : 113518581454602240,
  "created_at" : "Tue Sep 13 07:45:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lingbo Li",
      "screen_name" : "LingboLi",
      "indices" : [ 0, 9 ],
      "id_str" : "21259000",
      "id" : 21259000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113479927352922112",
  "geo" : {
  },
  "id_str" : "113517985603391488",
  "in_reply_to_user_id" : 21259000,
  "text" : "@LingboLi what are you doing on Buffalo NY?",
  "id" : 113517985603391488,
  "in_reply_to_status_id" : 113479927352922112,
  "created_at" : "Tue Sep 13 07:42:51 +0000 2011",
  "in_reply_to_screen_name" : "LingboLi",
  "in_reply_to_user_id_str" : "21259000",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113313151537250304",
  "text" : "I am the only person in this class not using a Mac. Does this make me some sort of bizzaro hipster?",
  "id" : 113313151537250304,
  "created_at" : "Mon Sep 12 18:08:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112928102086213632",
  "text" : "10 years ago, I was in 6th grade science class when the principle came in and told us something terrible had happened.",
  "id" : 112928102086213632,
  "created_at" : "Sun Sep 11 16:38:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112783526562250752",
  "text" : "A cool app I used this past summer at Microsoft is now available to the public! Mouse Without Borders: http://j.mp/qllGMw",
  "id" : 112783526562250752,
  "created_at" : "Sun Sep 11 07:04:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "indices" : [ 0, 8 ],
      "id_str" : "184543773",
      "id" : 184543773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112029466716418048",
  "geo" : {
  },
  "id_str" : "112639614791073793",
  "in_reply_to_user_id" : 184543773,
  "text" : "@stat110 I'm not sure how valuable the domain would be to a squatter if I don't want it!",
  "id" : 112639614791073793,
  "in_reply_to_status_id" : 112029466716418048,
  "created_at" : "Sat Sep 10 21:32:31 +0000 2011",
  "in_reply_to_screen_name" : "stat110",
  "in_reply_to_user_id_str" : "184543773",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 36, 52 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/3oHutom",
      "expanded_url" : "http://bit.ly/ny952n",
      "display_url" : "bit.ly/ny952n"
    } ]
  },
  "geo" : {
  },
  "id_str" : "112638508874739714",
  "text" : "A fascinating underworld culture RT @GlobalAsianista Candid portrayals of the Yakuza by Belgian photographer A Kusters: http://t.co/3oHutom",
  "id" : 112638508874739714,
  "created_at" : "Sat Sep 10 21:28:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "preemptivenostalgia",
      "indices" : [ 54, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112637325799981057",
  "text" : "Writing in Harvard Yard. I'm going to miss this place #preemptivenostalgia",
  "id" : 112637325799981057,
  "created_at" : "Sat Sep 10 21:23:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112023632326303744",
  "text" : "Debating if I should acquire kanehsieh.xxx now that the domain is available...",
  "id" : 112023632326303744,
  "created_at" : "Fri Sep 09 04:44:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112021364084445184",
  "text" : "Apple is now matching employee donations... something Microsoft has been doing for a while now http://j.mp/qozhkj",
  "id" : 112021364084445184,
  "created_at" : "Fri Sep 09 04:35:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "BobaReview",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111914445940330497",
  "text" : "RT @HarvardCSA: New to Cambridge, MA? We'll be reviewing the best places to get bubble tea around #harvard campus this week! #BobaReview",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "harvard",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "BobaReview",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "111911577053184000",
    "text" : "New to Cambridge, MA? We'll be reviewing the best places to get bubble tea around #harvard campus this week! #BobaReview",
    "id" : 111911577053184000,
    "created_at" : "Thu Sep 08 21:19:33 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 111914445940330497,
  "created_at" : "Thu Sep 08 21:30:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111885564302725120",
  "text" : "\"If you've learned anything in class today, know that Green Eggs & Ham only has 50 unique words\" - Prof in parallel programming class",
  "id" : 111885564302725120,
  "created_at" : "Thu Sep 08 19:36:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111852824048050176",
  "text" : "I wonder if all the Zagat Rated stickers in restaurant windows will become +1 stickers now.",
  "id" : 111852824048050176,
  "created_at" : "Thu Sep 08 17:26:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http://t.co/DJFs17u",
      "expanded_url" : "http://on.wsj.com/qd3km8",
      "display_url" : "on.wsj.com/qd3km8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "111816846050734080",
  "text" : "RT @WSJ: 92% of Afghan men between ages 15 and 30 haven't heard of \"this event foreigners call 9/11\" http://t.co/DJFs17u",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 111 ],
        "url" : "http://t.co/DJFs17u",
        "expanded_url" : "http://on.wsj.com/qd3km8",
        "display_url" : "on.wsj.com/qd3km8"
      } ]
    },
    "geo" : {
    },
    "id_str" : "111814498398117888",
    "text" : "92% of Afghan men between ages 15 and 30 haven't heard of \"this event foreigners call 9/11\" http://t.co/DJFs17u",
    "id" : 111814498398117888,
    "created_at" : "Thu Sep 08 14:53:48 +0000 2011",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 111816846050734080,
  "created_at" : "Thu Sep 08 15:03:08 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    }, {
      "name" : "Kashmir Hill",
      "screen_name" : "kashhill",
      "indices" : [ 19, 28 ],
      "id_str" : "25160944",
      "id" : 25160944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http://t.co/3dBLeWu",
      "expanded_url" : "http://bloom.bg/qqWyRw",
      "display_url" : "bloom.bg/qqWyRw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "111813692936564736",
  "text" : "RT @ForbesTech: RT @kashhill: So there's finally an \"America's Next Top Start-up\" reality TV show: http://t.co/3dBLeWu",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kashmir Hill",
        "screen_name" : "kashhill",
        "indices" : [ 3, 12 ],
        "id_str" : "25160944",
        "id" : 25160944
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 102 ],
        "url" : "http://t.co/3dBLeWu",
        "expanded_url" : "http://bloom.bg/qqWyRw",
        "display_url" : "bloom.bg/qqWyRw"
      } ]
    },
    "geo" : {
    },
    "id_str" : "111792188635099136",
    "text" : "RT @kashhill: So there's finally an \"America's Next Top Start-up\" reality TV show: http://t.co/3dBLeWu",
    "id" : 111792188635099136,
    "created_at" : "Thu Sep 08 13:25:09 +0000 2011",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 111813692936564736,
  "created_at" : "Thu Sep 08 14:50:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111657875235016704",
  "text" : "I'm going to bed now... before 1 AM. what is this i don't even",
  "id" : 111657875235016704,
  "created_at" : "Thu Sep 08 04:31:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 42, 53 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http://t.co/qEAelE3",
      "expanded_url" : "http://4sq.com/nUrAs6",
      "display_url" : "4sq.com/nUrAs6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "111567472649449473",
  "text" : "I just unlocked the \"Super User\" badge on @foursquare! http://t.co/qEAelE3",
  "id" : 111567472649449473,
  "created_at" : "Wed Sep 07 22:32:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111559137367834624",
  "text" : "Is it me, or does Drew Faust's #harvard welcome video seem like a pharma commercial? http://j.mp/nfZzY6",
  "id" : 111559137367834624,
  "created_at" : "Wed Sep 07 21:59:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111524408329388032",
  "text" : "BAE designs a pseudo invisibility cloak for tanks http://j.mp/qK62AQ",
  "id" : 111524408329388032,
  "created_at" : "Wed Sep 07 19:41:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 0, 9 ],
      "id_str" : "18008249",
      "id" : 18008249
    }, {
      "name" : "Steven",
      "screen_name" : "mash_daddy",
      "indices" : [ 10, 21 ],
      "id_str" : "193150867",
      "id" : 193150867
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 22, 34 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovationneversleeps",
      "indices" : [ 36, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111348978574049280",
  "geo" : {
  },
  "id_str" : "111349890784833536",
  "in_reply_to_user_id" : 18008249,
  "text" : "@thepunit @mash_daddy @badboyboyce  #innovationneversleeps, but I do. Peace, boys.",
  "id" : 111349890784833536,
  "in_reply_to_status_id" : 111348978574049280,
  "created_at" : "Wed Sep 07 08:07:37 +0000 2011",
  "in_reply_to_screen_name" : "thepunit",
  "in_reply_to_user_id_str" : "18008249",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Owens",
      "screen_name" : "to2",
      "indices" : [ 0, 4 ],
      "id_str" : "6635012",
      "id" : 6635012
    }, {
      "name" : "Grace Ng",
      "screen_name" : "uxceo",
      "indices" : [ 5, 11 ],
      "id_str" : "72353074",
      "id" : 72353074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111270433386528768",
  "geo" : {
  },
  "id_str" : "111349505034682368",
  "in_reply_to_user_id" : 6635012,
  "text" : "@to2 @UXceo how about a class on how to make a USEFUL restaurant website? Re: UX class",
  "id" : 111349505034682368,
  "in_reply_to_status_id" : 111270433386528768,
  "created_at" : "Wed Sep 07 08:06:05 +0000 2011",
  "in_reply_to_screen_name" : "to2",
  "in_reply_to_user_id_str" : "6635012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111348429531258880",
  "text" : "RT @parislemon: I once told a room full of startups that if they didn't sell me their souls I would club a baby seal. Then I did it anyway.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "111209727731576832",
    "text" : "I once told a room full of startups that if they didn't sell me their souls I would club a baby seal. Then I did it anyway.",
    "id" : 111209727731576832,
    "created_at" : "Tue Sep 06 22:50:39 +0000 2011",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3336694463/99718483afb19d6d441290afccb72772_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 111348429531258880,
  "created_at" : "Wed Sep 07 08:01:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bing",
      "screen_name" : "bing",
      "indices" : [ 0, 5 ],
      "id_str" : "14874480",
      "id" : 14874480
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 10, 18 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http://t.co/mEjyPSh",
      "expanded_url" : "http://yfrog.com/hw2uizj",
      "display_url" : "yfrog.com/hw2uizj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "111202991339601920",
  "in_reply_to_user_id" : 14874480,
  "text" : "@bing and @twitter cooking something up http://t.co/mEjyPSh",
  "id" : 111202991339601920,
  "created_at" : "Tue Sep 06 22:23:53 +0000 2011",
  "in_reply_to_screen_name" : "bing",
  "in_reply_to_user_id_str" : "14874480",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 0, 13 ],
      "id_str" : "101114131",
      "id" : 101114131
    }, {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 29, 39 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111120991157108736",
  "in_reply_to_user_id" : 101114131,
  "text" : "@Blueasiacafe hands down! RT @momogoose: Best bobba tea in Boston? Lollicup? Vote!",
  "id" : 111120991157108736,
  "created_at" : "Tue Sep 06 16:58:03 +0000 2011",
  "in_reply_to_screen_name" : "Blueasiacafe",
  "in_reply_to_user_id_str" : "101114131",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111120300560752642",
  "text" : "I feel like there's a gnome with a reciprocating hammer going to town on my sinuses.",
  "id" : 111120300560752642,
  "created_at" : "Tue Sep 06 16:55:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Yim (\uC2A4\uCE87 \uC784)",
      "screen_name" : "thenscottsaid",
      "indices" : [ 3, 17 ],
      "id_str" : "16573515",
      "id" : 16573515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111119459556671489",
  "text" : "RT @thenscottsaid: No one should be wearing a blazer with brass buttons...unless you're doing business on a yacht--that you own.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "111089981426114560",
    "text" : "No one should be wearing a blazer with brass buttons...unless you're doing business on a yacht--that you own.",
    "id" : 111089981426114560,
    "created_at" : "Tue Sep 06 14:54:50 +0000 2011",
    "user" : {
      "name" : "Scott Yim (\uC2A4\uCE87 \uC784)",
      "screen_name" : "thenscottsaid",
      "protected" : false,
      "id_str" : "16573515",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2994085365/0d9b6de647dc80642968e1e345d9d93f_normal.jpeg",
      "id" : 16573515,
      "verified" : false
    }
  },
  "id" : 111119459556671489,
  "created_at" : "Tue Sep 06 16:51:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 17, 30 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110871646352584704",
  "text" : "For some reason, @TheEconomist narrators' pronunciation of \"al qaeda\" is really really annoying.",
  "id" : 110871646352584704,
  "created_at" : "Tue Sep 06 00:27:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Owens",
      "screen_name" : "to2",
      "indices" : [ 0, 4 ],
      "id_str" : "6635012",
      "id" : 6635012
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 86, 98 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110438862018453504",
  "geo" : {
  },
  "id_str" : "110439228239912961",
  "in_reply_to_user_id" : 6635012,
  "text" : "@to2 thanks; we'll see how I feel about it in a few weeks. Stalking your website now! @badboyboyce",
  "id" : 110439228239912961,
  "in_reply_to_status_id" : 110438862018453504,
  "created_at" : "Sun Sep 04 19:48:58 +0000 2011",
  "in_reply_to_screen_name" : "to2",
  "in_reply_to_user_id_str" : "6635012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110432869196898304",
  "text" : "Finally built a standing desk for my dorm room. Hopefully will keep me more productive http://j.mp/olKBsy",
  "id" : 110432869196898304,
  "created_at" : "Sun Sep 04 19:23:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110384472163221504",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce showed the room GIF.TV and just killed all of our productivity.",
  "id" : 110384472163221504,
  "created_at" : "Sun Sep 04 16:11:23 +0000 2011",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 81, 93 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 94, 103 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110251635703418880",
  "text" : "Remember our conversation on recapturing energy from subways? http://j.mp/o7E9Ha @badboyboyce @thepunit",
  "id" : 110251635703418880,
  "created_at" : "Sun Sep 04 07:23:32 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 36, 45 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110232348221648896",
  "text" : "\"It's this from West Side Story?\" - @thepunit, while listening to \"I'll make a man out of you\"",
  "id" : 110232348221648896,
  "created_at" : "Sun Sep 04 06:06:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 26, 38 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 58, 67 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110143163607433216",
  "text" : "At a nice restaurant with @badboyboyce @themonkeychow and @thepunit. Ordered a plate of bacon. Getting weird looks.",
  "id" : 110143163607433216,
  "created_at" : "Sun Sep 04 00:12:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://taptaptap.com/camera+\" rel=\"nofollow\">Camera+</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http://t.co/Id6fawn",
      "expanded_url" : "http://campl.us/es8N",
      "display_url" : "campl.us/es8N"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3744075457, -71.1158349229 ]
  },
  "id_str" : "110110235565359106",
  "text" : "It's definitely info session day at Harvard! http://t.co/Id6fawn",
  "id" : 110110235565359106,
  "created_at" : "Sat Sep 03 22:01:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 3, 12 ],
      "id_str" : "817386",
      "id" : 817386
    }, {
      "name" : "gavin_clarke",
      "screen_name" : "gavin_clarke",
      "indices" : [ 68, 81 ],
      "id_str" : "17360375",
      "id" : 17360375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http://t.co/bku3ZSW",
      "expanded_url" : "http://techme.me/C0V4",
      "display_url" : "techme.me/C0V4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "110032080439750656",
  "text" : "RT @Techmeme: Apple's iCloud runs on Microsoft and Amazon services (@gavin_clarke / The Register) http://j.mp/mTT5Q2 http://t.co/bku3ZSW",
  "retweeted_status" : {
    "source" : "<a href=\"http://techmeme.com/\" rel=\"nofollow\">Techmeme</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "gavin_clarke",
        "screen_name" : "gavin_clarke",
        "indices" : [ 54, 67 ],
        "id_str" : "17360375",
        "id" : 17360375
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 122 ],
        "url" : "http://t.co/bku3ZSW",
        "expanded_url" : "http://techme.me/C0V4",
        "display_url" : "techme.me/C0V4"
      } ]
    },
    "geo" : {
    },
    "id_str" : "109855924553924609",
    "text" : "Apple's iCloud runs on Microsoft and Amazon services (@gavin_clarke / The Register) http://j.mp/mTT5Q2 http://t.co/bku3ZSW",
    "id" : 109855924553924609,
    "created_at" : "Sat Sep 03 05:11:08 +0000 2011",
    "user" : {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "protected" : false,
      "id_str" : "817386",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1783187293/techmeme_tw_av_normal",
      "id" : 817386,
      "verified" : false
    }
  },
  "id" : 110032080439750656,
  "created_at" : "Sat Sep 03 16:51:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109484580448374784",
  "text" : "the RED EPIC-X is finally in production! http://j.mp/qXdWZC",
  "id" : 109484580448374784,
  "created_at" : "Fri Sep 02 04:35:32 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Paiji",
      "screen_name" : "spaiji",
      "indices" : [ 0, 7 ],
      "id_str" : "213867225",
      "id" : 213867225
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 21, 33 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109435234549903360",
  "in_reply_to_user_id" : 213867225,
  "text" : "@spaiji did you know @badboyboyce is my roommate? Small world.",
  "id" : 109435234549903360,
  "created_at" : "Fri Sep 02 01:19:27 +0000 2011",
  "in_reply_to_screen_name" : "spaiji",
  "in_reply_to_user_id_str" : "213867225",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Sloan MBA",
      "screen_name" : "MITSloanMBA",
      "indices" : [ 3, 15 ],
      "id_str" : "761810479",
      "id" : 761810479
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIT",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109426223242936320",
  "text" : "RT @MITSloanMBA: # Andy Lo is joining CSAIL, the first professor from #MIT Sloan, merging Computer Science and Finance research.\nhttp:// ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MIT",
        "indices" : [ 53, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 131 ],
        "url" : "http://t.co/D522xRW",
        "expanded_url" : "http://web.mit.edu/newsoffice/2011/lo-joins-csail.html",
        "display_url" : "web.mit.edu/newsoffice/201\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "109396433744052224",
    "text" : "# Andy Lo is joining CSAIL, the first professor from #MIT Sloan, merging Computer Science and Finance research.\nhttp://t.co/D522xRW",
    "id" : 109396433744052224,
    "created_at" : "Thu Sep 01 22:45:16 +0000 2011",
    "user" : {
      "name" : "MITSloanAdmissions",
      "screen_name" : "MITSloanAdcom",
      "protected" : false,
      "id_str" : "44155527",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3498570533/0cd79d6a94da597c69cf2b6cc1734609_normal.jpeg",
      "id" : 44155527,
      "verified" : false
    }
  },
  "id" : 109426223242936320,
  "created_at" : "Fri Sep 02 00:43:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http://t.co/beP1TEK",
      "expanded_url" : "http://4sq.com/nPMqMe",
      "display_url" : "4sq.com/nPMqMe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "109420283391258624",
  "text" : "I just unlocked the \"Explorer\" badge on @foursquare! http://t.co/beP1TEK",
  "id" : 109420283391258624,
  "created_at" : "Fri Sep 02 00:20:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 45, 56 ],
      "id_str" : "16626603",
      "id" : 16626603
    }, {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 76, 89 ],
      "id_str" : "202968305",
      "id" : 202968305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109308703903191041",
  "text" : "It looks like the #harvard email fiasco made @thecrimson http://j.mp/qXTWbn @jamesdotcuff",
  "id" : 109308703903191041,
  "created_at" : "Thu Sep 01 16:56:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109288448883556352",
  "text" : "In an ideal city: traffic can only turn right, vehicles have right of way over pedestrians (but pedestrians have sky bridges).",
  "id" : 109288448883556352,
  "created_at" : "Thu Sep 01 15:36:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joi Ito",
      "screen_name" : "Joi",
      "indices" : [ 3, 7 ],
      "id_str" : "691353",
      "id" : 691353
    }, {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 58, 67 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109287720819507201",
  "text" : "RT @Joi: I'm finally \"officially\" the Director of the MIT @medialab and here's my first blog post on the new Media Lab blog: http://t.co ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MIT Media Lab",
        "screen_name" : "medialab",
        "indices" : [ 49, 58 ],
        "id_str" : "13982132",
        "id" : 13982132
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 135 ],
        "url" : "http://t.co/OETp0EB",
        "expanded_url" : "http://blog.media.mit.edu/2011/09/welcome.html",
        "display_url" : "blog.media.mit.edu/2011/09/welcom\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "109243735891656704",
    "text" : "I'm finally \"officially\" the Director of the MIT @medialab and here's my first blog post on the new Media Lab blog: http://t.co/OETp0EB",
    "id" : 109243735891656704,
    "created_at" : "Thu Sep 01 12:38:30 +0000 2011",
    "user" : {
      "name" : "Joi Ito",
      "screen_name" : "Joi",
      "protected" : false,
      "id_str" : "691353",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1083551051/headshotColor180_normal.jpg",
      "id" : 691353,
      "verified" : true
    }
  },
  "id" : 109287720819507201,
  "created_at" : "Thu Sep 01 15:33:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http://t.co/ecNLiMs",
      "expanded_url" : "http://www.nytimes.com/2011/09/01/fashion/recent-college-graduates-wait-for-their-real-careers-to-begin.html",
      "display_url" : "nytimes.com/2011/09/01/fas\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "109141512964673537",
  "text" : "RT @HarvardCSA: Generation Limbo: over educated, under employed http://t.co/ecNLiMs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 67 ],
        "url" : "http://t.co/ecNLiMs",
        "expanded_url" : "http://www.nytimes.com/2011/09/01/fashion/recent-college-graduates-wait-for-their-real-careers-to-begin.html",
        "display_url" : "nytimes.com/2011/09/01/fas\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "109137910837673984",
    "text" : "Generation Limbo: over educated, under employed http://t.co/ecNLiMs",
    "id" : 109137910837673984,
    "created_at" : "Thu Sep 01 05:38:00 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 109141512964673537,
  "created_at" : "Thu Sep 01 05:52:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]