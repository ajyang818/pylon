Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174634597269782528",
  "text" : "Ernst & Young all up in my twitter feed with a promoted tweet. not cool.",
  "id" : 174634597269782528,
  "created_at" : "Tue Feb 28 23:18:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174317776410902528",
  "geo" : {
  },
  "id_str" : "174318705663152128",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce except for our (undefeated) chicken wing eating team events.",
  "id" : 174318705663152128,
  "in_reply_to_status_id" : 174317776410902528,
  "created_at" : "Tue Feb 28 02:23:12 +0000 2012",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "andrewrosenthal",
      "indices" : [ 0, 16 ],
      "id_str" : "770178408",
      "id" : 770178408
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 33, 42 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174120347078107136",
  "geo" : {
  },
  "id_str" : "174317111848599552",
  "in_reply_to_user_id" : 15792969,
  "text" : "@andrewrosenthal I'm part time w @romotive right now, and will be joining them in LV for a few days over spring break!",
  "id" : 174317111848599552,
  "in_reply_to_status_id" : 174120347078107136,
  "created_at" : "Tue Feb 28 02:16:52 +0000 2012",
  "in_reply_to_screen_name" : "rosenthal",
  "in_reply_to_user_id_str" : "15792969",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 21, 33 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "excited",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174316877655457793",
  "text" : "Submitted project to @kickstarter and started talking with exotic leather manufacturers. #excited",
  "id" : 174316877655457793,
  "created_at" : "Tue Feb 28 02:15:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 3, 15 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174031288133632000",
  "text" : "RT @christinelu: ...it's that time of year again. brace yourselves for a week of TED tweets followed by a week of SXSW tweets.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "174027677047595008",
    "text" : "...it's that time of year again. brace yourselves for a week of TED tweets followed by a week of SXSW tweets.",
    "id" : 174027677047595008,
    "created_at" : "Mon Feb 27 07:06:46 +0000 2012",
    "user" : {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "protected" : false,
      "id_str" : "7782442",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3450541400/337b7b26ba5560ad0bd34ff4cfd4f160_normal.jpeg",
      "id" : 7782442,
      "verified" : false
    }
  },
  "id" : 174031288133632000,
  "created_at" : "Mon Feb 27 07:21:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 53, 62 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Skillshare",
      "screen_name" : "skillshare",
      "indices" : [ 99, 110 ],
      "id_str" : "171613435",
      "id" : 171613435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173993657379201024",
  "text" : "This week to do: GMAT, prototype iPhone case, hack w @romotive, chicken wing eating contest, teach @skillshare class, psets.",
  "id" : 173993657379201024,
  "created_at" : "Mon Feb 27 04:51:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sol\u00E9 Bicycle Co.",
      "screen_name" : "SoleBicycles",
      "indices" : [ 0, 13 ],
      "id_str" : "51428246",
      "id" : 51428246
    }, {
      "name" : "Dan Rumennik",
      "screen_name" : "djdan85",
      "indices" : [ 60, 68 ],
      "id_str" : "22803575",
      "id" : 22803575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173993103873671168",
  "in_reply_to_user_id" : 51428246,
  "text" : "@SoleBicycles heard you wanted to do an east coast push via @djdan85! Would love to chat.",
  "id" : 173993103873671168,
  "created_at" : "Mon Feb 27 04:49:23 +0000 2012",
  "in_reply_to_screen_name" : "SoleBicycles",
  "in_reply_to_user_id_str" : "51428246",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Rumennik",
      "screen_name" : "djdan85",
      "indices" : [ 0, 8 ],
      "id_str" : "22803575",
      "id" : 22803575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173989275728232448",
  "geo" : {
  },
  "id_str" : "173989745033089024",
  "in_reply_to_user_id" : 22803575,
  "text" : "@djdan85 looking forward to building (tangible) products.",
  "id" : 173989745033089024,
  "in_reply_to_status_id" : 173989275728232448,
  "created_at" : "Mon Feb 27 04:36:02 +0000 2012",
  "in_reply_to_screen_name" : "djdan85",
  "in_reply_to_user_id_str" : "22803575",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skillshare",
      "screen_name" : "skillshare",
      "indices" : [ 50, 61 ],
      "id_str" : "171613435",
      "id" : 171613435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/kZnLEkab",
      "expanded_url" : "http://skl.sh/wOBe7E",
      "display_url" : "skl.sh/wOBe7E"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172759668639285248",
  "text" : "Finally teaching \u201CFundamentals of Photography\u201D on @skillshare! http://t.co/kZnLEkab",
  "id" : 172759668639285248,
  "created_at" : "Thu Feb 23 19:08:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172240887928209408",
  "text" : "I'm all for competition but Microsoft's ads attacking Google are a little juvenile.",
  "id" : 172240887928209408,
  "created_at" : "Wed Feb 22 08:46:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172071772420710403",
  "text" : "RIM updates PlayBook to have native email support to the raucous sounds of no one caring.",
  "id" : 172071772420710403,
  "created_at" : "Tue Feb 21 21:34:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 11, 23 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Clear",
      "screen_name" : "UseClear",
      "indices" : [ 49, 58 ],
      "id_str" : "461175278",
      "id" : 461175278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171767067475845120",
  "geo" : {
  },
  "id_str" : "171800098869747712",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick @badboyboyce now you both have to try @UseClear.",
  "id" : 171800098869747712,
  "in_reply_to_status_id" : 171767067475845120,
  "created_at" : "Tue Feb 21 03:35:10 +0000 2012",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clear",
      "screen_name" : "UseClear",
      "indices" : [ 11, 20 ],
      "id_str" : "461175278",
      "id" : 461175278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3683745554, -71.1156369467 ]
  },
  "id_str" : "169683877844099072",
  "text" : "Downloaded @UseClear todo list app. Wonder if it will live up to the hype.",
  "id" : 169683877844099072,
  "created_at" : "Wed Feb 15 07:26:03 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Lin",
      "screen_name" : "JLin7",
      "indices" : [ 7, 13 ],
      "id_str" : "170424259",
      "id" : 170424259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3700972871, -71.1194128422 ]
  },
  "id_str" : "168140129578401794",
  "text" : "I love @JLin7's handshake with Fields - close the book and put away the glasses.",
  "id" : 168140129578401794,
  "created_at" : "Sat Feb 11 01:11:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Expedia ",
      "screen_name" : "Expedia",
      "indices" : [ 0, 8 ],
      "id_str" : "17365848",
      "id" : 17365848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168065383830528000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3787255975, -71.1156931953 ]
  },
  "id_str" : "168066596999397377",
  "in_reply_to_user_id" : 17365848,
  "text" : "@Expedia thanks for taking care of it.",
  "id" : 168066596999397377,
  "in_reply_to_status_id" : 168065383830528000,
  "created_at" : "Fri Feb 10 20:19:33 +0000 2012",
  "in_reply_to_screen_name" : "Expedia",
  "in_reply_to_user_id_str" : "17365848",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/9pNYUzrR",
      "expanded_url" : "http://www.autoblog.com/2012/02/09/toyota-gt86-comes-in-stripped-down-rc-flavor-in-japan/",
      "display_url" : "autoblog.com/2012/02/09/toy\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "168030457391366145",
  "text" : "Toyota to offer stripped GT86 in Japan only. http://t.co/9pNYUzrR",
  "id" : 168030457391366145,
  "created_at" : "Fri Feb 10 17:55:57 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Notepad++",
      "screen_name" : "Notepad_plus",
      "indices" : [ 0, 13 ],
      "id_str" : "268469475",
      "id" : 268469475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168019421418373120",
  "in_reply_to_user_id" : 268469475,
  "text" : "@notepad_plus and MikTeX is a phenomenal typesetting combination.",
  "id" : 168019421418373120,
  "created_at" : "Fri Feb 10 17:12:06 +0000 2012",
  "in_reply_to_screen_name" : "Notepad_plus",
  "in_reply_to_user_id_str" : "268469475",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 31, 45 ],
      "id_str" : "15593773",
      "id" : 15593773
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 57, 64 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cs124",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3603514681, -71.0872904237 ]
  },
  "id_str" : "166967663447375873",
  "text" : "Due to that monster Pset... RT @lexiberylross: I see you @khsieh, sleeping in #cs124",
  "id" : 166967663447375873,
  "created_at" : "Tue Feb 07 19:32:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166780954600411137",
  "text" : "Voigtlander announced a 17.5mm f/.95 lens for MFT. Along with the EM5, my faith in micro 4/3 has been restored.",
  "id" : 166780954600411137,
  "created_at" : "Tue Feb 07 07:10:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows Phone",
      "screen_name" : "windowsphone",
      "indices" : [ 17, 30 ],
      "id_str" : "16425197",
      "id" : 16425197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165160228973854721",
  "text" : "How can there be @windowsphone 8 details already when Verizon doesn't even have a good WP7 device yet??",
  "id" : 165160228973854721,
  "created_at" : "Thu Feb 02 19:50:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 0, 9 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164835434483023872",
  "in_reply_to_user_id" : 2425151,
  "text" : "@Facebook IPO crashed the SEC website.",
  "id" : 164835434483023872,
  "created_at" : "Wed Feb 01 22:20:04 +0000 2012",
  "in_reply_to_screen_name" : "facebook",
  "in_reply_to_user_id_str" : "2425151",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]