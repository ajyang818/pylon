Grailbird.data.tweets_2013_05 = 
[ {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yonatan Kogan",
      "screen_name" : "yjkogan",
      "indices" : [ 24, 32 ],
      "id_str" : "29844377",
      "id" : 29844377
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/330769506500759553/photo/1",
      "indices" : [ 69, 91 ],
      "url" : "http://t.co/wLcnSrswL3",
      "media_url" : "http://pbs.twimg.com/media/BJchHRoCUAA_qdq.jpg",
      "id_str" : "330769506509148160",
      "id" : 330769506509148160,
      "media_url_https" : "https://pbs.twimg.com/media/BJchHRoCUAA_qdq.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/wLcnSrswL3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330769506500759553",
  "text" : "Using FaceTime to bring @yjkogan into a hackathon. Technology rules. http://t.co/wLcnSrswL3",
  "id" : 330769506500759553,
  "created_at" : "Sat May 04 19:42:50 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/330746394908450816/photo/1",
      "indices" : [ 24, 46 ],
      "url" : "http://t.co/oxTqfXGNOb",
      "media_url" : "http://pbs.twimg.com/media/BJcMGAOCYAAD_a3.jpg",
      "id_str" : "330746394912645120",
      "id" : 330746394912645120,
      "media_url_https" : "https://pbs.twimg.com/media/BJcMGAOCYAAD_a3.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/oxTqfXGNOb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330746394908450816",
  "text" : "Next level iPad holder. http://t.co/oxTqfXGNOb",
  "id" : 330746394908450816,
  "created_at" : "Sat May 04 18:11:00 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Winston Waters II",
      "screen_name" : "winstonwatersii",
      "indices" : [ 13, 29 ],
      "id_str" : "15411491",
      "id" : 15411491
    }, {
      "name" : "Zach Hamed",
      "screen_name" : "zhamed",
      "indices" : [ 30, 37 ],
      "id_str" : "224321197",
      "id" : 224321197
    }, {
      "name" : "PitchBook Data",
      "screen_name" : "PitchBook",
      "indices" : [ 61, 71 ],
      "id_str" : "46470906",
      "id" : 46470906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330712931681579008",
  "geo" : {
  },
  "id_str" : "330728108061773825",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce @winstonwatersii @zhamed another good source is @PitchBook.",
  "id" : 330728108061773825,
  "in_reply_to_status_id" : 330712931681579008,
  "created_at" : "Sat May 04 16:58:20 +0000 2013",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarkBox",
      "screen_name" : "getbarkbox",
      "indices" : [ 55, 66 ],
      "id_str" : "419538326",
      "id" : 419538326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https://t.co/9zL8b3ZEsZ",
      "expanded_url" : "https://www.facebook.com/photo.php?fbid=371502612958737&set=a.261906473918352.54076.202889316486735&type=1&theater",
      "display_url" : "facebook.com/photo.php?fbid\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330385098631442432",
  "text" : "Imitation is the sincerest form of flattery? Brazilian @GetBarkBox clone doesn't even bother to remove BB's logo: https://t.co/9zL8b3ZEsZ",
  "id" : 330385098631442432,
  "created_at" : "Fri May 03 18:15:20 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DISGRASIAN\u2122",
      "screen_name" : "disgrasian",
      "indices" : [ 11, 22 ],
      "id_str" : "1472021",
      "id" : 1472021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330375600575508483",
  "geo" : {
  },
  "id_str" : "330383721452679169",
  "in_reply_to_user_id" : 1472021,
  "text" : "\u30FE(\uFF20\u2312\u30FC\u2312\uFF20)\u30CE \u201C@disgrasian: I need a hug. Make it awkward though, I'm Asian.\u201D",
  "id" : 330383721452679169,
  "in_reply_to_status_id" : 330375600575508483,
  "created_at" : "Fri May 03 18:09:52 +0000 2013",
  "in_reply_to_screen_name" : "disgrasian",
  "in_reply_to_user_id_str" : "1472021",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 0, 10 ],
      "id_str" : "22745680",
      "id" : 22745680
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 11, 25 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330339723476340736",
  "geo" : {
  },
  "id_str" : "330345496818360320",
  "in_reply_to_user_id" : 22745680,
  "text" : "@Besvinick @libbybrittain Spotify is sorely missing Skyfall still.",
  "id" : 330345496818360320,
  "in_reply_to_status_id" : 330339723476340736,
  "created_at" : "Fri May 03 15:37:58 +0000 2013",
  "in_reply_to_screen_name" : "Besvinick",
  "in_reply_to_user_id_str" : "22745680",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 57, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330340394573377537",
  "text" : "If \"The Great Gatsby\" were written today it'd be titled \"#firstworldproblems.\"",
  "id" : 330340394573377537,
  "created_at" : "Fri May 03 15:17:42 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http://t.co/zEfEdq562P",
      "expanded_url" : "http://timehop.com/c/5181e1193dafc5663102ae7d",
      "display_url" : "timehop.com/c/5181e1193daf\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330314175391862784",
  "text" : "A question I still ask to this day. http://t.co/zEfEdq562P",
  "id" : 330314175391862784,
  "created_at" : "Fri May 03 13:33:31 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 0, 6 ],
      "id_str" : "15227849",
      "id" : 15227849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330201900681154561",
  "geo" : {
  },
  "id_str" : "330206795702349824",
  "in_reply_to_user_id" : 15227849,
  "text" : "@semil Spam Samurai.",
  "id" : 330206795702349824,
  "in_reply_to_status_id" : 330201900681154561,
  "created_at" : "Fri May 03 06:26:49 +0000 2013",
  "in_reply_to_screen_name" : "semil",
  "in_reply_to_user_id_str" : "15227849",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "judgingyou",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330097027742584832",
  "text" : "OH: \"do you even *have* a twitter account?\" #judgingyou",
  "id" : 330097027742584832,
  "created_at" : "Thu May 02 23:10:38 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 33, 39 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https://t.co/E5TcaCeCsO",
      "expanded_url" : "https://www.youtube.com/watch?feature=player_embedded&v=cyjKOJhIiuU",
      "display_url" : "youtube.com/watch?feature=\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330084648623423489",
  "text" : "Congrats to Robert Woods team at @HSEAS on the first flight of the robobees! https://t.co/E5TcaCeCsO",
  "id" : 330084648623423489,
  "created_at" : "Thu May 02 22:21:27 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 56, 64 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Chuck Yeager",
      "screen_name" : "GenChuckYeager",
      "indices" : [ 66, 81 ],
      "id_str" : "111778335",
      "id" : 111778335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330067988759859200",
  "text" : "That moment when you discover your childhood hero is on @twitter: @GenChuckYeager",
  "id" : 330067988759859200,
  "created_at" : "Thu May 02 21:15:15 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hipster Hacker",
      "screen_name" : "hipsterhacker",
      "indices" : [ 3, 17 ],
      "id_str" : "261546340",
      "id" : 261546340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330066301705928704",
  "text" : "RT @hipsterhacker: Imperative programming is so over.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "330060033750614016",
    "text" : "Imperative programming is so over.",
    "id" : 330060033750614016,
    "created_at" : "Thu May 02 20:43:38 +0000 2013",
    "user" : {
      "name" : "Hipster Hacker",
      "screen_name" : "hipsterhacker",
      "protected" : false,
      "id_str" : "261546340",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1263403750/riverscuomo-mustache_normal.jpg",
      "id" : 261546340,
      "verified" : false
    }
  },
  "id" : 330066301705928704,
  "created_at" : "Thu May 02 21:08:33 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/TWroSoocse",
      "expanded_url" : "http://twistedoakstudios.com/blog/Post3631_computer-science-blows-my-mind",
      "display_url" : "twistedoakstudios.com/blog/Post3631_\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330046477533593602",
  "text" : "\"Computer Science Blows My Mind\" - http://t.co/TWroSoocse",
  "id" : 330046477533593602,
  "created_at" : "Thu May 02 19:49:46 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren Buffett",
      "screen_name" : "WarrenBuffett",
      "indices" : [ 3, 17 ],
      "id_str" : "1364930179",
      "id" : 1364930179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330035151495114752",
  "text" : "RT @WarrenBuffett: Warren is in the house.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "329993701524918272",
    "text" : "Warren is in the house.",
    "id" : 329993701524918272,
    "created_at" : "Thu May 02 16:20:04 +0000 2013",
    "user" : {
      "name" : "Warren Buffett",
      "screen_name" : "WarrenBuffett",
      "protected" : false,
      "id_str" : "1364930179",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3599636117/8468a03db84ec4211c3efeba18ac3925_normal.png",
      "id" : 1364930179,
      "verified" : true
    }
  },
  "id" : 330035151495114752,
  "created_at" : "Thu May 02 19:04:46 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/330000585304719361/photo/1",
      "indices" : [ 45, 67 ],
      "url" : "http://t.co/9LqrrAOBwv",
      "media_url" : "http://pbs.twimg.com/media/BJRlyK9CQAAe30J.jpg",
      "id_str" : "330000585313107968",
      "id" : 330000585313107968,
      "media_url_https" : "https://pbs.twimg.com/media/BJRlyK9CQAAe30J.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com/9LqrrAOBwv"
    } ],
    "hashtags" : [ {
      "text" : "wut",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330000585304719361",
  "text" : "Kaspersky for Mac: Ready for Windows 8! #wut http://t.co/9LqrrAOBwv",
  "id" : 330000585304719361,
  "created_at" : "Thu May 02 16:47:25 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marissamayer",
      "screen_name" : "marissamayer",
      "indices" : [ 3, 16 ],
      "id_str" : "17503180",
      "id" : 17503180
    }, {
      "name" : "Yahoo! ",
      "screen_name" : "Yahoo",
      "indices" : [ 29, 35 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "Astrid",
      "screen_name" : "astrid",
      "indices" : [ 37, 44 ],
      "id_str" : "41886173",
      "id" : 41886173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http://t.co/ysNSD67Hej",
      "expanded_url" : "http://blog.astrid.com/blog/2013/05/01/yahoo-acquires-astrid/",
      "display_url" : "blog.astrid.com/blog/2013/05/0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "329818233299402752",
  "text" : "RT @marissamayer: Welcome to @Yahoo, @astrid!!  Excited to have you :). http://t.co/ysNSD67Hej",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo! ",
        "screen_name" : "Yahoo",
        "indices" : [ 11, 17 ],
        "id_str" : "19380829",
        "id" : 19380829
      }, {
        "name" : "Astrid",
        "screen_name" : "astrid",
        "indices" : [ 19, 26 ],
        "id_str" : "41886173",
        "id" : 41886173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http://t.co/ysNSD67Hej",
        "expanded_url" : "http://blog.astrid.com/blog/2013/05/01/yahoo-acquires-astrid/",
        "display_url" : "blog.astrid.com/blog/2013/05/0\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "329809631436210176",
    "text" : "Welcome to @Yahoo, @astrid!!  Excited to have you :). http://t.co/ysNSD67Hej",
    "id" : 329809631436210176,
    "created_at" : "Thu May 02 04:08:38 +0000 2013",
    "user" : {
      "name" : "marissamayer",
      "screen_name" : "marissamayer",
      "protected" : false,
      "id_str" : "17503180",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/323982494/marissa_new4_normal.jpg",
      "id" : 17503180,
      "verified" : true
    }
  },
  "id" : 329818233299402752,
  "created_at" : "Thu May 02 04:42:49 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxstoller",
      "screen_name" : "maxstoller",
      "indices" : [ 0, 11 ],
      "id_str" : "15337726",
      "id" : 15337726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329684386498875392",
  "geo" : {
  },
  "id_str" : "329686848383361026",
  "in_reply_to_user_id" : 15337726,
  "text" : "@maxstoller nothing really. Just spec'ing one out to see how cheap they are now.",
  "id" : 329686848383361026,
  "in_reply_to_status_id" : 329684386498875392,
  "created_at" : "Wed May 01 20:00:44 +0000 2013",
  "in_reply_to_screen_name" : "maxstoller",
  "in_reply_to_user_id_str" : "15337726",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 8, 15 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/329678754169364480/photo/1",
      "indices" : [ 72, 94 ],
      "url" : "http://t.co/FN9HB7ULN7",
      "media_url" : "http://pbs.twimg.com/media/BJNBFIiCIAEmq2Q.jpg",
      "id_str" : "329678754173558785",
      "id" : 329678754173558785,
      "media_url_https" : "https://pbs.twimg.com/media/BJNBFIiCIAEmq2Q.jpg",
      "sizes" : [ {
        "h" : 286,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/FN9HB7ULN7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329678754169364480",
  "text" : "Thanks, @Amazon! That was the next thing I needed to build this server. http://t.co/FN9HB7ULN7",
  "id" : 329678754169364480,
  "created_at" : "Wed May 01 19:28:34 +0000 2013",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]