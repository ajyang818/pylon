Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/252582663880339456/photo/1",
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/QzPx6H4u",
      "media_url" : "http://pbs.twimg.com/media/A4FamDWCcAAP5jJ.jpg",
      "id_str" : "252582663888728064",
      "id" : 252582663888728064,
      "media_url_https" : "https://pbs.twimg.com/media/A4FamDWCcAAP5jJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/QzPx6H4u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "252582663880339456",
  "text" : "Finally got my hands on a Raspberry Pi! What to do? HTPC? Mobile pen test device? Home automation? http://t.co/QzPx6H4u",
  "id" : 252582663880339456,
  "created_at" : "Mon Oct 01 01:36:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "252563912686436352",
  "text" : "\"The next stop is Mets-Willet Point, where the Mets attempt to play baseball.\"",
  "id" : 252563912686436352,
  "created_at" : "Mon Oct 01 00:21:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maker Faire",
      "screen_name" : "makerfaire",
      "indices" : [ 24, 35 ],
      "id_str" : "1578141",
      "id" : 1578141
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/251843825117585409/photo/1",
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/oQMIbXgL",
      "media_url" : "http://pbs.twimg.com/media/A366n-dCYAEZjca.jpg",
      "id_str" : "251843825121779713",
      "id" : 251843825121779713,
      "media_url_https" : "https://pbs.twimg.com/media/A366n-dCYAEZjca.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/oQMIbXgL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251843825117585409",
  "text" : "So many things to do at @MakerFaire! http://t.co/oQMIbXgL",
  "id" : 251843825117585409,
  "created_at" : "Sat Sep 29 00:40:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smokey Robotic",
      "screen_name" : "SmokeyRobotic",
      "indices" : [ 1, 15 ],
      "id_str" : "154203947",
      "id" : 154203947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251764681876852739",
  "text" : ".@SmokeyRobotic has some of the nicest PR people (and coolest music). Keep up the good work!",
  "id" : 251764681876852739,
  "created_at" : "Fri Sep 28 19:25:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 3, 17 ],
      "id_str" : "15593773",
      "id" : 15593773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251744246309208065",
  "text" : "RT @lexiberylross: STACKS ON STACKS ON HEAP",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "251744027110686720",
    "text" : "STACKS ON STACKS ON HEAP",
    "id" : 251744027110686720,
    "created_at" : "Fri Sep 28 18:03:47 +0000 2012",
    "user" : {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "protected" : false,
      "id_str" : "15593773",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1909477451/image_normal.jpg",
      "id" : 15593773,
      "verified" : false
    }
  },
  "id" : 251744246309208065,
  "created_at" : "Fri Sep 28 18:04:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/6W0NzvCi",
      "expanded_url" : "http://feeds.boingboing.net/~r/boingboing/iBag/~3/s-hzNE15qjQ/human-flesh-pop-up-butcher-sho.html",
      "display_url" : "feeds.boingboing.net/~r/boingboing/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251678517903900672",
  "text" : "Annnnd the most WTF advertising campaign award goes to Resident Evil.  http://t.co/6W0NzvCi",
  "id" : 251678517903900672,
  "created_at" : "Fri Sep 28 13:43:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/mzuhuFsG",
      "expanded_url" : "http://www.wired.com/gadgetlab/2012/09/nokia-lumia-premium-pricing-will-hinder-windows-phone-adoption/",
      "display_url" : "wired.com/gadgetlab/2012\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104422155, -74.0063682646 ]
  },
  "id_str" : "251555956067024896",
  "text" : "Nokia's branding problem. Pity, since I genuinely enjoy Windows Phone experience. http://t.co/mzuhuFsG",
  "id" : 251555956067024896,
  "created_at" : "Fri Sep 28 05:36:28 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/IrZOVHF1",
      "expanded_url" : "http://pandodaily.com/2012/09/27/shut-the-fuck-up/",
      "display_url" : "pandodaily.com/2012/09/27/shu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104960957, -74.0063717343 ]
  },
  "id_str" : "251555030220537856",
  "text" : "\"Having money, like possessing a fully-stocked brain, didn\u2019t used to be an inherently evil thing in America.\" http://t.co/IrZOVHF1",
  "id" : 251555030220537856,
  "created_at" : "Fri Sep 28 05:32:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.716288155, -74.0018492472 ]
  },
  "id_str" : "251448932650070016",
  "text" : "It's embarrassing that my Chinese is so bad that proprietors in Chinatown decide to respond to me in English.",
  "id" : 251448932650070016,
  "created_at" : "Thu Sep 27 22:31:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeder",
      "screen_name" : "reederapp",
      "indices" : [ 0, 10 ],
      "id_str" : "79033767",
      "id" : 79033767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7104383019, -74.0063422721 ]
  },
  "id_str" : "251181241280376832",
  "in_reply_to_user_id" : 79033767,
  "text" : "@reederapp is freezing when I try to email link in iOS 5 on an iPhone 4S. It's unusable.",
  "id" : 251181241280376832,
  "created_at" : "Thu Sep 27 04:47:29 +0000 2012",
  "in_reply_to_screen_name" : "reederapp",
  "in_reply_to_user_id_str" : "79033767",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7097433704, -74.0066600763 ]
  },
  "id_str" : "251109624474914817",
  "text" : "Given the iPhone 5's buggy maps and questionably durable aluminum frame, I think Jobs is rolling in his grave right now.",
  "id" : 251109624474914817,
  "created_at" : "Thu Sep 27 00:02:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251075065561612288",
  "text" : "Where can I buy Meixin mooncakes in NYC Chinatown?",
  "id" : 251075065561612288,
  "created_at" : "Wed Sep 26 21:45:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250724511920566273",
  "text" : "Idea: Kinect on a Roomba to 3D map a room; scrape furniture dimensions from IKEA catalog. Virtually place furniture, then one-click-ship.",
  "id" : 250724511920566273,
  "created_at" : "Tue Sep 25 22:32:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 99 ],
      "url" : "https://t.co/xdaKmmji",
      "expanded_url" : "https://new.myspace.com/play",
      "display_url" : "new.myspace.com/play"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250395881117974528",
  "text" : "Wow, maybe it's time to go back to Myspace. Facebook's getting stale anyways. https://t.co/xdaKmmji",
  "id" : 250395881117974528,
  "created_at" : "Tue Sep 25 00:46:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249367902770327552",
  "text" : "Overheard in William Sonoma: \"Wow, white people have so many unnecessarily specialized kitchen tools.\"",
  "id" : 249367902770327552,
  "created_at" : "Sat Sep 22 04:41:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bianca Bosker",
      "screen_name" : "bbosker",
      "indices" : [ 3, 11 ],
      "id_str" : "21736571",
      "id" : 21736571
    }, {
      "name" : "Danilo Campos",
      "screen_name" : "_danilo",
      "indices" : [ 16, 24 ],
      "id_str" : "14625899",
      "id" : 14625899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/5Abn6it5",
      "expanded_url" : "http://i.imgur.com/D4xKq.jpg",
      "display_url" : "i.imgur.com/D4xKq.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249111857841971200",
  "text" : "RT @bbosker: RT @_danilo: iPhone 5 boxes pour through the FedEx system. http://t.co/5Abn6it5",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Danilo Campos",
        "screen_name" : "_danilo",
        "indices" : [ 3, 11 ],
        "id_str" : "14625899",
        "id" : 14625899
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http://t.co/5Abn6it5",
        "expanded_url" : "http://i.imgur.com/D4xKq.jpg",
        "display_url" : "i.imgur.com/D4xKq.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "249109673612042240",
    "text" : "RT @_danilo: iPhone 5 boxes pour through the FedEx system. http://t.co/5Abn6it5",
    "id" : 249109673612042240,
    "created_at" : "Fri Sep 21 11:35:49 +0000 2012",
    "user" : {
      "name" : "Bianca Bosker",
      "screen_name" : "bbosker",
      "protected" : false,
      "id_str" : "21736571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2231961445/Screen_shot_2012-05-19_at_10.14.46_AM_normal.png",
      "id" : 21736571,
      "verified" : true
    }
  },
  "id" : 249111857841971200,
  "created_at" : "Fri Sep 21 11:44:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Fox",
      "screen_name" : "kfury",
      "indices" : [ 52, 58 ],
      "id_str" : "785",
      "id" : 785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.717424783, -73.995080106 ]
  },
  "id_str" : "249110437273141248",
  "text" : "Easy: launch crippled iOS version with android ads. @kfury: what a quandary: Launch great iOS Google Maps or hope people move to Android?",
  "id" : 249110437273141248,
  "created_at" : "Fri Sep 21 11:38:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 11, 18 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7172970008, -73.9952286334 ]
  },
  "id_str" : "249109728444178432",
  "text" : "Introduced @square to a bakery in Chinatown. Dozens more here that would benefit from affordable card processing capability.",
  "id" : 249109728444178432,
  "created_at" : "Fri Sep 21 11:36:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7097141445, -74.006858524 ]
  },
  "id_str" : "248962006042955776",
  "text" : "After all these maps shenanigans, I'm hesitant to upgrade to iOS6. Hell, makes me want to use android again. Native Google apps ftw.",
  "id" : 248962006042955776,
  "created_at" : "Fri Sep 21 01:49:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/y7sW9nPe",
      "expanded_url" : "http://www.theverge.com/2012/9/20/3365880/kickstarter-new-project-guidelines-risks-challenges",
      "display_url" : "theverge.com/2012/9/20/3365\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248961602404106240",
  "text" : "Kickstarter bans product renderings. Patent Office used to require models as well, prevents trolling. http://t.co/y7sW9nPe",
  "id" : 248961602404106240,
  "created_at" : "Fri Sep 21 01:47:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/iBjae26s",
      "expanded_url" : "http://theamazingios6maps.tumblr.com/",
      "display_url" : "theamazingios6maps.tumblr.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248840175092916224",
  "text" : "If you've been unfortunate enough to have to use iOS6 Maps: http://t.co/iBjae26s",
  "id" : 248840175092916224,
  "created_at" : "Thu Sep 20 17:44:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netflix US",
      "screen_name" : "netflix",
      "indices" : [ 8, 16 ],
      "id_str" : "16573941",
      "id" : 16573941
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/248604718014795777/photo/1",
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/cmx9lGWe",
      "media_url" : "http://pbs.twimg.com/media/A3M4rIMCEAAulW3.png",
      "id_str" : "248604718018990080",
      "id" : 248604718018990080,
      "media_url_https" : "https://pbs.twimg.com/media/A3M4rIMCEAAulW3.png",
      "sizes" : [ {
        "h" : 327,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/cmx9lGWe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248604718014795777",
  "text" : "I think @Netflix's email server is spazzing out. http://t.co/cmx9lGWe",
  "id" : 248604718014795777,
  "created_at" : "Thu Sep 20 02:09:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/BWb3mjd2",
      "expanded_url" : "http://feedproxy.google.com/~r/Techcrunch/~3/d_FboqIIN9s/",
      "display_url" : "feedproxy.google.com/~r/Techcrunch/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248501073885671424",
  "text" : "Home-grown visualization used to monitor Facebook's massive server farms. http://t.co/BWb3mjd2",
  "id" : 248501073885671424,
  "created_at" : "Wed Sep 19 19:17:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stripe",
      "screen_name" : "stripe",
      "indices" : [ 9, 16 ],
      "id_str" : "102812444",
      "id" : 102812444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 62 ],
      "url" : "https://t.co/yMw9JOIm",
      "expanded_url" : "https://stripe.com/blog/stripe-in-canada",
      "display_url" : "stripe.com/blog/stripe-in\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248461648073994241",
  "text" : "Congrats @stripe on launching in Canada! https://t.co/yMw9JOIm",
  "id" : 248461648073994241,
  "created_at" : "Wed Sep 19 16:40:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Wiesen",
      "screen_name" : "ewiesen",
      "indices" : [ 0, 8 ],
      "id_str" : "798536",
      "id" : 798536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247433560598908928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9361812724, -78.73006708 ]
  },
  "id_str" : "247433984064249856",
  "in_reply_to_user_id" : 798536,
  "text" : "@ewiesen I'm going to be an optimist and hope for super powers from all the backscatter.",
  "id" : 247433984064249856,
  "in_reply_to_status_id" : 247433560598908928,
  "created_at" : "Sun Sep 16 20:37:13 +0000 2012",
  "in_reply_to_screen_name" : "ewiesen",
  "in_reply_to_user_id_str" : "798536",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cenciotti",
      "screen_name" : "cencio4",
      "indices" : [ 27, 35 ],
      "id_str" : "53138772",
      "id" : 53138772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/f97Zu0Fd",
      "expanded_url" : "http://wp.me/pEfC-3AM",
      "display_url" : "wp.me/pEfC-3AM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9349842528, -78.7261357997 ]
  },
  "id_str" : "247429156567142400",
  "text" : "That's double the Raptor!! @cencio4: China unveils its brand new stealth fighter: the J-31 \"Falcon Eagle\". http://t.co/f97Zu0Fd",
  "id" : 247429156567142400,
  "created_at" : "Sun Sep 16 20:18:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.2127873247, -83.3592420394 ]
  },
  "id_str" : "247322006691930112",
  "text" : "Airlines burn $7-8B of fuel a year taxiing. 747 can consume one ton of fuel during taxi. Lufthansa to roll out robot solution next year.",
  "id" : 247322006691930112,
  "created_at" : "Sun Sep 16 13:12:16 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatishappening",
      "indices" : [ 41, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247304000255438848",
  "text" : "Gangam Style is now #1 on iTunes in USA. #whatishappening",
  "id" : 247304000255438848,
  "created_at" : "Sun Sep 16 12:00:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/oGgrDYor",
      "expanded_url" : "http://feeds.boingboing.net/~r/boingboing/iBag/~3/qtgvR4fhl6g/yahoo-to-give-employees-any-sm.html",
      "display_url" : "feeds.boingboing.net/~r/boingboing/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247294870664916992",
  "text" : "Yahoo to give employees any smartphone they like... As long as it's not a Blackberry. Death bells tolling. http://t.co/oGgrDYor",
  "id" : 247294870664916992,
  "created_at" : "Sun Sep 16 11:24:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/Q81TLejs",
      "expanded_url" : "http://feedproxy.google.com/~r/hackaday/LgoM/~3/Sn_oZm_7GQc/",
      "display_url" : "feedproxy.google.com/~r/hackaday/Lg\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247294569979449344",
  "text" : "I was proud of changing my own oil, but this high school senior built a 700+ hp electric Honda S2000... http://t.co/Q81TLejs",
  "id" : 247294569979449344,
  "created_at" : "Sun Sep 16 11:23:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/247293404168454144/photo/1",
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/2Y7F9Gvh",
      "media_url" : "http://pbs.twimg.com/media/A26QCncCAAIHz-B.jpg",
      "id_str" : "247293404172648450",
      "id" : 247293404172648450,
      "media_url_https" : "https://pbs.twimg.com/media/A26QCncCAAIHz-B.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/2Y7F9Gvh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247293404168454144",
  "text" : "Bad news: Google Nexus 7 cracks easily in padded backpack. Good news: really good warranty service. http://t.co/2Y7F9Gvh",
  "id" : 247293404168454144,
  "created_at" : "Sun Sep 16 11:18:37 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.1999051099, -83.3870848272 ]
  },
  "id_str" : "247284577905803264",
  "text" : "757s make a lot of disconcerting noises while they are landing.",
  "id" : 247284577905803264,
  "created_at" : "Sun Sep 16 10:43:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247039309344014336",
  "text" : "Old iPod Nano + SDK + connectivity would have been an amazing product. New Nano took many steps back in product design.",
  "id" : 247039309344014336,
  "created_at" : "Sat Sep 15 18:28:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Fung",
      "screen_name" : "andrewjfung",
      "indices" : [ 3, 15 ],
      "id_str" : "21522890",
      "id" : 21522890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246808502473986048",
  "text" : "RT @andrewjfung: Who blogs more: College educated Chinese Americans.... or EVERYONE ELSE COMBINED?",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "246805832518475777",
    "text" : "Who blogs more: College educated Chinese Americans.... or EVERYONE ELSE COMBINED?",
    "id" : 246805832518475777,
    "created_at" : "Sat Sep 15 03:01:10 +0000 2012",
    "user" : {
      "name" : "Andrew Fung",
      "screen_name" : "andrewjfung",
      "protected" : false,
      "id_str" : "21522890",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3446446074/79e25a29feac284508d64abed6ba1f87_normal.jpeg",
      "id" : 21522890,
      "verified" : false
    }
  },
  "id" : 246808502473986048,
  "created_at" : "Sat Sep 15 03:11:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246808445687320576",
  "text" : "The Presidential election is really just a high stakes reality show with a new season every four years.",
  "id" : 246808445687320576,
  "created_at" : "Sat Sep 15 03:11:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/z09BsSY0",
      "expanded_url" : "http://www.pcmag.com/article2/0,2817,2409635,00.asp",
      "display_url" : "pcmag.com/article2/0,281\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246695816834711552",
  "text" : "With 5nm chips, Intel is good on Moore's law for another decade, gives finger to nay-sayers. http://t.co/z09BsSY0",
  "id" : 246695816834711552,
  "created_at" : "Fri Sep 14 19:44:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246649041730023424",
  "text" : "Did everyone just stop caring about 7\" iPad rumors now that we have a shiny new iPhone?",
  "id" : 246649041730023424,
  "created_at" : "Fri Sep 14 16:38:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thairu",
      "screen_name" : "thairu",
      "indices" : [ 0, 7 ],
      "id_str" : "36772968",
      "id" : 36772968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246429162372472832",
  "geo" : {
  },
  "id_str" : "246480946247905280",
  "in_reply_to_user_id" : 36772968,
  "text" : "@thairu nothing ventured nothing gained.",
  "id" : 246480946247905280,
  "in_reply_to_status_id" : 246429162372472832,
  "created_at" : "Fri Sep 14 05:30:11 +0000 2012",
  "in_reply_to_screen_name" : "thairu",
  "in_reply_to_user_id_str" : "36772968",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246407205845356544",
  "text" : "Cool social engineering idea: go to speed dating and casually ask everyone common security questions.",
  "id" : 246407205845356544,
  "created_at" : "Fri Sep 14 00:37:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows Phone",
      "screen_name" : "windowsphone",
      "indices" : [ 42, 55 ],
      "id_str" : "16425197",
      "id" : 16425197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246334986532315136",
  "text" : "I still just want a flagship global Nokia @windowsphone for Verizon.",
  "id" : 246334986532315136,
  "created_at" : "Thu Sep 13 19:50:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Mintz",
      "screen_name" : "jakemintz",
      "indices" : [ 3, 13 ],
      "id_str" : "12469412",
      "id" : 12469412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246327243180240896",
  "text" : "RT @jakemintz: Time to start these up again. My contribution: the iPhone 6 will definitely have NFC. Why? Because the next iPhone will a ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "246303554149679104",
    "text" : "Time to start these up again. My contribution: the iPhone 6 will definitely have NFC. Why? Because the next iPhone will always have NFC.",
    "id" : 246303554149679104,
    "created_at" : "Thu Sep 13 17:45:18 +0000 2012",
    "user" : {
      "name" : "Jake Mintz",
      "screen_name" : "jakemintz",
      "protected" : false,
      "id_str" : "12469412",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1253906043/49148_7303961_1135820_q_normal.jpg",
      "id" : 12469412,
      "verified" : false
    }
  },
  "id" : 246327243180240896,
  "created_at" : "Thu Sep 13 19:19:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 17, 24 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "Google Chrome",
      "screen_name" : "googlechrome",
      "indices" : [ 58, 71 ],
      "id_str" : "56505125",
      "id" : 56505125
    }, {
      "name" : "Firefox",
      "screen_name" : "firefox",
      "indices" : [ 91, 99 ],
      "id_str" : "2142731",
      "id" : 2142731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/SlScWMuh",
      "expanded_url" : "http://www.youtube.com/watch?v=NBQNoB5HePE&feature=youtu.be",
      "display_url" : "youtube.com/watch?v=NBQNoB\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245975111658790912",
  "text" : "For some reason, @google docs have NEVER worked for me in @GoogleChrome. I have to fire up @FireFox just to use it... http://t.co/SlScWMuh",
  "id" : 245975111658790912,
  "created_at" : "Wed Sep 12 20:00:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245942699335745536",
  "text" : "The iPhone is now a product of sustained evolution, not revolution.",
  "id" : 245942699335745536,
  "created_at" : "Wed Sep 12 17:51:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245934724885921792",
  "text" : "I feel like Apple wasn't able to keep anything about the iPhone 5 secret leading up to today's official announcement.",
  "id" : 245934724885921792,
  "created_at" : "Wed Sep 12 17:19:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 3, 15 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245665183178051584",
  "text" : "RT @christinelu: ...you think they have enough blog posts about zuckerberg on techcrunch right now? lol",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "245662244745138177",
    "text" : "...you think they have enough blog posts about zuckerberg on techcrunch right now? lol",
    "id" : 245662244745138177,
    "created_at" : "Tue Sep 11 23:16:57 +0000 2012",
    "user" : {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "protected" : false,
      "id_str" : "7782442",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3450541400/337b7b26ba5560ad0bd34ff4cfd4f160_normal.jpeg",
      "id" : 7782442,
      "verified" : false
    }
  },
  "id" : 245665183178051584,
  "created_at" : "Tue Sep 11 23:28:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boosted Boards",
      "screen_name" : "BoostedBoards",
      "indices" : [ 68, 82 ],
      "id_str" : "545821170",
      "id" : 545821170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/Xyt4Z9L9",
      "expanded_url" : "http://www.kickstarter.com/projects/170315130/boosted-boards-the-worlds-lightest-electric-vehicl",
      "display_url" : "kickstarter.com/projects/17031\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245659667701833729",
  "text" : "A friend's DIY e-skateboard was a 20lb fire hazard w/ lead battery. @BoostedBoards fixes all of that and adds style. http://t.co/Xyt4Z9L9",
  "id" : 245659667701833729,
  "created_at" : "Tue Sep 11 23:06:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 19, 25 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "paranoid",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/Yqs6Fipj",
      "expanded_url" : "http://www.wired.com/gadgetlab/2012/09/cosmo-the-god-who-fell-to-earth/all/",
      "display_url" : "wired.com/gadgetlab/2012\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245659126095568896",
  "text" : "After reading this @Wired post on social engineering, I've switched Gmail, Paypal, and BofA to 2-factor auth. #paranoid http://t.co/Yqs6Fipj",
  "id" : 245659126095568896,
  "created_at" : "Tue Sep 11 23:04:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin C. Tofel",
      "screen_name" : "KevinCTofel",
      "indices" : [ 3, 15 ],
      "id_str" : "43553",
      "id" : 43553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245556851100483586",
  "text" : "RT @KevinCTofel: New GMail filter: If Subject has \"Webinar\" send directly to Trash, burn it, rip it to shreds, obliterate it &amp; send  ...",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/webstore/detail/ikknnkomiokeodcdkknnhgjmncfiefmn\" rel=\"nofollow\">Notifier for Chrome</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "245554301949317120",
    "text" : "New GMail filter: If Subject has \"Webinar\" send directly to Trash, burn it, rip it to shreds, obliterate it &amp; send it to Trash a second time",
    "id" : 245554301949317120,
    "created_at" : "Tue Sep 11 16:08:02 +0000 2012",
    "user" : {
      "name" : "Kevin C. Tofel",
      "screen_name" : "KevinCTofel",
      "protected" : false,
      "id_str" : "43553",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2818778140/acd51a476c7d1bb77372c2ddea31445c_normal.jpeg",
      "id" : 43553,
      "verified" : false
    }
  },
  "id" : 245556851100483586,
  "created_at" : "Tue Sep 11 16:18:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DreamHost",
      "screen_name" : "DreamHost",
      "indices" : [ 49, 59 ],
      "id_str" : "14217022",
      "id" : 14217022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245275952928665601",
  "text" : "I'm glad I moved all my websites from GoDaddy to @Dreamhost last year. Anonymous managed to take down all of GD's DNS.",
  "id" : 245275952928665601,
  "created_at" : "Mon Sep 10 21:41:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 27, 33 ],
      "id_str" : "236921052",
      "id" : 236921052
    }, {
      "name" : "Michelle Borkin",
      "screen_name" : "michelle_borkin",
      "indices" : [ 99, 115 ],
      "id_str" : "37801244",
      "id" : 37801244
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/244179948770828288/photo/1",
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/60X1vZAt",
      "media_url" : "http://pbs.twimg.com/media/A2OAXqUCIAAWzfZ.jpg",
      "id_str" : "244179948791799808",
      "id" : 244179948791799808,
      "media_url_https" : "https://pbs.twimg.com/media/A2OAXqUCIAAWzfZ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/60X1vZAt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244068294255054848",
  "geo" : {
  },
  "id_str" : "244179948770828288",
  "in_reply_to_user_id" : 37801244,
  "text" : "Computer networks class at @hseas seems to have gotten a lot more interesting since I took it. via @michelle_borkin http://t.co/60X1vZAt",
  "id" : 244179948770828288,
  "in_reply_to_status_id" : 244068294255054848,
  "created_at" : "Fri Sep 07 21:06:51 +0000 2012",
  "in_reply_to_screen_name" : "michelle_borkin",
  "in_reply_to_user_id_str" : "37801244",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 18, 28 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "Plympton",
      "screen_name" : "plympton",
      "indices" : [ 33, 42 ],
      "id_str" : "316727597",
      "id" : 316727597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/p4Okio5P",
      "expanded_url" : "http://boingboing.net/2012/09/06/kickstarting-a-literary-studio.html",
      "display_url" : "boingboing.net/2012/09/06/kic\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244153962004094976",
  "text" : "Nice shout out to @jenny8lee and @plympton from Boing Boing! http://t.co/p4Okio5P",
  "id" : 244153962004094976,
  "created_at" : "Fri Sep 07 19:23:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 3, 13 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "Plympton",
      "screen_name" : "plympton",
      "indices" : [ 85, 94 ],
      "id_str" : "316727597",
      "id" : 316727597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/ROGZqu5z",
      "expanded_url" : "http://bit.ly/NOYhuR",
      "display_url" : "bit.ly/NOYhuR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243807468768092160",
  "text" : "RT @jenny8lee: Amazon Press release for Kindle Serials. Love the \"collaboration with @plympton\" http://t.co/ROGZqu5z",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Plympton",
        "screen_name" : "plympton",
        "indices" : [ 70, 79 ],
        "id_str" : "316727597",
        "id" : 316727597
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http://t.co/ROGZqu5z",
        "expanded_url" : "http://bit.ly/NOYhuR",
        "display_url" : "bit.ly/NOYhuR"
      } ]
    },
    "geo" : {
    },
    "id_str" : "243806006780510208",
    "text" : "Amazon Press release for Kindle Serials. Love the \"collaboration with @plympton\" http://t.co/ROGZqu5z",
    "id" : 243806006780510208,
    "created_at" : "Thu Sep 06 20:20:56 +0000 2012",
    "user" : {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "protected" : false,
      "id_str" : "1976841",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1842465869/jenny_baby_graduation_cap_cropped_normal.jpg",
      "id" : 1976841,
      "verified" : true
    }
  },
  "id" : 243807468768092160,
  "created_at" : "Thu Sep 06 20:26:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 12, 22 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "Plympton",
      "screen_name" : "plympton",
      "indices" : [ 45, 54 ],
      "id_str" : "316727597",
      "id" : 316727597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/BQx9y1UQ",
      "expanded_url" : "http://www.kickstarter.com/projects/plympton/plympton-serialized-fiction-for-digital-readers",
      "display_url" : "kickstarter.com/projects/plymp\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243598189113008129",
  "text" : "Congrats to @jenny8lee and the launch of the @plympton Kickstarter! http://t.co/BQx9y1UQ",
  "id" : 243598189113008129,
  "created_at" : "Thu Sep 06 06:35:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Relevant Organs",
      "screen_name" : "relevantorgans",
      "indices" : [ 3, 18 ],
      "id_str" : "86975611",
      "id" : 86975611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243553658162274305",
  "text" : "RT @relevantorgans: What a nice hug between Obama and Clinton. We tried that with Jiang and Hu once. Just kidding. Seriously? Your leade ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "243552447027630080",
    "text" : "What a nice hug between Obama and Clinton. We tried that with Jiang and Hu once. Just kidding. Seriously? Your leaders hug?",
    "id" : 243552447027630080,
    "created_at" : "Thu Sep 06 03:33:23 +0000 2012",
    "user" : {
      "name" : "The Relevant Organs",
      "screen_name" : "relevantorgans",
      "protected" : false,
      "id_str" : "86975611",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1069675605/TRO_normal.jpg",
      "id" : 86975611,
      "verified" : false
    }
  },
  "id" : 243553658162274305,
  "created_at" : "Thu Sep 06 03:38:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243542498583130113",
  "text" : "Jeremy Renner's roles from Avengers, Mission Impossible, and Bourne are actually interchangeable.",
  "id" : 243542498583130113,
  "created_at" : "Thu Sep 06 02:53:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/243449220475006976/photo/1",
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/30TP5eIV",
      "media_url" : "http://pbs.twimg.com/media/A2DnxrPCMAAtrJ5.jpg",
      "id_str" : "243449220483395584",
      "id" : 243449220483395584,
      "media_url_https" : "https://pbs.twimg.com/media/A2DnxrPCMAAtrJ5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com/30TP5eIV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243449220475006976",
  "text" : "Dear tech blogs, did we really need individual articles and headlines for all of these? http://t.co/30TP5eIV",
  "id" : 243449220475006976,
  "created_at" : "Wed Sep 05 20:43:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243427206263627776",
  "text" : "RT @parislemon: On the other hand, Business Insider should probably sue Motorola for infringing on their use of ALL CAPS.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "243424207994773504",
    "text" : "On the other hand, Business Insider should probably sue Motorola for infringing on their use of ALL CAPS.",
    "id" : 243424207994773504,
    "created_at" : "Wed Sep 05 19:03:48 +0000 2012",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3336694463/99718483afb19d6d441290afccb72772_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 243427206263627776,
  "created_at" : "Wed Sep 05 19:15:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "metaLAB (at) Harvard",
      "screen_name" : "metalabharvard",
      "indices" : [ 3, 18 ],
      "id_str" : "321792211",
      "id" : 321792211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243405969953009665",
  "text" : "RT @metalabharvard: Super PAC App: Giving voters information on the big-money donors behind campaign ads in real time. http://t.co/crKiW ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 125, 133 ],
        "id_str" : "39585367",
        "id" : 39585367
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http://t.co/crKiW14A",
        "expanded_url" : "http://ow.ly/du4Ie",
        "display_url" : "ow.ly/du4Ie"
      } ]
    },
    "geo" : {
    },
    "id_str" : "243369888029224961",
    "text" : "Super PAC App: Giving voters information on the big-money donors behind campaign ads in real time. http://t.co/crKiW14A (via @Harvard)",
    "id" : 243369888029224961,
    "created_at" : "Wed Sep 05 15:27:57 +0000 2012",
    "user" : {
      "name" : "metaLAB (at) Harvard",
      "screen_name" : "metalabharvard",
      "protected" : false,
      "id_str" : "321792211",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1503366766/MLaH_Round_initials-14_normal.jpg",
      "id" : 321792211,
      "verified" : false
    }
  },
  "id" : 243405969953009665,
  "created_at" : "Wed Sep 05 17:51:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/1pWnQJHb",
      "expanded_url" : "http://www.cio.com/article/715411/Bitcoin_Exchange_Loses_250_0000_After_Unencrypted_Keys_Stolen",
      "display_url" : "cio.com/article/715411\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243256860713578496",
  "text" : "Love the idea of Bitcoin, but I'm losing faith faster and faster. A lot of repeated dumb mistakes. http://t.co/1pWnQJHb",
  "id" : 243256860713578496,
  "created_at" : "Wed Sep 05 07:58:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/BkowF8Ta",
      "expanded_url" : "http://blogs.valvesoftware.com/linux/faster-zombies/",
      "display_url" : "blogs.valvesoftware.com/linux/faster-z\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243028344273264640",
  "text" : "Given Steam's Linux development and hardware foray, I'd put money on a Linux powered Steam console. http://t.co/BkowF8Ta",
  "id" : 243028344273264640,
  "created_at" : "Tue Sep 04 16:50:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HIPSTER UAV",
      "screen_name" : "hipsterUAV",
      "indices" : [ 22, 33 ],
      "id_str" : "273066211",
      "id" : 273066211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242850210466893824",
  "geo" : {
  },
  "id_str" : "242875124297121792",
  "in_reply_to_user_id" : 273066211,
  "text" : "Getting a kick out of @hipsterUAV.",
  "id" : 242875124297121792,
  "in_reply_to_status_id" : 242850210466893824,
  "created_at" : "Tue Sep 04 06:41:56 +0000 2012",
  "in_reply_to_screen_name" : "hipsterUAV",
  "in_reply_to_user_id_str" : "273066211",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/242846019392503808/photo/1",
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/fFWuuSE8",
      "media_url" : "http://pbs.twimg.com/media/A17DKwFCAAAjlyP.jpg",
      "id_str" : "242846019396698112",
      "id" : 242846019396698112,
      "media_url_https" : "https://pbs.twimg.com/media/A17DKwFCAAAjlyP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/fFWuuSE8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242846019392503808",
  "text" : "Motorcycle meetup at the In N Out. http://t.co/fFWuuSE8",
  "id" : 242846019392503808,
  "created_at" : "Tue Sep 04 04:46:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/xvatTvXk",
      "expanded_url" : "http://www.theverge.com/2012/9/3/3289689/valve-confirms-hardware-plans",
      "display_url" : "theverge.com/2012/9/3/32896\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242744891002716160",
  "text" : "Valve making its own hardware. Steam game console, anyone? http://t.co/xvatTvXk",
  "id" : 242744891002716160,
  "created_at" : "Mon Sep 03 22:04:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242707935782920193",
  "text" : "Buying a watch sold by a fashion brand is silly.",
  "id" : 242707935782920193,
  "created_at" : "Mon Sep 03 19:37:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/Y6pbk1Al",
      "expanded_url" : "http://www.ablogtoread.com/citizen-proximity-bluetooth-watch-for-iphone/",
      "display_url" : "ablogtoread.com/citizen-proxim\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242426938994601984",
  "text" : "Citizen produces an analog smartwatch. Love the idea, not a huge fan of the aesthetic. http://t.co/Y6pbk1Al",
  "id" : 242426938994601984,
  "created_at" : "Mon Sep 03 01:01:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242093108777603073",
  "text" : "One month in with the Olympus EM5 and Voigtlander optics, and I don't know why I ever had a DSLR.",
  "id" : 242093108777603073,
  "created_at" : "Sun Sep 02 02:54:29 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas J. Loverro",
      "screen_name" : "tomloverro",
      "indices" : [ 0, 11 ],
      "id_str" : "21160381",
      "id" : 21160381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241748727847612416",
  "geo" : {
  },
  "id_str" : "241760165873979393",
  "in_reply_to_user_id" : 21160381,
  "text" : "@tomloverro in that case they will go away almost as fast as the battery life.",
  "id" : 241760165873979393,
  "in_reply_to_status_id" : 241748727847612416,
  "created_at" : "Sat Sep 01 04:51:29 +0000 2012",
  "in_reply_to_screen_name" : "tomloverro",
  "in_reply_to_user_id_str" : "21160381",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]