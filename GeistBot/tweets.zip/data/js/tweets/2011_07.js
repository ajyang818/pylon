Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97791342113075200",
  "text" : "Played with the HTC facebook phone. Was skeptical, but the hardware is actually pretty nice! http://yfrog.com/kianwraj",
  "id" : 97791342113075200,
  "created_at" : "Sun Jul 31 22:10:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "indices" : [ 16, 25 ],
      "id_str" : "237573925",
      "id" : 237573925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97417584500162560",
  "text" : "Thanks, sis. RT @touhsieh: The awkward moment when you convince yourself you're adopted because you're the only sexy one in the family.",
  "id" : 97417584500162560,
  "created_at" : "Sat Jul 30 21:25:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 17, 29 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97367868357869568",
  "text" : "I miss this!! RT @alishalisha: Going to Harvard Sq to run some errands and maybe buy a book!",
  "id" : 97367868357869568,
  "created_at" : "Sat Jul 30 18:08:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 0, 8 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97021838005256192",
  "geo" : {
  },
  "id_str" : "97039770768785408",
  "in_reply_to_user_id" : 38399009,
  "text" : "@bznotes especially turbo diesels re: new CAFE standards",
  "id" : 97039770768785408,
  "in_reply_to_status_id" : 97021838005256192,
  "created_at" : "Fri Jul 29 20:24:18 +0000 2011",
  "in_reply_to_screen_name" : "bznotes",
  "in_reply_to_user_id_str" : "38399009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96998171867226113",
  "text" : "The new BMW i8 is beautifully sleek. The i3, however, looks like a compact had a bastard child with an orca and it got all the ugly genes.",
  "id" : 96998171867226113,
  "created_at" : "Fri Jul 29 17:39:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96981065037656064",
  "text" : "RT @WSJ: Google has purchased more than 1,000 patents from IBM, stocking up on IP to defend itself against lawsuits http://on.wsj.com/pFdWcp",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "96939426214723584",
    "text" : "Google has purchased more than 1,000 patents from IBM, stocking up on IP to defend itself against lawsuits http://on.wsj.com/pFdWcp",
    "id" : 96939426214723584,
    "created_at" : "Fri Jul 29 13:45:34 +0000 2011",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 96981065037656064,
  "created_at" : "Fri Jul 29 16:31:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Forman",
      "screen_name" : "isaacforman",
      "indices" : [ 3, 15 ],
      "id_str" : "16662617",
      "id" : 16662617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96777970710102016",
  "text" : "RT @isaacforman: As of Thursday afternoon, Apple has greater cash reserves ($75.9b) than the US government ($73.8b total operating balance).",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "96746276972007424",
    "text" : "As of Thursday afternoon, Apple has greater cash reserves ($75.9b) than the US government ($73.8b total operating balance).",
    "id" : 96746276972007424,
    "created_at" : "Fri Jul 29 00:58:04 +0000 2011",
    "user" : {
      "name" : "Isaac Forman",
      "screen_name" : "isaacforman",
      "protected" : false,
      "id_str" : "16662617",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/806787221/isaac-booth_normal.jpg",
      "id" : 16662617,
      "verified" : false
    }
  },
  "id" : 96777970710102016,
  "created_at" : "Fri Jul 29 03:04:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96777404265148416",
  "text" : "Dave Matthews is fantastically witty in person!",
  "id" : 96777404265148416,
  "created_at" : "Fri Jul 29 03:01:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96775544305229824",
  "text" : "Dave Matthews at microsoft. So THATS what he looks like. http://yfrog.com/kech3clj",
  "id" : 96775544305229824,
  "created_at" : "Fri Jul 29 02:54:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96722681638031360",
  "geo" : {
  },
  "id_str" : "96724565782306816",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil MacBook air?",
  "id" : 96724565782306816,
  "in_reply_to_status_id" : 96722681638031360,
  "created_at" : "Thu Jul 28 23:31:48 +0000 2011",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bijan Dhanani",
      "screen_name" : "fake_bijan",
      "indices" : [ 3, 14 ],
      "id_str" : "115576067",
      "id" : 115576067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96619871298793472",
  "text" : "RT @fake_bijan: If you're looking for a wildcard pandora station, try 'shanghai restoration project'. It's randomly pretty cool.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "96582581599997953",
    "text" : "If you're looking for a wildcard pandora station, try 'shanghai restoration project'. It's randomly pretty cool.",
    "id" : 96582581599997953,
    "created_at" : "Thu Jul 28 14:07:36 +0000 2011",
    "user" : {
      "name" : "Bijan Dhanani",
      "screen_name" : "fake_bijan",
      "protected" : false,
      "id_str" : "115576067",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1438750908/121252_normal.jpg",
      "id" : 115576067,
      "verified" : false
    }
  },
  "id" : 96619871298793472,
  "created_at" : "Thu Jul 28 16:35:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96438849680572416",
  "text" : "Snagged a reissue of the 1963 PLAAF chronograph from Hong Kong! http://yfrog.com/kek5akjj",
  "id" : 96438849680572416,
  "created_at" : "Thu Jul 28 04:36:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96383857951121408",
  "text" : "Soap boxing bus driver making afternoon commute really awkward.",
  "id" : 96383857951121408,
  "created_at" : "Thu Jul 28 00:57:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96314482615271424",
  "text" : "I don't quite understand the purpose of non waterproofed boat shoes.",
  "id" : 96314482615271424,
  "created_at" : "Wed Jul 27 20:22:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bradley Lautenbach",
      "screen_name" : "lautenbach",
      "indices" : [ 3, 14 ],
      "id_str" : "7894162",
      "id" : 7894162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95661196006526976",
  "text" : "RT @lautenbach: with OSX Lion, Apple has ported their wildly popular \"damn you autocorrect\" feature to the desktop, opening up whole new ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "95632560348069888",
    "text" : "with OSX Lion, Apple has ported their wildly popular \"damn you autocorrect\" feature to the desktop, opening up whole new worlds of hilarity.",
    "id" : 95632560348069888,
    "created_at" : "Mon Jul 25 23:12:33 +0000 2011",
    "user" : {
      "name" : "Bradley Lautenbach",
      "screen_name" : "lautenbach",
      "protected" : false,
      "id_str" : "7894162",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2794716129/8e7f27993ff4db27a550ce925f8ffa16_normal.png",
      "id" : 7894162,
      "verified" : false
    }
  },
  "id" : 95661196006526976,
  "created_at" : "Tue Jul 26 01:06:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95532607374233600",
  "text" : "RT @Fake_Dispatch: BREAKING: Blackberry to lay off 2000 workers. It was only going to be 20, but the CEO accidentally mashed his Blackbe ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "95530883884400640",
    "text" : "BREAKING: Blackberry to lay off 2000 workers. It was only going to be 20, but the CEO accidentally mashed his Blackberry's tiny 0 button.",
    "id" : 95530883884400640,
    "created_at" : "Mon Jul 25 16:28:32 +0000 2011",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 95532607374233600,
  "created_at" : "Mon Jul 25 16:35:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taegan Goddard",
      "screen_name" : "pwire",
      "indices" : [ 3, 9 ],
      "id_str" : "435213502",
      "id" : 435213502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95530102733029376",
  "text" : "RT @pwire: White House official says, anonymously, that there's a 50-50 chance of default... \nhttp://pwire.at/pFOwsR",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "95499520737161216",
    "text" : "White House official says, anonymously, that there's a 50-50 chance of default... \nhttp://pwire.at/pFOwsR",
    "id" : 95499520737161216,
    "created_at" : "Mon Jul 25 14:23:54 +0000 2011",
    "user" : {
      "name" : "Taegan Goddard",
      "screen_name" : "politicalwire",
      "protected" : false,
      "id_str" : "16250929",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/949739970/goddard-b_w-snapshot-sm_normal.jpeg",
      "id" : 16250929,
      "verified" : false
    }
  },
  "id" : 95530102733029376,
  "created_at" : "Mon Jul 25 16:25:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Blaine",
      "screen_name" : "davidblaine",
      "indices" : [ 3, 15 ],
      "id_str" : "23631859",
      "id" : 23631859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http://t.co/0ToFrsg",
      "expanded_url" : "http://i.imgur.com/zCbHw.jpg",
      "display_url" : "i.imgur.com/zCbHw.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "95421404253663233",
  "text" : "RT @davidblaine: Visually deconstructing the Apple logo http://t.co/0ToFrsg",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 58 ],
        "url" : "http://t.co/0ToFrsg",
        "expanded_url" : "http://i.imgur.com/zCbHw.jpg",
        "display_url" : "i.imgur.com/zCbHw.jpg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "95239816052092929",
    "text" : "Visually deconstructing the Apple logo http://t.co/0ToFrsg",
    "id" : 95239816052092929,
    "created_at" : "Sun Jul 24 21:11:56 +0000 2011",
    "user" : {
      "name" : "David Blaine",
      "screen_name" : "davidblaine",
      "protected" : false,
      "id_str" : "23631859",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3338241234/53c618232e70618e95613cf896ec7c86_normal.jpeg",
      "id" : 23631859,
      "verified" : true
    }
  },
  "id" : 95421404253663233,
  "created_at" : "Mon Jul 25 09:13:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94894885236260865",
  "text" : "Helicopter tour! Also sweet rolling shutter effect http://yfrog.com/kihbyebj",
  "id" : 94894885236260865,
  "created_at" : "Sat Jul 23 22:21:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    }, {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 11, 27 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94876364297093120",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose @GlobalAsianista would love to see a momo truck in NY! So would many alum :)",
  "id" : 94876364297093120,
  "created_at" : "Sat Jul 23 21:07:42 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter U Recruiting",
      "screen_name" : "TwitterU",
      "indices" : [ 3, 12 ],
      "id_str" : "172442947",
      "id" : 172442947
    }, {
      "name" : "The Terns",
      "screen_name" : "terns",
      "indices" : [ 25, 31 ],
      "id_str" : "284201599",
      "id" : 284201599
    }, {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 32, 37 ],
      "id_str" : "132319630",
      "id" : 132319630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94835267776684033",
  "text" : "RT @TwitterU: One of our @terns @sidd reps Twitter! \"What Student Blogs Say About Corporate Culture At Twitter, Intel, IBM, AndGoogle\" h ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Terns",
        "screen_name" : "terns",
        "indices" : [ 11, 17 ],
        "id_str" : "284201599",
        "id" : 284201599
      }, {
        "name" : "Siddarth",
        "screen_name" : "sidd",
        "indices" : [ 18, 23 ],
        "id_str" : "132319630",
        "id" : 132319630
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 140 ],
        "url" : "http://t.co/PRgCbfg",
        "expanded_url" : "http://www.fastcompany.com/1768584/my-life-as-an-intern-the-best-and-worst-of-tech-internship-diaries",
        "display_url" : "fastcompany.com/1768584/my-lif\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "94819609844269057",
    "text" : "One of our @terns @sidd reps Twitter! \"What Student Blogs Say About Corporate Culture At Twitter, Intel, IBM, AndGoogle\" http://t.co/PRgCbfg",
    "id" : 94819609844269057,
    "created_at" : "Sat Jul 23 17:22:11 +0000 2011",
    "user" : {
      "name" : "Twitter U Recruiting",
      "screen_name" : "TwitterU",
      "protected" : false,
      "id_str" : "172442947",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284174639/7na0wje12oerqyfgdr1d_normal.png",
      "id" : 172442947,
      "verified" : true
    }
  },
  "id" : 94835267776684033,
  "created_at" : "Sat Jul 23 18:24:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94835229444939778",
  "text" : "RT @YourAnonNews: Android Passwords are stored in plain text on Disk http://goo.gl/fb/3f6rT",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "94816828152479745",
    "text" : "Android Passwords are stored in plain text on Disk http://goo.gl/fb/3f6rT",
    "id" : 94816828152479745,
    "created_at" : "Sat Jul 23 17:11:08 +0000 2011",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1769643466/258844_104131489680984_104118713015595_32268_721285_o__1__normal.jpeg",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 94835229444939778,
  "created_at" : "Sat Jul 23 18:24:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 84, 100 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94835043490480128",
  "text" : "Asian food rampage through a sweltering NYC weekend. Thanks for the recommendations @GlobalAsianista!",
  "id" : 94835043490480128,
  "created_at" : "Sat Jul 23 18:23:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94500767913869312",
  "text" : "NYC weather worse than Taipei right now. Thank go for air conditioning.",
  "id" : 94500767913869312,
  "created_at" : "Fri Jul 22 20:15:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94497027450351616",
  "text" : "O hai, New York City.",
  "id" : 94497027450351616,
  "created_at" : "Fri Jul 22 20:00:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony DeVincenzi",
      "screen_name" : "tonydevincenzi",
      "indices" : [ 3, 18 ],
      "id_str" : "10425532",
      "id" : 10425532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http://t.co/U4IOqJi",
      "expanded_url" : "http://gigaom.com/2011/07/19/affectiva-raises-5-7m-to-sense-and-measure-emotion/",
      "display_url" : "gigaom.com/2011/07/19/aff\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94208193554685952",
  "text" : "RT @tonydevincenzi: Media Lab spin-off Affectiva raises 5.7M in series B. Get it! http://t.co/U4IOqJi",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 81 ],
        "url" : "http://t.co/U4IOqJi",
        "expanded_url" : "http://gigaom.com/2011/07/19/affectiva-raises-5-7m-to-sense-and-measure-emotion/",
        "display_url" : "gigaom.com/2011/07/19/aff\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "94187122302525440",
    "text" : "Media Lab spin-off Affectiva raises 5.7M in series B. Get it! http://t.co/U4IOqJi",
    "id" : 94187122302525440,
    "created_at" : "Thu Jul 21 23:28:54 +0000 2011",
    "user" : {
      "name" : "Anthony DeVincenzi",
      "screen_name" : "tonydevincenzi",
      "protected" : false,
      "id_str" : "10425532",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2201620909/Screen_Shot_2012-05-08_at_9.40.27_AM_normal.png",
      "id" : 10425532,
      "verified" : false
    }
  },
  "id" : 94208193554685952,
  "created_at" : "Fri Jul 22 00:52:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 14, 25 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94205199564029954",
  "text" : "Say what?! RT @TechCrunch: Google Tried To Buy Color For $200 Million. Color Said No. http://j.mp/p0885H",
  "id" : 94205199564029954,
  "created_at" : "Fri Jul 22 00:40:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackbookpro",
      "indices" : [ 43, 56 ]
    }, {
      "text" : "sexy",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 37 ],
      "url" : "http://t.co/0JJDdvN",
      "expanded_url" : "http://topazanodizing.com",
      "display_url" : "topazanodizing.com"
    }, {
      "indices" : [ 94, 113 ],
      "url" : "http://t.co/WF83ta4",
      "expanded_url" : "http://yfrog.com/kf8uc8j",
      "display_url" : "yfrog.com/kf8uc8j"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94162032026337280",
  "text" : "Thanks to josh at http://t.co/0JJDdvN, the #blackbookpro is one step closer to reality! #sexy http://t.co/WF83ta4",
  "id" : 94162032026337280,
  "created_at" : "Thu Jul 21 21:49:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bonnie Cao",
      "screen_name" : "bonnie_cao",
      "indices" : [ 0, 11 ],
      "id_str" : "28455753",
      "id" : 28455753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94093297676595200",
  "geo" : {
  },
  "id_str" : "94160713622368257",
  "in_reply_to_user_id" : 28455753,
  "text" : "@bonnie_cao well, if 2+2 goes well then it's two more years of school in Cambridge :P",
  "id" : 94160713622368257,
  "in_reply_to_status_id" : 94093297676595200,
  "created_at" : "Thu Jul 21 21:43:58 +0000 2011",
  "in_reply_to_screen_name" : "bonnie_cao",
  "in_reply_to_user_id_str" : "28455753",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bonnie Cao",
      "screen_name" : "bonnie_cao",
      "indices" : [ 0, 11 ],
      "id_str" : "28455753",
      "id" : 28455753
    }, {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 12, 23 ],
      "id_str" : "21061803",
      "id" : 21061803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94073680254074881",
  "geo" : {
  },
  "id_str" : "94083086236647425",
  "in_reply_to_user_id" : 28455753,
  "text" : "@bonnie_cao @_Eric_Chen are you all applying to 2+2? We can hang out in Cambridge for another two years :)",
  "id" : 94083086236647425,
  "in_reply_to_status_id" : 94073680254074881,
  "created_at" : "Thu Jul 21 16:35:30 +0000 2011",
  "in_reply_to_screen_name" : "bonnie_cao",
  "in_reply_to_user_id_str" : "28455753",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "indices" : [ 3, 14 ],
      "id_str" : "16626603",
      "id" : 16626603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94082766391607296",
  "text" : "RT @thecrimson: How Harvard College's switch to Gmail affects the Class of 2012: http://ow.ly/5JDLd",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "94069130789011456",
    "text" : "How Harvard College's switch to Gmail affects the Class of 2012: http://ow.ly/5JDLd",
    "id" : 94069130789011456,
    "created_at" : "Thu Jul 21 15:40:03 +0000 2011",
    "user" : {
      "name" : "The Harvard Crimson",
      "screen_name" : "thecrimson",
      "protected" : false,
      "id_str" : "16626603",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/242496967/CrimsonSeal-large-color_normal.jpg",
      "id" : 16626603,
      "verified" : false
    }
  },
  "id" : 94082766391607296,
  "created_at" : "Thu Jul 21 16:34:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackbookpro",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94080534275293185",
  "text" : "For those of you following #blackbookpro, it is currently getting a dust black anodizing treatment in my NY hometown.",
  "id" : 94080534275293185,
  "created_at" : "Thu Jul 21 16:25:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 58, 69 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94080400053374977",
  "text" : "Except the people arrested were just script kiddies... RT @ForbesTech: Arrests Show Hacktivism Is Cat And Mouse Game http://j.mp/o47Z36",
  "id" : 94080400053374977,
  "created_at" : "Thu Jul 21 16:24:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94079622160982016",
  "text" : "RT @Fake_Dispatch: BREAKING: Only way we are going to get funds for space exploration is if Hezbollah and the Taliban plan a moon landing.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "94005174221279232",
    "text" : "BREAKING: Only way we are going to get funds for space exploration is if Hezbollah and the Taliban plan a moon landing.",
    "id" : 94005174221279232,
    "created_at" : "Thu Jul 21 11:25:54 +0000 2011",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 94079622160982016,
  "created_at" : "Thu Jul 21 16:21:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93950924569055232",
  "text" : "Why would the invert the scrolling by default in OSX Lion? Poor UX design, rare for apple.",
  "id" : 93950924569055232,
  "created_at" : "Thu Jul 21 07:50:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93848777496076288",
  "text" : "That being said having wifi on free public buses is pretty awesome.",
  "id" : 93848777496076288,
  "created_at" : "Thu Jul 21 01:04:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seattle",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93847512296857600",
  "text" : "520 in utter gridlock ahead of the Manchester U v. Sounders game. #seattle",
  "id" : 93847512296857600,
  "created_at" : "Thu Jul 21 00:59:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "General Catalyst",
      "screen_name" : "gcvp",
      "indices" : [ 3, 8 ],
      "id_str" : "31099876",
      "id" : 31099876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http://t.co/pMsxhtJ",
      "expanded_url" : "http://bit.ly/pM1Wh1",
      "display_url" : "bit.ly/pM1Wh1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93805364348334080",
  "text" : "RT @gcvp: The top 10 most active Boston VC firms of the last quarter: http://t.co/pMsxhtJ\u201D",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 79 ],
        "url" : "http://t.co/pMsxhtJ",
        "expanded_url" : "http://bit.ly/pM1Wh1",
        "display_url" : "bit.ly/pM1Wh1"
      } ]
    },
    "geo" : {
    },
    "id_str" : "93755116334747648",
    "text" : "The top 10 most active Boston VC firms of the last quarter: http://t.co/pMsxhtJ\u201D",
    "id" : 93755116334747648,
    "created_at" : "Wed Jul 20 18:52:16 +0000 2011",
    "user" : {
      "name" : "General Catalyst",
      "screen_name" : "gcvp",
      "protected" : false,
      "id_str" : "31099876",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/822838702/General_Catalyst_Swoosh_normal.gif",
      "id" : 31099876,
      "verified" : false
    }
  },
  "id" : 93805364348334080,
  "created_at" : "Wed Jul 20 22:11:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ella",
      "screen_name" : "ellachou",
      "indices" : [ 0, 9 ],
      "id_str" : "2082721",
      "id" : 2082721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93753053995483136",
  "geo" : {
  },
  "id_str" : "93805269330567168",
  "in_reply_to_user_id" : 2082721,
  "text" : "@ellachou have you tried flavors.me instead?",
  "id" : 93805269330567168,
  "in_reply_to_status_id" : 93753053995483136,
  "created_at" : "Wed Jul 20 22:11:33 +0000 2011",
  "in_reply_to_screen_name" : "ellachou",
  "in_reply_to_user_id_str" : "2082721",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93719547445657601",
  "text" : "I love apple products as much as the next guy, but having my entire feed be \"zomg new MacBook air!!1\" is kind of annoying.",
  "id" : 93719547445657601,
  "created_at" : "Wed Jul 20 16:30:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Taussig",
      "screen_name" : "ataussig",
      "indices" : [ 0, 9 ],
      "id_str" : "22097962",
      "id" : 22097962
    }, {
      "name" : "Kevin Meyers",
      "screen_name" : "kevinmeyers",
      "indices" : [ 10, 22 ],
      "id_str" : "15138104",
      "id" : 15138104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93512951193026560",
  "geo" : {
  },
  "id_str" : "93604044748242944",
  "in_reply_to_user_id" : 22097962,
  "text" : "@ataussig @kevinmeyers I still use Alpine in terminal over the horrendous fas.harvard.edu webmail interface...",
  "id" : 93604044748242944,
  "in_reply_to_status_id" : 93512951193026560,
  "created_at" : "Wed Jul 20 08:51:58 +0000 2011",
  "in_reply_to_screen_name" : "ataussig",
  "in_reply_to_user_id_str" : "22097962",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 3, 11 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 16, 24 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93603401081954304",
  "text" : "RT @digitil: so @Harvard switched its email provider to Google? stay tuned for the mailing list app I shall dev.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 3, 11 ],
        "id_str" : "39585367",
        "id" : 39585367
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "93496215995547648",
    "text" : "so @Harvard switched its email provider to Google? stay tuned for the mailing list app I shall dev.",
    "id" : 93496215995547648,
    "created_at" : "Wed Jul 20 01:43:29 +0000 2011",
    "user" : {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "protected" : false,
      "id_str" : "142513192",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1642320634/166801_1511992884964_1388640188_31084711_5921086_n_normal.jpg",
      "id" : 142513192,
      "verified" : false
    }
  },
  "id" : 93603401081954304,
  "created_at" : "Wed Jul 20 08:49:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 3, 16 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93479470870171648",
  "text" : "RT @kevinmitnick: Murdoch gets a pie in the face for hacking voicemails. And I got prison. Where's the justice. HAHAHA.  http://tinyurl. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "93361138045173760",
    "text" : "Murdoch gets a pie in the face for hacking voicemails. And I got prison. Where's the justice. HAHAHA.  http://tinyurl.com/3zoathk",
    "id" : 93361138045173760,
    "created_at" : "Tue Jul 19 16:46:44 +0000 2011",
    "user" : {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "protected" : false,
      "id_str" : "14666934",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/53807085/Mitnick_Color_normal.jpg",
      "id" : 14666934,
      "verified" : true
    }
  },
  "id" : 93479470870171648,
  "created_at" : "Wed Jul 20 00:36:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93475145464823809",
  "text" : "Google+ app crashing in iOS5 beta constantly :(",
  "id" : 93475145464823809,
  "created_at" : "Wed Jul 20 00:19:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MetroTwit",
      "screen_name" : "metrotwitapp",
      "indices" : [ 0, 13 ],
      "id_str" : "128159436",
      "id" : 128159436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93102325543092225",
  "geo" : {
  },
  "id_str" : "93466774217043969",
  "in_reply_to_user_id" : 128159436,
  "text" : "@metrotwitapp is the most elegant Twitter client I've used for a computer. Can't wait for it to leave beta.",
  "id" : 93466774217043969,
  "in_reply_to_status_id" : 93102325543092225,
  "created_at" : "Tue Jul 19 23:46:30 +0000 2011",
  "in_reply_to_screen_name" : "metrotwitapp",
  "in_reply_to_user_id_str" : "128159436",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http://t.co/3Utewzb",
      "expanded_url" : "http://hackaday.com/2011/07/19/chilean-teen-builds-automatic-earthquake-alarm/?utm_source=feedburner",
      "display_url" : "hackaday.com/2011/07/19/chi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93465813180362753",
  "text" : "Agile, simple, elegant, useful: all things that innovation shuold be. Being a preteen inventor is icing on the cake. http://t.co/3Utewzb",
  "id" : 93465813180362753,
  "created_at" : "Tue Jul 19 23:42:41 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 69 ],
      "url" : "http://t.co/H0AO3h6",
      "expanded_url" : "http://www.kickstarter.com/projects/205734763/pen-type-a-a-minimal-pen",
      "display_url" : "kickstarter.com/projects/20573\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93463227396141056",
  "text" : "I'm in love with this Type-A pen on KickStarter - http://t.co/H0AO3h6 - reminds me of the Lamy studios I always lose...",
  "id" : 93463227396141056,
  "created_at" : "Tue Jul 19 23:32:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93460758729457664",
  "text" : "Apple blows past analyst expectations for the quarter. Too bad all my money has been locked away in GE purgatory since 2007...",
  "id" : 93460758729457664,
  "created_at" : "Tue Jul 19 23:22:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93202867330088961",
  "text" : "DeaadMau5 has some new competition http://j.mp/prm3ff",
  "id" : 93202867330088961,
  "created_at" : "Tue Jul 19 06:17:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Lulz Boat",
      "screen_name" : "LulzSec",
      "indices" : [ 3, 11 ],
      "id_str" : "294325981",
      "id" : 294325981
    }, {
      "name" : "James Ball",
      "screen_name" : "jamesrbuk",
      "indices" : [ 123, 133 ],
      "id_str" : "40713876",
      "id" : 40713876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93121889320443905",
  "text" : "RT @LulzSec: News International's DNS servers (link web addresses to servers) and all 1,024 web addresses are down. --&gt; @jamesrbuk",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Ball",
        "screen_name" : "jamesrbuk",
        "indices" : [ 110, 120 ],
        "id_str" : "40713876",
        "id" : 40713876
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "93109433189675009",
    "text" : "News International's DNS servers (link web addresses to servers) and all 1,024 web addresses are down. --&gt; @jamesrbuk",
    "id" : 93109433189675009,
    "created_at" : "Tue Jul 19 00:06:33 +0000 2011",
    "user" : {
      "name" : "The Lulz Boat",
      "screen_name" : "LulzSec",
      "protected" : false,
      "id_str" : "294325981",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1341989664/somehwat-mad-completely-mad-u-mad-MADAD_normal.jpg",
      "id" : 294325981,
      "verified" : false
    }
  },
  "id" : 93121889320443905,
  "created_at" : "Tue Jul 19 00:56:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93105325745520640",
  "geo" : {
  },
  "id_str" : "93105876507967488",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee LulzSec is waging war on News Corp's web properties too. So many story arcs!",
  "id" : 93105876507967488,
  "in_reply_to_status_id" : 93105325745520640,
  "created_at" : "Mon Jul 18 23:52:25 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony DeVincenzi",
      "screen_name" : "tonydevincenzi",
      "indices" : [ 3, 18 ],
      "id_str" : "10425532",
      "id" : 10425532
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "medialabtalk",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93014741110362112",
  "text" : "RT @tonydevincenzi: #medialabtalk is trending on Twitter.",
  "id" : 93014741110362112,
  "created_at" : "Mon Jul 18 17:50:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92991837358395392",
  "text" : "Three years ago I owned a Leica M8; today the X100 gives me much better images at 1/3 the price. If only I could hack an M-mount onto it.",
  "id" : 92991837358395392,
  "created_at" : "Mon Jul 18 16:19:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "rip empson",
      "screen_name" : "ripemp",
      "indices" : [ 110, 117 ],
      "id_str" : "152476366",
      "id" : 152476366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92987986525958144",
  "text" : "RT @TechCrunch: Ruxum: Wall Street Level Security Comes To Bitcoin With New Exchange http://tcrn.ch/pXFQnv by @ripemp",
  "retweeted_status" : {
    "source" : "<a href=\"http://vip.wordpress.com/hosting\" rel=\"nofollow\">WordPress.com VIP</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "rip empson",
        "screen_name" : "ripemp",
        "indices" : [ 94, 101 ],
        "id_str" : "152476366",
        "id" : 152476366
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "92929463083470848",
    "text" : "Ruxum: Wall Street Level Security Comes To Bitcoin With New Exchange http://tcrn.ch/pXFQnv by @ripemp",
    "id" : 92929463083470848,
    "created_at" : "Mon Jul 18 12:11:25 +0000 2011",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2176846885/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 92987986525958144,
  "created_at" : "Mon Jul 18 16:03:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 33, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92347240886177792",
  "text" : "Food coma during case interviews #firstworldproblems",
  "id" : 92347240886177792,
  "created_at" : "Sat Jul 16 21:37:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Chenglin Yuan",
      "screen_name" : "chenglinnn",
      "indices" : [ 13, 24 ],
      "id_str" : "49660090",
      "id" : 49660090
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerd",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92290798711877633",
  "geo" : {
  },
  "id_str" : "92296794763034624",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha @chenglinnn I saw snapdragon and thought \"mobile processors?\" #nerd",
  "id" : 92296794763034624,
  "in_reply_to_status_id" : 92290798711877633,
  "created_at" : "Sat Jul 16 18:17:25 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chenglin Yuan",
      "screen_name" : "chenglinnn",
      "indices" : [ 0, 11 ],
      "id_str" : "49660090",
      "id" : 49660090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91616972613230592",
  "geo" : {
  },
  "id_str" : "92265934575775744",
  "in_reply_to_user_id" : 49660090,
  "text" : "@chenglinnn it's actually just backed in flavors.me - best cms for personal site I've used",
  "id" : 92265934575775744,
  "in_reply_to_status_id" : 91616972613230592,
  "created_at" : "Sat Jul 16 16:14:47 +0000 2011",
  "in_reply_to_screen_name" : "chenglinnn",
  "in_reply_to_user_id_str" : "49660090",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 3, 12 ],
      "id_str" : "817386",
      "id" : 817386
    }, {
      "name" : "Lucas Mearian",
      "screen_name" : "lucasmearian",
      "indices" : [ 77, 90 ],
      "id_str" : "15962933",
      "id" : 15962933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92260202279223297",
  "text" : "RT @Techmeme: U.S. banks changing out core systems for real-time processing (@lucasmearian / Computerworld) http://j.mp/plBl0a http://te ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://techmeme.com/\" rel=\"nofollow\">Techmeme</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lucas Mearian",
        "screen_name" : "lucasmearian",
        "indices" : [ 63, 76 ],
        "id_str" : "15962933",
        "id" : 15962933
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "92246076756725760",
    "text" : "U.S. banks changing out core systems for real-time processing (@lucasmearian / Computerworld) http://j.mp/plBl0a http://techme.me/Bnk7",
    "id" : 92246076756725760,
    "created_at" : "Sat Jul 16 14:55:53 +0000 2011",
    "user" : {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "protected" : false,
      "id_str" : "817386",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1783187293/techmeme_tw_av_normal",
      "id" : 817386,
      "verified" : false
    }
  },
  "id" : 92260202279223297,
  "created_at" : "Sat Jul 16 15:52:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92259914654810113",
  "text" : "RT @Fake_Dispatch: BREAKING: U.S. Army tests smartphones. Soldiers think they are playing Angry Birds, but they are actually bombing ene ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "92208188912443392",
    "text" : "BREAKING: U.S. Army tests smartphones. Soldiers think they are playing Angry Birds, but they are actually bombing enemy positions.",
    "id" : 92208188912443392,
    "created_at" : "Sat Jul 16 12:25:20 +0000 2011",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 92259914654810113,
  "created_at" : "Sat Jul 16 15:50:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92111764807884801",
  "geo" : {
  },
  "id_str" : "92259442443300864",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce if you're in Falmouth, UNO is one of the more exciting things you can do...",
  "id" : 92259442443300864,
  "in_reply_to_status_id" : 92111764807884801,
  "created_at" : "Sat Jul 16 15:48:59 +0000 2011",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "googleplus",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91893211999633409",
  "text" : "\"you know who else put friends in circles? Dante.\" - the Internet. #googleplus",
  "id" : 91893211999633409,
  "created_at" : "Fri Jul 15 15:33:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kiwiana Restaurant",
      "screen_name" : "KiwianaNYC",
      "indices" : [ 29, 40 ],
      "id_str" : "311728535",
      "id" : 311728535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http://t.co/E89lRvH",
      "expanded_url" : "http://kiwiana-nyc.com",
      "display_url" : "kiwiana-nyc.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91741243297644544",
  "text" : "Putting finishing touches on @kiwianaNYC's website - http://t.co/E89lRvH - can't wait to actually try the food.",
  "id" : 91741243297644544,
  "created_at" : "Fri Jul 15 05:29:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Core77",
      "screen_name" : "core77",
      "indices" : [ 3, 10 ],
      "id_str" : "20236725",
      "id" : 20236725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91673069143334912",
  "text" : "RT @core77: Mid-Century Goes 21st Gentury: Custom Furniture by Gitane Workshop:  http://bit.ly/oDDXpa",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91632472130981888",
    "text" : "Mid-Century Goes 21st Gentury: Custom Furniture by Gitane Workshop:  http://bit.ly/oDDXpa",
    "id" : 91632472130981888,
    "created_at" : "Thu Jul 14 22:17:38 +0000 2011",
    "user" : {
      "name" : "Core77",
      "screen_name" : "core77",
      "protected" : false,
      "id_str" : "20236725",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2706662093/6d6e3a2ac48b0d4a077a39bba1f03fc5_normal.jpeg",
      "id" : 20236725,
      "verified" : false
    }
  },
  "id" : 91673069143334912,
  "created_at" : "Fri Jul 15 00:58:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 3, 12 ],
      "id_str" : "817386",
      "id" : 817386
    }, {
      "name" : "David Alexander",
      "screen_name" : "davidalexander5",
      "indices" : [ 66, 82 ],
      "id_str" : "60995964",
      "id" : 60995964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91671134713544704",
  "text" : "RT @Techmeme: Pentagon to treat cyberspace as operational domain (@davidalexander5 / Reuters) http://reut.rs/n2Z4uU http://techme.me/BnFa",
  "retweeted_status" : {
    "source" : "<a href=\"http://techmeme.com/\" rel=\"nofollow\">Techmeme</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Alexander",
        "screen_name" : "davidalexander5",
        "indices" : [ 52, 68 ],
        "id_str" : "60995964",
        "id" : 60995964
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91584239681802241",
    "text" : "Pentagon to treat cyberspace as operational domain (@davidalexander5 / Reuters) http://reut.rs/n2Z4uU http://techme.me/BnFa",
    "id" : 91584239681802241,
    "created_at" : "Thu Jul 14 19:05:58 +0000 2011",
    "user" : {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "protected" : false,
      "id_str" : "817386",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1783187293/techmeme_tw_av_normal",
      "id" : 817386,
      "verified" : false
    }
  },
  "id" : 91671134713544704,
  "created_at" : "Fri Jul 15 00:51:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Lukoff",
      "screen_name" : "klukoff",
      "indices" : [ 3, 11 ],
      "id_str" : "14754639",
      "id" : 14754639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91542157969719297",
  "text" : "RT @klukoff: MBA grads as indicator: if they all want to go into i-banking, there'll be financial crisis. If into tech, a bubble is form ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://chrome.google.com/extensions/detail/aicelmgbddfgmpieedjiggifabdpcnln\" rel=\"nofollow\">FaWave</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91401457437376512",
    "text" : "MBA grads as indicator: if they all want to go into i-banking, there'll be financial crisis. If into tech, a bubble is forming. -Andreesen",
    "id" : 91401457437376512,
    "created_at" : "Thu Jul 14 06:59:40 +0000 2011",
    "user" : {
      "name" : "Kai Lukoff",
      "screen_name" : "klukoff",
      "protected" : false,
      "id_str" : "14754639",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1669736640/500_normal.jpg",
      "id" : 14754639,
      "verified" : false
    }
  },
  "id" : 91542157969719297,
  "created_at" : "Thu Jul 14 16:18:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emi Meyer",
      "screen_name" : "EmiMeyer",
      "indices" : [ 3, 12 ],
      "id_str" : "98080993",
      "id" : 98080993
    }, {
      "name" : "Sorrento Hotel",
      "screen_name" : "SorrentoHotel",
      "indices" : [ 65, 79 ],
      "id_str" : "26880750",
      "id" : 26880750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http://t.co/5J69UZS",
      "expanded_url" : "http://bit.ly/psfr7r",
      "display_url" : "bit.ly/psfr7r"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91310350833692672",
  "text" : "RT @EmiMeyer: Playing in Seattle, Aug 19th, 8pm in Fireside Room @SorrentoHotel http://t.co/5J69UZS",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sorrento Hotel",
        "screen_name" : "SorrentoHotel",
        "indices" : [ 51, 65 ],
        "id_str" : "26880750",
        "id" : 26880750
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 85 ],
        "url" : "http://t.co/5J69UZS",
        "expanded_url" : "http://bit.ly/psfr7r",
        "display_url" : "bit.ly/psfr7r"
      } ]
    },
    "geo" : {
    },
    "id_str" : "91306348981133313",
    "text" : "Playing in Seattle, Aug 19th, 8pm in Fireside Room @SorrentoHotel http://t.co/5J69UZS",
    "id" : 91306348981133313,
    "created_at" : "Thu Jul 14 00:41:44 +0000 2011",
    "user" : {
      "name" : "Emi Meyer",
      "screen_name" : "EmiMeyer",
      "protected" : false,
      "id_str" : "98080993",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2897587908/691fc9aae1395fa31e73ad87df8580d6_normal.jpeg",
      "id" : 98080993,
      "verified" : false
    }
  },
  "id" : 91310350833692672,
  "created_at" : "Thu Jul 14 00:57:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McKinsey Quarterly",
      "screen_name" : "McKQuarterly",
      "indices" : [ 3, 16 ],
      "id_str" : "15308469",
      "id" : 15308469
    }, {
      "name" : "MIX",
      "screen_name" : "hackmanagement",
      "indices" : [ 104, 119 ],
      "id_str" : "118837674",
      "id" : 118837674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91300129331617792",
  "text" : "RT @McKQuarterly: How is the Internet changing management? Enter your idea for the HBR/McKinsey M-Prize @hackmanagement Challenge http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MIX",
        "screen_name" : "hackmanagement",
        "indices" : [ 86, 101 ],
        "id_str" : "118837674",
        "id" : 118837674
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91256687528378369",
    "text" : "How is the Internet changing management? Enter your idea for the HBR/McKinsey M-Prize @hackmanagement Challenge http://bit.ly/kS9W17",
    "id" : 91256687528378369,
    "created_at" : "Wed Jul 13 21:24:24 +0000 2011",
    "user" : {
      "name" : "McKinsey Quarterly",
      "screen_name" : "McKQuarterly",
      "protected" : false,
      "id_str" : "15308469",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/58066104/TwitterQ_normal.jpg",
      "id" : 15308469,
      "verified" : true
    }
  },
  "id" : 91300129331617792,
  "created_at" : "Thu Jul 14 00:17:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 103, 110 ],
      "id_str" : "18327902",
      "id" : 18327902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91285787496292354",
  "text" : "RT @TechCrunch: Spotify Will Launch In The US Tomorrow Morning (It's About Time) http://j.mp/nE4pxa by @alexia",
  "id" : 91285787496292354,
  "created_at" : "Wed Jul 13 23:20:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 3, 15 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 17, 25 ],
      "id_str" : "142513192",
      "id" : 142513192
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 26, 33 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90941876626137090",
  "text" : "RT @badboyboyce: @digitil @khsieh stop taking photos of bikes & get ready for us to found a company together Fall 2011",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u265A Calvin McEachron",
        "screen_name" : "digitil",
        "indices" : [ 0, 8 ],
        "id_str" : "142513192",
        "id" : 142513192
      }, {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 9, 16 ],
        "id_str" : "111999960",
        "id" : 111999960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "90935628430184448",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.7338882, -73.99069029 ]
    },
    "id_str" : "90938917032955904",
    "in_reply_to_user_id" : 142513192,
    "text" : "@digitil @khsieh stop taking photos of bikes & get ready for us to found a company together Fall 2011",
    "id" : 90938917032955904,
    "in_reply_to_status_id" : 90935628430184448,
    "created_at" : "Wed Jul 13 00:21:42 +0000 2011",
    "in_reply_to_screen_name" : "digitil",
    "in_reply_to_user_id_str" : "142513192",
    "user" : {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "protected" : false,
      "id_str" : "110823121",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1736585624/HaLongBay_Profile_Thumbnail_normal.jpg",
      "id" : 110823121,
      "verified" : false
    }
  },
  "id" : 90941876626137090,
  "created_at" : "Wed Jul 13 00:33:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90906766518390786",
  "geo" : {
  },
  "id_str" : "90910890819465217",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil rotate those handlebars a bit dude",
  "id" : 90910890819465217,
  "in_reply_to_status_id" : 90906766518390786,
  "created_at" : "Tue Jul 12 22:30:20 +0000 2011",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90826022483787776",
  "text" : "Pandora + HTML5 = new hotness",
  "id" : 90826022483787776,
  "created_at" : "Tue Jul 12 16:53:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90813017503178753",
  "text" : "TechCrunch redesign reminiscent of Windows Metro, at least on a wide monitor.",
  "id" : 90813017503178753,
  "created_at" : "Tue Jul 12 16:01:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 3, 19 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dotherightthing",
      "indices" : [ 86, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90597617146413058",
  "text" : "RT @GlobalAsianista: Director Spike Lee confirmed for remake of Korean film 'Oldboy.' #dotherightthing",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dotherightthing",
        "indices" : [ 65, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "90592130313105409",
    "text" : "Director Spike Lee confirmed for remake of Korean film 'Oldboy.' #dotherightthing",
    "id" : 90592130313105409,
    "created_at" : "Tue Jul 12 01:23:41 +0000 2011",
    "user" : {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "protected" : false,
      "id_str" : "228489296",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1479092871/Twitter4_normal.jpg",
      "id" : 228489296,
      "verified" : false
    }
  },
  "id" : 90597617146413058,
  "created_at" : "Tue Jul 12 01:45:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dunstan Orchard",
      "screen_name" : "dunstan",
      "indices" : [ 0, 8 ],
      "id_str" : "66",
      "id" : 66
    }, {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "indices" : [ 9, 13 ],
      "id_str" : "13",
      "id" : 13
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90550032348086272",
  "geo" : {
  },
  "id_str" : "90596814570536960",
  "in_reply_to_user_id" : 66,
  "text" : "@dunstan @biz set auto-review to off and mount a holga lens to SLR and BAM, instant Holga D. Use an m4/3 camera an you even get form factor.",
  "id" : 90596814570536960,
  "in_reply_to_status_id" : 90550032348086272,
  "created_at" : "Tue Jul 12 01:42:18 +0000 2011",
  "in_reply_to_screen_name" : "dunstan",
  "in_reply_to_user_id_str" : "66",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90594621461241858",
  "text" : "The week I buy an X100 Ricoh shows an M-mount for the GXR. Le sigh.",
  "id" : 90594621461241858,
  "created_at" : "Tue Jul 12 01:33:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90473570555277314",
  "geo" : {
  },
  "id_str" : "90593453490176000",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin low carb diets lead to ketosis and bad breath anyways. You only live once; might as well eat real food.",
  "id" : 90593453490176000,
  "in_reply_to_status_id" : 90473570555277314,
  "created_at" : "Tue Jul 12 01:28:57 +0000 2011",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leica Camera AG",
      "screen_name" : "leica_camera",
      "indices" : [ 3, 16 ],
      "id_str" : "24884768",
      "id" : 24884768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90592534560120832",
  "text" : "RT @leica_camera: Behind-the-scenes look at the hand-made craftsmanship & meticulous manufacturing processes for every Leica lens: http: ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 132 ],
        "url" : "http://t.co/eh2zBMy",
        "expanded_url" : "http://bit.ly/nC1GWV",
        "display_url" : "bit.ly/nC1GWV"
      } ]
    },
    "geo" : {
    },
    "id_str" : "90453883461189632",
    "text" : "Behind-the-scenes look at the hand-made craftsmanship & meticulous manufacturing processes for every Leica lens: http://t.co/eh2zBMy",
    "id" : 90453883461189632,
    "created_at" : "Mon Jul 11 16:14:21 +0000 2011",
    "user" : {
      "name" : "Leica Camera AG",
      "screen_name" : "leica_camera",
      "protected" : false,
      "id_str" : "24884768",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1208392854/180px_normal.jpg",
      "id" : 24884768,
      "verified" : false
    }
  },
  "id" : 90592534560120832,
  "created_at" : "Tue Jul 12 01:25:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Stewart",
      "screen_name" : "socialtopher",
      "indices" : [ 3, 16 ],
      "id_str" : "7870892",
      "id" : 7870892
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 18, 25 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 26, 33 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90592255743770626",
  "text" : "RT @socialtopher: @khsieh @Square is now working on iOS 5 beta, in case you haven't updated yet.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 0, 7 ],
        "id_str" : "111999960",
        "id" : 111999960
      }, {
        "name" : "Square, Inc.",
        "screen_name" : "Square",
        "indices" : [ 8, 15 ],
        "id_str" : "93017945",
        "id" : 93017945
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "85798560158842880",
    "geo" : {
    },
    "id_str" : "90548204826918913",
    "in_reply_to_user_id" : 19380775,
    "text" : "@khsieh @Square is now working on iOS 5 beta, in case you haven't updated yet.",
    "id" : 90548204826918913,
    "in_reply_to_status_id" : 85798560158842880,
    "created_at" : "Mon Jul 11 22:29:09 +0000 2011",
    "in_reply_to_screen_name" : "kane",
    "in_reply_to_user_id_str" : "19380775",
    "user" : {
      "name" : "Chris Stewart",
      "screen_name" : "socialtopher",
      "protected" : false,
      "id_str" : "7870892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/65217632/ChrisFace_normal.png",
      "id" : 7870892,
      "verified" : false
    }
  },
  "id" : 90592255743770626,
  "created_at" : "Tue Jul 12 01:24:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 99, 108 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http://t.co/Bk2AnKT",
      "expanded_url" : "http://web.media.mit.edu/~pamplona/NETRA/home.html",
      "display_url" : "web.media.mit.edu/~pamplona/NETR\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "89969015467950080",
  "text" : "More startup innovation I can get behind: eye prescriptions for $2 for developing nations. Thanks, @medialab. http://t.co/Bk2AnKT",
  "id" : 89969015467950080,
  "created_at" : "Sun Jul 10 08:07:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 34, 49 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89905951745912832",
  "text" : "Dunster House from the inside. RT @NaveenSrivatsa: Nothing is uglier than Mather House from the outside.",
  "id" : 89905951745912832,
  "created_at" : "Sun Jul 10 03:57:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Souvik",
      "screen_name" : "bboysandwich",
      "indices" : [ 0, 13 ],
      "id_str" : "140105516",
      "id" : 140105516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89880240888872960",
  "geo" : {
  },
  "id_str" : "89903478578749440",
  "in_reply_to_user_id" : 140105516,
  "text" : "@bboysandwich is NarcRa7 DeadMau5's alternate ego?",
  "id" : 89903478578749440,
  "in_reply_to_status_id" : 89880240888872960,
  "created_at" : "Sun Jul 10 03:47:14 +0000 2011",
  "in_reply_to_screen_name" : "bboysandwich",
  "in_reply_to_user_id_str" : "140105516",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89826830399455232",
  "text" : "On a quest to find the best bubble tea in Seattle.",
  "id" : 89826830399455232,
  "created_at" : "Sat Jul 09 22:42:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Innovation",
      "screen_name" : "BostonInnov",
      "indices" : [ 102, 114 ],
      "id_str" : "126639927",
      "id" : 126639927
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hbs",
      "indices" : [ 115, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/HoLoyeg",
      "expanded_url" : "http://bostinnovation.com/2011/07/08/hbs-student-creates-smartphone-app-to-detect-malaria/",
      "display_url" : "bostinnovation.com/2011/07/08/hbs\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "89518513466781696",
  "text" : "THIS is what startups & innovation should be about. We dont need that many more consumer webapps. via @BostonInnov #hbs http://t.co/HoLoyeg",
  "id" : 89518513466781696,
  "created_at" : "Sat Jul 09 02:17:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProperCloth",
      "screen_name" : "ProperCloth",
      "indices" : [ 29, 41 ],
      "id_str" : "17415379",
      "id" : 17415379
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 51, 63 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89495558003245057",
  "text" : "Ordered a bespoke shirt from @ProperCloth. Thanks, @badboyboyce. No one actually sells shirts in my size in store.",
  "id" : 89495558003245057,
  "created_at" : "Sat Jul 09 00:46:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89363701278310401",
  "text" : "In orbit. Godspeed, Atlantis.",
  "id" : 89363701278310401,
  "created_at" : "Fri Jul 08 16:02:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Francis Tan \uF8FF",
      "screen_name" : "francistan",
      "indices" : [ 107, 118 ],
      "id_str" : "16668321",
      "id" : 16668321
    }, {
      "name" : "TheNextWeb Asia",
      "screen_name" : "TheNextWebAsia",
      "indices" : [ 122, 137 ],
      "id_str" : "74614502",
      "id" : 74614502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89175373119627264",
  "text" : "RT @TheNextWeb: Taiwanese telco commits to boosting Internet speeds tenfold by 2015 http://tnw.to/19tN0 by @francistan on @TheNextWebAsia",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Francis Tan \uF8FF",
        "screen_name" : "francistan",
        "indices" : [ 91, 102 ],
        "id_str" : "16668321",
        "id" : 16668321
      }, {
        "name" : "TheNextWeb Asia",
        "screen_name" : "TheNextWebAsia",
        "indices" : [ 106, 121 ],
        "id_str" : "74614502",
        "id" : 74614502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "89163395537969153",
    "text" : "Taiwanese telco commits to boosting Internet speeds tenfold by 2015 http://tnw.to/19tN0 by @francistan on @TheNextWebAsia",
    "id" : 89163395537969153,
    "created_at" : "Fri Jul 08 02:46:24 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 89175373119627264,
  "created_at" : "Fri Jul 08 03:34:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Verizon",
      "indices" : [ 3, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89131097060933632",
  "text" : "My #Verizon unlimited plan is now an antique! Data is dead. Long live data.",
  "id" : 89131097060933632,
  "created_at" : "Fri Jul 08 00:38:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 71, 81 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Boston",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89129336178868224",
  "text" : "Trying banh mi around Seattle. Haven't found anything quite as good as @momogoose though. #Boston ftw",
  "id" : 89129336178868224,
  "created_at" : "Fri Jul 08 00:31:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berkman Center",
      "screen_name" : "berkmancenter",
      "indices" : [ 3, 17 ],
      "id_str" : "14706139",
      "id" : 14706139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89033638255140865",
  "text" : "RT @berkmancenter: The metaLAB (at) Harvard is looking to hire a part-time designer/developer! http://bit.ly/nXRtQn",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "89005892569280512",
    "text" : "The metaLAB (at) Harvard is looking to hire a part-time designer/developer! http://bit.ly/nXRtQn",
    "id" : 89005892569280512,
    "created_at" : "Thu Jul 07 16:20:33 +0000 2011",
    "user" : {
      "name" : "Berkman Center",
      "screen_name" : "berkmancenter",
      "protected" : false,
      "id_str" : "14706139",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1850942959/twitter_normal.jpg",
      "id" : 14706139,
      "verified" : false
    }
  },
  "id" : 89033638255140865,
  "created_at" : "Thu Jul 07 18:10:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndarKness",
      "screen_name" : "Alex_IndarKness",
      "indices" : [ 3, 19 ],
      "id_str" : "90575128",
      "id" : 90575128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88993732870938625",
  "text" : "RT @Alex_IndarKness: Mr. Jiang is now officially Schrodinger's cat, he's death depends on hu and wen sees it.",
  "id" : 88993732870938625,
  "created_at" : "Thu Jul 07 15:32:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ogilvy & Mather",
      "screen_name" : "Ogilvy",
      "indices" : [ 63, 70 ],
      "id_str" : "5894902",
      "id" : 5894902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88873640615096320",
  "text" : "Not enough resolution in the pic to see the submission url! RT @OGILVY: Your reward for reading my tweets: A job in London perhaps...",
  "id" : 88873640615096320,
  "created_at" : "Thu Jul 07 07:35:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "citizen lab",
      "screen_name" : "citizenlab",
      "indices" : [ 3, 14 ],
      "id_str" : "35341530",
      "id" : 35341530
    }, {
      "name" : "Helmi Noman",
      "screen_name" : "helminoman",
      "indices" : [ 81, 92 ],
      "id_str" : "17972530",
      "id" : 17972530
    }, {
      "name" : "Infowar Monitor",
      "screen_name" : "InfowarMonitor",
      "indices" : [ 93, 108 ],
      "id_str" : "19069845",
      "id" : 19069845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88774773420732416",
  "text" : "RT @citizenlab: Syrian Electronic Army defaces UCLA website http://bit.ly/pIIV7S @helminoman @infowarmonitor",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Helmi Noman",
        "screen_name" : "helminoman",
        "indices" : [ 65, 76 ],
        "id_str" : "17972530",
        "id" : 17972530
      }, {
        "name" : "Infowar Monitor",
        "screen_name" : "InfowarMonitor",
        "indices" : [ 77, 92 ],
        "id_str" : "19069845",
        "id" : 19069845
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "88770282159996929",
    "text" : "Syrian Electronic Army defaces UCLA website http://bit.ly/pIIV7S @helminoman @infowarmonitor",
    "id" : 88770282159996929,
    "created_at" : "Thu Jul 07 00:44:19 +0000 2011",
    "user" : {
      "name" : "citizen lab",
      "screen_name" : "citizenlab",
      "protected" : false,
      "id_str" : "35341530",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857394514/14876528995faf3261e633473ea53e19_normal.png",
      "id" : 35341530,
      "verified" : false
    }
  },
  "id" : 88774773420732416,
  "created_at" : "Thu Jul 07 01:02:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "indices" : [ 3, 9 ],
      "id_str" : "14782518",
      "id" : 14782518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88727895605911552",
  "text" : "RT @cltom: DNA is now DIY: OpenPCR ships worldwide http://bit.ly/qTWGp3",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.brizzly.com\" rel=\"nofollow\">Brizzly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "88726294132563969",
    "text" : "DNA is now DIY: OpenPCR ships worldwide http://bit.ly/qTWGp3",
    "id" : 88726294132563969,
    "created_at" : "Wed Jul 06 21:49:31 +0000 2011",
    "user" : {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "protected" : false,
      "id_str" : "14782518",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2908096260/d10e7982fa92f0bf560a50a76d76e392_normal.png",
      "id" : 14782518,
      "verified" : false
    }
  },
  "id" : 88727895605911552,
  "created_at" : "Wed Jul 06 21:55:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88721791861788673",
  "text" : "\"many people spend more time looking at Outlook than at their spouses. Therefore it should be more attractive.\" Delbene on future design",
  "id" : 88721791861788673,
  "created_at" : "Wed Jul 06 21:31:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88716213898854400",
  "text" : "Listening to Kurt Delbene speak against the backdrop of the Pacific NW mountains.",
  "id" : 88716213898854400,
  "created_at" : "Wed Jul 06 21:09:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Core77",
      "screen_name" : "core77",
      "indices" : [ 3, 10 ],
      "id_str" : "20236725",
      "id" : 20236725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88694330113540096",
  "text" : "RT @core77: Toyota working on a thought-controlled bicycle shifter. Seriously - http://bit.ly/kQ1b5Y",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.exacttarget.com/social\" rel=\"nofollow\">SocialEngage</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "88659373089505280",
    "text" : "Toyota working on a thought-controlled bicycle shifter. Seriously - http://bit.ly/kQ1b5Y",
    "id" : 88659373089505280,
    "created_at" : "Wed Jul 06 17:23:36 +0000 2011",
    "user" : {
      "name" : "Core77",
      "screen_name" : "core77",
      "protected" : false,
      "id_str" : "20236725",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2706662093/6d6e3a2ac48b0d4a077a39bba1f03fc5_normal.jpeg",
      "id" : 20236725,
      "verified" : false
    }
  },
  "id" : 88694330113540096,
  "created_at" : "Wed Jul 06 19:42:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http://t.co/iwmh6Hf",
      "expanded_url" : "http://hvrd.me/plV8EL",
      "display_url" : "hvrd.me/plV8EL"
    } ]
  },
  "geo" : {
  },
  "id_str" : "88641662888329217",
  "text" : "RT @hseas: Coated nanowires show a 90-fold increase in sensitivity, offering applications in solar cells http://t.co/iwmh6Hf",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 113 ],
        "url" : "http://t.co/iwmh6Hf",
        "expanded_url" : "http://hvrd.me/plV8EL",
        "display_url" : "hvrd.me/plV8EL"
      } ]
    },
    "geo" : {
    },
    "id_str" : "88633158488174592",
    "text" : "Coated nanowires show a 90-fold increase in sensitivity, offering applications in solar cells http://t.co/iwmh6Hf",
    "id" : 88633158488174592,
    "created_at" : "Wed Jul 06 15:39:26 +0000 2011",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 88641662888329217,
  "created_at" : "Wed Jul 06 16:13:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88425161023426560",
  "text" : "Doing the tourist thing in Seattle http://yfrog.com/hsq2sdcj",
  "id" : 88425161023426560,
  "created_at" : "Wed Jul 06 01:52:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88396530297487360",
  "text" : "Bike has finally made it to Seattle, just in time for epic summer weather.",
  "id" : 88396530297487360,
  "created_at" : "Tue Jul 05 23:59:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88380463332335616",
  "text" : "Mckinsey's new website is MUCH better than the pixelated raw HTML they were rocking earlier this year. http://j.mp/pM0pQh",
  "id" : 88380463332335616,
  "created_at" : "Tue Jul 05 22:55:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "X100",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88379508922662913",
  "text" : "Fujifilm's #X100's hybrid finder was underwhelming in light of all the hype... but I still want one really really badly.",
  "id" : 88379508922662913,
  "created_at" : "Tue Jul 05 22:51:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nirvana",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88367524894359553",
  "text" : "Zero new messages in inbox. #nirvana",
  "id" : 88367524894359553,
  "created_at" : "Tue Jul 05 22:03:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88283906331262976",
  "text" : "When did \"tablet\" become synonymous for \"slate?\" And what should we call tablets of the Wacom type?",
  "id" : 88283906331262976,
  "created_at" : "Tue Jul 05 16:31:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "indices" : [ 3, 9 ],
      "id_str" : "14782518",
      "id" : 14782518
    }, {
      "name" : "Darius Tahir",
      "screen_name" : "dariustahir",
      "indices" : [ 86, 98 ],
      "id_str" : "55874399",
      "id" : 55874399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88165877249355776",
  "text" : "RT @cltom: Global race on to match U.S. drone capabilities http://wapo.st/iQYIQ8 /via @dariustahir",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.brizzly.com\" rel=\"nofollow\">Brizzly</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Darius Tahir",
        "screen_name" : "dariustahir",
        "indices" : [ 75, 87 ],
        "id_str" : "55874399",
        "id" : 55874399
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "88129282244743169",
    "text" : "Global race on to match U.S. drone capabilities http://wapo.st/iQYIQ8 /via @dariustahir",
    "id" : 88129282244743169,
    "created_at" : "Tue Jul 05 06:17:12 +0000 2011",
    "user" : {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "protected" : false,
      "id_str" : "14782518",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2908096260/d10e7982fa92f0bf560a50a76d76e392_normal.png",
      "id" : 14782518,
      "verified" : false
    }
  },
  "id" : 88165877249355776,
  "created_at" : "Tue Jul 05 08:42:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "87823705031450624",
  "text" : "It is way too easy to turn off an iPhone alarm in the morning... Needs additional user interactions!",
  "id" : 87823705031450624,
  "created_at" : "Mon Jul 04 10:02:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 30, 40 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "87722126634778625",
  "text" : "Equilibrium! and Star Wars RT @jenny8lee: Best western adaption of Chinese martial arts style fighting? Matrix... Anything else?",
  "id" : 87722126634778625,
  "created_at" : "Mon Jul 04 03:19:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 0, 8 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hypermiling",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87551159040094208",
  "geo" : {
  },
  "id_str" : "87634429610164224",
  "in_reply_to_user_id" : 38399009,
  "text" : "@bznotes gallon-per-hour flow to engine and pedostatic readings, both from airplanes, would be really helpful for #hypermiling!",
  "id" : 87634429610164224,
  "in_reply_to_status_id" : 87551159040094208,
  "created_at" : "Sun Jul 03 21:30:50 +0000 2011",
  "in_reply_to_screen_name" : "bznotes",
  "in_reply_to_user_id_str" : "38399009",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86880842265272320",
  "text" : "Hulu + Google = Huggle?",
  "id" : 86880842265272320,
  "created_at" : "Fri Jul 01 19:36:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 0, 13 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86798815092408320",
  "geo" : {
  },
  "id_str" : "86835110816657408",
  "in_reply_to_user_id" : 112919587,
  "text" : "@vcruzcontrol what I wouldn't do for Harvard farmers market ice cream right now...",
  "id" : 86835110816657408,
  "in_reply_to_status_id" : 86798815092408320,
  "created_at" : "Fri Jul 01 16:34:38 +0000 2011",
  "in_reply_to_screen_name" : "vcruzcontrol",
  "in_reply_to_user_id_str" : "112919587",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 121, 125 ]
    }, {
      "text" : "Minnesota",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86834819518046208",
  "text" : "Instead of shutting down the gov, legislators should be slapped and fined on the hour until compromise on the budget gap #wtf #Minnesota",
  "id" : 86834819518046208,
  "created_at" : "Fri Jul 01 16:33:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]