Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http://t.co/EMB2KHO",
      "expanded_url" : "http://vimeo.com/16981453",
      "display_url" : "vimeo.com/16981453"
    } ]
  },
  "geo" : {
  },
  "id_str" : "32160902459432960",
  "text" : "\"Like flying a plane with a reciprocating engine\" - awesome documentary of the day http://t.co/EMB2KHO",
  "id" : 32160902459432960,
  "created_at" : "Mon Jan 31 19:38:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "musings",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32124055075168256",
  "text" : "Android surpasses Symbian - but will Verizon iOS throttle its US growth? #musings",
  "id" : 32124055075168256,
  "created_at" : "Mon Jan 31 17:12:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget Mobile",
      "screen_name" : "engadgetmobile",
      "indices" : [ 3, 18 ],
      "id_str" : "15008936",
      "id" : 15008936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32030247624900608",
  "text" : "RT @engadgetmobile: Canalys: Android overtakes Symbian as world's best-selling smartphone platform in Q4 2010 http://engt.co/fYf2RM",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "32025124370649088",
    "text" : "Canalys: Android overtakes Symbian as world's best-selling smartphone platform in Q4 2010 http://engt.co/fYf2RM",
    "id" : 32025124370649088,
    "created_at" : "Mon Jan 31 10:39:19 +0000 2011",
    "user" : {
      "name" : "Engadget Mobile",
      "screen_name" : "engadgetmobile",
      "protected" : false,
      "id_str" : "15008936",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/56815175/engadgetmobiletouchicon_normal.png",
      "id" : 15008936,
      "verified" : true
    }
  },
  "id" : 32030247624900608,
  "created_at" : "Mon Jan 31 10:59:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Gao",
      "screen_name" : "jasongao",
      "indices" : [ 107, 116 ],
      "id_str" : "11829482",
      "id" : 11829482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http://t.co/0LwCDfG",
      "expanded_url" : "http://nchoosetwo.com",
      "display_url" : "nchoosetwo.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "32005050733694977",
  "text" : "http://t.co/0LwCDfG is pretty nifty, but I have NO inkling on who picked me. Makes it difficult to use IMO @jasongao",
  "id" : 32005050733694977,
  "created_at" : "Mon Jan 31 09:19:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Gao",
      "screen_name" : "jasongao",
      "indices" : [ 13, 22 ],
      "id_str" : "11829482",
      "id" : 11829482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http://t.co/0LwCDfG",
      "expanded_url" : "http://nchoosetwo.com",
      "display_url" : "nchoosetwo.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "32004415573458944",
  "text" : "playing with @jasongao's http://t.co/0LwCDfG instead of working",
  "id" : 32004415573458944,
  "created_at" : "Mon Jan 31 09:17:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31912824624119808",
  "text" : "RT @HarvardCSA: Recruiting for banking this season? We're giving away 5 copies of Vault's Investment Banking Guide! http://www.harvardcs ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "31912785541599232",
    "text" : "Recruiting for banking this season? We're giving away 5 copies of Vault's Investment Banking Guide! http://www.harvardcsa.org/vault-raffle",
    "id" : 31912785541599232,
    "created_at" : "Mon Jan 31 03:12:55 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 31912824624119808,
  "created_at" : "Mon Jan 31 03:13:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seriously",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31756435826147328",
  "text" : "Oliver Wyman's recruiting site supports IE and Netscape only. #seriously?",
  "id" : 31756435826147328,
  "created_at" : "Sun Jan 30 16:51:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NBC",
      "indices" : [ 41, 45 ]
    }, {
      "text" : "internet",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http://t.co/JjhWgVh",
      "expanded_url" : "http://www.youtube.com/watch?v=9nTPX4JW_Ts&feature=player_embedded#",
      "display_url" : "youtube.com/watch?v=9nTPX4\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "31454883584413696",
  "text" : "\"what do you write to it... like mail?!\" #NBC tries to understand #internet, circa 1994 http://t.co/JjhWgVh",
  "id" : 31454883584413696,
  "created_at" : "Sat Jan 29 20:53:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http://t.co/BrpcaU1",
      "expanded_url" : "http://yfrog.com/h4awqnfj",
      "display_url" : "yfrog.com/h4awqnfj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "31444549154906112",
  "text" : "Awesome bathroom reading, courtesy of suitemates http://t.co/BrpcaU1",
  "id" : 31444549154906112,
  "created_at" : "Sat Jan 29 20:12:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31145914785599489",
  "text" : "looking forward to news on Honeycomb from google on 2/2!",
  "id" : 31145914785599489,
  "created_at" : "Sat Jan 29 00:25:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 52 ],
      "url" : "http://t.co/TrOc8ZV",
      "expanded_url" : "http://www.wired.com/reviews/2011/01/undercover-kicks-let-you-pedal-or-hoof-it-in-high-style/",
      "display_url" : "wired.com/reviews/2011/0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "31082737058193408",
  "text" : "Awesome street/bike shoe hybrid! http://t.co/TrOc8ZV",
  "id" : 31082737058193408,
  "created_at" : "Fri Jan 28 20:14:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31074806413660160",
  "text" : "lost my leatherman squirt at airport security :(",
  "id" : 31074806413660160,
  "created_at" : "Fri Jan 28 19:43:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 53 ],
      "url" : "http://t.co/oe1rfFG",
      "expanded_url" : "http://yfrog.com/h0z5heij",
      "display_url" : "yfrog.com/h0z5heij"
    } ]
  },
  "geo" : {
  },
  "id_str" : "30856234877849600",
  "text" : "spotted in the streets of seattle http://t.co/oe1rfFG",
  "id" : 30856234877849600,
  "created_at" : "Fri Jan 28 05:14:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 49 ],
      "url" : "http://t.co/Gre9JfU",
      "expanded_url" : "http://yfrog.com/hskvhsfj",
      "display_url" : "yfrog.com/hskvhsfj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "30804039406981121",
  "text" : "spotted in microsoft's campus http://t.co/Gre9JfU",
  "id" : 30804039406981121,
  "created_at" : "Fri Jan 28 01:47:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PSP2",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http://t.co/YATF8ms",
      "expanded_url" : "http://www.crunchgear.com/2011/01/27/sony-unveils-the-psp2/",
      "display_url" : "crunchgear.com/2011/01/27/son\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "30548080533176320",
  "text" : "The specs on the #PSP2 are crazy. Makes me excited about handheld gaming again. http://t.co/YATF8ms",
  "id" : 30548080533176320,
  "created_at" : "Thu Jan 27 08:50:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 0, 6 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30437582810652672",
  "in_reply_to_user_id" : 1344951,
  "text" : "@wired used 'BlackBerry' as a verb in their latest issue...",
  "id" : 30437582810652672,
  "created_at" : "Thu Jan 27 01:30:59 +0000 2011",
  "in_reply_to_screen_name" : "wired",
  "in_reply_to_user_id_str" : "1344951",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30362376263958528",
  "text" : "I love pilots with a sense of humor.",
  "id" : 30362376263958528,
  "created_at" : "Wed Jan 26 20:32:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30359056333930497",
  "text" : "the DC's are a lot more comfortable than the Embraer regional jets, but delta puts tiny tiny seats in them :(",
  "id" : 30359056333930497,
  "created_at" : "Wed Jan 26 20:18:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 81, 89 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30358364659654657",
  "text" : "departed for detroit just as another snowstorm is slated to hit boston. have fun @harvard!",
  "id" : 30358364659654657,
  "created_at" : "Wed Jan 26 20:16:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30196157867098113",
  "text" : "all this #android hardware fragmentation means no cool cases or after-market accessories :(",
  "id" : 30196157867098113,
  "created_at" : "Wed Jan 26 09:31:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30194599683170305",
  "text" : "high-speed rail? yes. ROTC? win. all else was vague fluff #sotu",
  "id" : 30194599683170305,
  "created_at" : "Wed Jan 26 09:25:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 91 ],
      "url" : "http://t.co/Wb8ttnh",
      "expanded_url" : "http://www.bbc.co.uk/news/technology-12093013",
      "display_url" : "bbc.co.uk/news/technolog\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "30038175942451200",
  "text" : "Promising step towards adopting the microUSB standard for smart phones! http://t.co/Wb8ttnh",
  "id" : 30038175942451200,
  "created_at" : "Tue Jan 25 23:03:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 12, 19 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29695111583498241",
  "text" : "nice to see @google put the reader link back in the gmail page",
  "id" : 29695111583498241,
  "created_at" : "Tue Jan 25 00:20:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 0, 8 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29601650448535552",
  "in_reply_to_user_id" : 39585367,
  "text" : "@harvard upgraded it's public terminals to slick W7 boxes!",
  "id" : 29601650448535552,
  "created_at" : "Mon Jan 24 18:09:18 +0000 2011",
  "in_reply_to_screen_name" : "Harvard",
  "in_reply_to_user_id_str" : "39585367",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29269691235041280",
  "text" : "Got my Apex Gingerbread ROM setup looking slick http://yfrog.com/h2bavp",
  "id" : 29269691235041280,
  "created_at" : "Sun Jan 23 20:10:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 17, 29 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 34, 40 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29260923893981184",
  "text" : "Hanging out with @badboyboyce and @cklee at the HackHarvard tech showcase",
  "id" : 29260923893981184,
  "created_at" : "Sun Jan 23 19:35:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 20, 28 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 66, 73 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29211018596974592",
  "text" : "For some reason the @twitter app for android keeps putting an old @google tweet at the top of my feed http://yfrog.com/h3s8fp",
  "id" : 29211018596974592,
  "created_at" : "Sun Jan 23 16:17:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bostoncalendar",
      "screen_name" : "bostoncalendar",
      "indices" : [ 3, 18 ],
      "id_str" : "17396810",
      "id" : 17396810
    }, {
      "name" : "Museum of Fine Arts",
      "screen_name" : "mfaboston",
      "indices" : [ 116, 126 ],
      "id_str" : "38213768",
      "id" : 38213768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28890801077485568",
  "text" : "RT @bostoncalendar: Contemporary Chinese ink painters respond to classical ink paintings in the exhibit \"Fresh Ink\" @MFABoston http://bi ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Museum of Fine Arts",
        "screen_name" : "mfaboston",
        "indices" : [ 96, 106 ],
        "id_str" : "38213768",
        "id" : 38213768
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "28877073401511937",
    "text" : "Contemporary Chinese ink painters respond to classical ink paintings in the exhibit \"Fresh Ink\" @MFABoston http://bit.ly/eHHRpm",
    "id" : 28877073401511937,
    "created_at" : "Sat Jan 22 18:10:05 +0000 2011",
    "user" : {
      "name" : "bostoncalendar",
      "screen_name" : "bostoncalendar",
      "protected" : false,
      "id_str" : "17396810",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/809800026/things_to_do_normal.jpg",
      "id" : 17396810,
      "verified" : false
    }
  },
  "id" : 28890801077485568,
  "created_at" : "Sat Jan 22 19:04:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 0, 7 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "annoyed",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28533801063817217",
  "in_reply_to_user_id" : 20536157,
  "text" : "@google no longer puts a reader link at the top of the gmail page! #annoyed",
  "id" : 28533801063817217,
  "created_at" : "Fri Jan 21 19:26:02 +0000 2011",
  "in_reply_to_screen_name" : "google",
  "in_reply_to_user_id_str" : "20536157",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "google",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "apple",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28201670039052288",
  "text" : "Is it CEOmageddon? #google and #apple ceos stepping down",
  "id" : 28201670039052288,
  "created_at" : "Thu Jan 20 21:26:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27857161115664384",
  "text" : "I can't think of a system as poorly implemented as the #mbta",
  "id" : 27857161115664384,
  "created_at" : "Wed Jan 19 22:37:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27792740553072640",
  "text" : "Best. Security check. Ever. http://yfrog.com/hs7lirj",
  "id" : 27792740553072640,
  "created_at" : "Wed Jan 19 18:21:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27558161669947392",
  "text" : "After riding the MTR, going back to the Boston T will be rough. I did miss Cambridge though.",
  "id" : 27558161669947392,
  "created_at" : "Wed Jan 19 02:49:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27552815551348737",
  "text" : "police with MP5's patrolling Hong Kong international airport. I wonder what's up?",
  "id" : 27552815551348737,
  "created_at" : "Wed Jan 19 02:27:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webOS",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27462674304475139",
  "text" : "#webOS tablet rumors. Too bad tablets don't excite me until they can run something akin to Adobe Lightroom.",
  "id" : 27462674304475139,
  "created_at" : "Tue Jan 18 20:29:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 0, 7 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27417104500137984",
  "in_reply_to_user_id" : 20793816,
  "text" : "@amazon randomly closed my account they reopened after wrongfully closing my old one in Oct... now I have to spend months on the phone again",
  "id" : 27417104500137984,
  "created_at" : "Tue Jan 18 17:28:41 +0000 2011",
  "in_reply_to_screen_name" : "amazon",
  "in_reply_to_user_id_str" : "20793816",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 36, 45 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http://t.co/T0ovofw",
      "expanded_url" : "http://www.engadget.com/2011/01/17/2g-3g-4g-and-everything-in-between-an-engadget-wireless-prim/",
      "display_url" : "engadget.com/2011/01/17/2g-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "27407779706707968",
  "text" : "The 4G is a lie: a great writeup by @engadget on mobile tech http://t.co/T0ovofw",
  "id" : 27407779706707968,
  "created_at" : "Tue Jan 18 16:51:38 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27034198405545984",
  "text" : "Bought a Murakami book at the airport to read. Addicted now.",
  "id" : 27034198405545984,
  "created_at" : "Mon Jan 17 16:07:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26854931294060544",
  "text" : "Taking off from taipei. I'm going to miss this city and all of its bubble tea.",
  "id" : 26854931294060544,
  "created_at" : "Mon Jan 17 04:14:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 3, 11 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25588682555658242",
  "text" : "RT @digitil: happy World IPv6 Day!!....",
  "id" : 25588682555658242,
  "created_at" : "Thu Jan 13 16:23:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "verizon",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "iphone",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25177924780957696",
  "text" : "Spent the day aboard a Taiwanese oyster boat. Came back to great news: #verizon #iphone!",
  "id" : 25177924780957696,
  "created_at" : "Wed Jan 12 13:10:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tron",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24514443173953536",
  "geo" : {
  },
  "id_str" : "24516181192871937",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha download the #tron soundtrack and the movie's awfulness hurts a little less",
  "id" : 24516181192871937,
  "in_reply_to_status_id" : 24514443173953536,
  "created_at" : "Mon Jan 10 17:21:27 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Motley Fool",
      "screen_name" : "themotleyfool",
      "indices" : [ 46, 60 ],
      "id_str" : "15568127",
      "id" : 15568127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24508958576214016",
  "text" : "Bet you $20 you're wrong. Win-win for me. RT: @themotleyfool: iPhone 4 for $VZ imminent:",
  "id" : 24508958576214016,
  "created_at" : "Mon Jan 10 16:52:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Liu",
      "screen_name" : "eliseliu",
      "indices" : [ 0, 9 ],
      "id_str" : "14458332",
      "id" : 14458332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24507683642023936",
  "in_reply_to_user_id" : 14458332,
  "text" : "@eliseliu get the early adopter award for being a 3 year tweeter!",
  "id" : 24507683642023936,
  "created_at" : "Mon Jan 10 16:47:41 +0000 2011",
  "in_reply_to_screen_name" : "eliseliu",
  "in_reply_to_user_id_str" : "14458332",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 16, 24 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "indices" : [ 110, 114 ],
      "id_str" : "13",
      "id" : 13
    }, {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 115, 120 ],
      "id_str" : "12",
      "id" : 12
    }, {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 125, 128 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24348287003791361",
  "text" : "I've been using @twitter for one year now! Watching it grow has been quite amazing to say the least. Congrats @biz @jack and @ev",
  "id" : 24348287003791361,
  "created_at" : "Mon Jan 10 06:14:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "taiwan",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24128752820682752",
  "text" : "You can swipe into the subway in #taiwan with RFID'd credit cards. Impressed.",
  "id" : 24128752820682752,
  "created_at" : "Sun Jan 09 15:41:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "verizon",
      "indices" : [ 4, 12 ]
    }, {
      "text" : "iphone",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23618743179419648",
  "text" : "The #verizon #iphone rumor mill is going crazy. Will we actually find out on 1/11?",
  "id" : 23618743179419648,
  "created_at" : "Sat Jan 08 05:55:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23423584349196289",
  "text" : "RT @engadget: ComScore: Android jumps ahead of iOS in total US smartphone subscribers http://engt.co/hUy9Wm",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "23406412436611072",
    "text" : "ComScore: Android jumps ahead of iOS in total US smartphone subscribers http://engt.co/hUy9Wm",
    "id" : 23406412436611072,
    "created_at" : "Fri Jan 07 15:51:38 +0000 2011",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2409263463/5g2vkay1y34xj17ke81c_normal.jpeg",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 23423584349196289,
  "created_at" : "Fri Jan 07 16:59:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 14, 22 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 63, 73 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23388103796326401",
  "text" : "Tweeting from @twitter's new Mac App.  Will split test against @tweetdeck for a bit.",
  "id" : 23388103796326401,
  "created_at" : "Fri Jan 07 14:38:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Aberman",
      "screen_name" : "RichAberman",
      "indices" : [ 1, 13 ],
      "id_str" : "16592401",
      "id" : 16592401
    }, {
      "name" : "chris dixon",
      "screen_name" : "cdixon",
      "indices" : [ 18, 25 ],
      "id_str" : "2529971",
      "id" : 2529971
    }, {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "indices" : [ 34, 40 ],
      "id_str" : "14782518",
      "id" : 14782518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23071685183799296",
  "text" : "\"@RichAberman: RT @cdixon: Lol RT @cltom Here's a mock-up of what Angry Birds for Blackberry looks like: http://bzfd.it/fuqUNQ\"",
  "id" : 23071685183799296,
  "created_at" : "Thu Jan 06 17:41:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "droid",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23049359297880064",
  "text" : "Liking the Apex ROM - lots of slick interface tweaks over BLUR. #droid",
  "id" : 23049359297880064,
  "created_at" : "Thu Jan 06 16:12:50 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22974592247140353",
  "text" : "RT @hackernewsbot: Pizza And Ramen Are Hurting Your Startup... http://blog.500startups.com/2011/01/06/pizza-and-ramen-are-hurting-your-s ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://news.ycombinator.com/\" rel=\"nofollow\">Hacker News Bot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22860420842786817",
    "text" : "Pizza And Ramen Are Hurting Your Startup... http://blog.500startups.com/2011/01/06/pizza-and-ramen-are-hurting-your-startup/",
    "id" : 22860420842786817,
    "created_at" : "Thu Jan 06 03:42:03 +0000 2011",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/73596050/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 22974592247140353,
  "created_at" : "Thu Jan 06 11:15:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 7, 13 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gingerbread",
      "indices" : [ 49, 61 ]
    }, {
      "text" : "Droid",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22954117844443136",
  "text" : "Bought @koush's bootstrapper and installing Apex #Gingerbread for the #Droid X!",
  "id" : 22954117844443136,
  "created_at" : "Thu Jan 06 09:54:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22555203479797762",
  "text" : "Greetings from Taipei! Forgot to pack shorts",
  "id" : 22555203479797762,
  "created_at" : "Wed Jan 05 07:29:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22515035817381888",
  "text" : "Boarding for Taipei!",
  "id" : 22515035817381888,
  "created_at" : "Wed Jan 05 04:49:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22491758029967360",
  "text" : "Continuously amazed by Hong Kong efficiency. Flight check in at subway station? Yes please.",
  "id" : 22491758029967360,
  "created_at" : "Wed Jan 05 03:17:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 0, 8 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22361842399580160",
  "in_reply_to_user_id" : 39585367,
  "text" : "@harvard's entire grading system is down.  Grades are late and inaccessible. Fail.",
  "id" : 22361842399580160,
  "created_at" : "Tue Jan 04 18:40:53 +0000 2011",
  "in_reply_to_screen_name" : "Harvard",
  "in_reply_to_user_id_str" : "39585367",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22087060428951552",
  "text" : "RT @bznotes: Now that Facebook has raised a gazillion dollars, the fact that it still has clunky interfaces and bugs all over really pis ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22060557058179072",
    "text" : "Now that Facebook has raised a gazillion dollars, the fact that it still has clunky interfaces and bugs all over really pisses me off...",
    "id" : 22060557058179072,
    "created_at" : "Mon Jan 03 22:43:41 +0000 2011",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 22087060428951552,
  "created_at" : "Tue Jan 04 00:29:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21998205990342656",
  "text" : "You don't really experience Hong Kong until you tour it from the second story balcony of a tram with an open bar and full of friends",
  "id" : 21998205990342656,
  "created_at" : "Mon Jan 03 18:35:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.28689537, 114.14669059 ]
  },
  "id_str" : "21771880599912448",
  "text" : "Happiness is congee and milk tea for breakfast",
  "id" : 21771880599912448,
  "created_at" : "Mon Jan 03 03:36:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viku Casillas",
      "screen_name" : "vcruzcontrol",
      "indices" : [ 35, 48 ],
      "id_str" : "112919587",
      "id" : 112919587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21573565681762304",
  "text" : "Fantastic shopping in HK. Clearly, @vcruzcontrol needs to be here.",
  "id" : 21573565681762304,
  "created_at" : "Sun Jan 02 14:28:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omnomnom",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.28506512, 114.15797117 ]
  },
  "id_str" : "21390683860369409",
  "text" : "Wandering around Hong Kong in the morning led to 4 breakfasts. So much good food available! #omnomnom",
  "id" : 21390683860369409,
  "created_at" : "Sun Jan 02 02:21:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21213382396874753",
  "text" : "Nepalese food for dinner in Hong Kong, since it had an English menu.",
  "id" : 21213382396874753,
  "created_at" : "Sat Jan 01 14:37:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]