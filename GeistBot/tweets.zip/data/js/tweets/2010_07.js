Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20014769228",
  "text" : "Hitting up the Fells carriage trails later. Testing out a Redline Conquest Pro!",
  "id" : 20014769228,
  "created_at" : "Sat Jul 31 19:56:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 28, 36 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19970432609",
  "text" : "Bike shopping with Kirk and @digitil tomorrow. Maybe he'll learn to keep his wheels locked!",
  "id" : 19970432609,
  "created_at" : "Sat Jul 31 05:34:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19923459261",
  "text" : "I never realize how boring Cambridge can be until I have to entertain visiting friends",
  "id" : 19923459261,
  "created_at" : "Fri Jul 30 16:46:44 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Carey",
      "screen_name" : "williambcarey",
      "indices" : [ 3, 17 ],
      "id_str" : "35484447",
      "id" : 35484447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19844105047",
  "text" : "RT @williambcarey: How many hippie greenpeace girls can try to talk to me on my short jaunt to harvard square? Five. That's five too many.",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "19841466326",
    "text" : "How many hippie greenpeace girls can try to talk to me on my short jaunt to harvard square? Five. That's five too many.",
    "id" : 19841466326,
    "created_at" : "Thu Jul 29 17:14:37 +0000 2010",
    "user" : {
      "name" : "William Carey",
      "screen_name" : "williambcarey",
      "protected" : false,
      "id_str" : "35484447",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3324825298/3fa775908c9aadccde34b2f7073ff469_normal.jpeg",
      "id" : 35484447,
      "verified" : false
    }
  },
  "id" : 19844105047,
  "created_at" : "Thu Jul 29 17:57:09 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "legit",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19842218543",
  "text" : "Company in our office block is prototyping liquid body armor. #legit",
  "id" : 19842218543,
  "created_at" : "Thu Jul 29 17:26:29 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19616391535",
  "text" : "Watching the full moon rise over Dunster and Mather",
  "id" : 19616391535,
  "created_at" : "Tue Jul 27 00:59:57 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 3, 9 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19609064121",
  "text" : "RT @cklee: I LOVE AMERICA! Now legal in the U.S.: Jailbreaking your iPhone, ripping a DVD http://bit.ly/bpNR9J",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "19608393268",
    "text" : "I LOVE AMERICA! Now legal in the U.S.: Jailbreaking your iPhone, ripping a DVD http://bit.ly/bpNR9J",
    "id" : 19608393268,
    "created_at" : "Mon Jul 26 22:51:40 +0000 2010",
    "user" : {
      "name" : "ChristopherKelvinLee",
      "screen_name" : "chriskelvinlee",
      "protected" : false,
      "id_str" : "15333079",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1522463496/250029_10150195101297050_597757049_7699921_6851115_n_normal.jpg",
      "id" : 15333079,
      "verified" : false
    }
  },
  "id" : 19609064121,
  "created_at" : "Mon Jul 26 23:02:31 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19566946952",
  "text" : "Today I was woken up by a Jamaican man hitting me with a stuffed radish.",
  "id" : 19566946952,
  "created_at" : "Mon Jul 26 11:40:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19549853435",
  "text" : "Looking forward to trying out the new rear wheel on the bike.",
  "id" : 19549853435,
  "created_at" : "Mon Jul 26 05:19:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "massachusetts",
      "indices" : [ 49, 63 ]
    }, {
      "text" : "fail",
      "indices" : [ 64, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19456463678",
  "text" : "Massachusetts laws are stupid.  This state sucks #massachusetts #fail",
  "id" : 19456463678,
  "created_at" : "Sun Jul 25 00:23:59 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19442930453",
  "geo" : {
  },
  "id_str" : "19444593733",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin classy",
  "id" : 19444593733,
  "in_reply_to_status_id" : 19442930453,
  "created_at" : "Sat Jul 24 20:21:06 +0000 2010",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19422921704",
  "text" : "Locked out of an office during a move.  Boss: \"It's cheaper to break down the door than hire the movers for another day.  Get it done.\"",
  "id" : 19422921704,
  "created_at" : "Sat Jul 24 14:07:59 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 69, 80 ],
      "id_str" : "21061803",
      "id" : 21061803
    }, {
      "name" : "Janet Y.",
      "screen_name" : "jyarboi",
      "indices" : [ 85, 93 ],
      "id_str" : "81476913",
      "id" : 81476913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19421456275",
  "text" : "Saturday morning at the office, then organizing the talent show with @_Eric_Chen and @jyarboi",
  "id" : 19421456275,
  "created_at" : "Sat Jul 24 13:43:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SushiTeq",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19385857686",
  "text" : "At #SushiTeq - a tequila and sushi bar fusion. Fascinating.",
  "id" : 19385857686,
  "created_at" : "Sat Jul 24 01:58:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19376006348",
  "geo" : {
  },
  "id_str" : "19376939073",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil they all sound like Awesome :)",
  "id" : 19376939073,
  "in_reply_to_status_id" : 19376006348,
  "created_at" : "Fri Jul 23 23:32:39 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 65, 70 ]
    }, {
      "text" : "fail",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19350744900",
  "text" : "MBTA delayed on red/green lines. The T is so old and outdated... #mbta #fail",
  "id" : 19350744900,
  "created_at" : "Fri Jul 23 16:09:52 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19304520010",
  "text" : "I finally found pants that fit!!  Levi 514, I &lt;3 you",
  "id" : 19304520010,
  "created_at" : "Fri Jul 23 02:39:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19279023058",
  "text" : "Going back to default Twitter theme. It's easy on the eyes.",
  "id" : 19279023058,
  "created_at" : "Thu Jul 22 19:43:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yahoo",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19263207075",
  "text" : "Yahoo.com is down! #yahoo",
  "id" : 19263207075,
  "created_at" : "Thu Jul 22 15:31:30 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 0, 13 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19224075421",
  "geo" : {
  },
  "id_str" : "19224295224",
  "in_reply_to_user_id" : 14666934,
  "text" : "@kevinmitnick that would be pretty cool!",
  "id" : 19224295224,
  "in_reply_to_status_id" : 19224075421,
  "created_at" : "Thu Jul 22 03:30:56 +0000 2010",
  "in_reply_to_screen_name" : "kevinmitnick",
  "in_reply_to_user_id_str" : "14666934",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 3, 16 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19224131066",
  "text" : "RT @kevinmitnick: I'll also have some codes in the book to crack. If you can do it, you get entered into a drawing to win FBI evidence s ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "19222324784",
    "text" : "I'll also have some codes in the book to crack. If you can do it, you get entered into a drawing to win FBI evidence seized in my case :-)",
    "id" : 19222324784,
    "created_at" : "Thu Jul 22 03:01:56 +0000 2010",
    "user" : {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "protected" : false,
      "id_str" : "14666934",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/53807085/Mitnick_Color_normal.jpg",
      "id" : 14666934,
      "verified" : true
    }
  },
  "id" : 19224131066,
  "created_at" : "Thu Jul 22 03:28:32 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19112396350",
  "text" : "Backstreet Boys dance party at work.",
  "id" : 19112396350,
  "created_at" : "Wed Jul 21 23:06:11 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19021768060",
  "text" : "Check out google image search!",
  "id" : 19021768060,
  "created_at" : "Tue Jul 20 20:55:18 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 50, 63 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19005408450",
  "text" : "I'm exited to read... Enjoyed Art of Deception RT @kevinmitnick: We settled on the title of my autobiography: Ghost in the Wires",
  "id" : 19005408450,
  "created_at" : "Tue Jul 20 16:17:46 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18859194969",
  "text" : "If you have no idea of how a motor vehicle works, you should NOT be allowed to pilot a boat.",
  "id" : 18859194969,
  "created_at" : "Sun Jul 18 19:18:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIT",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18840724634",
  "text" : "Heading to the Flea @ #MIT with the roomie.",
  "id" : 18840724634,
  "created_at" : "Sun Jul 18 13:48:49 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Orama",
      "screen_name" : "davorama429",
      "indices" : [ 0, 12 ],
      "id_str" : "52447217",
      "id" : 52447217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18831966632",
  "geo" : {
  },
  "id_str" : "18840666009",
  "in_reply_to_user_id" : 52447217,
  "text" : "@davorama429 that doesn't sound very enjoyable...",
  "id" : 18840666009,
  "in_reply_to_status_id" : 18831966632,
  "created_at" : "Sun Jul 18 13:47:44 +0000 2010",
  "in_reply_to_screen_name" : "davorama429",
  "in_reply_to_user_id_str" : "52447217",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18778175230",
  "text" : "Navigating the Saturday tourist storm.",
  "id" : 18778175230,
  "created_at" : "Sat Jul 17 16:47:09 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 38, 51 ],
      "id_str" : "101114131",
      "id" : 101114131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18723114655",
  "text" : "Fam is visiting! Hope to take them to @Blueasiacafe :)",
  "id" : 18723114655,
  "created_at" : "Fri Jul 16 23:21:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18667055327",
  "text" : "Waking up from an epic nap in after sunset is extremely disorienting",
  "id" : 18667055327,
  "created_at" : "Fri Jul 16 07:08:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Orama",
      "screen_name" : "davorama429",
      "indices" : [ 0, 12 ],
      "id_str" : "52447217",
      "id" : 52447217
    }, {
      "name" : "helen the stylist",
      "screen_name" : "helenthestylist",
      "indices" : [ 35, 51 ],
      "id_str" : "70479817",
      "id" : 70479817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18568416219",
  "geo" : {
  },
  "id_str" : "18569787063",
  "in_reply_to_user_id" : 52447217,
  "text" : "@davorama429 Hair Cuttery! Ask for @helenthestylist",
  "id" : 18569787063,
  "in_reply_to_status_id" : 18568416219,
  "created_at" : "Thu Jul 15 02:54:56 +0000 2010",
  "in_reply_to_screen_name" : "davorama429",
  "in_reply_to_user_id_str" : "52447217",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "helen the stylist",
      "screen_name" : "helenthestylist",
      "indices" : [ 23, 39 ],
      "id_str" : "70479817",
      "id" : 70479817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18557259115",
  "text" : "Cool haircut thanks to @helenthestylist !",
  "id" : 18557259115,
  "created_at" : "Wed Jul 14 23:36:40 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18552573846",
  "text" : "Disc brake performed admirably in the rain. Next test: snow.",
  "id" : 18552573846,
  "created_at" : "Wed Jul 14 22:18:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18483183833",
  "text" : "Bricked another ipod.",
  "id" : 18483183833,
  "created_at" : "Wed Jul 14 01:48:09 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Easton Ellis",
      "screen_name" : "BretEastonEllis",
      "indices" : [ 3, 19 ],
      "id_str" : "30345764",
      "id" : 30345764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18454029056",
  "text" : "RT @BretEastonEllis: Not to sound too much like Bateman but the James Perse t-shirts and hoodies I bought a week ago are the best clothe ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "18429849868",
    "text" : "Not to sound too much like Bateman but the James Perse t-shirts and hoodies I bought a week ago are the best clothes I've worn in a year...",
    "id" : 18429849868,
    "created_at" : "Tue Jul 13 11:31:07 +0000 2010",
    "user" : {
      "name" : "Bret Easton Ellis",
      "screen_name" : "BretEastonEllis",
      "protected" : false,
      "id_str" : "30345764",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3180215487/9b2b0be15b8d2aa89a4e866b135523d3_normal.jpeg",
      "id" : 30345764,
      "verified" : true
    }
  },
  "id" : 18454029056,
  "created_at" : "Tue Jul 13 17:38:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18330741770",
  "text" : "Its time for a haircut. Recommendations for someplace nice around harvard?",
  "id" : 18330741770,
  "created_at" : "Mon Jul 12 04:58:16 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rachel marie",
      "screen_name" : "moirayma",
      "indices" : [ 3, 12 ],
      "id_str" : "29140972",
      "id" : 29140972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Boston",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18319281339",
  "text" : "RT @moirayma: RAIN. finally. #Boston",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Boston",
        "indices" : [ 15, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "18318147160",
    "text" : "RAIN. finally. #Boston",
    "id" : 18318147160,
    "created_at" : "Mon Jul 12 01:24:08 +0000 2010",
    "user" : {
      "name" : "rachel marie",
      "screen_name" : "moirayma",
      "protected" : false,
      "id_str" : "29140972",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1386079212/twitter_normal.jpg",
      "id" : 29140972,
      "verified" : false
    }
  },
  "id" : 18319281339,
  "created_at" : "Mon Jul 12 01:43:50 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Seiko",
      "indices" : [ 30, 36 ]
    }, {
      "text" : "Omega",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18282543365",
  "text" : "For some reason, favoring the #Seiko beater over the #Omega at the moment.",
  "id" : 18282543365,
  "created_at" : "Sun Jul 11 16:32:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nook",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18249675936",
  "text" : "Starting second book on the #nook. Still not sure if I like it or not.",
  "id" : 18249675936,
  "created_at" : "Sun Jul 11 05:31:44 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18227710652",
  "geo" : {
  },
  "id_str" : "18229291465",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha I hate that everyone loves that song.",
  "id" : 18229291465,
  "in_reply_to_status_id" : 18227710652,
  "created_at" : "Sat Jul 10 23:17:04 +0000 2010",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18217529373",
  "text" : "Dancing in the rain, hope my phone doesn't short out.",
  "id" : 18217529373,
  "created_at" : "Sat Jul 10 19:22:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18050908869",
  "text" : "Google Reader Play has just killed my productivity and spit on its corpse.",
  "id" : 18050908869,
  "created_at" : "Thu Jul 08 17:33:37 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18043362871",
  "text" : "Lesson learned this summer: people are stupid.  And that's profitable.",
  "id" : 18043362871,
  "created_at" : "Thu Jul 08 15:43:17 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 0, 8 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17837937555",
  "geo" : {
  },
  "id_str" : "17844308391",
  "in_reply_to_user_id" : 142513192,
  "text" : "@digitil Lenovo T410",
  "id" : 17844308391,
  "in_reply_to_status_id" : 17837937555,
  "created_at" : "Tue Jul 06 04:58:42 +0000 2010",
  "in_reply_to_screen_name" : "digitil",
  "in_reply_to_user_id_str" : "142513192",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 10, 23 ],
      "id_str" : "101114131",
      "id" : 101114131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17823387072",
  "text" : "Dinner at @Blueasiacafe !",
  "id" : 17823387072,
  "created_at" : "Mon Jul 05 23:04:01 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17801813370",
  "text" : "Reading in the yard. Why didn't I do this during the school year?",
  "id" : 17801813370,
  "created_at" : "Mon Jul 05 16:29:14 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17759906846",
  "text" : "Fire works from the Charles River!",
  "id" : 17759906846,
  "created_at" : "Mon Jul 05 02:30:31 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nook",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17679249793",
  "text" : "I'm tweeting from a #nook!",
  "id" : 17679249793,
  "created_at" : "Sat Jul 03 21:57:24 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Harvard",
      "screen_name" : "jharvardstatue",
      "indices" : [ 66, 81 ],
      "id_str" : "85747975",
      "id" : 85747975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17607079544",
  "text" : "Ambushed by Korean tourist paparazzi in the Yard AH. Must be what @jharvardstatue feels like.",
  "id" : 17607079544,
  "created_at" : "Fri Jul 02 23:09:08 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17548162658",
  "geo" : {
  },
  "id_str" : "17548759868",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin at least you're not stuck in boston!",
  "id" : 17548759868,
  "in_reply_to_status_id" : 17548162658,
  "created_at" : "Fri Jul 02 05:13:43 +0000 2010",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17520254259",
  "text" : "Laughing as a blue Lambo attempts to navigate Mass Ave during rush hour.",
  "id" : 17520254259,
  "created_at" : "Thu Jul 01 21:00:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17509159330",
  "text" : "Internet broken in the office. Sitting around scratching our heads.",
  "id" : 17509159330,
  "created_at" : "Thu Jul 01 17:41:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 3, 16 ],
      "id_str" : "101114131",
      "id" : 101114131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17475222451",
  "text" : "RT @Blueasiacafe: Ice Cream Boba Black Tea....now is available in store :D",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "17470595960",
    "text" : "Ice Cream Boba Black Tea....now is available in store :D",
    "id" : 17470595960,
    "created_at" : "Thu Jul 01 05:15:53 +0000 2010",
    "user" : {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "protected" : false,
      "id_str" : "101114131",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/604737097/LOGO_normal.jpg",
      "id" : 101114131,
      "verified" : false
    }
  },
  "id" : 17475222451,
  "created_at" : "Thu Jul 01 06:54:58 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]