Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lax",
      "screen_name" : "jlax",
      "indices" : [ 3, 8 ],
      "id_str" : "11735032",
      "id" : 11735032
    }, {
      "name" : "darrell whitelaw",
      "screen_name" : "darrellwhitelaw",
      "indices" : [ 58, 74 ],
      "id_str" : "14392842",
      "id" : 14392842
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/KeithStoeckeler/status/229735807412482050/photo/1",
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/7UAJtVgv",
      "media_url" : "http://pbs.twimg.com/media/AzAvf-lCMAALI6p.jpg",
      "id_str" : "229735807416676352",
      "id" : 229735807416676352,
      "media_url_https" : "https://pbs.twimg.com/media/AzAvf-lCMAALI6p.jpg",
      "sizes" : [ {
        "h" : 586,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/7UAJtVgv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230183238042284033",
  "text" : "RT @jlax: This is how to parent  http://t.co/7UAJtVgv h/t @darrellwhitelaw",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "darrell whitelaw",
        "screen_name" : "darrellwhitelaw",
        "indices" : [ 48, 64 ],
        "id_str" : "14392842",
        "id" : 14392842
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/KeithStoeckeler/status/229735807412482050/photo/1",
        "indices" : [ 23, 43 ],
        "url" : "http://t.co/7UAJtVgv",
        "media_url" : "http://pbs.twimg.com/media/AzAvf-lCMAALI6p.jpg",
        "id_str" : "229735807416676352",
        "id" : 229735807416676352,
        "media_url_https" : "https://pbs.twimg.com/media/AzAvf-lCMAALI6p.jpg",
        "sizes" : [ {
          "h" : 586,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/7UAJtVgv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "229738234769461248",
    "text" : "This is how to parent  http://t.co/7UAJtVgv h/t @darrellwhitelaw",
    "id" : 229738234769461248,
    "created_at" : "Mon Jul 30 00:40:38 +0000 2012",
    "user" : {
      "name" : "Jon Lax",
      "screen_name" : "jlax",
      "protected" : false,
      "id_str" : "11735032",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1148796114/Picture_3_normal.png",
      "id" : 11735032,
      "verified" : false
    }
  },
  "id" : 230183238042284033,
  "created_at" : "Tue Jul 31 06:08:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "indices" : [ 3, 19 ],
      "id_str" : "263122363",
      "id" : 263122363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bowchickawowwow",
      "indices" : [ 72, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230005221043097600",
  "text" : "RT @HarvardAsianGuy: I was an Olympian four years ago. A math Olympian. #bowchickawowwow",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bowchickawowwow",
        "indices" : [ 51, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "229988699998408704",
    "text" : "I was an Olympian four years ago. A math Olympian. #bowchickawowwow",
    "id" : 229988699998408704,
    "created_at" : "Mon Jul 30 17:15:53 +0000 2012",
    "user" : {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "protected" : false,
      "id_str" : "263122363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1713903417/asian_normal.jpg",
      "id" : 263122363,
      "verified" : false
    }
  },
  "id" : 230005221043097600,
  "created_at" : "Mon Jul 30 18:21:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229819817484484608",
  "geo" : {
  },
  "id_str" : "229827574300278785",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee hope you're not tweeting and driving!",
  "id" : 229827574300278785,
  "in_reply_to_status_id" : 229819817484484608,
  "created_at" : "Mon Jul 30 06:35:38 +0000 2012",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229745160425205760",
  "text" : "RT @Fake_Dispatch: The Obama re-election team is going to pay for three more Mitt Romney overseas trips.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "229719559429570560",
    "text" : "The Obama re-election team is going to pay for three more Mitt Romney overseas trips.",
    "id" : 229719559429570560,
    "created_at" : "Sun Jul 29 23:26:25 +0000 2012",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 229745160425205760,
  "created_at" : "Mon Jul 30 01:08:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/229715610181976065/photo/1",
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/IP462uPV",
      "media_url" : "http://pbs.twimg.com/media/AzAdIWDCQAA-CWn.jpg",
      "id_str" : "229715610190364672",
      "id" : 229715610190364672,
      "media_url_https" : "https://pbs.twimg.com/media/AzAdIWDCQAA-CWn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 726
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 726
      } ],
      "display_url" : "pic.twitter.com/IP462uPV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229715610181976065",
  "text" : "The obsessiveness of Apple design. http://t.co/IP462uPV",
  "id" : 229715610181976065,
  "created_at" : "Sun Jul 29 23:10:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 3, 13 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 59, 66 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/gkRERPJW",
      "expanded_url" : "http://instagr.am/p/Nrpbkqif1z/",
      "display_url" : "instagr.am/p/Nrpbkqif1z/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229713581036412928",
  "text" : "RT @jenny8lee: Want. An iphone wallet case. Custom-made by @khsieh.  http://t.co/gkRERPJW",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 44, 51 ],
        "id_str" : "111999960",
        "id" : 111999960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http://t.co/gkRERPJW",
        "expanded_url" : "http://instagr.am/p/Nrpbkqif1z/",
        "display_url" : "instagr.am/p/Nrpbkqif1z/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "229709155227811840",
    "text" : "Want. An iphone wallet case. Custom-made by @khsieh.  http://t.co/gkRERPJW",
    "id" : 229709155227811840,
    "created_at" : "Sun Jul 29 22:45:05 +0000 2012",
    "user" : {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "protected" : false,
      "id_str" : "1976841",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1842465869/jenny_baby_graduation_cap_cropped_normal.jpg",
      "id" : 1976841,
      "verified" : true
    }
  },
  "id" : 229713581036412928,
  "created_at" : "Sun Jul 29 23:02:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio",
      "screen_name" : "antrod",
      "indices" : [ 55, 62 ],
      "id_str" : "464493",
      "id" : 464493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229503078204846080",
  "text" : "Cell phone, Polaroid, Walkman, and bag of AAA maps. RT @antrod: What is the 1990s equivalent of the smartphone?",
  "id" : 229503078204846080,
  "created_at" : "Sun Jul 29 09:06:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229474583680516096",
  "text" : "RT @TheEconomist: Apple is one of the most admired brands in China. Apple's products are selling fast and likely to sell even faster htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/n7i4P4Dv",
        "expanded_url" : "http://econ.st/MQi08M",
        "display_url" : "econ.st/MQi08M"
      } ]
    },
    "geo" : {
    },
    "id_str" : "229474276724588544",
    "text" : "Apple is one of the most admired brands in China. Apple's products are selling fast and likely to sell even faster http://t.co/n7i4P4Dv",
    "id" : 229474276724588544,
    "created_at" : "Sun Jul 29 07:11:45 +0000 2012",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 229474583680516096,
  "created_at" : "Sun Jul 29 07:12:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229469916091273216",
  "text" : "Imagine: a Halo game set at the same time as the original, in which you play a marine escaping the Flood, rendered w the Dead Space engine.",
  "id" : 229469916091273216,
  "created_at" : "Sun Jul 29 06:54:26 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229451036388110336",
  "geo" : {
  },
  "id_str" : "229451864503119873",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee if you're in vegas, wanna get boba?",
  "id" : 229451864503119873,
  "in_reply_to_status_id" : 229451036388110336,
  "created_at" : "Sun Jul 29 05:42:42 +0000 2012",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.1699415762, -115.1396845774 ]
  },
  "id_str" : "229299527327285248",
  "text" : "DEFCON is actually more interesting than the NBC Olympics coverage right now.",
  "id" : 229299527327285248,
  "created_at" : "Sat Jul 28 19:37:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 0, 5 ],
      "id_str" : "132319630",
      "id" : 132319630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228701372281917440",
  "in_reply_to_user_id" : 132319630,
  "text" : "@sidd you coming out for Defcon?",
  "id" : 228701372281917440,
  "created_at" : "Fri Jul 27 04:00:30 +0000 2012",
  "in_reply_to_screen_name" : "sidd",
  "in_reply_to_user_id_str" : "132319630",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228628231710965760",
  "text" : "I wonder if dino ISPs will innovate to compete with Google Fiber or just try to litigate/mire Fiber growth. Probably the latter.",
  "id" : 228628231710965760,
  "created_at" : "Thu Jul 26 23:09:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 101 ],
      "url" : "https://t.co/u1psI77q",
      "expanded_url" : "https://fiber.google.com/plans/residential/",
      "display_url" : "fiber.google.com/plans/resident\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228626808151617536",
  "text" : "Google Fiber is going piss a lot of ISPs off and bury dial-up once and for all. https://t.co/u1psI77q",
  "id" : 228626808151617536,
  "created_at" : "Thu Jul 26 23:04:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 1, 9 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/8U22Wsaw",
      "expanded_url" : "http://harvardmagazine.com/2012/06/undergraduate-art-and-architecture-track-begins-in-fall",
      "display_url" : "harvardmagazine.com/2012/06/underg\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228543063256084480",
  "text" : ".@Harvard to offer undergraduate architectural studies. Finally. http://t.co/8U22Wsaw",
  "id" : 228543063256084480,
  "created_at" : "Thu Jul 26 17:31:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228540445758722048",
  "text" : "Bing has been doing hi-def 3D maps for a while, but iOS6 will advertise it as \"revolutionary;\" Reality Distortion Field at full strength.",
  "id" : 228540445758722048,
  "created_at" : "Thu Jul 26 17:21:03 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Twinks Say",
      "screen_name" : "ShitTwinksSay",
      "indices" : [ 30, 44 ],
      "id_str" : "459476435",
      "id" : 459476435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228219263654174720",
  "text" : "Friends keep mixing up me and @ShitTwinksSay due to our profile pictures.",
  "id" : 228219263654174720,
  "created_at" : "Wed Jul 25 20:04:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ludwin",
      "screen_name" : "adamludwin",
      "indices" : [ 21, 32 ],
      "id_str" : "6568422",
      "id" : 6568422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228206142193545216",
  "text" : "Or 52 Instagrams. RT @adamludwin: Or they could do it with one Facebook.",
  "id" : 228206142193545216,
  "created_at" : "Wed Jul 25 19:12:38 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B&H Photo Video",
      "screen_name" : "BHPhotoVideo",
      "indices" : [ 7, 20 ],
      "id_str" : "10422602",
      "id" : 10422602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228196389639835648",
  "text" : "Thanks @BHPhotoVideo for making your mail catalog opt-in and saving a lot of paper!",
  "id" : 228196389639835648,
  "created_at" : "Wed Jul 25 18:33:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 11, 20 ],
      "id_str" : "20568189",
      "id" : 20568189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/wEvFfw1f",
      "expanded_url" : "http://hodinkee.com/2012/7/18/swatch-reaches-draft-agreement-to-cut-supplies-to-competing.html",
      "display_url" : "hodinkee.com/2012/7/18/swat\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228033048107687936",
  "text" : "I disagree @hodinkee; Swatch will hurt creativity by reducing mvmnt supply bc small creative boutiques will go under. http://t.co/wEvFfw1f",
  "id" : 228033048107687936,
  "created_at" : "Wed Jul 25 07:44:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227820326065688576",
  "text" : "RT @Fake_Dispatch: Iranian nuclear program hit by 'AC/DC Virus.' Hackers say if their demands aren't met then they will launch the deadl ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "227815773958193152",
    "text" : "Iranian nuclear program hit by 'AC/DC Virus.' Hackers say if their demands aren't met then they will launch the deadlier 'Nickelback Virus.'",
    "id" : 227815773958193152,
    "created_at" : "Tue Jul 24 17:21:27 +0000 2012",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 227820326065688576,
  "created_at" : "Tue Jul 24 17:39:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 3, 15 ],
      "id_str" : "2735591",
      "id" : 2735591
    }, {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 75, 83 ],
      "id_str" : "6825792",
      "id" : 6825792
    }, {
      "name" : "Georgia Tech",
      "screen_name" : "georgiatech",
      "indices" : [ 87, 99 ],
      "id_str" : "19080617",
      "id" : 19080617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/KUXaYJjp",
      "expanded_url" : "http://bit.ly/SGvQwY",
      "display_url" : "bit.ly/SGvQwY"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227592554185629697",
  "text" : "RT @FastCompany: Kickstarter is \"a Like button attached to your wallet.\" - @ibogost of @georgiatech http://t.co/KUXaYJjp",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Bogost",
        "screen_name" : "ibogost",
        "indices" : [ 58, 66 ],
        "id_str" : "6825792",
        "id" : 6825792
      }, {
        "name" : "Georgia Tech",
        "screen_name" : "georgiatech",
        "indices" : [ 70, 82 ],
        "id_str" : "19080617",
        "id" : 19080617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http://t.co/KUXaYJjp",
        "expanded_url" : "http://bit.ly/SGvQwY",
        "display_url" : "bit.ly/SGvQwY"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227585897242189824",
    "text" : "Kickstarter is \"a Like button attached to your wallet.\" - @ibogost of @georgiatech http://t.co/KUXaYJjp",
    "id" : 227585897242189824,
    "created_at" : "Tue Jul 24 02:08:00 +0000 2012",
    "user" : {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "protected" : false,
      "id_str" : "2735591",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1797716029/fc-logo-300x300_normal.gif",
      "id" : 2735591,
      "verified" : true
    }
  },
  "id" : 227592554185629697,
  "created_at" : "Tue Jul 24 02:34:28 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/WC5k8fw6",
      "expanded_url" : "http://hvrd.me/ObV4m1",
      "display_url" : "hvrd.me/ObV4m1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227517517369839616",
  "text" : "RT @hseas: \"We took a rat apart and rebuilt it as a jellyfish.\" http://t.co/WC5k8fw6",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http://t.co/WC5k8fw6",
        "expanded_url" : "http://hvrd.me/ObV4m1",
        "display_url" : "hvrd.me/ObV4m1"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227507823389577216",
    "text" : "\"We took a rat apart and rebuilt it as a jellyfish.\" http://t.co/WC5k8fw6",
    "id" : 227507823389577216,
    "created_at" : "Mon Jul 23 20:57:46 +0000 2012",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 227517517369839616,
  "created_at" : "Mon Jul 23 21:36:17 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "indices" : [ 45, 56 ],
      "id_str" : "1000591",
      "id" : 1000591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/i5d8Q31B",
      "expanded_url" : "http://4sq.com/MAJzF1",
      "display_url" : "4sq.com/MAJzF1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227516604093693952",
  "text" : "Good to see people bullish on upstate NY. RT @fredwilson: At the grand opening of Buffalo's Z80 tech incubator: http://t.co/i5d8Q31B",
  "id" : 227516604093693952,
  "created_at" : "Mon Jul 23 21:32:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/p6CIQzFJ",
      "expanded_url" : "http://www.theonion.com/video/hp-on-that-cloud-thing-that-everyone-else-is-talki,28789/",
      "display_url" : "theonion.com/video/hp-on-th\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227213715848699904",
  "text" : "HP is doing the cloud thing, and doing it better than everyone else. http://t.co/p6CIQzFJ",
  "id" : 227213715848699904,
  "created_at" : "Mon Jul 23 01:29:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/omnSLUiT",
      "expanded_url" : "http://www.economist.com/node/21559308",
      "display_url" : "economist.com/node/21559308"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226798624275845120",
  "text" : "\"[We chase] after ever-higher gross domestic product... that takes no account of the blessings of nature or leisure.\" http://t.co/omnSLUiT",
  "id" : 226798624275845120,
  "created_at" : "Sat Jul 21 21:59:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/8bO1cMam",
      "expanded_url" : "http://swisswatchwire.com/2012/07/swiss-watch-exports-defy-economic-malaise.html",
      "display_url" : "swisswatchwire.com/2012/07/swiss-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226786043251265536",
  "text" : "Unsurprisingly, demand for luxury Swiss watches highest in Hong Kong and China; demand beats economic malaise.  http://t.co/8bO1cMam",
  "id" : 226786043251265536,
  "created_at" : "Sat Jul 21 21:09:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 13, 25 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/7pXSNwgV",
      "expanded_url" : "http://bit.ly/OqXqgz",
      "display_url" : "bit.ly/OqXqgz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226523320508633088",
  "text" : "Hot damn. RT @christinelu: \"China\u2019s Tencent Sees Market Cap Hit $66 Billion, Passes Facebook\" [Tech In Asia]  http://t.co/7pXSNwgV",
  "id" : 226523320508633088,
  "created_at" : "Sat Jul 21 03:45:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226497033928843265",
  "text" : "Also, not sure if the helmet is a bit too tight, but Christian Bale can't seem to touch his lips together when he's batman.",
  "id" : 226497033928843265,
  "created_at" : "Sat Jul 21 02:01:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226495586159964160",
  "text" : "Re: Dark Knight - apparently there are very few minorities in Gotham City.",
  "id" : 226495586159964160,
  "created_at" : "Sat Jul 21 01:55:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/PQ41gEQ2",
      "expanded_url" : "http://www.engadget.com/2012/07/20/qantas-to-hand-out-free-ipads-to-all-passengers-on-boeing-767s/",
      "display_url" : "engadget.com/2012/07/20/qan\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226425440129142784",
  "text" : "Apparently, giving iPads to everyone on a 767 is more cost effective than in-flight entertainment due to weight. http://t.co/PQ41gEQ2",
  "id" : 226425440129142784,
  "created_at" : "Fri Jul 20 21:16:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SparrowMail",
      "screen_name" : "sparrow",
      "indices" : [ 52, 60 ],
      "id_str" : "163449492",
      "id" : 163449492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226351956229242880",
  "text" : "Google's shopping spree continues. Buy-of-the-week: @Sparrow.",
  "id" : 226351956229242880,
  "created_at" : "Fri Jul 20 16:24:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/9GskVtXc",
      "expanded_url" : "http://www.engadget.com/2012/07/20/lenovo-ceo-spreads-the-wealth/",
      "display_url" : "engadget.com/2012/07/20/len\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226350779030712320",
  "text" : "Lenovo's CEO divides his $3MM bonus amongst his employees. http://t.co/9GskVtXc",
  "id" : 226350779030712320,
  "created_at" : "Fri Jul 20 16:20:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Maps",
      "screen_name" : "googlemaps",
      "indices" : [ 56, 67 ],
      "id_str" : "31311757",
      "id" : 31311757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226330690843705344",
  "text" : "It would be awesome if I could cache specific cities in @GoogleMaps, especially since Nexus 7 is wifi only.",
  "id" : 226330690843705344,
  "created_at" : "Fri Jul 20 15:00:16 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Ellman",
      "screen_name" : "bikenyc",
      "indices" : [ 0, 8 ],
      "id_str" : "4515021",
      "id" : 4515021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226251421882933248",
  "geo" : {
  },
  "id_str" : "226258756135165953",
  "in_reply_to_user_id" : 4515021,
  "text" : "@bikenyc you know what's great in the rain? Cyclocross.",
  "id" : 226258756135165953,
  "in_reply_to_status_id" : 226251421882933248,
  "created_at" : "Fri Jul 20 10:14:25 +0000 2012",
  "in_reply_to_screen_name" : "bikenyc",
  "in_reply_to_user_id_str" : "4515021",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/GZVM5MKi",
      "expanded_url" : "http://blog.kanehsieh.com/2012/07/20/nexus-7-review/",
      "display_url" : "blog.kanehsieh.com/2012/07/20/nex\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226183250769485824",
  "text" : "Nexus 7: the tablet that made me a tablet user. http://t.co/GZVM5MKi",
  "id" : 226183250769485824,
  "created_at" : "Fri Jul 20 05:14:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 36, 46 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/zNN480PW",
      "expanded_url" : "http://www.geekwire.com/2012/zillow-celebrates-1year-ipo-anniversary-soaring-stock-12-billion-market/",
      "display_url" : "geekwire.com/2012/zillow-ce\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226091977941344256",
  "text" : "Zillow valued at 1.2 Instagrams. RT @johnhcook: Zillow celebrates 1-year anniversary... $1.2B market value: http://t.co/zNN480PW",
  "id" : 226091977941344256,
  "created_at" : "Thu Jul 19 23:11:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/225678962586681346/photo/1",
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/8kHTqSRy",
      "media_url" : "http://pbs.twimg.com/media/AyHF0h6CAAI9qpE.png",
      "id_str" : "225678962590875650",
      "id" : 225678962590875650,
      "media_url_https" : "https://pbs.twimg.com/media/AyHF0h6CAAI9qpE.png",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/8kHTqSRy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225678962586681346",
  "text" : "Despite Android widgets I still fall into the groove of static-icons-on-desktop paradigm. http://t.co/8kHTqSRy",
  "id" : 225678962586681346,
  "created_at" : "Wed Jul 18 19:50:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 0, 12 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225671820035104768",
  "geo" : {
  },
  "id_str" : "225677929655439360",
  "in_reply_to_user_id" : 7782442,
  "text" : "@christinelu you should just dress up as a mainland tourist. Burberry everything, Gucci bag, zero taste. Easy.",
  "id" : 225677929655439360,
  "in_reply_to_status_id" : 225671820035104768,
  "created_at" : "Wed Jul 18 19:46:25 +0000 2012",
  "in_reply_to_screen_name" : "christinelu",
  "in_reply_to_user_id_str" : "7782442",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 3, 17 ],
      "id_str" : "15593773",
      "id" : 15593773
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 19, 26 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225658383640977409",
  "text" : "RT @lexiberylross: @khsieh is that a Nexus 7 in your pocket, or are you just happy to see me?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 0, 7 ],
        "id_str" : "111999960",
        "id" : 111999960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "225628896945647616",
    "geo" : {
    },
    "id_str" : "225630032679284736",
    "in_reply_to_user_id" : 19380775,
    "text" : "@khsieh is that a Nexus 7 in your pocket, or are you just happy to see me?",
    "id" : 225630032679284736,
    "in_reply_to_status_id" : 225628896945647616,
    "created_at" : "Wed Jul 18 16:36:06 +0000 2012",
    "in_reply_to_screen_name" : "kane",
    "in_reply_to_user_id_str" : "19380775",
    "user" : {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "protected" : false,
      "id_str" : "15593773",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1909477451/image_normal.jpg",
      "id" : 15593773,
      "verified" : false
    }
  },
  "id" : 225658383640977409,
  "created_at" : "Wed Jul 18 18:28:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 42, 55 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/2H67g2Nc",
      "expanded_url" : "http://econ.st/NVm215",
      "display_url" : "econ.st/NVm215"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225646663564398592",
  "text" : "This further worsens gender imbalance. RT @TheEconomist: In China, estimated 16m straight women are married to gay men http://t.co/2H67g2Nc",
  "id" : 225646663564398592,
  "created_at" : "Wed Jul 18 17:42:11 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/7BSs4Uli",
      "expanded_url" : "http://dvice.com/archives/2012/07/space-kill-vehi.php",
      "display_url" : "dvice.com/archives/2012/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225641548740706304",
  "text" : "\"Exoatmospheric Kill Vehicle\" sounds like Michael Bay's wet dream. http://t.co/7BSs4Uli",
  "id" : 225641548740706304,
  "created_at" : "Wed Jul 18 17:21:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane",
      "screen_name" : "kane",
      "indices" : [ 20, 25 ],
      "id_str" : "19380775",
      "id" : 19380775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225630650433142784",
  "text" : "Still trying to get @kane handle. Love what they've done with my name though.",
  "id" : 225630650433142784,
  "created_at" : "Wed Jul 18 16:38:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/225628896945647616/photo/1",
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/w4YZ7t76",
      "media_url" : "http://pbs.twimg.com/media/AyGYSU3CMAAPBpy.jpg",
      "id_str" : "225628896949841920",
      "id" : 225628896949841920,
      "media_url_https" : "https://pbs.twimg.com/media/AyGYSU3CMAAPBpy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/w4YZ7t76"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225628896945647616",
  "text" : "The Nexus 7 is totally pocketable. http://t.co/w4YZ7t76",
  "id" : 225628896945647616,
  "created_at" : "Wed Jul 18 16:31:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSJ Life & Style",
      "screen_name" : "WSJLife",
      "indices" : [ 25, 33 ],
      "id_str" : "28182280",
      "id" : 28182280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/QaFww1oa",
      "expanded_url" : "http://on.wsj.com/OXVR7f",
      "display_url" : "on.wsj.com/OXVR7f"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225626937542979584",
  "text" : "Love the DIY culture. RT @WSJLife: DIY Toys. How to get kids into crafts, not catalogs http://t.co/QaFww1oa",
  "id" : 225626937542979584,
  "created_at" : "Wed Jul 18 16:23:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BostInnovation",
      "screen_name" : "BostInnovation",
      "indices" : [ 3, 18 ],
      "id_str" : "1056260852",
      "id" : 1056260852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/Xpkm8kKH",
      "expanded_url" : "http://bostinno.com/2012/07/18/massachusetts-saw-a-serious-uptick-in-series-a-deals-in-q2-data/#ss__187773_1_0__ss",
      "display_url" : "bostinno.com/2012/07/18/mas\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225625613262786560",
  "text" : "RT @BostInnovation: Massachusetts Saw a Serious Uptick in Series A Deals in Q2 [Data] http://t.co/Xpkm8kKH",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http://t.co/Xpkm8kKH",
        "expanded_url" : "http://bostinno.com/2012/07/18/massachusetts-saw-a-serious-uptick-in-series-a-deals-in-q2-data/#ss__187773_1_0__ss",
        "display_url" : "bostinno.com/2012/07/18/mas\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "225595265493639168",
    "text" : "Massachusetts Saw a Serious Uptick in Series A Deals in Q2 [Data] http://t.co/Xpkm8kKH",
    "id" : 225595265493639168,
    "created_at" : "Wed Jul 18 14:17:57 +0000 2012",
    "user" : {
      "name" : "BostInno",
      "screen_name" : "BostInno",
      "protected" : false,
      "id_str" : "16877220",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3314802473/f7d5c89cb0722c196a4e7639165f5907_normal.jpeg",
      "id" : 16877220,
      "verified" : false
    }
  },
  "id" : 225625613262786560,
  "created_at" : "Wed Jul 18 16:18:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 11, 19 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225459667646693376",
  "text" : "I wish the @twitter app would sync where I've scrolled to across devices so I can keep reading my stream seamlessly.",
  "id" : 225459667646693376,
  "created_at" : "Wed Jul 18 05:19:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/Yu2FdviQ",
      "expanded_url" : "http://pandodaily.com/2012/07/17/already-valued-at-4b-chinas-xiaomi-has-declared-war-on-apple/",
      "display_url" : "pandodaily.com/2012/07/17/alr\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225389344742055936",
  "text" : "Remain ignorant about China at your own risk: $4B valuation, strong team, but still unknown in America. http://t.co/Yu2FdviQ",
  "id" : 225389344742055936,
  "created_at" : "Wed Jul 18 00:39:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225360933394984960",
  "text" : "It still blows my mind that we pee into potable water. Someone please develop a better toilet.",
  "id" : 225360933394984960,
  "created_at" : "Tue Jul 17 22:46:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    }, {
      "name" : "Scott Kirsner",
      "screen_name" : "ScottKirsner",
      "indices" : [ 114, 127 ],
      "id_str" : "896221",
      "id" : 896221
    }, {
      "name" : "Damien",
      "screen_name" : "bostond",
      "indices" : [ 128, 136 ],
      "id_str" : "34986576",
      "id" : 34986576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/XziiCBrn",
      "expanded_url" : "http://bo.st/SBczxb",
      "display_url" : "bo.st/SBczxb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225360666796621824",
  "text" : "RT @medialab: The Media Lab roots of Google Glass, the wearable computer information display http://t.co/XziiCBrn @scottkirsner @bostond ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Kirsner",
        "screen_name" : "ScottKirsner",
        "indices" : [ 100, 113 ],
        "id_str" : "896221",
        "id" : 896221
      }, {
        "name" : "Boston.com",
        "screen_name" : "BostonDotCom",
        "indices" : [ 114, 127 ],
        "id_str" : "14602259",
        "id" : 14602259
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http://t.co/XziiCBrn",
        "expanded_url" : "http://bo.st/SBczxb",
        "display_url" : "bo.st/SBczxb"
      } ]
    },
    "geo" : {
    },
    "id_str" : "225358073613651969",
    "text" : "The Media Lab roots of Google Glass, the wearable computer information display http://t.co/XziiCBrn @scottkirsner @bostondotcom",
    "id" : 225358073613651969,
    "created_at" : "Tue Jul 17 22:35:26 +0000 2012",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 225360666796621824,
  "created_at" : "Tue Jul 17 22:45:44 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/225331683459727361/photo/1",
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/Rupo33Vd",
      "media_url" : "http://pbs.twimg.com/media/AyCJ-OaCAAAyD6j.jpg",
      "id_str" : "225331683480698880",
      "id" : 225331683480698880,
      "media_url_https" : "https://pbs.twimg.com/media/AyCJ-OaCAAAyD6j.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/Rupo33Vd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225331683459727361",
  "text" : "Spending the day with Nexus 7 and Jelly Bean. http://t.co/Rupo33Vd",
  "id" : 225331683459727361,
  "created_at" : "Tue Jul 17 20:50:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225309623538819073",
  "text" : "Judging from texts, my friends in i-banking are sleeping, reading, or playing iPhone games thru training. Future of economy in good hands.",
  "id" : 225309623538819073,
  "created_at" : "Tue Jul 17 19:22:54 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Bailey",
      "screen_name" : "RMB",
      "indices" : [ 28, 32 ],
      "id_str" : "19094625",
      "id" : 19094625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225307687787827200",
  "text" : "Where can I find report? RT @RMB: Internet users w income over $100k/year are 70 times more likely to Tweet than the average population.",
  "id" : 225307687787827200,
  "created_at" : "Tue Jul 17 19:15:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audi",
      "screen_name" : "Audi",
      "indices" : [ 5, 10 ],
      "id_str" : "27650674",
      "id" : 27650674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/xxQbfyPn",
      "expanded_url" : "http://www.stuff.tv/news/life-etc/news-nugget/audi-launches-worlds-first-kinect-powered-car-dealership-in-london",
      "display_url" : "stuff.tv/news/life-etc/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225291528308928512",
  "text" : "This @Audi dealship is like Saville Row + Minority Report. http://t.co/xxQbfyPn",
  "id" : 225291528308928512,
  "created_at" : "Tue Jul 17 18:11:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexi Ross",
      "screen_name" : "lexiberylross",
      "indices" : [ 0, 14 ],
      "id_str" : "15593773",
      "id" : 15593773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225125792974258179",
  "geo" : {
  },
  "id_str" : "225126558111760384",
  "in_reply_to_user_id" : 15593773,
  "text" : "@lexiberylross I resorted to this grayish clump of papers that someone leaves in front of my door for news today.",
  "id" : 225126558111760384,
  "in_reply_to_status_id" : 225125792974258179,
  "created_at" : "Tue Jul 17 07:15:28 +0000 2012",
  "in_reply_to_screen_name" : "lexiberylross",
  "in_reply_to_user_id_str" : "15593773",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/225105460611649536/photo/1",
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/bWmKX9cC",
      "media_url" : "http://pbs.twimg.com/media/Ax-8OUkCEAAxSfn.jpg",
      "id_str" : "225105460615843840",
      "id" : 225105460615843840,
      "media_url_https" : "https://pbs.twimg.com/media/Ax-8OUkCEAAxSfn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/bWmKX9cC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225105460611649536",
  "text" : "Tony Hsieh has a giant foam playground in his apartment. http://t.co/bWmKX9cC",
  "id" : 225105460611649536,
  "created_at" : "Tue Jul 17 05:51:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McDonald's",
      "screen_name" : "McDonalds",
      "indices" : [ 24, 34 ],
      "id_str" : "71026122",
      "id" : 71026122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/1i7TsMQM",
      "expanded_url" : "http://eyetap.blogspot.com/2012/07/physical-assault-by-mcdonalds-for.html",
      "display_url" : "eyetap.blogspot.com/2012/07/physic\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225054889561169920",
  "text" : "Steve Mann assaulted by @McDonalds employees in Paris of all places. http://t.co/1i7TsMQM",
  "id" : 225054889561169920,
  "created_at" : "Tue Jul 17 02:30:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225041769757294593",
  "text" : "Nexus 7 by end of day tomorrow.",
  "id" : 225041769757294593,
  "created_at" : "Tue Jul 17 01:38:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Rosser Eldon",
      "screen_name" : "eldon",
      "indices" : [ 3, 9 ],
      "id_str" : "7982802",
      "id" : 7982802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224977408409878528",
  "text" : "RT @eldon: poor microsoft thought it would own the news cycle today.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "224969111720042497",
    "text" : "poor microsoft thought it would own the news cycle today.",
    "id" : 224969111720042497,
    "created_at" : "Mon Jul 16 20:49:50 +0000 2012",
    "user" : {
      "name" : "Eric Rosser Eldon",
      "screen_name" : "eldon",
      "protected" : false,
      "id_str" : "7982802",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2046149481/Screen_Shot_2012-04-05_at_4.40.49_PM_normal.png",
      "id" : 7982802,
      "verified" : true
    }
  },
  "id" : 224977408409878528,
  "created_at" : "Mon Jul 16 21:22:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 15, 24 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/5VhfXHta",
      "expanded_url" : "http://dealbook.nytimes.com/2012/07/16/googles-marissa-mayer-tapped-as-yahoos-chief/",
      "display_url" : "dealbook.nytimes.com/2012/07/16/goo\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224959228887040000",
  "text" : "Hello what? RT @Techmeme: Google's Marissa Mayer Tapped as Yahoo's Chief http://t.co/5VhfXHta",
  "id" : 224959228887040000,
  "created_at" : "Mon Jul 16 20:10:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/25PR2kil",
      "expanded_url" : "http://www.wired.com/dangerroom/2012/07/blackwater-lawsuit",
      "display_url" : "wired.com/dangerroom/201\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224923566540460033",
  "text" : "Surprise! Academi n\u00E9 Blackwater sued by employees for malfeasance. http://t.co/25PR2kil",
  "id" : 224923566540460033,
  "created_at" : "Mon Jul 16 17:48:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bussgang",
      "screen_name" : "bussgang",
      "indices" : [ 3, 12 ],
      "id_str" : "18691131",
      "id" : 18691131
    }, {
      "name" : "Skillshare",
      "screen_name" : "skillshare",
      "indices" : [ 60, 71 ],
      "id_str" : "171613435",
      "id" : 171613435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/Usl38XrU",
      "expanded_url" : "http://skl.sh/Ah90bs",
      "display_url" : "skl.sh/Ah90bs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224898864329662464",
  "text" : "RT @bussgang: Just to prove VCs work in Aug, I'm teaching a @SkillShare class on raising capital: 8/13 @ Havard iLab - http://t.co/Usl38XrU",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Skillshare",
        "screen_name" : "skillshare",
        "indices" : [ 46, 57 ],
        "id_str" : "171613435",
        "id" : 171613435
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http://t.co/Usl38XrU",
        "expanded_url" : "http://skl.sh/Ah90bs",
        "display_url" : "skl.sh/Ah90bs"
      } ]
    },
    "geo" : {
    },
    "id_str" : "224883156141084672",
    "text" : "Just to prove VCs work in Aug, I'm teaching a @SkillShare class on raising capital: 8/13 @ Havard iLab - http://t.co/Usl38XrU",
    "id" : 224883156141084672,
    "created_at" : "Mon Jul 16 15:08:17 +0000 2012",
    "user" : {
      "name" : "Jeff Bussgang",
      "screen_name" : "bussgang",
      "protected" : false,
      "id_str" : "18691131",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1769148744/JB_profile_pic_normal.jpg",
      "id" : 18691131,
      "verified" : false
    }
  },
  "id" : 224898864329662464,
  "created_at" : "Mon Jul 16 16:10:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Schlafman",
      "screen_name" : "schlaf",
      "indices" : [ 1, 8 ],
      "id_str" : "9544202",
      "id" : 9544202
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 39, 48 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/224738641115754496/photo/1",
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/g5JgaVQx",
      "media_url" : "http://pbs.twimg.com/media/Ax5umneCMAAxDA6.jpg",
      "id_str" : "224738641124143104",
      "id" : 224738641124143104,
      "media_url_https" : "https://pbs.twimg.com/media/Ax5umneCMAAxDA6.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com/g5JgaVQx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224738641115754496",
  "text" : ".@schlaf grabbing late dinner with the @Romotive team. http://t.co/g5JgaVQx",
  "id" : 224738641115754496,
  "created_at" : "Mon Jul 16 05:34:03 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Singleton",
      "screen_name" : "MicahSingleton",
      "indices" : [ 3, 18 ],
      "id_str" : "337801323",
      "id" : 337801323
    }, {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 21, 32 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224733184334630912",
  "text" : "RT @MicahSingleton: .@parislemon\u2019s Nexus 7 review is trending worldwide. Higher than the Kardashians. Maybe there is hope for us after all.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MG Siegler",
        "screen_name" : "parislemon",
        "indices" : [ 1, 12 ],
        "id_str" : "652193",
        "id" : 652193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "224726917864108033",
    "text" : ".@parislemon\u2019s Nexus 7 review is trending worldwide. Higher than the Kardashians. Maybe there is hope for us after all.",
    "id" : 224726917864108033,
    "created_at" : "Mon Jul 16 04:47:27 +0000 2012",
    "user" : {
      "name" : "Micah Singleton",
      "screen_name" : "MicahSingleton",
      "protected" : false,
      "id_str" : "337801323",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3514007844/a087fd5babf89806ee76b0150929efe7_normal.jpeg",
      "id" : 337801323,
      "verified" : false
    }
  },
  "id" : 224733184334630912,
  "created_at" : "Mon Jul 16 05:12:21 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/SUKFGHgf",
      "expanded_url" : "http://theaviationist.com/2012/07/14/airspace-lock-down/",
      "display_url" : "theaviationist.com/2012/07/14/air\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224688729699262465",
  "text" : "If you find yourself flying above London... here's how to avoid being shot down by a Eurofighter. http://t.co/SUKFGHgf",
  "id" : 224688729699262465,
  "created_at" : "Mon Jul 16 02:15:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYPD NEWS",
      "screen_name" : "NYPDnews",
      "indices" : [ 1, 10 ],
      "id_str" : "17393196",
      "id" : 17393196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224642806096998400",
  "text" : ".@NYPDnews not sure how you screen your officers, but I'd think blatant sexual harassment would be a disqualifying factor.",
  "id" : 224642806096998400,
  "created_at" : "Sun Jul 15 23:13:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYPD NEWS",
      "screen_name" : "NYPDnews",
      "indices" : [ 4, 13 ],
      "id_str" : "17393196",
      "id" : 17393196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224639838048092160",
  "text" : "Hey @NYPDnews, I don't appreciate your officers at WTC propositioning my girlfriend, telling her to 'date around' while I'm out of town.",
  "id" : 224639838048092160,
  "created_at" : "Sun Jul 15 23:01:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyssa Milano",
      "screen_name" : "Alyssa_Milano",
      "indices" : [ 47, 61 ],
      "id_str" : "26642006",
      "id" : 26642006
    }, {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 62, 74 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224626154898849793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.170641355, -115.1395184242 ]
  },
  "id_str" : "224635021892403200",
  "in_reply_to_user_id" : 26642006,
  "text" : "Roots manufactures about 60% overseas as well. @Alyssa_Milano @christinelu",
  "id" : 224635021892403200,
  "in_reply_to_status_id" : 224626154898849793,
  "created_at" : "Sun Jul 15 22:42:17 +0000 2012",
  "in_reply_to_screen_name" : "Alyssa_Milano",
  "in_reply_to_user_id_str" : "26642006",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Xu",
      "screen_name" : "Chrysaora",
      "indices" : [ 3, 13 ],
      "id_str" : "14550221",
      "id" : 14550221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/EUCJaCKg",
      "expanded_url" : "http://twitpic.com/a7nn3t",
      "display_url" : "twitpic.com/a7nn3t"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224280568936923139",
  "text" : "RT @Chrysaora: Pretty cool Dropbox hardware prototype.  http://t.co/EUCJaCKg",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/\" rel=\"nofollow\">Seesmic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/EUCJaCKg",
        "expanded_url" : "http://twitpic.com/a7nn3t",
        "display_url" : "twitpic.com/a7nn3t"
      } ]
    },
    "geo" : {
    },
    "id_str" : "224270351327166465",
    "text" : "Pretty cool Dropbox hardware prototype.  http://t.co/EUCJaCKg",
    "id" : 224270351327166465,
    "created_at" : "Sat Jul 14 22:33:13 +0000 2012",
    "user" : {
      "name" : "Christina Xu",
      "screen_name" : "Chrysaora",
      "protected" : false,
      "id_str" : "14550221",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3060651218/947023bc9d17cab864379f6c14b4b9bf_normal.jpeg",
      "id" : 14550221,
      "verified" : false
    }
  },
  "id" : 224280568936923139,
  "created_at" : "Sat Jul 14 23:13:49 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/224279955649998848/photo/1",
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/B6Jlo7Ik",
      "media_url" : "http://pbs.twimg.com/media/AxzNbm8CMAAHJ-o.jpg",
      "id_str" : "224279955654193152",
      "id" : 224279955654193152,
      "media_url_https" : "https://pbs.twimg.com/media/AxzNbm8CMAAHJ-o.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/B6Jlo7Ik"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6155432111, -122.3828774156 ]
  },
  "id_str" : "224279955649998848",
  "text" : "I knew the A380 was massive, but seeing one in real life is something else. http://t.co/B6Jlo7Ik",
  "id" : 224279955649998848,
  "created_at" : "Sat Jul 14 23:11:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/rFYps8Rd",
      "expanded_url" : "http://ebiquity.umbc.edu/blogger/2008/01/19/how-dr-suess-would-prove-the-halting-problem-undecidable/",
      "display_url" : "ebiquity.umbc.edu/blogger/2008/0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224270712070864897",
  "text" : "How Dr. Seuss would prove the halting problem undecidable. http://t.co/rFYps8Rd",
  "id" : 224270712070864897,
  "created_at" : "Sat Jul 14 22:34:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 0, 12 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224191400990883841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6165838354, -122.3805736286 ]
  },
  "id_str" : "224258492310097921",
  "in_reply_to_user_id" : 7782442,
  "text" : "@christinelu my friend did video for CCTV in Beijing, said they were often too lazy to go tape breaking news.",
  "id" : 224258492310097921,
  "in_reply_to_status_id" : 224191400990883841,
  "created_at" : "Sat Jul 14 21:46:05 +0000 2012",
  "in_reply_to_screen_name" : "christinelu",
  "in_reply_to_user_id_str" : "7782442",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.6440825759, -73.7816346 ]
  },
  "id_str" : "224160352370311168",
  "text" : "Cutest thing ever: Chinese toddler and French toddler sharing Pokemon in JFK security line.",
  "id" : 224160352370311168,
  "created_at" : "Sat Jul 14 15:16:07 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/7MSxnA1d",
      "expanded_url" : "http://feeds.boingboing.net/~r/boingboing/iBag/~3/nS1PMtJkLLk/stuff-makes-us-sad-especially.html",
      "display_url" : "feeds.boingboing.net/~r/boingboing/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223893260983218177",
  "text" : "Material possessions, good jobs, extracurricular enrichment, and misery. http://t.co/7MSxnA1d",
  "id" : 223893260983218177,
  "created_at" : "Fri Jul 13 21:34:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/boMqiioX",
      "expanded_url" : "http://vedantmisra.com/2011/12/elevator-algorithms/",
      "display_url" : "vedantmisra.com/2011/12/elevat\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223875321282314240",
  "text" : "Next time you're waiting for an elevator, learn about what algorithms are determining your wait. http://t.co/boMqiioX",
  "id" : 223875321282314240,
  "created_at" : "Fri Jul 13 20:23:30 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/cRNNM5qx",
      "expanded_url" : "http://feedproxy.google.com/~r/typepad/swisswatchboutique/~3/TutmDvNNC4c/fake-swiss-watches-reach-new-levels-of-sophistication.html",
      "display_url" : "feedproxy.google.com/~r/typepad/swi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223828129582559234",
  "text" : "Interesting questions arise when counterfeits are so sophisticated. If you can't tell, does it matter? (as consumer) http://t.co/cRNNM5qx",
  "id" : 223828129582559234,
  "created_at" : "Fri Jul 13 17:15:59 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 54, 68 ],
      "id_str" : "16005250",
      "id" : 16005250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7133716718, -74.0159481951 ]
  },
  "id_str" : "223827141794598912",
  "text" : "Cheating on Regents is like robbing Salvation Army cc @angryasianman",
  "id" : 223827141794598912,
  "created_at" : "Fri Jul 13 17:12:03 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 36, 50 ],
      "id_str" : "16005250",
      "id" : 16005250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/LqWryX28",
      "expanded_url" : "http://bit.ly/Mpx0KK",
      "display_url" : "bit.ly/Mpx0KK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7133716718, -74.0159481951 ]
  },
  "id_str" : "223826934927331329",
  "text" : "Of all exams, they pick Regents? RT @angryasianman: 70 Stuyvesant students caught cheating on Regents exam: http://t.co/LqWryX28",
  "id" : 223826934927331329,
  "created_at" : "Fri Jul 13 17:11:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/223824820230557698/photo/1",
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/u1yZ06eM",
      "media_url" : "http://pbs.twimg.com/media/AxsvfPZCEAIBdvT.jpg",
      "id_str" : "223824820238946306",
      "id" : 223824820238946306,
      "media_url_https" : "https://pbs.twimg.com/media/AxsvfPZCEAIBdvT.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com/u1yZ06eM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223824820230557698",
  "text" : "iPad based point of sales taking over. http://t.co/u1yZ06eM",
  "id" : 223824820230557698,
  "created_at" : "Fri Jul 13 17:02:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dragon ",
      "screen_name" : "dragoninnovate",
      "indices" : [ 3, 18 ],
      "id_str" : "421859846",
      "id" : 421859846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223801695870779392",
  "text" : "RT @dragoninnovate: It's not new to us, but glad to have it affirmed what we already knew: hardware is the new software.  Amen. http://t ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/8KMA4BWO",
        "expanded_url" : "http://bit.ly/NHGGBv",
        "display_url" : "bit.ly/NHGGBv"
      } ]
    },
    "geo" : {
    },
    "id_str" : "223799968778039296",
    "text" : "It's not new to us, but glad to have it affirmed what we already knew: hardware is the new software.  Amen. http://t.co/8KMA4BWO",
    "id" : 223799968778039296,
    "created_at" : "Fri Jul 13 15:24:05 +0000 2012",
    "user" : {
      "name" : "Dragon ",
      "screen_name" : "dragoninnovate",
      "protected" : false,
      "id_str" : "421859846",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2226528205/DI_gear_normal.jpg",
      "id" : 421859846,
      "verified" : false
    }
  },
  "id" : 223801695870779392,
  "created_at" : "Fri Jul 13 15:30:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7267749636, -74.0034765937 ]
  },
  "id_str" : "223599494481186816",
  "text" : "Talking to VZW store manager. \"Accessory sales correlate to quality of packaging. That's really about it.\"",
  "id" : 223599494481186816,
  "created_at" : "Fri Jul 13 02:07:28 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7154780021, -74.0145376046 ]
  },
  "id_str" : "223541637215817729",
  "text" : "Armies of fashionable (but not TOO fashionable) blue button ups in NY financial district at 6PM. Armies.",
  "id" : 223541637215817729,
  "created_at" : "Thu Jul 12 22:17:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "affairs",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "debt",
      "indices" : [ 105, 110 ]
    }, {
      "text" : "drugs",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223517369664946176",
  "text" : "You overhear some really dysfunctional stuff in a Financial District cafe at 4 PM on a weekday. #affairs #debt #drugs",
  "id" : 223517369664946176,
  "created_at" : "Thu Jul 12 20:41:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223499276599304192",
  "text" : "Back in the iOS fold. Galaxy SIII was overwhelmingly large, Incredible 4G was underwhelming plain.",
  "id" : 223499276599304192,
  "created_at" : "Thu Jul 12 19:29:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/223485432195858432/photo/1",
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/5t992dT9",
      "media_url" : "http://pbs.twimg.com/media/Axn60QbCQAAhpSA.jpg",
      "id_str" : "223485432200052736",
      "id" : 223485432200052736,
      "media_url_https" : "https://pbs.twimg.com/media/Axn60QbCQAAhpSA.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com/5t992dT9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.715279, -74.011654 ]
  },
  "id_str" : "223485432195858432",
  "text" : "At NYC Verizon store for Galaxy SIII launch. http://t.co/5t992dT9",
  "id" : 223485432195858432,
  "created_at" : "Thu Jul 12 18:34:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pawe\u0142 Szymczykowski",
      "screen_name" : "makenai",
      "indices" : [ 3, 11 ],
      "id_str" : "4569381",
      "id" : 4569381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223127462689775616",
  "text" : "RT @makenai: May you live in ridiculous times.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "223082317286080513",
    "text" : "May you live in ridiculous times.",
    "id" : 223082317286080513,
    "created_at" : "Wed Jul 11 15:52:23 +0000 2012",
    "user" : {
      "name" : "Pawe\u0142 Szymczykowski",
      "screen_name" : "makenai",
      "protected" : false,
      "id_str" : "4569381",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2419919807/ea5my0bt24zy65naioem_normal.jpeg",
      "id" : 4569381,
      "verified" : false
    }
  },
  "id" : 223127462689775616,
  "created_at" : "Wed Jul 11 18:51:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.75168489, -73.98019252 ]
  },
  "id_str" : "223051275439308802",
  "text" : "Facebook employees, how do they know when you're actually working and not just on Facebook?",
  "id" : 223051275439308802,
  "created_at" : "Wed Jul 11 13:49:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Noble",
      "screen_name" : "cfnoble",
      "indices" : [ 35, 43 ],
      "id_str" : "14479692",
      "id" : 14479692
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 98, 111 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/Y9PhwiAQ",
      "expanded_url" : "http://econ.st/LFtWh3",
      "display_url" : "econ.st/LFtWh3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7470675, -73.9888934 ]
  },
  "id_str" : "223046719309492224",
  "text" : "Does that count sales overseas? RT @cfnoble: Prada and Gucci owe 1/3 of their sales to China. via @TheEconomist http://t.co/Y9PhwiAQ",
  "id" : 223046719309492224,
  "created_at" : "Wed Jul 11 13:30:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222924186740473856",
  "text" : "Overheard hanging out w college friends in NY: \"If I want to stay in banking, I have to figure out what to talk to white guys about.\"",
  "id" : 222924186740473856,
  "created_at" : "Wed Jul 11 05:24:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 56, 68 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/RX4mcQ9I",
      "expanded_url" : "http://kck.st/Mfvs9y",
      "display_url" : "kck.st/Mfvs9y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222923824285491200",
  "text" : "I just backed OUYA: A New Kind of Video Game Console on @Kickstarter http://t.co/RX4mcQ9I",
  "id" : 222923824285491200,
  "created_at" : "Wed Jul 11 05:22:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hobby",
      "screen_name" : "strobist",
      "indices" : [ 0, 9 ],
      "id_str" : "14305530",
      "id" : 14305530
    }, {
      "name" : "PosterBrain.com",
      "screen_name" : "posterbrain",
      "indices" : [ 45, 57 ],
      "id_str" : "30991249",
      "id" : 30991249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222880794794930177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.73285659, -73.92029819 ]
  },
  "id_str" : "222885020333899777",
  "in_reply_to_user_id" : 14305530,
  "text" : "@strobist you can big cheap poster prints at @posterbrain unless you're looking for fancy papers.",
  "id" : 222885020333899777,
  "in_reply_to_status_id" : 222880794794930177,
  "created_at" : "Wed Jul 11 02:48:24 +0000 2012",
  "in_reply_to_screen_name" : "strobist",
  "in_reply_to_user_id_str" : "14305530",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 11, 20 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/2vyTGDzq",
      "expanded_url" : "http://www.macrumors.com/2012/07/10/13-inch-retina-macbook-pro-shows-up-in-benchmarks/",
      "display_url" : "macrumors.com/2012/07/10/13-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.0870735, -115.1509653 ]
  },
  "id_str" : "222793785707462656",
  "text" : "Yessss. RT @Techmeme: 13-Inch Retina MacBook Pro Shows Up in Benchmarks http://t.co/2vyTGDzq",
  "id" : 222793785707462656,
  "created_at" : "Tue Jul 10 20:45:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222765423781883904",
  "text" : "Nexus 7 preordered. By the laws of the universe, a retina iPad mini will be announced in the next month.",
  "id" : 222765423781883904,
  "created_at" : "Tue Jul 10 18:53:10 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harbus News",
      "screen_name" : "TheHarbusHBS",
      "indices" : [ 3, 16 ],
      "id_str" : "241161213",
      "id" : 241161213
    }, {
      "name" : "Ann Handley",
      "screen_name" : "MarketingProfs",
      "indices" : [ 21, 36 ],
      "id_str" : "8596022",
      "id" : 8596022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "urbanairship",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222765185411194883",
  "text" : "RT @TheHarbusHBS: RT @marketingprofs: \"APPathy\" is a real problem -- Average lifespan of a mobile app is one month. #urbanairship",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ann Handley",
        "screen_name" : "MarketingProfs",
        "indices" : [ 3, 18 ],
        "id_str" : "8596022",
        "id" : 8596022
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "urbanairship",
        "indices" : [ 98, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "222751374763503616",
    "text" : "RT @marketingprofs: \"APPathy\" is a real problem -- Average lifespan of a mobile app is one month. #urbanairship",
    "id" : 222751374763503616,
    "created_at" : "Tue Jul 10 17:57:20 +0000 2012",
    "user" : {
      "name" : "The Harbus News",
      "screen_name" : "TheHarbusHBS",
      "protected" : false,
      "id_str" : "241161213",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1879812168/harbuslogo_normal.jpeg",
      "id" : 241161213,
      "verified" : false
    }
  },
  "id" : 222765185411194883,
  "created_at" : "Tue Jul 10 18:52:13 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle Team",
      "screen_name" : "AmazonKindle",
      "indices" : [ 15, 28 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222596845438898176",
  "text" : "My 3-month old @AmazonKindle Touch 3G stopped working after intermittent issues. Thinking of just going to Nexus 7 at this point.",
  "id" : 222596845438898176,
  "created_at" : "Tue Jul 10 07:43:18 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Tseng",
      "screen_name" : "BenjaminTseng",
      "indices" : [ 3, 17 ],
      "id_str" : "15876871",
      "id" : 15876871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/UtKkHXMs",
      "expanded_url" : "http://content.usatoday.com/communities/driveon/post/2012/07/toyota-camry-beats-ford-f-150-as-most-american-made/1",
      "display_url" : "content.usatoday.com/communities/dr\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222561923290505216",
  "text" : "RT @BenjaminTseng: What does it mean to drive \"American\"? Toyota Camry beats Ford F-150 as most 'American made' http://t.co/UtKkHXMs",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http://t.co/UtKkHXMs",
        "expanded_url" : "http://content.usatoday.com/communities/driveon/post/2012/07/toyota-camry-beats-ford-f-150-as-most-american-made/1",
        "display_url" : "content.usatoday.com/communities/dr\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "222506421898575873",
    "text" : "What does it mean to drive \"American\"? Toyota Camry beats Ford F-150 as most 'American made' http://t.co/UtKkHXMs",
    "id" : 222506421898575873,
    "created_at" : "Tue Jul 10 01:43:59 +0000 2012",
    "user" : {
      "name" : "Benjamin Tseng",
      "screen_name" : "BenjaminTseng",
      "protected" : false,
      "id_str" : "15876871",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2355557182/n0mQ0SQp_normal",
      "id" : 15876871,
      "verified" : false
    }
  },
  "id" : 222561923290505216,
  "created_at" : "Tue Jul 10 05:24:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/gvev5PDm",
      "expanded_url" : "http://www.10000yearclock.net/learnmore.html",
      "display_url" : "10000yearclock.net/learnmore.html"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222552169965035520",
  "text" : "Just subscribed to Bezo's awe-inspiring 10,000 year project. http://t.co/gvev5PDm",
  "id" : 222552169965035520,
  "created_at" : "Tue Jul 10 04:45:46 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.16863446, -115.13848534 ]
  },
  "id_str" : "222542898552512512",
  "text" : "Watching a slam poet read off of an iPad. Most over engineered napkin ever.",
  "id" : 222542898552512512,
  "created_at" : "Tue Jul 10 04:08:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa Hsiao",
      "screen_name" : "teresahsiao",
      "indices" : [ 15, 27 ],
      "id_str" : "313121859",
      "id" : 313121859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/9v29T309",
      "expanded_url" : "http://www.huffingtonpost.com/teresa-hsiao/what-harvards-like_b_1657848.html",
      "display_url" : "huffingtonpost.com/teresa-hsiao/w\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222505018060832768",
  "text" : "Good points by @teresahsiao, but for one caveat: never in four years did someone tell me not to like Franzia. http://t.co/9v29T309",
  "id" : 222505018060832768,
  "created_at" : "Tue Jul 10 01:38:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Helfferich",
      "screen_name" : "JoshHelfferich",
      "indices" : [ 3, 18 ],
      "id_str" : "563200400",
      "id" : 563200400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222488356901228544",
  "text" : "RT @JoshHelfferich: Does Google\u2019s autonomous car have to download drivers?",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "222470038916046848",
    "text" : "Does Google\u2019s autonomous car have to download drivers?",
    "id" : 222470038916046848,
    "created_at" : "Mon Jul 09 23:19:25 +0000 2012",
    "user" : {
      "name" : "Josh Helfferich",
      "screen_name" : "JoshHelfferich",
      "protected" : false,
      "id_str" : "563200400",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2735503490/380fa0452d92f9dd814e8aa079799783_normal.jpeg",
      "id" : 563200400,
      "verified" : false
    }
  },
  "id" : 222488356901228544,
  "created_at" : "Tue Jul 10 00:32:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/YSjdnV1j",
      "expanded_url" : "http://www.dpreview.com/news/2012/07/09/Research-uses-noise-patterns-to-detect-manipulated-images",
      "display_url" : "dpreview.com/news/2012/07/0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222472042384080897",
  "text" : "\"This looks shooped. I can tell because of the noise.\" http://t.co/YSjdnV1j",
  "id" : 222472042384080897,
  "created_at" : "Mon Jul 09 23:27:22 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 31, 39 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222450326568046595",
  "text" : "RT @hseas: Flight tests in the @Harvard Microrobotics Lab at SEAS. \"Robobees\" are smaller than a U.S. quarter &amp; ~60 times lighter! h ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 20, 28 ],
        "id_str" : "39585367",
        "id" : 39585367
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http://t.co/rqQcjNEM",
        "expanded_url" : "http://hvrd.me/NVY3e3",
        "display_url" : "hvrd.me/NVY3e3"
      } ]
    },
    "geo" : {
    },
    "id_str" : "222436885916688384",
    "text" : "Flight tests in the @Harvard Microrobotics Lab at SEAS. \"Robobees\" are smaller than a U.S. quarter &amp; ~60 times lighter! http://t.co/rqQcjNEM",
    "id" : 222436885916688384,
    "created_at" : "Mon Jul 09 21:07:40 +0000 2012",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 222450326568046595,
  "created_at" : "Mon Jul 09 22:01:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/KIZA01G9",
      "expanded_url" : "http://tcrn.ch/L4rbzG",
      "display_url" : "tcrn.ch/L4rbzG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222448814290776065",
  "text" : "Holy crap, that's a lot of zeroes: GitHub Raises $100 Million From Power VC Andreessen Horowitz http://t.co/KIZA01G9",
  "id" : 222448814290776065,
  "created_at" : "Mon Jul 09 21:55:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222430313794650112",
  "text" : "6 guys in a Chevy Suburban listening to One Direction. What is my life.",
  "id" : 222430313794650112,
  "created_at" : "Mon Jul 09 20:41:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222235893853995008",
  "text" : "Does anyone else think good Android phones are getting unreasonably big? Sold my Galaxy Nexus for an old HTC Incredible based on size.",
  "id" : 222235893853995008,
  "created_at" : "Mon Jul 09 07:49:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "koush",
      "screen_name" : "koush",
      "indices" : [ 3, 9 ],
      "id_str" : "18918415",
      "id" : 18918415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222172923631386624",
  "text" : "RT @koush: Retina is just a buzzword. iPhone 4 retina: 326. iPad 3 dpi: 264. MacBook Pro \"retina\": 220.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "222164444531277824",
    "text" : "Retina is just a buzzword. iPhone 4 retina: 326. iPad 3 dpi: 264. MacBook Pro \"retina\": 220.",
    "id" : 222164444531277824,
    "created_at" : "Mon Jul 09 03:05:05 +0000 2012",
    "user" : {
      "name" : "koush",
      "screen_name" : "koush",
      "protected" : false,
      "id_str" : "18918415",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1577420755/img-18_normal.jpg",
      "id" : 18918415,
      "verified" : false
    }
  },
  "id" : 222172923631386624,
  "created_at" : "Mon Jul 09 03:38:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/yJ6JRYCf",
      "expanded_url" : "http://blog.kanehsieh.com/2012/07/07/seagull-1963-review/",
      "display_url" : "blog.kanehsieh.com/2012/07/07/sea\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222028284198789121",
  "text" : "My watch of choice. It might surprise you. http://t.co/yJ6JRYCf",
  "id" : 222028284198789121,
  "created_at" : "Sun Jul 08 18:04:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221795525882679296",
  "geo" : {
  },
  "id_str" : "221835904459882496",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee you use OSX right? Try SourceTree for git management.",
  "id" : 221835904459882496,
  "in_reply_to_status_id" : 221795525882679296,
  "created_at" : "Sun Jul 08 05:19:35 +0000 2012",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Bodnick",
      "screen_name" : "MarcBodnick",
      "indices" : [ 14, 26 ],
      "id_str" : "22832236",
      "id" : 22832236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221730236285460481",
  "text" : "I had no idea @MarcBodnick was from the Buffalo area.",
  "id" : 221730236285460481,
  "created_at" : "Sat Jul 07 22:19:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    }, {
      "name" : "WIPO",
      "screen_name" : "WIPO",
      "indices" : [ 105, 110 ],
      "id_str" : "428885306",
      "id" : 428885306
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovative",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221320800991576064",
  "text" : "RT @medialab: Switzerland, Sweden and Singapore are the world\u2019s most #innovative countries, according to @WIPO study http://t.co/49exF8U ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WIPO",
        "screen_name" : "WIPO",
        "indices" : [ 91, 96 ],
        "id_str" : "428885306",
        "id" : 428885306
      }, {
        "name" : "Jennifer Freedman",
        "screen_name" : "americlogs",
        "indices" : [ 124, 135 ],
        "id_str" : "302101168",
        "id" : 302101168
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "innovative",
        "indices" : [ 55, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http://t.co/49exF8UB",
        "expanded_url" : "http://bloom.bg/LiWDAp",
        "display_url" : "bloom.bg/LiWDAp"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221292472444264448",
    "text" : "Switzerland, Sweden and Singapore are the world\u2019s most #innovative countries, according to @WIPO study http://t.co/49exF8UB @americlogs",
    "id" : 221292472444264448,
    "created_at" : "Fri Jul 06 17:20:11 +0000 2012",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 221320800991576064,
  "created_at" : "Fri Jul 06 19:12:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 3, 11 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221293611122298881",
  "text" : "RT @Harvard: Did you know? Families with incomes from $65K-$150K &amp; w/typical assets pay 0-10% of their annual incomes http://t.co/Sf ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/SfcLgPAT",
        "expanded_url" : "http://hvrd.me/NukJbT",
        "display_url" : "hvrd.me/NukJbT"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221290939799441409",
    "text" : "Did you know? Families with incomes from $65K-$150K &amp; w/typical assets pay 0-10% of their annual incomes http://t.co/SfcLgPAT",
    "id" : 221290939799441409,
    "created_at" : "Fri Jul 06 17:14:06 +0000 2012",
    "user" : {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "protected" : false,
      "id_str" : "39585367",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3349317264/1954930211e08d2ba39bb6a670049eb3_normal.png",
      "id" : 39585367,
      "verified" : true
    }
  },
  "id" : 221293611122298881,
  "created_at" : "Fri Jul 06 17:24:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neal Wu",
      "screen_name" : "WuNeal",
      "indices" : [ 3, 10 ],
      "id_str" : "493458695",
      "id" : 493458695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/Ikc1xEM8",
      "expanded_url" : "http://www.textfromxcode.com/",
      "display_url" : "textfromxcode.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221157938788696065",
  "text" : "RT @WuNeal: For everyone who took CS164: http://t.co/Ikc1xEM8",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http://t.co/Ikc1xEM8",
        "expanded_url" : "http://www.textfromxcode.com/",
        "display_url" : "textfromxcode.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221151961762897920",
    "text" : "For everyone who took CS164: http://t.co/Ikc1xEM8",
    "id" : 221151961762897920,
    "created_at" : "Fri Jul 06 08:01:51 +0000 2012",
    "user" : {
      "name" : "Neal Wu",
      "screen_name" : "WuNeal",
      "protected" : false,
      "id_str" : "493458695",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3343659603/ccc62c3493f31312aa2b4b5fe2908e62_normal.jpeg",
      "id" : 493458695,
      "verified" : false
    }
  },
  "id" : 221157938788696065,
  "created_at" : "Fri Jul 06 08:25:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dragon ",
      "screen_name" : "dragoninnovate",
      "indices" : [ 0, 15 ],
      "id_str" : "421859846",
      "id" : 421859846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220864038928789504",
  "geo" : {
  },
  "id_str" : "221117895839723520",
  "in_reply_to_user_id" : 421859846,
  "text" : "@dragoninnovate emailed you guys; hope we can work something out and get producing!",
  "id" : 221117895839723520,
  "in_reply_to_status_id" : 220864038928789504,
  "created_at" : "Fri Jul 06 05:46:29 +0000 2012",
  "in_reply_to_screen_name" : "dragoninnovate",
  "in_reply_to_user_id_str" : "421859846",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg LP",
      "screen_name" : "Bloomberg",
      "indices" : [ 13, 23 ],
      "id_str" : "80357931",
      "id" : 80357931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221094143852679168",
  "text" : "According to @bloomberg, Amazon is planning a smartphone. I can't wait for one-click drunk texts.",
  "id" : 221094143852679168,
  "created_at" : "Fri Jul 06 04:12:06 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 25, 35 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221055262256152577",
  "text" : "Ran into an MIT alum and @momogoose fan while searching for banh mi in Vegas today. \"worth the flight to Boston just for that food truck.\"",
  "id" : 221055262256152577,
  "created_at" : "Fri Jul 06 01:37:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BostInnovation",
      "screen_name" : "BostInnovation",
      "indices" : [ 3, 18 ],
      "id_str" : "1056260852",
      "id" : 1056260852
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 76, 84 ],
      "id_str" : "39585367",
      "id" : 39585367
    }, {
      "name" : "Song Yu Ting",
      "screen_name" : "Boo",
      "indices" : [ 132, 136 ],
      "id_str" : "732693",
      "id" : 732693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/gDMfF91Z",
      "expanded_url" : "http://bit.ly/NpqYJu",
      "display_url" : "bit.ly/NpqYJu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220953809147543554",
  "text" : "RT @BostInnovation: How Local Street Style Blog Books&amp;Liquor Interprets @Harvard\u2019s Fashion Sense [Images] http://t.co/gDMfF91Z  @Boo ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 56, 64 ],
        "id_str" : "39585367",
        "id" : 39585367
      }, {
        "name" : "BooksandLiquor",
        "screen_name" : "BooksandLiquor",
        "indices" : [ 112, 127 ],
        "id_str" : "243077211",
        "id" : 243077211
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/gDMfF91Z",
        "expanded_url" : "http://bit.ly/NpqYJu",
        "display_url" : "bit.ly/NpqYJu"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220944633356763137",
    "text" : "How Local Street Style Blog Books&amp;Liquor Interprets @Harvard\u2019s Fashion Sense [Images] http://t.co/gDMfF91Z  @BooksandLiquor",
    "id" : 220944633356763137,
    "created_at" : "Thu Jul 05 18:18:00 +0000 2012",
    "user" : {
      "name" : "BostInno",
      "screen_name" : "BostInno",
      "protected" : false,
      "id_str" : "16877220",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3314802473/f7d5c89cb0722c196a4e7639165f5907_normal.jpeg",
      "id" : 16877220,
      "verified" : false
    }
  },
  "id" : 220953809147543554,
  "created_at" : "Thu Jul 05 18:54:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Rein",
      "screen_name" : "shaunrein",
      "indices" : [ 10, 20 ],
      "id_str" : "95655465",
      "id" : 95655465
    }, {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 47, 53 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220791706512142336",
  "text" : "Check out @shaunrein's book on the subject. RT @jluan: Crazy... relatives here from China; [amazed at] how *cheap* everything is in America",
  "id" : 220791706512142336,
  "created_at" : "Thu Jul 05 08:10:19 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/7QXSjRVN",
      "expanded_url" : "http://www.nytimes.com/2012/07/04/world/asia/china-says-no-more-shark-fin-soup-at-state-banquets.html?_r=2",
      "display_url" : "nytimes.com/2012/07/04/wor\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220700407561859072",
  "text" : "\"China Says No More Shark Fin Soup at State Banquets.\" Good! It's like crunchy tasteless jelly anyways. http://t.co/7QXSjRVN",
  "id" : 220700407561859072,
  "created_at" : "Thu Jul 05 02:07:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dragon ",
      "screen_name" : "dragoninnovate",
      "indices" : [ 25, 40 ],
      "id_str" : "421859846",
      "id" : 421859846
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "struggle",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220697909124005889",
  "text" : "I wish I had known about @dragoninnovate last year. Google Translate just doesn't cut it with Shenzhen prototypers. #struggle",
  "id" : 220697909124005889,
  "created_at" : "Thu Jul 05 01:57:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 3, 15 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220420191903952896",
  "text" : "RT @marcoarment: Whenever I'm testing custom fonts, I always end my font-family list with \"Comic Sans MS\" so it's REALLY obvious when th ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "220213710952738816",
    "text" : "Whenever I'm testing custom fonts, I always end my font-family list with \"Comic Sans MS\" so it's REALLY obvious when they're not loading.",
    "id" : 220213710952738816,
    "created_at" : "Tue Jul 03 17:53:34 +0000 2012",
    "user" : {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "protected" : false,
      "id_str" : "14231571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1282173124/untitled-158-2_normal.jpg",
      "id" : 14231571,
      "verified" : false
    }
  },
  "id" : 220420191903952896,
  "created_at" : "Wed Jul 04 07:34:03 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/lmVVPNC4",
      "expanded_url" : "http://i.imgur.com/Wx91Z.jpg",
      "display_url" : "i.imgur.com/Wx91Z.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220394175722569728",
  "text" : "RT @cipher3d: RIP Computer Science. http://t.co/lmVVPNC4",
  "id" : 220394175722569728,
  "created_at" : "Wed Jul 04 05:50:40 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Anderson",
      "screen_name" : "chr1sa",
      "indices" : [ 65, 72 ],
      "id_str" : "17595439",
      "id" : 17595439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220393638490947585",
  "text" : "Our Jetta diesel gets better mileage than a Prius; less lame. RT @chr1sa: ...I can't understand why [diesels] aren't bigger here.",
  "id" : 220393638490947585,
  "created_at" : "Wed Jul 04 05:48:32 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220287719102877696",
  "text" : "Thorsten Heins says \"nothing wrong with [RIM];\" pigs fly, Bills win Super bowl.",
  "id" : 220287719102877696,
  "created_at" : "Tue Jul 03 22:47:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robgo",
      "screen_name" : "robgo",
      "indices" : [ 0, 6 ],
      "id_str" : "14208617",
      "id" : 14208617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220261656599592962",
  "geo" : {
  },
  "id_str" : "220286004404301824",
  "in_reply_to_user_id" : 14208617,
  "text" : "@robgo the PayPal redesign was literally just the homepage.",
  "id" : 220286004404301824,
  "in_reply_to_status_id" : 220261656599592962,
  "created_at" : "Tue Jul 03 22:40:50 +0000 2012",
  "in_reply_to_screen_name" : "robgo",
  "in_reply_to_user_id_str" : "14208617",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/mM6c9JoB",
      "expanded_url" : "http://techcrunch.com/2012/07/02/chinese-servant-gets-ten-years-in-jail-stealing-overpriced-nokia-vertu-handset/",
      "display_url" : "techcrunch.com/2012/07/02/chi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220247756856504320",
  "text" : "In one article: the absurdity of Vertu, the hypocrisy of the Chinese Communist Party, and turnips. http://t.co/mM6c9JoB",
  "id" : 220247756856504320,
  "created_at" : "Tue Jul 03 20:08:51 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/CCpvEUFE",
      "expanded_url" : "http://www.minimallyminimal.com/journal/2012/7/3/the-next-microsoft.html",
      "display_url" : "minimallyminimal.com/journal/2012/7\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220246389391765505",
  "text" : "Andrew Kim mocks up an epic Microsoft rebranding. http://t.co/CCpvEUFE",
  "id" : 220246389391765505,
  "created_at" : "Tue Jul 03 20:03:25 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 0, 13 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220066654015602689",
  "geo" : {
  },
  "id_str" : "220222557331271680",
  "in_reply_to_user_id" : 14666934,
  "text" : "@kevinmitnick even better. If you're game we'd love to demo for you when you're around.",
  "id" : 220222557331271680,
  "in_reply_to_status_id" : 220066654015602689,
  "created_at" : "Tue Jul 03 18:28:43 +0000 2012",
  "in_reply_to_screen_name" : "kevinmitnick",
  "in_reply_to_user_id_str" : "14666934",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/220011940058107904/photo/1",
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/mAJ3FpdC",
      "media_url" : "http://pbs.twimg.com/media/Aw2jsZ4CEAAB0yr.jpg",
      "id_str" : "220011940066496512",
      "id" : 220011940066496512,
      "media_url_https" : "https://pbs.twimg.com/media/Aw2jsZ4CEAAB0yr.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/mAJ3FpdC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220011940058107904",
  "text" : "I try not to fuel the Asian stereotype and take pictures of food... But bacon wrapped mochi!! http://t.co/mAJ3FpdC",
  "id" : 220011940058107904,
  "created_at" : "Tue Jul 03 04:31:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/4AvKxJSA",
      "expanded_url" : "http://bit.ly/wRcY7k",
      "display_url" : "bit.ly/wRcY7k"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219996198071828482",
  "text" : "RT @wired: Twitter harder to resist than cigs and booze, study says. Hard thing is doing all 3 at once. Need moar hanz. http://t.co/4AvKxJSA",
  "retweeted_status" : {
    "source" : "<a href=\"http://sites.google.com/site/yorufukurou/\" rel=\"nofollow\">YoruFukurou</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/4AvKxJSA",
        "expanded_url" : "http://bit.ly/wRcY7k",
        "display_url" : "bit.ly/wRcY7k"
      } ]
    },
    "geo" : {
    },
    "id_str" : "219914542786945029",
    "text" : "Twitter harder to resist than cigs and booze, study says. Hard thing is doing all 3 at once. Need moar hanz. http://t.co/4AvKxJSA",
    "id" : 219914542786945029,
    "created_at" : "Mon Jul 02 22:04:47 +0000 2012",
    "user" : {
      "name" : "Wired",
      "screen_name" : "wired",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2958887633/eab60d838d5c4bb20fa52f0577a2c698_normal.jpeg",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 219996198071828482,
  "created_at" : "Tue Jul 03 03:29:15 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 0, 13 ],
      "id_str" : "14666934",
      "id" : 14666934
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 48, 57 ],
      "id_str" : "340545195",
      "id" : 340545195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219901230347075584",
  "geo" : {
  },
  "id_str" : "219948873538473985",
  "in_reply_to_user_id" : 14666934,
  "text" : "@kevinmitnick if you're in Vegas, want to visit @Romotive?",
  "id" : 219948873538473985,
  "in_reply_to_status_id" : 219901230347075584,
  "created_at" : "Tue Jul 03 00:21:12 +0000 2012",
  "in_reply_to_screen_name" : "kevinmitnick",
  "in_reply_to_user_id_str" : "14666934",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]