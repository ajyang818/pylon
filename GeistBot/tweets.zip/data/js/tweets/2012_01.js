Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/jJI2Wbj6",
      "expanded_url" : "http://archive.truthout.org/pac-man-hacked-onto-a-touch-screen-voting-machine-without-breaking-tamper-evident-seals62597",
      "display_url" : "archive.truthout.org/pac-man-hacked\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164464367293833216",
  "text" : "I get that making a secure voting machine is a challenge, but being able to just remove the case screws is a joke. http://t.co/jJI2Wbj6",
  "id" : 164464367293833216,
  "created_at" : "Tue Jan 31 21:45:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "indices" : [ 39, 53 ],
      "id_str" : "2172",
      "id" : 2172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/R3l9JUy2",
      "expanded_url" : "http://dlvr.it/18B50Y",
      "display_url" : "dlvr.it/18B50Y"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3712737066, -71.11675021 ]
  },
  "id_str" : "164183338742067200",
  "text" : "Quick, someone make this a service. RT @LaughingSquid: 5 y.o. Describes What She Sees Looking at Various Brand Logos http://t.co/R3l9JUy2",
  "id" : 164183338742067200,
  "created_at" : "Tue Jan 31 03:08:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/ojFuJEz0",
      "expanded_url" : "http://bit.ly/xT7Xow",
      "display_url" : "bit.ly/xT7Xow"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164183003994656768",
  "text" : "RT @ForbesTech: Do We Need a Ministry of Truth for the Internet? http://t.co/ojFuJEz0",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/ojFuJEz0",
        "expanded_url" : "http://bit.ly/xT7Xow",
        "display_url" : "bit.ly/xT7Xow"
      } ]
    },
    "geo" : {
    },
    "id_str" : "164153357571862528",
    "text" : "Do We Need a Ministry of Truth for the Internet? http://t.co/ojFuJEz0",
    "id" : 164153357571862528,
    "created_at" : "Tue Jan 31 01:09:44 +0000 2012",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 164183003994656768,
  "created_at" : "Tue Jan 31 03:07:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Zittrain",
      "screen_name" : "zittrain",
      "indices" : [ 37, 46 ],
      "id_str" : "1039531",
      "id" : 1039531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3712930679, -71.1166220319 ]
  },
  "id_str" : "164182663865970688",
  "text" : "Trying my absolute hardest to take a @zittrain class during add drop week.",
  "id" : 164182663865970688,
  "created_at" : "Tue Jan 31 03:06:12 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 13, 26 ],
      "id_str" : "14877810",
      "id" : 14877810
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 45, 53 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164111249020436482",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3685130245, -71.1151129939 ]
  },
  "id_str" : "164112949630345216",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce @sunilnagaraj photographing for @Harvard MCB dept at the moment. What are you up to after lab talk?",
  "id" : 164112949630345216,
  "in_reply_to_status_id" : 164111249020436482,
  "created_at" : "Mon Jan 30 22:29:10 +0000 2012",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164030344968929280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3733517714, -71.1169307773 ]
  },
  "id_str" : "164045448951250944",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj I'm working past 5 but will try to catch the end of your talk.",
  "id" : 164045448951250944,
  "in_reply_to_status_id" : 164030344968929280,
  "created_at" : "Mon Jan 30 18:00:57 +0000 2012",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163889605593149440",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj I heard you'll be visiting Cambridge tomorrow!",
  "id" : 163889605593149440,
  "created_at" : "Mon Jan 30 07:41:41 +0000 2012",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 8, 20 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 22, 29 ],
      "id_str" : "111999960",
      "id" : 111999960
    }, {
      "name" : "joanne chang-myers",
      "screen_name" : "jbchang",
      "indices" : [ 85, 93 ],
      "id_str" : "31391307",
      "id" : 31391307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3699414588, -71.1172897195 ]
  },
  "id_str" : "163447499430965250",
  "text" : "Done RT @badboyboyce: @khsieh Can that be a double-date night? You know I'm a fan of @jbchang :)",
  "id" : 163447499430965250,
  "created_at" : "Sun Jan 29 02:24:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    }, {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 52, 59 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163434417858150400",
  "text" : "RT @SpaceX: Pass it on. Our new Twitter username is @SpaceX",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ 40, 47 ],
        "id_str" : "34743251",
        "id" : 34743251
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "163433815656775681",
    "text" : "Pass it on. Our new Twitter username is @SpaceX",
    "id" : 163433815656775681,
    "created_at" : "Sun Jan 29 01:30:32 +0000 2012",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2341252179/4zbhy2jm5xiflnqvy8bw_normal.jpeg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 163434417858150400,
  "created_at" : "Sun Jan 29 01:32:56 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joanne chang-myers",
      "screen_name" : "jbchang",
      "indices" : [ 28, 36 ],
      "id_str" : "31391307",
      "id" : 31391307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.369988496, -71.1176721724 ]
  },
  "id_str" : "163433912847171585",
  "text" : "Decided to reserve spots at @jbchang's restaurant next Friday for date night.",
  "id" : 163433912847171585,
  "created_at" : "Sun Jan 29 01:30:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard GSD",
      "screen_name" : "HarvardGSD",
      "indices" : [ 20, 31 ],
      "id_str" : "19272669",
      "id" : 19272669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3770125527, -71.112348241 ]
  },
  "id_str" : "162953881939222528",
  "text" : "Shopping classes at @HarvardGSD. Why did I wait four years to do so?",
  "id" : 162953881939222528,
  "created_at" : "Fri Jan 27 17:43:27 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162953697033326592",
  "text" : "RT @WSJ: Twitter can censor by county, plans to use that tool to enter countries w different ideas about freedom of expression http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/5gQDXkU9",
        "expanded_url" : "http://on.wsj.com/xZ5BNZ",
        "display_url" : "on.wsj.com/xZ5BNZ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "162941238838960128",
    "text" : "Twitter can censor by county, plans to use that tool to enter countries w different ideas about freedom of expression http://t.co/5gQDXkU9",
    "id" : 162941238838960128,
    "created_at" : "Fri Jan 27 16:53:13 +0000 2012",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 162953697033326592,
  "created_at" : "Fri Jan 27 17:42:43 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "atrubek",
      "screen_name" : "atrubek",
      "indices" : [ 10, 18 ],
      "id_str" : "25105016",
      "id" : 25105016
    }, {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 30, 36 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3681313126, -71.1155871582 ]
  },
  "id_str" : "162646766636896256",
  "text" : "Just read @atrubek's op-ed in @wired about pedantic spelling rules. I propose a defense for strict rules: easier AI language processing!",
  "id" : 162646766636896256,
  "created_at" : "Thu Jan 26 21:23:05 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verizon",
      "screen_name" : "Verizon",
      "indices" : [ 38, 46 ],
      "id_str" : "59602642",
      "id" : 59602642
    }, {
      "name" : "Daniel P. Rubino",
      "screen_name" : "malatesta77",
      "indices" : [ 57, 69 ],
      "id_str" : "45387210",
      "id" : 45387210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162574519259774977",
  "text" : "Will I see a good WP7 phone launch on @verizon ever?? cc @malatesta77",
  "id" : 162574519259774977,
  "created_at" : "Thu Jan 26 16:36:00 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3683987791, -71.1153066997 ]
  },
  "id_str" : "162381659499544576",
  "text" : "Too many MIT Media Lab classes I want to take in my last semester...",
  "id" : 162381659499544576,
  "created_at" : "Thu Jan 26 03:49:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/jBEk0YiQ",
      "expanded_url" : "http://econ.st/z2IYDC",
      "display_url" : "econ.st/z2IYDC"
    } ]
  },
  "geo" : {
  },
  "id_str" : "162381448488292352",
  "text" : "RT @TheEconomist: Europe's largest ever aircraft order has come from Norwegian Air Shuttle. It is time to take notice http://t.co/jBEk0YiQ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http://t.co/jBEk0YiQ",
        "expanded_url" : "http://econ.st/z2IYDC",
        "display_url" : "econ.st/z2IYDC"
      } ]
    },
    "geo" : {
    },
    "id_str" : "162350472513060864",
    "text" : "Europe's largest ever aircraft order has come from Norwegian Air Shuttle. It is time to take notice http://t.co/jBEk0YiQ",
    "id" : 162350472513060864,
    "created_at" : "Thu Jan 26 01:45:43 +0000 2012",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 162381448488292352,
  "created_at" : "Thu Jan 26 03:48:48 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 43, 55 ],
      "id_str" : "7782442",
      "id" : 7782442
    }, {
      "name" : "@jdrive",
      "screen_name" : "jdrive",
      "indices" : [ 56, 63 ],
      "id_str" : "15137329",
      "id" : 15137329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162366547292200962",
  "text" : "Back in Cambridge. Great NY trip thanks to @christinelu @jdrive and Dragon Week.",
  "id" : 162366547292200962,
  "created_at" : "Thu Jan 26 02:49:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "indices" : [ 0, 6 ],
      "id_str" : "14782518",
      "id" : 14782518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161483024289103874",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.756983717, -73.9682121512 ]
  },
  "id_str" : "161618480989343744",
  "in_reply_to_user_id" : 14782518,
  "text" : "@cltom No matter how rich you are, you can always count on Fung Wah bus.",
  "id" : 161618480989343744,
  "in_reply_to_status_id" : 161483024289103874,
  "created_at" : "Tue Jan 24 01:17:03 +0000 2012",
  "in_reply_to_screen_name" : "cltom",
  "in_reply_to_user_id_str" : "14782518",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandarin Oriental NY",
      "screen_name" : "MO_NEWYORK",
      "indices" : [ 7, 18 ],
      "id_str" : "74833333",
      "id" : 74833333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.2385340211, -71.5997614932 ]
  },
  "id_str" : "161427719186415616",
  "text" : "Off to @MO_NEWYORK for Dragon Week New York. Thank you, Chinatown bus.",
  "id" : 161427719186415616,
  "created_at" : "Mon Jan 23 12:39:02 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/4xjCoc6H",
      "expanded_url" : "http://www.theverge.com/2012/1/20/2722022/olympus-om-d-micro-four-thirds-camera-picture-leak",
      "display_url" : "theverge.com/2012/1/20/2722\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "160567581139419137",
  "text" : "Olympus OM-D looking sweet. http://t.co/4xjCoc6H",
  "id" : 160567581139419137,
  "created_at" : "Sat Jan 21 03:41:09 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/STDHIeJ5",
      "expanded_url" : "http://ow.ly/8zxoT",
      "display_url" : "ow.ly/8zxoT"
    } ]
  },
  "geo" : {
  },
  "id_str" : "160567435936792576",
  "text" : "RT @HarvardCSA: China seeks to expand program to register all microbloggers with the government http://t.co/STDHIeJ5",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http://t.co/STDHIeJ5",
        "expanded_url" : "http://ow.ly/8zxoT",
        "display_url" : "ow.ly/8zxoT"
      } ]
    },
    "geo" : {
    },
    "id_str" : "160445271522807808",
    "text" : "China seeks to expand program to register all microbloggers with the government http://t.co/STDHIeJ5",
    "id" : 160445271522807808,
    "created_at" : "Fri Jan 20 19:35:08 +0000 2012",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 160567435936792576,
  "created_at" : "Sat Jan 21 03:40:34 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3688610411, -71.0217411072 ]
  },
  "id_str" : "160471678139371520",
  "text" : "Mass transit fail. In the time it takes Boston MBTA to leave airport property, the Hong Kong MTR can traverse two islands.",
  "id" : 160471678139371520,
  "created_at" : "Fri Jan 20 21:20:04 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.1997029509, -83.3484168377 ]
  },
  "id_str" : "160411434809962498",
  "text" : "Police boarding aircraft to arrest someone. Cutting this connection timing a little too close for comfort.",
  "id" : 160411434809962498,
  "created_at" : "Fri Jan 20 17:20:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.3132959777, 113.9282983435 ]
  },
  "id_str" : "159947666778882048",
  "text" : "Cute moment: Chinese toddler and Italian toddler sharing snacks in the aisle of the Airbus.",
  "id" : 159947666778882048,
  "created_at" : "Thu Jan 19 10:37:50 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 15, 27 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159660227929714688",
  "text" : "Excited to see @christinelu's Dragon Week events in NYC for Chinese New Years.",
  "id" : 159660227929714688,
  "created_at" : "Wed Jan 18 15:35:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 25.0625786261, 121.5264584325 ]
  },
  "id_str" : "159575191612178434",
  "text" : "Based on ethnographical research, I believe that Taiwans economy is entirely consumer electronics, bubble tea, restaurants, and cuteness.",
  "id" : 159575191612178434,
  "created_at" : "Wed Jan 18 09:57:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/2aQpsjjM",
      "expanded_url" : "http://instagr.am/p/h95-C/",
      "display_url" : "instagr.am/p/h95-C/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "159178258196336640",
  "text" : "Dutch waffles next to a Buddhist monk in a Japanese building ordered in Chinese. Only possible in Taiwan. http://t.co/2aQpsjjM",
  "id" : 159178258196336640,
  "created_at" : "Tue Jan 17 07:40:28 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 24.1409127476, 120.6633075151 ]
  },
  "id_str" : "159166793536118784",
  "text" : "I just sat on modern art in the Taiwan Museum of Fine Arts. I thought it was a bench. Getting a lot of glares now.",
  "id" : 159166793536118784,
  "created_at" : "Tue Jan 17 06:54:55 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/5sYuUYcA",
      "expanded_url" : "http://instagr.am/p/h9O8-/",
      "display_url" : "instagr.am/p/h9O8-/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "159160857710952448",
  "text" : "Biking in Kowloon http://t.co/5sYuUYcA",
  "id" : 159160857710952448,
  "created_at" : "Tue Jan 17 06:31:20 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 24.1409980905, 120.6635930573 ]
  },
  "id_str" : "159159113253785600",
  "text" : "Taichung is really idyllic. I wonder why my parents left.",
  "id" : 159159113253785600,
  "created_at" : "Tue Jan 17 06:24:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 52, 64 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "158778606741495808",
  "text" : "I've been interning in all the wrong industries. RT @christinelu need an intern to assist Ms. Universe China during Dragon Week NYC.",
  "id" : 158778606741495808,
  "created_at" : "Mon Jan 16 05:12:24 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "158777676830752768",
  "text" : "Conundrum: Taiwanese food very fried and/or very sugary; yet no fat people in sight.",
  "id" : 158777676830752768,
  "created_at" : "Mon Jan 16 05:08:42 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 25.0876757981, 121.5258841042 ]
  },
  "id_str" : "157660607842234369",
  "text" : "Bought Indian food from an Egyptian man using English in Taipei. Whoa.",
  "id" : 157660607842234369,
  "created_at" : "Fri Jan 13 03:09:52 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/BFyj9usD",
      "expanded_url" : "http://onesixtieth.net/post/15621794584/catholic-nuns-in-a-buddhist-temple",
      "display_url" : "onesixtieth.net/post/156217945\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "156774396323823617",
  "text" : "Picture: Catholic nuns at a Buddhist temple in Taipei. http://t.co/BFyj9usD",
  "id" : 156774396323823617,
  "created_at" : "Tue Jan 10 16:28:23 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/Arwl6ZdI",
      "expanded_url" : "http://www.43rumors.com/ft4-olympus-will-launch-an-om-alike-micro-four-thrids-camera/",
      "display_url" : "43rumors.com/ft4-olympus-wi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "156393941502140416",
  "text" : "Excited for Olympus's u4/3 OM camera http://t.co/Arwl6ZdI",
  "id" : 156393941502140416,
  "created_at" : "Mon Jan 09 15:16:35 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 22.3152108151, 113.9356140012 ]
  },
  "id_str" : "154541022104395776",
  "text" : "Time to explore Hong Kong.",
  "id" : 154541022104395776,
  "created_at" : "Wed Jan 04 12:33:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Ko",
      "screen_name" : "ryanko",
      "indices" : [ 60, 67 ],
      "id_str" : "15951349",
      "id" : 15951349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.209782075, -83.3575299277 ]
  },
  "id_str" : "154292003620925440",
  "text" : "Running while tweeting is the new driving while calling. RT @ryanko: even more impressive is the fact that you tweeted while doing it :P",
  "id" : 154292003620925440,
  "created_at" : "Tue Jan 03 20:04:14 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.2098169849, -83.3574020025 ]
  },
  "id_str" : "154290214939013120",
  "text" : "Crazy sprint across Detroit International for a 10 min international layover.",
  "id" : 154290214939013120,
  "created_at" : "Tue Jan 03 19:57:08 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaeger-LeCoultre",
      "screen_name" : "jaegerlecoultre",
      "indices" : [ 22, 38 ],
      "id_str" : "182819292",
      "id" : 182819292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9365647864, -78.7307280768 ]
  },
  "id_str" : "154252170852700160",
  "text" : "As much as I love the @jaegerlecoultre reverso, the Mad Men tribute oozes tacky.",
  "id" : 154252170852700160,
  "created_at" : "Tue Jan 03 17:25:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9332481293, -78.7256979084 ]
  },
  "id_str" : "154237303009714177",
  "text" : "Noshing on wings in Buffalo airport before heading off to Asia.",
  "id" : 154237303009714177,
  "created_at" : "Tue Jan 03 16:26:53 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/cBDbN6a2",
      "expanded_url" : "http://instagr.am/p/eFTtY/",
      "display_url" : "instagr.am/p/eFTtY/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "154119044126085120",
  "text" : "OCD packing of tshirts. http://t.co/cBDbN6a2",
  "id" : 154119044126085120,
  "created_at" : "Tue Jan 03 08:36:58 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.006838956, -78.699950399 ]
  },
  "id_str" : "154098842135048192",
  "text" : "Just noticed that one of the monitors in Ozymandias' lair in Watchmen was playing the Apple 1984 commercial.",
  "id" : 154098842135048192,
  "created_at" : "Tue Jan 03 07:16:41 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/154029372670607362/photo/1",
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/U9g6LAef",
      "media_url" : "http://pbs.twimg.com/media/AiM45ftCAAI7WjC.jpg",
      "id_str" : "154029372674801666",
      "id" : 154029372674801666,
      "media_url_https" : "https://pbs.twimg.com/media/AiM45ftCAAI7WjC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com/U9g6LAef"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.006843566, -78.6999507342 ]
  },
  "id_str" : "154029372670607362",
  "text" : "Getting ready to kick it old school in HK. http://t.co/U9g6LAef",
  "id" : 154029372670607362,
  "created_at" : "Tue Jan 03 02:40:39 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen O'Brien",
      "screen_name" : "colleenobrien",
      "indices" : [ 0, 14 ],
      "id_str" : "14078449",
      "id" : 14078449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153902940938186752",
  "geo" : {
  },
  "id_str" : "153947500615696384",
  "in_reply_to_user_id" : 14078449,
  "text" : "@colleenobrien are you in upstate NY?",
  "id" : 153947500615696384,
  "in_reply_to_status_id" : 153902940938186752,
  "created_at" : "Mon Jan 02 21:15:19 +0000 2012",
  "in_reply_to_screen_name" : "colleenobrien",
  "in_reply_to_user_id_str" : "14078449",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon",
      "screen_name" : "billyeveryteen",
      "indices" : [ 3, 18 ],
      "id_str" : "24561674",
      "id" : 24561674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153801096480034816",
  "text" : "RT @billyeveryteen: You're in \u4E2D\u56FD when girl has Gucci bag, a tacky fur coat & pink rabbit ears on her cellphone, which she talks on while ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "153718556448669697",
    "text" : "You're in \u4E2D\u56FD when girl has Gucci bag, a tacky fur coat & pink rabbit ears on her cellphone, which she talks on while the plane lands",
    "id" : 153718556448669697,
    "created_at" : "Mon Jan 02 06:05:34 +0000 2012",
    "user" : {
      "name" : "Brandon",
      "screen_name" : "billyeveryteen",
      "protected" : false,
      "id_str" : "24561674",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1834907720/b-on-phone_normal.jpg",
      "id" : 24561674,
      "verified" : false
    }
  },
  "id" : 153801096480034816,
  "created_at" : "Mon Jan 02 11:33:33 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153769939344424960",
  "text" : "Sometimes I wish I had a DS to play pokemon on.",
  "id" : 153769939344424960,
  "created_at" : "Mon Jan 02 09:29:45 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    }, {
      "name" : "chinaSMACK",
      "screen_name" : "chinaSMACK",
      "indices" : [ 110, 121 ],
      "id_str" : "15438349",
      "id" : 15438349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/oII2wuxH",
      "expanded_url" : "http://www.chinasmack.com/2012/announcements/2011-chinasmack-year-in-review.html",
      "display_url" : "chinasmack.com/2012/announcem\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "153549998255120386",
  "text" : "RT @HarvardCSA: The (scandalous) year in review. Funny, depressing, and bewildering: http://t.co/oII2wuxH via @chinaSMACK",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "chinaSMACK",
        "screen_name" : "chinaSMACK",
        "indices" : [ 94, 105 ],
        "id_str" : "15438349",
        "id" : 15438349
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http://t.co/oII2wuxH",
        "expanded_url" : "http://www.chinasmack.com/2012/announcements/2011-chinasmack-year-in-review.html",
        "display_url" : "chinasmack.com/2012/announcem\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "153549193812783104",
    "text" : "The (scandalous) year in review. Funny, depressing, and bewildering: http://t.co/oII2wuxH via @chinaSMACK",
    "id" : 153549193812783104,
    "created_at" : "Sun Jan 01 18:52:35 +0000 2012",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 153549998255120386,
  "created_at" : "Sun Jan 01 18:55:47 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "indices" : [ 3, 11 ],
      "id_str" : "184543773",
      "id" : 184543773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leapyear",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "transitofvenus",
      "indices" : [ 78, 93 ]
    }, {
      "text" : "alanturingyear",
      "indices" : [ 94, 109 ]
    }, {
      "text" : "newyear",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "toomanyhashtags",
      "indices" : [ 119, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153420347994152960",
  "text" : "RT @stat110: Also, Happy Leap Year and Happy Transit of Venus Year! #leapyear #transitofvenus #alanturingyear #newyear #toomanyhashtags",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "leapyear",
        "indices" : [ 55, 64 ]
      }, {
        "text" : "transitofvenus",
        "indices" : [ 65, 80 ]
      }, {
        "text" : "alanturingyear",
        "indices" : [ 81, 96 ]
      }, {
        "text" : "newyear",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "toomanyhashtags",
        "indices" : [ 106, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "153407967268573185",
    "text" : "Also, Happy Leap Year and Happy Transit of Venus Year! #leapyear #transitofvenus #alanturingyear #newyear #toomanyhashtags",
    "id" : 153407967268573185,
    "created_at" : "Sun Jan 01 09:31:24 +0000 2012",
    "user" : {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "protected" : false,
      "id_str" : "184543773",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1360113908/Stat110Picture_normal.jpg",
      "id" : 184543773,
      "verified" : false
    }
  },
  "id" : 153420347994152960,
  "created_at" : "Sun Jan 01 10:20:36 +0000 2012",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]