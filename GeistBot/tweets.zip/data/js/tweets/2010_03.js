Grailbird.data.tweets_2010_03 = 
 [ {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11372255580",
  "text" : "I had brunch with Beyonce and Gaga in my dreams... And twittered about it in my dreams too!",
  "id" : 11372255580,
  "created_at" : "Wed Mar 31 15:34:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11294765791",
  "text" : "Ordered an SSD for computer.  Let's see if I can actually like a Mac!",
  "id" : 11294765791,
  "created_at" : "Tue Mar 30 06:17:50 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11273858928",
  "text" : "The Bike Snob reveals his identity! http://bit.ly/9vi2tu",
  "id" : 11273858928,
  "created_at" : "Mon Mar 29 22:33:02 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11241374033",
  "geo" : {
  },
  "id_str" : "11241915959",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow feel better!! We'll get Blue Asia soon :D",
  "id" : 11241915959,
  "in_reply_to_status_id" : 11241374033,
  "created_at" : "Mon Mar 29 10:01:06 +0000 2010",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11224495600",
  "text" : "Semi-disappointed that my mac survived.  This is such a love-hate relationship.",
  "id" : 11224495600,
  "created_at" : "Mon Mar 29 01:45:13 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRCSA",
      "screen_name" : "HRCSA",
      "indices" : [ 15, 21 ],
      "id_str" : "376067018",
      "id" : 376067018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11181981513",
  "geo" : {
  },
  "id_str" : "11213198535",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow @hrcsa what's a hata?",
  "id" : 11213198535,
  "in_reply_to_status_id" : 11181981513,
  "created_at" : "Sun Mar 28 21:18:58 +0000 2010",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11160476669",
  "geo" : {
  },
  "id_str" : "11167032654",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern you JUST had berryline?",
  "id" : 11167032654,
  "in_reply_to_status_id" : 11160476669,
  "created_at" : "Sat Mar 27 23:32:54 +0000 2010",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11134984612",
  "text" : "Victim of major party foul tonight.  RIP Mac.  As much as I hated on you, I still counted on you.",
  "id" : 11134984612,
  "created_at" : "Sat Mar 27 08:07:48 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11105235056",
  "text" : "DAMMIT MAC don't die on me now.",
  "id" : 11105235056,
  "created_at" : "Fri Mar 26 19:12:35 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11102816900",
  "text" : "Who the hell is Wale and why is he coming to Yardfest?",
  "id" : 11102816900,
  "created_at" : "Fri Mar 26 18:14:29 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11024445091",
  "text" : "So my final project for CS is basically a giant innuendo...",
  "id" : 11024445091,
  "created_at" : "Thu Mar 25 08:15:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11012563560",
  "text" : "Darn it people, use the full body scanners at airports and speed things up.  Flying is not a *right*.  If you don't like scanner, don't fly.",
  "id" : 11012563560,
  "created_at" : "Thu Mar 25 02:21:27 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRCSA",
      "screen_name" : "HRCSA",
      "indices" : [ 3, 9 ],
      "id_str" : "376067018",
      "id" : 376067018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11005318110",
  "text" : "RT @HRCSA: Join us for Ramen Bar (yum!) tomorrow, 3/25 @ 7 PM in Holworthy Kitchen! http://bit.ly/9xQrtF",
  "id" : 11005318110,
  "created_at" : "Wed Mar 24 23:47:38 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10970090483",
  "text" : "Any recommendations for a bike wheelbuilder around Cambridge/Boston?",
  "id" : 10970090483,
  "created_at" : "Wed Mar 24 08:34:24 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10950889847",
  "text" : "Got the bike back from repairs!  pumped for springtime biking (as soon as the rain stops)",
  "id" : 10950889847,
  "created_at" : "Tue Mar 23 23:54:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10914827197",
  "text" : "tweeting in haikus / eating takeout from the Kong. / rain patters outside.",
  "id" : 10914827197,
  "created_at" : "Tue Mar 23 07:30:03 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10878820430",
  "text" : "On Snow Leopard, I have the option of Firefox 3.6 which takes almost 1 GB of RAM, or Chrome, which (ironically) processes gmail very slowly.",
  "id" : 10878820430,
  "created_at" : "Mon Mar 22 16:11:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10858511511",
  "text" : "Am I the only person in Cambridge not impressed by the health care bill?  Probably.",
  "id" : 10858511511,
  "created_at" : "Mon Mar 22 05:29:30 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10738566063",
  "text" : "In love with Boston right now.  School needs to stay away for at least another week...",
  "id" : 10738566063,
  "created_at" : "Fri Mar 19 19:56:36 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10679990421",
  "text" : "Really Glock?  SIG beat you in making an official carbine?  Facepalm",
  "id" : 10679990421,
  "created_at" : "Thu Mar 18 17:00:06 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10655231423",
  "text" : "http://onesixtieth.net - obviously not working during break",
  "id" : 10655231423,
  "created_at" : "Thu Mar 18 04:19:01 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10633115577",
  "text" : "lol",
  "id" : 10633115577,
  "created_at" : "Wed Mar 17 18:32:51 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10633075379",
  "text" : "Beautiful bike ride into downtown with blockmate, followed by haircut.  Now to babysit tutor's toddler!!",
  "id" : 10633075379,
  "created_at" : "Wed Mar 17 18:31:42 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10599908541",
  "text" : "\"Hey Microsoft, don't f*ck up Windows Phone 7\" http://bit.ly/9bFp1h",
  "id" : 10599908541,
  "created_at" : "Wed Mar 17 02:07:56 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10595766699",
  "text" : "Taiwanese food in Allston at Blue Asia Cafe! So excited.",
  "id" : 10595766699,
  "created_at" : "Wed Mar 17 00:31:34 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 31, 37 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10560716688",
  "text" : "Fantastic bibimbap dinner with @cklee!",
  "id" : 10560716688,
  "created_at" : "Tue Mar 16 08:13:22 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10505239651",
  "text" : "My PC not connecting to internet is a sign that I should sleep more and stop playing Steam games/",
  "id" : 10505239651,
  "created_at" : "Mon Mar 15 06:03:28 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10503325506",
  "text" : "My Mac is failing.  Between the shitshow that is Snow Leopard and poor quality control, this is one of the most frustrating comps.",
  "id" : 10503325506,
  "created_at" : "Mon Mar 15 04:58:41 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10442187603",
  "text" : "Boston weather hates us!",
  "id" : 10442187603,
  "created_at" : "Sat Mar 13 22:56:48 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10385818741",
  "text" : "reinstalling Snow Leopard.  again.",
  "id" : 10385818741,
  "created_at" : "Fri Mar 12 19:15:21 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10380813683",
  "text" : "Done (with exams). One more pset between me and freedom.",
  "id" : 10380813683,
  "created_at" : "Fri Mar 12 17:09:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10262310325",
  "text" : "4 psets, 3 days, 2 midterms, 1 KANE.  Hoo-rah.",
  "id" : 10262310325,
  "created_at" : "Wed Mar 10 08:12:39 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10233194654",
  "text" : "\"The reason I run these review sessions is to see what you guys are afraid of so I can add them to the exam.\" - CS prof",
  "id" : 10233194654,
  "created_at" : "Tue Mar 09 18:58:25 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10233001463",
  "text" : "Guy next to me is in class reading \"how to make your  cat look like a shark.\"",
  "id" : 10233001463,
  "created_at" : "Tue Mar 09 18:53:09 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10231472622",
  "text" : "\"There *might* be impossible questions on your midterm.  Just a heads up.\" -CS prof",
  "id" : 10231472622,
  "created_at" : "Tue Mar 09 18:11:10 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10161292548",
  "text" : "Wow, Counterstrike.  Midterm period.  Not good.",
  "id" : 10161292548,
  "created_at" : "Mon Mar 08 07:44:02 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10116409002",
  "text" : "Sleeping at sunrise",
  "id" : 10116409002,
  "created_at" : "Sun Mar 07 11:16:00 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10048888321",
  "text" : "Want Harvard Personals?  Let us know here: http://bit.ly/dCHBSz",
  "id" : 10048888321,
  "created_at" : "Sat Mar 06 00:03:23 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springtime",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10038841784",
  "text" : "I hear robins and sparrows!  Yay #springtime",
  "id" : 10038841784,
  "created_at" : "Fri Mar 05 19:41:33 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Child",
      "screen_name" : "mlchild",
      "indices" : [ 4, 12 ],
      "id_str" : "21630525",
      "id" : 21630525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10027434014",
  "text" : "RT: @mlchild 4 mins of Top Gear brilliance.  I love this show. http://www.youtube.com/watch?v=a6l7X5zFu0s",
  "id" : 10027434014,
  "created_at" : "Fri Mar 05 14:59:47 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "10019319957",
  "text" : "I'm legitimately nocturnal now.",
  "id" : 10019319957,
  "created_at" : "Fri Mar 05 11:04:20 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9984296510",
  "text" : "\"Welcome to the real world\" - professor on the problems, ambiguity, typos, and lack of support on the project.  Sigh.",
  "id" : 9984296510,
  "created_at" : "Thu Mar 04 18:13:50 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9938658581",
  "text" : "\"Cores have killed my passion for anything in life.\" -CKL",
  "id" : 9938658581,
  "created_at" : "Wed Mar 03 20:09:54 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9892228016",
  "text" : "bubble tea for dinner!",
  "id" : 9892228016,
  "created_at" : "Tue Mar 02 21:31:53 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.orangatame.com/products/openbeak/\" rel=\"nofollow\">OpenBeak</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9848599423",
  "text" : "Green tea ice cream in dhalls make me happy",
  "id" : 9848599423,
  "created_at" : "Tue Mar 02 00:02:30 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9838341582",
  "text" : "The shuttles need to stop playing tik tok",
  "id" : 9838341582,
  "created_at" : "Mon Mar 01 19:35:49 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9833254770",
  "text" : "On a scale of 1 to fucked, I'm at a solid 12.",
  "id" : 9833254770,
  "created_at" : "Mon Mar 01 17:14:43 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "9817071021",
  "text" : "blurbleblurbleblurbe",
  "id" : 9817071021,
  "created_at" : "Mon Mar 01 08:40:44 +0000 2010",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]