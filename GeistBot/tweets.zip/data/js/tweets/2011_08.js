Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 0, 6 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109040014251393024",
  "in_reply_to_user_id" : 1344951,
  "text" : "@wired opinion piece lauding the value of charging for software rather than ruining experience with ads; ex-microsoft part of me smiled.",
  "id" : 109040014251393024,
  "created_at" : "Wed Aug 31 23:08:59 +0000 2011",
  "in_reply_to_screen_name" : "wired",
  "in_reply_to_user_id_str" : "1344951",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108971083453054976",
  "text" : "\u201CWhen we designed the boat we had visions of capsizings where the whole wing detonates.\" - excited for Americas Cup 2.0! http://j.mp/nwyvLc",
  "id" : 108971083453054976,
  "created_at" : "Wed Aug 31 18:35:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108930633174233088",
  "text" : "DOJ seeking to block AT&T and T-Mobile merger. I guess they might not get to use that shiny new logo.",
  "id" : 108930633174233088,
  "created_at" : "Wed Aug 31 15:54:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SeniorDesk",
      "indices" : [ 26, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108761819350437888",
  "text" : "My pet project this year: #SeniorDesk http://j.mp/olKBsy",
  "id" : 108761819350437888,
  "created_at" : "Wed Aug 31 04:43:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108722905688457217",
  "text" : "My google calendar looks like someone threw up skittles all over it.",
  "id" : 108722905688457217,
  "created_at" : "Wed Aug 31 02:08:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108414478546243584",
  "text" : "How many Google engineers, Microsoft engineers, and Investment Bankers does it take to catch a mouse in our dorm?",
  "id" : 108414478546243584,
  "created_at" : "Tue Aug 30 05:43:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 0, 9 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collegelife",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108414290574323712",
  "in_reply_to_user_id" : 18008249,
  "text" : "@thepunit freaking out about bugs in our room. #collegelife",
  "id" : 108414290574323712,
  "created_at" : "Tue Aug 30 05:42:35 +0000 2011",
  "in_reply_to_screen_name" : "thepunit",
  "in_reply_to_user_id_str" : "18008249",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108227767740538882",
  "text" : "Facebook's new inline privacy settings reminiscent of Google+.",
  "id" : 108227767740538882,
  "created_at" : "Mon Aug 29 17:21:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "indices" : [ 72, 81 ],
      "id_str" : "237573925",
      "id" : 237573925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "appropriate",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107537686386065408",
  "text" : "Also, I am blasting Marc Anthony's Rain Over Me right now. #appropriate @touhsieh",
  "id" : 107537686386065408,
  "created_at" : "Sat Aug 27 19:39:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107536101635395585",
  "text" : "\"Irene, f-ing Irene!\" -  Chief Warrant Officer Michael Durant, in Black Hawk Down",
  "id" : 107536101635395585,
  "created_at" : "Sat Aug 27 19:32:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http://t.co/VmrS3I3",
      "expanded_url" : "http://www.google.com/patents/?vid=Szh4AAAAEBAJ",
      "display_url" : "google.com/patents/?vid=S\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "107480617532403713",
  "text" : "RT @hackernewsbot: Linked Lists are patented, every piece of code is in violation... http://t.co/VmrS3I3",
  "retweeted_status" : {
    "source" : "<a href=\"http://news.ycombinator.com/\" rel=\"nofollow\">Hacker News Bot</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 85 ],
        "url" : "http://t.co/VmrS3I3",
        "expanded_url" : "http://www.google.com/patents/?vid=Szh4AAAAEBAJ",
        "display_url" : "google.com/patents/?vid=S\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "107372328807178240",
    "text" : "Linked Lists are patented, every piece of code is in violation... http://t.co/VmrS3I3",
    "id" : 107372328807178240,
    "created_at" : "Sat Aug 27 08:42:12 +0000 2011",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/73596050/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 107480617532403713,
  "created_at" : "Sat Aug 27 15:52:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107281294538444800",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee is your car okay? Are you okay?!",
  "id" : 107281294538444800,
  "created_at" : "Sat Aug 27 02:40:28 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107280968792023041",
  "text" : "My last Harvard move-in, completed. Bittersweet.",
  "id" : 107280968792023041,
  "created_at" : "Sat Aug 27 02:39:10 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 70, 85 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107247089536344064",
  "text" : "We waved at the Google streetview car as it passed Dunster and Mather @NaveenSrivatsa",
  "id" : 107247089536344064,
  "created_at" : "Sat Aug 27 00:24:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106891354755444736",
  "text" : "Oh MBTA, I missed your endearing inefficiency.",
  "id" : 106891354755444736,
  "created_at" : "Fri Aug 26 00:50:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Shen",
      "screen_name" : "dianashen",
      "indices" : [ 0, 10 ],
      "id_str" : "23283205",
      "id" : 23283205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106758485739450368",
  "geo" : {
  },
  "id_str" : "106761457047314432",
  "in_reply_to_user_id" : 23283205,
  "text" : "@dianashen if only my dislike of energy drinks was analogous to my general eating habits...",
  "id" : 106761457047314432,
  "in_reply_to_status_id" : 106758485739450368,
  "created_at" : "Thu Aug 25 16:14:49 +0000 2011",
  "in_reply_to_screen_name" : "dianashen",
  "in_reply_to_user_id_str" : "23283205",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Shen",
      "screen_name" : "dianashen",
      "indices" : [ 0, 10 ],
      "id_str" : "23283205",
      "id" : 23283205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106751456761225216",
  "geo" : {
  },
  "id_str" : "106752791967576064",
  "in_reply_to_user_id" : 23283205,
  "text" : "@dianashen water and apples for all nighters!",
  "id" : 106752791967576064,
  "in_reply_to_status_id" : 106751456761225216,
  "created_at" : "Thu Aug 25 15:40:23 +0000 2011",
  "in_reply_to_screen_name" : "dianashen",
  "in_reply_to_user_id_str" : "23283205",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Shen",
      "screen_name" : "dianashen",
      "indices" : [ 0, 10 ],
      "id_str" : "23283205",
      "id" : 23283205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106715672683356161",
  "geo" : {
  },
  "id_str" : "106750393354174465",
  "in_reply_to_user_id" : 23283205,
  "text" : "@dianashen Redbull was gross! Im too naturally hyper to get any benefit from it except as a diuretic.",
  "id" : 106750393354174465,
  "in_reply_to_status_id" : 106715672683356161,
  "created_at" : "Thu Aug 25 15:30:51 +0000 2011",
  "in_reply_to_screen_name" : "dianashen",
  "in_reply_to_user_id_str" : "23283205",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Redbull",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106688118442311681",
  "text" : "I feel like I just embalmed myself. #Redbull",
  "id" : 106688118442311681,
  "created_at" : "Thu Aug 25 11:23:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106684724277297152",
  "text" : "Just tried Redbull for the first time. This stuff is pretty nasty.",
  "id" : 106684724277297152,
  "created_at" : "Thu Aug 25 11:09:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 36, 49 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/RdEWjFu",
      "expanded_url" : "http://econ.st/nAuYSp",
      "display_url" : "econ.st/nAuYSp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "106600212109332481",
  "text" : "I stayed in a dodgy hostel here! RT @TheEconomist: Chungking Mansions [HK] comes as a shock of otherworldly proportions http://t.co/RdEWjFu",
  "id" : 106600212109332481,
  "created_at" : "Thu Aug 25 05:34:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 3, 17 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106594322618662912",
  "text" : "RT @marcprecipice: Holy crap. This WSJ compilation of Steve Jobs' Best Quotes has got to be the best such thing ever compiled: http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 127 ],
        "url" : "http://t.co/bCbVNDS",
        "expanded_url" : "http://blogs.wsj.com/digits/2011/08/24/steve-jobss-best-quotes/",
        "display_url" : "blogs.wsj.com/digits/2011/08\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "106550320737435648",
    "text" : "Holy crap. This WSJ compilation of Steve Jobs' Best Quotes has got to be the best such thing ever compiled: http://t.co/bCbVNDS",
    "id" : 106550320737435648,
    "created_at" : "Thu Aug 25 02:15:50 +0000 2011",
    "user" : {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "protected" : false,
      "id_str" : "226976689",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2321403275/b546axjksj5f7z194wjm_normal.jpeg",
      "id" : 226976689,
      "verified" : false
    }
  },
  "id" : 106594322618662912,
  "created_at" : "Thu Aug 25 05:10:41 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Steven",
      "screen_name" : "mash_daddy",
      "indices" : [ 13, 24 ],
      "id_str" : "193150867",
      "id" : 193150867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106541493547843585",
  "geo" : {
  },
  "id_str" : "106594082968698880",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha @mash_daddy tropical storm Irene is set to touch down soon. Will Harv '15 be the new Harv '12?",
  "id" : 106594082968698880,
  "in_reply_to_status_id" : 106541493547843585,
  "created_at" : "Thu Aug 25 05:09:44 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apple",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106539307321393153",
  "text" : "Now would be a good time for anyone in the consumer tech space to apologize for a sex scandal. #apple",
  "id" : 106539307321393153,
  "created_at" : "Thu Aug 25 01:32:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106223656534945792",
  "text" : "Verizon Internet down in East Amherst, NY. It's like the early 90s up in here.",
  "id" : 106223656534945792,
  "created_at" : "Wed Aug 24 04:37:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 0, 10 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106222463800705024",
  "in_reply_to_user_id" : 182074162,
  "text" : "@momogoose what about edible plates and boxes made up of those white dry noodle-y things? What PF Changs puts under every dish",
  "id" : 106222463800705024,
  "created_at" : "Wed Aug 24 04:33:03 +0000 2011",
  "in_reply_to_screen_name" : "momogoose",
  "in_reply_to_user_id_str" : "182074162",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 28, 34 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http://t.co/cPbeiEu",
      "expanded_url" : "http://harvardi3.org/",
      "display_url" : "harvardi3.org"
    } ]
  },
  "geo" : {
  },
  "id_str" : "106221538478526464",
  "text" : "Nice to see SEAS leading RT @hseas: Coming this fall at Harvard: Innovation Mondays! Workshops for student entrepreneurs http://t.co/cPbeiEu",
  "id" : 106221538478526464,
  "created_at" : "Wed Aug 24 04:29:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 43, 57 ],
      "id_str" : "16005250",
      "id" : 16005250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106153041392185344",
  "text" : "Almost as cute as a west coast snow day RT @angryasianman: Whats this about an east coast earthquake? 5.8? That's cute.",
  "id" : 106153041392185344,
  "created_at" : "Tue Aug 23 23:57:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105912336711303168",
  "text" : "Late night IT support. Coffee and LCDs galore.",
  "id" : 105912336711303168,
  "created_at" : "Tue Aug 23 08:00:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Aayush Arya",
      "screen_name" : "aryayush",
      "indices" : [ 96, 105 ],
      "id_str" : "11944142",
      "id" : 11944142
    }, {
      "name" : "TNW Mobile",
      "screen_name" : "TNWmobile",
      "indices" : [ 109, 119 ],
      "id_str" : "108621686",
      "id" : 108621686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http://t.co/MPT808x",
      "expanded_url" : "http://tnw.to/1AU4W",
      "display_url" : "tnw.to/1AU4W"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105912027507200000",
  "text" : "RT @TheNextWeb: Android overtakes Symbian as the most-attacked mobile OS http://t.co/MPT808x by @aryayush on @TNWmobile",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aayush Arya",
        "screen_name" : "aryayush",
        "indices" : [ 80, 89 ],
        "id_str" : "11944142",
        "id" : 11944142
      }, {
        "name" : "TNW Mobile",
        "screen_name" : "TNWmobile",
        "indices" : [ 93, 103 ],
        "id_str" : "108621686",
        "id" : 108621686
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 76 ],
        "url" : "http://t.co/MPT808x",
        "expanded_url" : "http://tnw.to/1AU4W",
        "display_url" : "tnw.to/1AU4W"
      } ]
    },
    "geo" : {
    },
    "id_str" : "105895883006160896",
    "text" : "Android overtakes Symbian as the most-attacked mobile OS http://t.co/MPT808x by @aryayush on @TNWmobile",
    "id" : 105895883006160896,
    "created_at" : "Tue Aug 23 06:55:20 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 105912027507200000,
  "created_at" : "Tue Aug 23 07:59:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105893289185648640",
  "text" : "Dealing with malware that makes all files hidden, because I'm the \"computer friend.\" What a pain.",
  "id" : 105893289185648640,
  "created_at" : "Tue Aug 23 06:45:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105869459398463488",
  "text" : "One of the best parts of visiting home is co-opting my mom's triple UltraSharp setup. #nerdtweet",
  "id" : 105869459398463488,
  "created_at" : "Tue Aug 23 05:10:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105828108690669568",
  "text" : "After trying my sister's 3rd gen MacBook Air, I prefer the ergonomics of my ugly X220 much more.",
  "id" : 105828108690669568,
  "created_at" : "Tue Aug 23 02:26:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard i-lab",
      "screen_name" : "innovationlab",
      "indices" : [ 0, 14 ],
      "id_str" : "246493616",
      "id" : 246493616
    }, {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 53, 65 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105772962375938048",
  "geo" : {
  },
  "id_str" : "105799030688325632",
  "in_reply_to_user_id" : 246493616,
  "text" : "@innovationlab will you be open for tours next week? @badboyboyce",
  "id" : 105799030688325632,
  "in_reply_to_status_id" : 105772962375938048,
  "created_at" : "Tue Aug 23 00:30:29 +0000 2011",
  "in_reply_to_screen_name" : "innovationlab",
  "in_reply_to_user_id_str" : "246493616",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 47, 55 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105767182989922304",
  "text" : "Couldnt you say that about any development? RT @digitil: Internet will never be the same",
  "id" : 105767182989922304,
  "created_at" : "Mon Aug 22 22:23:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 29, 38 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105737890142756865",
  "text" : "Experimenting with RFID with @thepunit",
  "id" : 105737890142756865,
  "created_at" : "Mon Aug 22 20:27:32 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR News",
      "screen_name" : "nprnews",
      "indices" : [ 40, 48 ],
      "id_str" : "5392522",
      "id" : 5392522
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 88, 101 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http://t.co/sViiYR4",
      "expanded_url" : "http://j.mp/oRoasK",
      "display_url" : "j.mp/oRoasK"
    }, {
      "indices" : [ 113, 132 ],
      "url" : "http://t.co/ff34w4h",
      "expanded_url" : "http://j.mp/oAjJ6b",
      "display_url" : "j.mp/oAjJ6b"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105518751641911297",
  "text" : "The mobile patent wars infographic, via @nprnews http://t.co/sViiYR4 - an update to the @TheEconomist 2010 chart http://t.co/ff34w4h",
  "id" : 105518751641911297,
  "created_at" : "Mon Aug 22 05:56:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105517060683087872",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj I guess adding a disclaimer about the training wouldn't decrease the security of it...",
  "id" : 105517060683087872,
  "created_at" : "Mon Aug 22 05:50:02 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105515403777806336",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj if there's a decent learner plugged in the back end it's good training data. Also, frustration as the ultimate turing test?",
  "id" : 105515403777806336,
  "created_at" : "Mon Aug 22 05:43:27 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105470227453714434",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj the more cryptic word in ReCaptcha is crowd-sourced OCR and not part of the verification ;)",
  "id" : 105470227453714434,
  "created_at" : "Mon Aug 22 02:43:56 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http://t.co/HR6RirO",
      "expanded_url" : "http://www.tomshardware.com/reviews/ssd-hard-drive,1968.html",
      "display_url" : "tomshardware.com/reviews/ssd-ha\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105469633338933248",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj SSD advantages: size, shock, and read speed more than power.  Power advantage only under load http://t.co/HR6RirO",
  "id" : 105469633338933248,
  "created_at" : "Mon Aug 22 02:41:34 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105461669853011969",
  "text" : "Rebels took Tripoli! #Libya is theirs! Why is Kim Kardashian trending?!",
  "id" : 105461669853011969,
  "created_at" : "Mon Aug 22 02:09:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 95, 111 ],
      "id_str" : "228489296",
      "id" : 228489296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105312991553138690",
  "text" : "Know any Asian American acting talent around Cambridge? For American Repertory Theater casting @GlobalAsianista",
  "id" : 105312991553138690,
  "created_at" : "Sun Aug 21 16:19:08 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 34, 43 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105148860170633216",
  "text" : "Perusing Fall 2011 classes at the @medialab. I want to take them all!!",
  "id" : 105148860170633216,
  "created_at" : "Sun Aug 21 05:26:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 95, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105095401664806912",
  "text" : "4 luggage conveyors, 3 inbound flights. So of course, all three flights are on one conveyor... #firstworldproblems",
  "id" : 105095401664806912,
  "created_at" : "Sun Aug 21 01:54:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105070641530671104",
  "text" : "Turbofan engines never cease to amaze me.",
  "id" : 105070641530671104,
  "created_at" : "Sun Aug 21 00:16:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 29, 42 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105068974139641856",
  "text" : "Joes shanghai, chinatown. RT @kevinmitnick: What's good in New York for grub?",
  "id" : 105068974139641856,
  "created_at" : "Sun Aug 21 00:09:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TSA",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105054130816561152",
  "text" : "Security flaw at airport: #TSA does not backscatter wheelchairs. No idea what is hidden in tires or hollow frame.",
  "id" : 105054130816561152,
  "created_at" : "Sat Aug 20 23:10:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105020055166783489",
  "text" : "I &lt;3 Cambridge",
  "id" : 105020055166783489,
  "created_at" : "Sat Aug 20 20:55:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105010637368856577",
  "text" : "Just over-the-air updated iOS 5 without having to backup. Mind. Blown.",
  "id" : 105010637368856577,
  "created_at" : "Sat Aug 20 20:17:41 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 101, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104994662506442752",
  "text" : "My iPhone always, always changes \"in\" to \"on\" which makes me grammatically incompetent on the phone. #firstworldproblems",
  "id" : 104994662506442752,
  "created_at" : "Sat Aug 20 19:14:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104892481346355202",
  "geo" : {
  },
  "id_str" : "104937295458729985",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce on way to Buffalo, NY unfortunately. Wish I could detour to the city instead.",
  "id" : 104937295458729985,
  "in_reply_to_status_id" : 104892481346355202,
  "created_at" : "Sat Aug 20 15:26:15 +0000 2011",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104856540367945728",
  "text" : "Who's at Harvard already? Long layover at  Boston-Logan today.",
  "id" : 104856540367945728,
  "created_at" : "Sat Aug 20 10:05:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104782973433413632",
  "text" : "People yelling at airline reps need to seriously chill. They don't control the weather...",
  "id" : 104782973433413632,
  "created_at" : "Sat Aug 20 05:13:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104782533060861952",
  "text" : "4 hour delay from Seattle due to NYC storms. Womp womp.",
  "id" : 104782533060861952,
  "created_at" : "Sat Aug 20 05:11:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "petpeeves",
      "indices" : [ 66, 76 ]
    }, {
      "text" : "firstworldproblems",
      "indices" : [ 77, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104780074200465408",
  "text" : "People that wait in bag check line just to get boarding passes... #petpeeves #firstworldproblems",
  "id" : 104780074200465408,
  "created_at" : "Sat Aug 20 05:01:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http://t.co/42WI6cN",
      "expanded_url" : "http://4sq.com/pZLull",
      "display_url" : "4sq.com/pZLull"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "104777640736600064",
  "text" : "Farewell, Seattle. (@ Seattle-Tacoma International Airport (SEA) w/ 68 others) http://t.co/42WI6cN",
  "id" : 104777640736600064,
  "created_at" : "Sat Aug 20 04:51:50 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104689453792108545",
  "text" : "Apparently, I use too many exclamation points. That's news to me!!",
  "id" : 104689453792108545,
  "created_at" : "Fri Aug 19 23:01:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinay Trivedi",
      "screen_name" : "trivinay",
      "indices" : [ 24, 33 ],
      "id_str" : "236627145",
      "id" : 236627145
    }, {
      "name" : "Harvard i-lab",
      "screen_name" : "innovationlab",
      "indices" : [ 90, 104 ],
      "id_str" : "246493616",
      "id" : 246493616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 23 ],
      "url" : "http://t.co/lBU1YPu",
      "expanded_url" : "http://bit.ly/rqNXPO",
      "display_url" : "bit.ly/rqNXPO"
    } ]
  },
  "in_reply_to_status_id_str" : "104686202258587648",
  "geo" : {
  },
  "id_str" : "104688102597074944",
  "in_reply_to_user_id" : 236627145,
  "text" : "re: http://t.co/lBU1YPu @trivinay Media Lab needs to be on that list. And in a few years, @innovationlab",
  "id" : 104688102597074944,
  "in_reply_to_status_id" : 104686202258587648,
  "created_at" : "Fri Aug 19 22:56:03 +0000 2011",
  "in_reply_to_screen_name" : "trivinay",
  "in_reply_to_user_id_str" : "236627145",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Fisher",
      "screen_name" : "kenfisher",
      "indices" : [ 3, 13 ],
      "id_str" : "10496902",
      "id" : 10496902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104657218581954560",
  "text" : "RT @kenfisher: Ars Technica has confirmed Apple's plans for iPad 4, 5, 6, 7, 8, 9, and 10, marketing names unknown, say sources familiar ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "104561282560163840",
    "text" : "Ars Technica has confirmed Apple's plans for iPad 4, 5, 6, 7, 8, 9, and 10, marketing names unknown, say sources familiar with reality.",
    "id" : 104561282560163840,
    "created_at" : "Fri Aug 19 14:32:07 +0000 2011",
    "user" : {
      "name" : "Ken Fisher",
      "screen_name" : "kenfisher",
      "protected" : false,
      "id_str" : "10496902",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2182004955/head_normal.png",
      "id" : 10496902,
      "verified" : false
    }
  },
  "id" : 104657218581954560,
  "created_at" : "Fri Aug 19 20:53:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 0, 13 ],
      "id_str" : "202968305",
      "id" : 202968305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104550860897517570",
  "geo" : {
  },
  "id_str" : "104656398633287680",
  "in_reply_to_user_id" : 202968305,
  "text" : "@jamesdotcuff yea dust has finally settled for me. I know the other khsieh on campus so it was easy, but privacy implications here are nasty",
  "id" : 104656398633287680,
  "in_reply_to_status_id" : 104550860897517570,
  "created_at" : "Fri Aug 19 20:50:04 +0000 2011",
  "in_reply_to_screen_name" : "jamesdotcuff",
  "in_reply_to_user_id_str" : "202968305",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 10, 23 ],
      "id_str" : "202968305",
      "id" : 202968305
    }, {
      "name" : "fas",
      "screen_name" : "fas",
      "indices" : [ 33, 37 ],
      "id_str" : "11015832",
      "id" : 11015832
    }, {
      "name" : "College",
      "screen_name" : "college",
      "indices" : [ 81, 89 ],
      "id_str" : "1105326799",
      "id" : 1105326799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104429027804184576",
  "text" : "Confirmed @jamesdotcuff: harvard @fas server migration does collision check with @college servers - autoforwards to FASuser@college",
  "id" : 104429027804184576,
  "created_at" : "Fri Aug 19 05:46:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 38, 49 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 70 ],
      "url" : "http://t.co/2DC86Ry",
      "expanded_url" : "http://4sq.com/nq8sfs",
      "display_url" : "4sq.com/nq8sfs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "104363040857796608",
  "text" : "I just unlocked the \"Bender\" badge on @foursquare! http://t.co/2DC86Ry",
  "id" : 104363040857796608,
  "created_at" : "Fri Aug 19 01:24:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104349359977668612",
  "geo" : {
  },
  "id_str" : "104350015765495808",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj noticeable wait but UXUI designers did great job with loading animations.",
  "id" : 104350015765495808,
  "in_reply_to_status_id" : 104349359977668612,
  "created_at" : "Fri Aug 19 00:32:37 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Nagaraj",
      "screen_name" : "sunilnagaraj",
      "indices" : [ 0, 13 ],
      "id_str" : "14877810",
      "id" : 14877810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104348205860388864",
  "geo" : {
  },
  "id_str" : "104348800629481472",
  "in_reply_to_user_id" : 14877810,
  "text" : "@sunilnagaraj Mango has vision-based text translation that overlays onto images. Just press what sign/text you want to translate and bam.",
  "id" : 104348800629481472,
  "in_reply_to_status_id" : 104348205860388864,
  "created_at" : "Fri Aug 19 00:27:47 +0000 2011",
  "in_reply_to_screen_name" : "sunilnagaraj",
  "in_reply_to_user_id_str" : "14877810",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james h bailey",
      "screen_name" : "jameshbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "928678760",
      "id" : 928678760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http://t.co/wlkkWcX",
      "expanded_url" : "http://kanehsieh.com",
      "display_url" : "kanehsieh.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "104348377596182528",
  "in_reply_to_user_id" : 75779773,
  "text" : "@jameshbailey what is the nature of the marketing role? Check http://t.co/wlkkWcX",
  "id" : 104348377596182528,
  "created_at" : "Fri Aug 19 00:26:06 +0000 2011",
  "in_reply_to_screen_name" : "jbailey13b",
  "in_reply_to_user_id_str" : "75779773",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104345796983537666",
  "text" : "Playing with WP7 Mango. Bing vision is blowing my minddd.",
  "id" : 104345796983537666,
  "created_at" : "Fri Aug 19 00:15:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "petpeeves",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104338607619325952",
  "text" : "The bus comes every 10 minutes. It isn't the last helicopter from Saigon. Calm down people. #petpeeves",
  "id" : 104338607619325952,
  "created_at" : "Thu Aug 18 23:47:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 0, 10 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104323323764293633",
  "geo" : {
  },
  "id_str" : "104323906944507904",
  "in_reply_to_user_id" : 14326765,
  "text" : "@johnhcook my roommate wore his Google shirt on his last day at Microsoft last week.",
  "id" : 104323906944507904,
  "in_reply_to_status_id" : 104323323764293633,
  "created_at" : "Thu Aug 18 22:48:52 +0000 2011",
  "in_reply_to_screen_name" : "johnhcook",
  "in_reply_to_user_id_str" : "14326765",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan Tweney",
      "screen_name" : "dylan20",
      "indices" : [ 3, 11 ],
      "id_str" : "3471",
      "id" : 3471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104299454760353792",
  "text" : "RT @dylan20: HP news is just insane today. Buying Autonomy, maybe spinning off PC business, and now killing WebOS? Sheesh",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "104272663756804098",
    "text" : "HP news is just insane today. Buying Autonomy, maybe spinning off PC business, and now killing WebOS? Sheesh",
    "id" : 104272663756804098,
    "created_at" : "Thu Aug 18 19:25:14 +0000 2011",
    "user" : {
      "name" : "Dylan Tweney",
      "screen_name" : "dylan20",
      "protected" : false,
      "id_str" : "3471",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1539914343/dylan_action_square_250_normal.jpg",
      "id" : 3471,
      "verified" : false
    }
  },
  "id" : 104299454760353792,
  "created_at" : "Thu Aug 18 21:11:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Huntsman",
      "screen_name" : "JonHuntsman",
      "indices" : [ 42, 54 ],
      "id_str" : "294728278",
      "id" : 294728278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104297819086655488",
  "text" : "Would it be ironic if I said Godspeed? RT @JonHuntsman: I believe in evolution and trust scientists on global warming. Call me crazy.",
  "id" : 104297819086655488,
  "created_at" : "Thu Aug 18 21:05:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Fu",
      "screen_name" : "susiefu",
      "indices" : [ 26, 34 ],
      "id_str" : "216144939",
      "id" : 216144939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIT",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http://t.co/84W7S5V",
      "expanded_url" : "http://vintagehelveticamit.tumblr.com",
      "display_url" : "vintagehelveticamit.tumblr.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "104297072123060224",
  "text" : "Browsing this at work! RT @susiefu: hipster #MIT students http://t.co/84W7S5V",
  "id" : 104297072123060224,
  "created_at" : "Thu Aug 18 21:02:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 3, 16 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104221638534512641",
  "text" : "RT @kevinmitnick: I'll be on Colbert tonight. I will bring him a Free Kevin sticker and a lockpick business card. Maybe he will even let ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "104200703995682816",
    "text" : "I'll be on Colbert tonight. I will bring him a Free Kevin sticker and a lockpick business card. Maybe he will even let me hack his phone ;-)",
    "id" : 104200703995682816,
    "created_at" : "Thu Aug 18 14:39:18 +0000 2011",
    "user" : {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "protected" : false,
      "id_str" : "14666934",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/53807085/Mitnick_Color_normal.jpg",
      "id" : 14666934,
      "verified" : true
    }
  },
  "id" : 104221638534512641,
  "created_at" : "Thu Aug 18 16:02:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 3, 12 ],
      "id_str" : "20568189",
      "id" : 20568189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104220522648322048",
  "text" : "RT @HODINKEE: This watch is made entirely of platinum, dial & stitching included. Also uses the best automatic movement of all time: htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 138 ],
        "url" : "http://t.co/GHOLr6N",
        "expanded_url" : "http://bit.ly/pb7q9v",
        "display_url" : "bit.ly/pb7q9v"
      } ]
    },
    "geo" : {
    },
    "id_str" : "104180220881420289",
    "text" : "This watch is made entirely of platinum, dial & stitching included. Also uses the best automatic movement of all time: http://t.co/GHOLr6N",
    "id" : 104180220881420289,
    "created_at" : "Thu Aug 18 13:17:54 +0000 2011",
    "user" : {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "protected" : false,
      "id_str" : "20568189",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2428159023/812wde5ico5f2eq91ucu_normal.png",
      "id" : 20568189,
      "verified" : false
    }
  },
  "id" : 104220522648322048,
  "created_at" : "Thu Aug 18 15:58:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Yu",
      "screen_name" : "Intenex",
      "indices" : [ 0, 8 ],
      "id_str" : "195474206",
      "id" : 195474206
    }, {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 13, 19 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104123779826991104",
  "in_reply_to_user_id" : 195474206,
  "text" : "@Intenex and @jluan you guys know each other? Both Thiel fellows.",
  "id" : 104123779826991104,
  "created_at" : "Thu Aug 18 09:33:38 +0000 2011",
  "in_reply_to_screen_name" : "Intenex",
  "in_reply_to_user_id_str" : "195474206",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/kane/status/104026463015145472/photo/1",
      "indices" : [ 58, 77 ],
      "url" : "http://t.co/mm5j2Aa",
      "media_url" : "http://pbs.twimg.com/media/AXGThFdCEAMgfKO.jpg",
      "id_str" : "104026463015145475",
      "id" : 104026463015145475,
      "media_url_https" : "https://pbs.twimg.com/media/AXGThFdCEAMgfKO.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com/mm5j2Aa"
    } ],
    "hashtags" : [ {
      "text" : "BlackBookPro",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104026463015145472",
  "text" : "#BlackBookPro anodizing is finished. Awaiting reassembly! http://t.co/mm5j2Aa",
  "id" : 104026463015145472,
  "created_at" : "Thu Aug 18 03:06:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Noronha",
      "screen_name" : "jonslaught",
      "indices" : [ 0, 11 ],
      "id_str" : "22866748",
      "id" : 22866748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103993426026053633",
  "geo" : {
  },
  "id_str" : "103994491039514625",
  "in_reply_to_user_id" : 22866748,
  "text" : "@jonslaught unfortunately I leave Seattle this Friday!",
  "id" : 103994491039514625,
  "in_reply_to_status_id" : 103993426026053633,
  "created_at" : "Thu Aug 18 00:59:53 +0000 2011",
  "in_reply_to_screen_name" : "jonslaught",
  "in_reply_to_user_id_str" : "22866748",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 18, 29 ],
      "id_str" : "14885549",
      "id" : 14885549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http://t.co/CVpzn81",
      "expanded_url" : "http://onforb.es/ny6RlS",
      "display_url" : "onforb.es/ny6RlS"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103976343313711104",
  "text" : "Combo breaker! RT @ForbesTech: Cathay Pacific Cockpit Sex Photos Ground New Ad Campaign, But Web Team Doesn't Get Memo http://t.co/CVpzn81",
  "id" : 103976343313711104,
  "created_at" : "Wed Aug 17 23:47:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 0, 15 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103898668247162881",
  "geo" : {
  },
  "id_str" : "103906281580015616",
  "in_reply_to_user_id" : 18107808,
  "text" : "@NaveenSrivatsa your tweets are making me miss Cambridge!!",
  "id" : 103906281580015616,
  "in_reply_to_status_id" : 103898668247162881,
  "created_at" : "Wed Aug 17 19:09:22 +0000 2011",
  "in_reply_to_screen_name" : "NaveenSrivatsa",
  "in_reply_to_user_id_str" : "18107808",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 32, 38 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103893870890332161",
  "text" : "They just hired cyanogen too RT @jluan: samsung's product designers are really getting good!",
  "id" : 103893870890332161,
  "created_at" : "Wed Aug 17 18:20:03 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 33, 40 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Abercrombie",
      "indices" : [ 42, 54 ]
    }, {
      "text" : "JerseyShore",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http://t.co/eSug5Jg",
      "expanded_url" : "http://cnnmon.ie/nLimyE",
      "display_url" : "cnnmon.ie/nLimyE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103891058005512192",
  "text" : "Is this really breaking news? RT @CNNbrk: #Abercrombie asks #JerseyShore cast not to wear their clothes - http://t.co/eSug5Jg",
  "id" : 103891058005512192,
  "created_at" : "Wed Aug 17 18:08:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103866736285188096",
  "text" : "Debating if I should Rick Roll my bosses during my final presentation.",
  "id" : 103866736285188096,
  "created_at" : "Wed Aug 17 16:32:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103625127765348352",
  "text" : "I'm amused when people whack digital devices to fix non-mechanical (software) problems.",
  "id" : 103625127765348352,
  "created_at" : "Wed Aug 17 00:32:10 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 3, 13 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http://t.co/bZcppvs",
      "expanded_url" : "http://www.geekwire.com/2011/blasting-ballmer-hedge-fund-manager-boosts-microsoft-stake-60",
      "display_url" : "geekwire.com/2011/blasting-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103601257431826432",
  "text" : "RT @johnhcook: Remember the hedge fund manager who wanted Ballmer fired. He's boosting his take in Microsoft. http://t.co/bZcppvs",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 114 ],
        "url" : "http://t.co/bZcppvs",
        "expanded_url" : "http://www.geekwire.com/2011/blasting-ballmer-hedge-fund-manager-boosts-microsoft-stake-60",
        "display_url" : "geekwire.com/2011/blasting-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "103476891264102400",
    "text" : "Remember the hedge fund manager who wanted Ballmer fired. He's boosting his take in Microsoft. http://t.co/bZcppvs",
    "id" : 103476891264102400,
    "created_at" : "Tue Aug 16 14:43:08 +0000 2011",
    "user" : {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "protected" : false,
      "id_str" : "14326765",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/403089484/john-headshot_normal.jpg",
      "id" : 14326765,
      "verified" : false
    }
  },
  "id" : 103601257431826432,
  "created_at" : "Tue Aug 16 22:57:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DreamHost",
      "screen_name" : "DreamHost",
      "indices" : [ 7, 17 ],
      "id_str" : "14217022",
      "id" : 14217022
    }, {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 85, 97 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103551106751275008",
  "text" : "I like @dreamhost for the convenience. Useful if you don't plan on mega-scaling. RT: @alishalisha Where should I buy hosting?",
  "id" : 103551106751275008,
  "created_at" : "Tue Aug 16 19:38:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lonely Planet",
      "screen_name" : "lonelyplanet",
      "indices" : [ 70, 83 ],
      "id_str" : "15066760",
      "id" : 15066760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103513813562826752",
  "text" : "RT @maevewang: Places to go for gap years, breakups, or just because: @lonelyplanet: 7 top reasons to go on a round-the-world trip http: ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lonely Planet",
        "screen_name" : "lonelyplanet",
        "indices" : [ 55, 68 ],
        "id_str" : "15066760",
        "id" : 15066760
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lp",
        "indices" : [ 136, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 135 ],
        "url" : "http://t.co/H0TPcH2",
        "expanded_url" : "http://bit.ly/f11djJ",
        "display_url" : "bit.ly/f11djJ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "103439835091578880",
    "text" : "Places to go for gap years, breakups, or just because: @lonelyplanet: 7 top reasons to go on a round-the-world trip http://t.co/H0TPcH2 #lp",
    "id" : 103439835091578880,
    "created_at" : "Tue Aug 16 12:15:53 +0000 2011",
    "user" : {
      "name" : "mtwang",
      "screen_name" : "m_t_wang",
      "protected" : true,
      "id_str" : "110202853",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1980206955/I8sOc_normal.png",
      "id" : 110202853,
      "verified" : false
    }
  },
  "id" : 103513813562826752,
  "created_at" : "Tue Aug 16 17:09:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xinerz",
      "screen_name" : "xinerz",
      "indices" : [ 0, 7 ],
      "id_str" : "17416592",
      "id" : 17416592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103316547472330752",
  "geo" : {
  },
  "id_str" : "103385467554238464",
  "in_reply_to_user_id" : 17416592,
  "text" : "@xinerz you're going to buffalo?",
  "id" : 103385467554238464,
  "in_reply_to_status_id" : 103316547472330752,
  "created_at" : "Tue Aug 16 08:39:50 +0000 2011",
  "in_reply_to_screen_name" : "xinerz",
  "in_reply_to_user_id_str" : "17416592",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http://t.co/Nhc22x8",
      "expanded_url" : "http://4sq.com/o0yqbD",
      "display_url" : "4sq.com/o0yqbD"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.619518, -122.356448 ]
  },
  "id_str" : "103346804271218688",
  "text" : "I'm at I Can Has Cheezburger? (190 Queen Anne Ave N, John St, Seattle) http://t.co/Nhc22x8",
  "id" : 103346804271218688,
  "created_at" : "Tue Aug 16 06:06:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 13, 21 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103239578487488512",
  "geo" : {
  },
  "id_str" : "103242184484061184",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha @aistern thesis? Is that a new Pokemon?",
  "id" : 103242184484061184,
  "in_reply_to_status_id" : 103239578487488512,
  "created_at" : "Mon Aug 15 23:10:29 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    }, {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 19, 26 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 93 ],
      "url" : "http://t.co/AlLjISD",
      "expanded_url" : "http://onforb.es/oEPOdk",
      "display_url" : "onforb.es/oEPOdk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103223986988654592",
  "text" : "RT @ForbesTech: RT @Forbes: Are Computers Bringing Down The Stock Market? http://t.co/AlLjISD",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Forbes",
        "screen_name" : "Forbes",
        "indices" : [ 3, 10 ],
        "id_str" : "91478624",
        "id" : 91478624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 77 ],
        "url" : "http://t.co/AlLjISD",
        "expanded_url" : "http://onforb.es/oEPOdk",
        "display_url" : "onforb.es/oEPOdk"
      } ]
    },
    "geo" : {
    },
    "id_str" : "103203593389215744",
    "text" : "RT @Forbes: Are Computers Bringing Down The Stock Market? http://t.co/AlLjISD",
    "id" : 103203593389215744,
    "created_at" : "Mon Aug 15 20:37:08 +0000 2011",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 103223986988654592,
  "created_at" : "Mon Aug 15 21:58:10 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103188879162609664",
  "text" : "RT @parislemon: I can't wait for the Android RAZR.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7730718726, -122.4228918315 ]
    },
    "id_str" : "103143745146462208",
    "text" : "I can't wait for the Android RAZR.",
    "id" : 103143745146462208,
    "created_at" : "Mon Aug 15 16:39:19 +0000 2011",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3336694463/99718483afb19d6d441290afccb72772_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 103188879162609664,
  "created_at" : "Mon Aug 15 19:38:40 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Blitzstein",
      "screen_name" : "stat110",
      "indices" : [ 0, 8 ],
      "id_str" : "184543773",
      "id" : 184543773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103162236658393088",
  "geo" : {
  },
  "id_str" : "103188491659264001",
  "in_reply_to_user_id" : 184543773,
  "text" : "@stat110 the optimal solution is to just move back to Cambridge!",
  "id" : 103188491659264001,
  "in_reply_to_status_id" : 103162236658393088,
  "created_at" : "Mon Aug 15 19:37:08 +0000 2011",
  "in_reply_to_screen_name" : "stat110",
  "in_reply_to_user_id_str" : "184543773",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Google",
      "indices" : [ 72, 79 ]
    }, {
      "text" : "Motorola",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103138240357335041",
  "text" : "Being on the west coast means I'm 3 hours late to all the morning news. #Google #Motorola",
  "id" : 103138240357335041,
  "created_at" : "Mon Aug 15 16:17:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 83, 96 ],
      "id_str" : "202968305",
      "id" : 202968305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102992235649433602",
  "text" : "Harvard IT rolls out Gmail-based email system today! Pity us poor FAS server users @jamesdotcuff",
  "id" : 102992235649433602,
  "created_at" : "Mon Aug 15 06:37:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102805005198823426",
  "text" : "The wannabe audiophile part of me scoffs at Bluetooth streamers... The rest of me can't stop blasting B. Spears over it.",
  "id" : 102805005198823426,
  "created_at" : "Sun Aug 14 18:13:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Luan",
      "screen_name" : "jluan",
      "indices" : [ 30, 36 ],
      "id_str" : "27015881",
      "id" : 27015881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thiel",
      "indices" : [ 16, 22 ]
    }, {
      "text" : "godspeed",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102554509666025472",
  "text" : "My roommate and #Thiel fellow @jluan just left Seattle to start a robotics company in San Fran. Nbd. #godspeed",
  "id" : 102554509666025472,
  "created_at" : "Sun Aug 14 01:37:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "indices" : [ 3, 19 ],
      "id_str" : "263122363",
      "id" : 263122363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AsianProblems",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http://t.co/T2pgIzO",
      "expanded_url" : "http://yfrog.com/kjuwwqjj",
      "display_url" : "yfrog.com/kjuwwqjj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "102499319906713600",
  "text" : "RT @HarvardAsianGuy: #AsianProblems http://t.co/T2pgIzO",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AsianProblems",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 15, 34 ],
        "url" : "http://t.co/T2pgIzO",
        "expanded_url" : "http://yfrog.com/kjuwwqjj",
        "display_url" : "yfrog.com/kjuwwqjj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "102491198278729728",
    "text" : "#AsianProblems http://t.co/T2pgIzO",
    "id" : 102491198278729728,
    "created_at" : "Sat Aug 13 21:26:20 +0000 2011",
    "user" : {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "protected" : false,
      "id_str" : "263122363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1713903417/asian_normal.jpg",
      "id" : 263122363,
      "verified" : false
    }
  },
  "id" : 102499319906713600,
  "created_at" : "Sat Aug 13 21:58:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lifeisgood",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102489743006253057",
  "text" : "Saturday lunch at Beard Papa bakery with bubble tea #Lifeisgood",
  "id" : 102489743006253057,
  "created_at" : "Sat Aug 13 21:20:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "indices" : [ 28, 37 ],
      "id_str" : "237573925",
      "id" : 237573925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thisshouldbeinteresting",
      "indices" : [ 62, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102117332255649792",
  "text" : "Arent you a lifeguard..? RT @touhsieh: Falling asleep at work #thisshouldbeinteresting",
  "id" : 102117332255649792,
  "created_at" : "Fri Aug 12 20:40:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Paiji",
      "screen_name" : "spaiji",
      "indices" : [ 0, 7 ],
      "id_str" : "213867225",
      "id" : 213867225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102092016405585920",
  "geo" : {
  },
  "id_str" : "102109749478305792",
  "in_reply_to_user_id" : 213867225,
  "text" : "@spaiji British retailer Banana Flame allows users to 'try' clothes on with webcam, save images, and share over social media",
  "id" : 102109749478305792,
  "in_reply_to_status_id" : 102092016405585920,
  "created_at" : "Fri Aug 12 20:10:36 +0000 2011",
  "in_reply_to_screen_name" : "spaiji",
  "in_reply_to_user_id_str" : "213867225",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan",
      "screen_name" : "evankerrigan",
      "indices" : [ 3, 16 ],
      "id_str" : "17261234",
      "id" : 17261234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102061400783994880",
  "text" : "RT @evankerrigan: Bus driver apologized over loudspeaker for neglecting to announce that it was \u201CFantastic Friday.\u201D I wonder about you s ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "102034940509683713",
    "text" : "Bus driver apologized over loudspeaker for neglecting to announce that it was \u201CFantastic Friday.\u201D I wonder about you sometimes, Seattle.",
    "id" : 102034940509683713,
    "created_at" : "Fri Aug 12 15:13:20 +0000 2011",
    "user" : {
      "name" : "Evan",
      "screen_name" : "evankerrigan",
      "protected" : false,
      "id_str" : "17261234",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/466463210/evan_topofroc_normal.jpg",
      "id" : 17261234,
      "verified" : false
    }
  },
  "id" : 102061400783994880,
  "created_at" : "Fri Aug 12 16:58:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 0, 13 ],
      "id_str" : "202968305",
      "id" : 202968305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101888671665496065",
  "geo" : {
  },
  "id_str" : "101891550296014849",
  "in_reply_to_user_id" : 202968305,
  "text" : "@jamesdotcuff design is hardly CS :P I can barely code to save my life.",
  "id" : 101891550296014849,
  "in_reply_to_status_id" : 101888671665496065,
  "created_at" : "Fri Aug 12 05:43:33 +0000 2011",
  "in_reply_to_screen_name" : "jamesdotcuff",
  "in_reply_to_user_id_str" : "202968305",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 0, 13 ],
      "id_str" : "202968305",
      "id" : 202968305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101888671665496065",
  "geo" : {
  },
  "id_str" : "101889959396515840",
  "in_reply_to_user_id" : 202968305,
  "text" : "@jamesdotcuff thanks! Let me know if you plan on stopping by.",
  "id" : 101889959396515840,
  "in_reply_to_status_id" : 101888671665496065,
  "created_at" : "Fri Aug 12 05:37:14 +0000 2011",
  "in_reply_to_screen_name" : "jamesdotcuff",
  "in_reply_to_user_id_str" : "202968305",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cuff",
      "screen_name" : "jamesdotcuff",
      "indices" : [ 0, 13 ],
      "id_str" : "202968305",
      "id" : 202968305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101883606934372352",
  "geo" : {
  },
  "id_str" : "101888283306500096",
  "in_reply_to_user_id" : 202968305,
  "text" : "@jamesdotcuff it was designed so contact, location, and hours require no clicks to see from any page on the site!",
  "id" : 101888283306500096,
  "in_reply_to_status_id" : 101883606934372352,
  "created_at" : "Fri Aug 12 05:30:34 +0000 2011",
  "in_reply_to_screen_name" : "jamesdotcuff",
  "in_reply_to_user_id_str" : "202968305",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Zealand Prints",
      "screen_name" : "NZPrints",
      "indices" : [ 34, 43 ],
      "id_str" : "62244410",
      "id" : 62244410
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kiwiana",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101883005345337344",
  "text" : "I made the restaurant website! RT @NZPrints: NY's first Kiwi restaurant features #kiwiana art http://j.mp/qdzDyS and superb NZ cuisine",
  "id" : 101883005345337344,
  "created_at" : "Fri Aug 12 05:09:36 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101756273749540864",
  "text" : "Protip Infiniti: If you're going to release teaser pictures of 2012 models, make sure they don't look really really generic and bland.",
  "id" : 101756273749540864,
  "created_at" : "Thu Aug 11 20:46:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 45, 58 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101747560804401153",
  "text" : "I might actually read the Britain section of @TheEconomist this week.",
  "id" : 101747560804401153,
  "created_at" : "Thu Aug 11 20:11:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 3, 16 ],
      "id_str" : "14666934",
      "id" : 14666934
    }, {
      "name" : "The Colbert Report",
      "screen_name" : "ColbertReport",
      "indices" : [ 34, 48 ],
      "id_str" : "158412741",
      "id" : 158412741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101747462762541057",
  "text" : "RT @kevinmitnick: I'll be on the  @colbertreport Thursday, August 18th 2011, at 11 p.m. EST :-)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Colbert Report",
        "screen_name" : "ColbertReport",
        "indices" : [ 16, 30 ],
        "id_str" : "158412741",
        "id" : 158412741
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "101746355923464192",
    "text" : "I'll be on the  @colbertreport Thursday, August 18th 2011, at 11 p.m. EST :-)",
    "id" : 101746355923464192,
    "created_at" : "Thu Aug 11 20:06:36 +0000 2011",
    "user" : {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "protected" : false,
      "id_str" : "14666934",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/53807085/Mitnick_Color_normal.jpg",
      "id" : 14666934,
      "verified" : true
    }
  },
  "id" : 101747462762541057,
  "created_at" : "Thu Aug 11 20:11:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProleDrift",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101714220994928640",
  "text" : "Will Blackberry's image slide like Burberry's in the UK due to the riots? #ProleDrift",
  "id" : 101714220994928640,
  "created_at" : "Thu Aug 11 17:58:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "indices" : [ 7, 16 ],
      "id_str" : "237573925",
      "id" : 237573925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jealous",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101552308453781504",
  "text" : "Helped @touhsieh pick out a Sandy Bridge MacBook Air. #jealous",
  "id" : 101552308453781504,
  "created_at" : "Thu Aug 11 07:15:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Steven",
      "screen_name" : "mash_daddy",
      "indices" : [ 13, 24 ],
      "id_str" : "193150867",
      "id" : 193150867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101475061604683776",
  "geo" : {
  },
  "id_str" : "101476557528383488",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha @mash_daddy ETA October for iPhone 5.",
  "id" : 101476557528383488,
  "in_reply_to_status_id" : 101475061604683776,
  "created_at" : "Thu Aug 11 02:14:31 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101449320863236097",
  "text" : "RT @TheEconomist: Slicing an Apple: How much of an iPhone is a Samsung? Daily Chart August 10th http://econ.st/nFlTvn",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "101435669347446785",
    "text" : "Slicing an Apple: How much of an iPhone is a Samsung? Daily Chart August 10th http://econ.st/nFlTvn",
    "id" : 101435669347446785,
    "created_at" : "Wed Aug 10 23:32:02 +0000 2011",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2935088950/e4d1ead030ff141e777bda02b961c8d9_normal.jpeg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 101449320863236097,
  "created_at" : "Thu Aug 11 00:26:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hsieh",
      "screen_name" : "touhsieh",
      "indices" : [ 37, 46 ],
      "id_str" : "237573925",
      "id" : 237573925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101411993994539008",
  "text" : "My sis is smarter than i thought. RT @touhsieh: Money can't buy happiness... But it can buy bacon, and that's pretty damn close.",
  "id" : 101411993994539008,
  "created_at" : "Wed Aug 10 21:57:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gant",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http://t.co/vUcFV7o",
      "expanded_url" : "http://us.gant.com/",
      "display_url" : "us.gant.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101409772024246273",
  "text" : "#Gant is back with the \"New Haven Math Club\" fall line. http://t.co/vUcFV7o",
  "id" : 101409772024246273,
  "created_at" : "Wed Aug 10 21:49:08 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101331544454606848",
  "text" : "The shuttle is grounded. The F22 is grounded. The F35 is grounded. I'd make a joke about American manufacturing but it's a $500B punchline",
  "id" : 101331544454606848,
  "created_at" : "Wed Aug 10 16:38:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101330550865920000",
  "text" : "RT @WSJ: The Pentagon plans to test an unmanned aircraft that could hit speeds of up to 13,000 miles per hour http://on.wsj.com/qu4Pz8",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "101317180230078464",
    "text" : "The Pentagon plans to test an unmanned aircraft that could hit speeds of up to 13,000 miles per hour http://on.wsj.com/qu4Pz8",
    "id" : 101317180230078464,
    "created_at" : "Wed Aug 10 15:41:12 +0000 2011",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 101330550865920000,
  "created_at" : "Wed Aug 10 16:34:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Emil Protalinski",
      "screen_name" : "emilprotalinski",
      "indices" : [ 110, 126 ],
      "id_str" : "328051466",
      "id" : 328051466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101152872212860928",
  "text" : "RT @TheNextWeb: Microsoft develops most advanced 3D modeling system for the human face http://tnw.to/1AJXa by @emilprotalinski on @TNWmi ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emil Protalinski",
        "screen_name" : "emilprotalinski",
        "indices" : [ 94, 110 ],
        "id_str" : "328051466",
        "id" : 328051466
      }, {
        "name" : "TNW Microsoft",
        "screen_name" : "TNWmicrosoft",
        "indices" : [ 114, 127 ],
        "id_str" : "127874471",
        "id" : 127874471
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "101125503309725696",
    "text" : "Microsoft develops most advanced 3D modeling system for the human face http://tnw.to/1AJXa by @emilprotalinski on @TNWmicrosoft",
    "id" : 101125503309725696,
    "created_at" : "Wed Aug 10 02:59:33 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 101152872212860928,
  "created_at" : "Wed Aug 10 04:48:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bain & Company",
      "screen_name" : "BainAlerts",
      "indices" : [ 3, 14 ],
      "id_str" : "65381936",
      "id" : 65381936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101090728259756032",
  "text" : "RT @BainAlerts: Fewer than one in five executives believe IT is aligned with their top business needs http://bit.ly/o03tvN",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "101089427417346048",
    "text" : "Fewer than one in five executives believe IT is aligned with their top business needs http://bit.ly/o03tvN",
    "id" : 101089427417346048,
    "created_at" : "Wed Aug 10 00:36:12 +0000 2011",
    "user" : {
      "name" : "Bain & Company",
      "screen_name" : "BainAlerts",
      "protected" : false,
      "id_str" : "65381936",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1829326650/Bain-twitter-logo_normal.jpg",
      "id" : 65381936,
      "verified" : false
    }
  },
  "id" : 101090728259756032,
  "created_at" : "Wed Aug 10 00:41:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Wang",
      "screen_name" : "annie_wang",
      "indices" : [ 3, 14 ],
      "id_str" : "29599103",
      "id" : 29599103
    }, {
      "name" : "SAI",
      "screen_name" : "SAI",
      "indices" : [ 127, 131 ],
      "id_str" : "8841372",
      "id" : 8841372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http://t.co/rh6TYom",
      "expanded_url" : "http://www.businessinsider.com/anonymous-facebook-2011-8?utm_source=twbutton&utm_medium=social&utm_term=&utm_content=&utm_campaign=sai",
      "display_url" : "businessinsider.com/anonymous-face\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101090686052474882",
  "text" : "RT @annie_wang: verrrrry interesting.....Hacker Group Anonymous Vows To Destroy Facebook On November 5 http://t.co/rh6TYom via @sai",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SAI",
        "screen_name" : "SAI",
        "indices" : [ 111, 115 ],
        "id_str" : "8841372",
        "id" : 8841372
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 106 ],
        "url" : "http://t.co/rh6TYom",
        "expanded_url" : "http://www.businessinsider.com/anonymous-facebook-2011-8?utm_source=twbutton&utm_medium=social&utm_term=&utm_content=&utm_campaign=sai",
        "display_url" : "businessinsider.com/anonymous-face\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "101088580415397888",
    "text" : "verrrrry interesting.....Hacker Group Anonymous Vows To Destroy Facebook On November 5 http://t.co/rh6TYom via @sai",
    "id" : 101088580415397888,
    "created_at" : "Wed Aug 10 00:32:50 +0000 2011",
    "user" : {
      "name" : "Annie Wang",
      "screen_name" : "annie_wang",
      "protected" : false,
      "id_str" : "29599103",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2911482959/06b7125282ebb0ebb4b7e63fc4a7cdc6_normal.jpeg",
      "id" : 29599103,
      "verified" : false
    }
  },
  "id" : 101090686052474882,
  "created_at" : "Wed Aug 10 00:41:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ella",
      "screen_name" : "ellachou",
      "indices" : [ 3, 12 ],
      "id_str" : "2082721",
      "id" : 2082721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cleantech",
      "indices" : [ 93, 103 ]
    }, {
      "text" : "transportation",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http://t.co/RA8G9qF",
      "expanded_url" : "http://goo.gl/duYbB",
      "display_url" : "goo.gl/duYbB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101041399679561728",
  "text" : "RT @ellachou: New MIT Battery Design Could Double Range of Electric Cars http://t.co/RA8G9qF #cleantech #transportation",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cleantech",
        "indices" : [ 79, 89 ]
      }, {
        "text" : "transportation",
        "indices" : [ 90, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 78 ],
        "url" : "http://t.co/RA8G9qF",
        "expanded_url" : "http://goo.gl/duYbB",
        "display_url" : "goo.gl/duYbB"
      } ]
    },
    "geo" : {
    },
    "id_str" : "100991608534740992",
    "text" : "New MIT Battery Design Could Double Range of Electric Cars http://t.co/RA8G9qF #cleantech #transportation",
    "id" : 100991608534740992,
    "created_at" : "Tue Aug 09 18:07:30 +0000 2011",
    "user" : {
      "name" : "Ella",
      "screen_name" : "ellachou",
      "protected" : false,
      "id_str" : "2082721",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3415266957/600b445a9e01cde89a63db66821e3903_normal.jpeg",
      "id" : 2082721,
      "verified" : false
    }
  },
  "id" : 101041399679561728,
  "created_at" : "Tue Aug 09 21:25:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "priorities",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100972718085779456",
  "text" : "Hey USA and UK: nice job trolling all the news outlets, but Africa is still suffering terrible famine... #priorities",
  "id" : 100972718085779456,
  "created_at" : "Tue Aug 09 16:52:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Ball",
      "screen_name" : "jamesrbuk",
      "indices" : [ 3, 13 ],
      "id_str" : "40713876",
      "id" : 40713876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100969744911450112",
  "text" : "RT @jamesrbuk: Incidentally, if we shut down BBM after 3-days of rioting, we lose all moral authority re: middle east doing same. Let's  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100936130861613056",
    "text" : "Incidentally, if we shut down BBM after 3-days of rioting, we lose all moral authority re: middle east doing same. Let's not, eh?",
    "id" : 100936130861613056,
    "created_at" : "Tue Aug 09 14:27:03 +0000 2011",
    "user" : {
      "name" : "James Ball",
      "screen_name" : "jamesrbuk",
      "protected" : false,
      "id_str" : "40713876",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3307519364/698f02f14b1b85a03b0084269e5568f0_normal.jpeg",
      "id" : 40713876,
      "verified" : false
    }
  },
  "id" : 100969744911450112,
  "created_at" : "Tue Aug 09 16:40:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100751668823605248",
  "geo" : {
  },
  "id_str" : "100758605791363072",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha I feel that men's shoes are a lot easier to understand than women's!",
  "id" : 100758605791363072,
  "in_reply_to_status_id" : 100751668823605248,
  "created_at" : "Tue Aug 09 02:41:38 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100749484660756480",
  "geo" : {
  },
  "id_str" : "100750244530237440",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha I wore through 3 Aldo shoes last year!! Bit the bullet on a pair of To Boot NY and haven't looked back.",
  "id" : 100750244530237440,
  "in_reply_to_status_id" : 100749484660756480,
  "created_at" : "Tue Aug 09 02:08:24 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100748022828367872",
  "text" : "RT @Fake_Dispatch: BREAKING: All the news is starting to sound like the first ten pages of a Neal Stephenson novel.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100727612892127232",
    "text" : "BREAKING: All the news is starting to sound like the first ten pages of a Neal Stephenson novel.",
    "id" : 100727612892127232,
    "created_at" : "Tue Aug 09 00:38:29 +0000 2011",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 100748022828367872,
  "created_at" : "Tue Aug 09 01:59:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100722448609185792",
  "text" : "RT @bznotes: Tea party f---ed up the US stock mkts. So why are the Britons rioting?",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100715856207679488",
    "text" : "Tea party f---ed up the US stock mkts. So why are the Britons rioting?",
    "id" : 100715856207679488,
    "created_at" : "Mon Aug 08 23:51:45 +0000 2011",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 100722448609185792,
  "created_at" : "Tue Aug 09 00:17:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "london",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100678661191122945",
  "text" : "Wait riots and chaos in #london now? what is this I don't even",
  "id" : 100678661191122945,
  "created_at" : "Mon Aug 08 21:23:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "diptychal ",
      "screen_name" : "diptychal",
      "indices" : [ 112, 122 ],
      "id_str" : "382580093",
      "id" : 382580093
    }, {
      "name" : "TNW Middle East",
      "screen_name" : "TheNextWebME",
      "indices" : [ 126, 139 ],
      "id_str" : "86800236",
      "id" : 86800236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100674549682679808",
  "text" : "RT @TheNextWeb: Syrian hackers retaliate, taking down Anonymous' social network AnonPlus http://tnw.to/1AIC6 by @diptychal on @TheNextWebME",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "diptychal ",
        "screen_name" : "diptychal",
        "indices" : [ 96, 106 ],
        "id_str" : "382580093",
        "id" : 382580093
      }, {
        "name" : "TNW Middle East",
        "screen_name" : "TheNextWebME",
        "indices" : [ 110, 123 ],
        "id_str" : "86800236",
        "id" : 86800236
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100660375749529600",
    "text" : "Syrian hackers retaliate, taking down Anonymous' social network AnonPlus http://tnw.to/1AIC6 by @diptychal on @TheNextWebME",
    "id" : 100660375749529600,
    "created_at" : "Mon Aug 08 20:11:18 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 100674549682679808,
  "created_at" : "Mon Aug 08 21:07:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Value Fool",
      "screen_name" : "TMFInsideValue",
      "indices" : [ 3, 18 ],
      "id_str" : "15945181",
      "id" : 15945181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100633732645527552",
  "text" : "RT @TMFInsideValue: \"Moody and Poor are not qualities I look for in credit rating agencies.\" -- Buddy",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100617386427826176",
    "text" : "\"Moody and Poor are not qualities I look for in credit rating agencies.\" -- Buddy",
    "id" : 100617386427826176,
    "created_at" : "Mon Aug 08 17:20:28 +0000 2011",
    "user" : {
      "name" : "A Value Fool",
      "screen_name" : "TMFInsideValue",
      "protected" : false,
      "id_str" : "15945181",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2898906271/689f32243d5977a280d3aa5179067e1f_normal.jpeg",
      "id" : 15945181,
      "verified" : false
    }
  },
  "id" : 100633732645527552,
  "created_at" : "Mon Aug 08 18:25:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 3, 16 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100633460540063744",
  "text" : "RT @kevinmitnick: Ghost in the Wires releases in one week. It just made Barnes and Noble's best book of the month list :-) very cool.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100613801061265408",
    "text" : "Ghost in the Wires releases in one week. It just made Barnes and Noble's best book of the month list :-) very cool.",
    "id" : 100613801061265408,
    "created_at" : "Mon Aug 08 17:06:14 +0000 2011",
    "user" : {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "protected" : false,
      "id_str" : "14666934",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/53807085/Mitnick_Color_normal.jpg",
      "id" : 14666934,
      "verified" : true
    }
  },
  "id" : 100633460540063744,
  "created_at" : "Mon Aug 08 18:24:21 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis K. Berman",
      "screen_name" : "dkberman",
      "indices" : [ 3, 12 ],
      "id_str" : "111441302",
      "id" : 111441302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100606496978632704",
  "text" : "RT @dkberman: Having dropped 15% today, Bank of America has lost 50% of its value in the last year. And this was supposed to be the \"rec ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100599625811099649",
    "text" : "Having dropped 15% today, Bank of America has lost 50% of its value in the last year. And this was supposed to be the \"recovery.\" $BAC $JPM",
    "id" : 100599625811099649,
    "created_at" : "Mon Aug 08 16:09:54 +0000 2011",
    "user" : {
      "name" : "Dennis K. Berman",
      "screen_name" : "dkberman",
      "protected" : false,
      "id_str" : "111441302",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2190304488/Berman_new_hedcut_normal.jpg",
      "id" : 111441302,
      "verified" : false
    }
  },
  "id" : 100606496978632704,
  "created_at" : "Mon Aug 08 16:37:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 34, 43 ],
      "id_str" : "20568189",
      "id" : 20568189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100436288347443200",
  "text" : "Seiko Spacewalk by any chance? RT @HODINKEE: Tomorrow we show you a previously unknown SPACE watch. And it's a big one.",
  "id" : 100436288347443200,
  "created_at" : "Mon Aug 08 05:20:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 3, 13 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100339923361607680",
  "text" : "RT @momogoose: Anyone suspected of patent-trolling any of our customers' startups will lose all peanut tofu privileges.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100176326094356480",
    "text" : "Anyone suspected of patent-trolling any of our customers' startups will lose all peanut tofu privileges.",
    "id" : 100176326094356480,
    "created_at" : "Sun Aug 07 12:07:51 +0000 2011",
    "user" : {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "protected" : false,
      "id_str" : "182074162",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3184583149/2b7b00023a1148627aee023205a4e2ab_normal.jpeg",
      "id" : 182074162,
      "verified" : false
    }
  },
  "id" : 100339923361607680,
  "created_at" : "Sun Aug 07 22:57:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100334882928078848",
  "text" : "\"You're above the weather that scares you when you fly mortal planes.\" - sr71 pilot Brian Shul",
  "id" : 100334882928078848,
  "created_at" : "Sun Aug 07 22:37:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 0, 16 ],
      "id_str" : "228489296",
      "id" : 228489296
    }, {
      "name" : "Rebecca Liao",
      "screen_name" : "beccaliao",
      "indices" : [ 120, 130 ],
      "id_str" : "237599567",
      "id" : 237599567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100043726205882368",
  "geo" : {
  },
  "id_str" : "100072320089075714",
  "in_reply_to_user_id" : 228489296,
  "text" : "@GlobalAsianista thanks for the intro! First time Twitter has been the initial point of contact. We live in the future! @beccaliao",
  "id" : 100072320089075714,
  "in_reply_to_status_id" : 100043726205882368,
  "created_at" : "Sun Aug 07 05:14:35 +0000 2011",
  "in_reply_to_screen_name" : "GlobalAsianista",
  "in_reply_to_user_id_str" : "228489296",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99967890308071426",
  "text" : "I somehow managed to lose my phone in my own apartment. #fail",
  "id" : 99967890308071426,
  "created_at" : "Sat Aug 06 22:19:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99659819757211649",
  "text" : "Uh oh, security flaw in Square http://j.mp/qiUM8v",
  "id" : 99659819757211649,
  "created_at" : "Sat Aug 06 01:55:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.metrotwit.com/\" rel=\"nofollow\">MetroTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "downgraded",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99649372169580545",
  "text" : "It's official. US #downgraded http://j.mp/pSZHZN",
  "id" : 99649372169580545,
  "created_at" : "Sat Aug 06 01:13:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 3, 14 ],
      "id_str" : "14885549",
      "id" : 14885549
    }, {
      "name" : "Andy Greenberg",
      "screen_name" : "a_greenberg",
      "indices" : [ 106, 118 ],
      "id_str" : "4255361",
      "id" : 4255361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http://t.co/g5n16i9",
      "expanded_url" : "http://onforb.es/oB6YGk",
      "display_url" : "onforb.es/oB6YGk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "99534638657183744",
  "text" : "RT @ForbesTech: Defcon Lockpickers Open Card-And-Code Government Locks In Seconds http://t.co/g5n16i9 via @a_greenberg",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Greenberg",
        "screen_name" : "a_greenberg",
        "indices" : [ 90, 102 ],
        "id_str" : "4255361",
        "id" : 4255361
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 85 ],
        "url" : "http://t.co/g5n16i9",
        "expanded_url" : "http://onforb.es/oB6YGk",
        "display_url" : "onforb.es/oB6YGk"
      } ]
    },
    "geo" : {
    },
    "id_str" : "99518700897574912",
    "text" : "Defcon Lockpickers Open Card-And-Code Government Locks In Seconds http://t.co/g5n16i9 via @a_greenberg",
    "id" : 99518700897574912,
    "created_at" : "Fri Aug 05 16:34:41 +0000 2011",
    "user" : {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "protected" : false,
      "id_str" : "14885549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/828527305/technology_normal.jpg",
      "id" : 14885549,
      "verified" : false
    }
  },
  "id" : 99534638657183744,
  "created_at" : "Fri Aug 05 17:38:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Punit Shah",
      "screen_name" : "thepunit",
      "indices" : [ 0, 9 ],
      "id_str" : "18008249",
      "id" : 18008249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http://t.co/75YA66t",
      "expanded_url" : "http://thesocietypages.org/cyborgology/2011/05/14/the-faux-vintage-photo-full-essay-parts-i-ii-and-iii/",
      "display_url" : "thesocietypages.org/cyborgology/20\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "99533028862341120",
  "in_reply_to_user_id" : 18008249,
  "text" : "@thepunit re: instagram and purposefully degraded pictures, read this: http://t.co/75YA66t",
  "id" : 99533028862341120,
  "created_at" : "Fri Aug 05 17:31:37 +0000 2011",
  "in_reply_to_screen_name" : "thepunit",
  "in_reply_to_user_id_str" : "18008249",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 3, 6 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 136 ],
      "url" : "http://t.co/g",
      "expanded_url" : "http://twitter.com/minimalist",
      "display_url" : "twitter.com/minimalist"
    } ]
  },
  "geo" : {
  },
  "id_str" : "99306567807139840",
  "text" : "RT @ev: After 50yrs of study: \"...the only reason we need to sleep that is really, really solid is because we get sleepy.\" http://t.co/g ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 134 ],
        "url" : "http://t.co/gBa3g3p",
        "expanded_url" : "http://ngm.nationalgeographic.com/2010/05/sleep/max-text/1",
        "display_url" : "ngm.nationalgeographic.com/2010/05/sleep/\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "99288428750979072",
    "text" : "After 50yrs of study: \"...the only reason we need to sleep that is really, really solid is because we get sleepy.\" http://t.co/gBa3g3p",
    "id" : 99288428750979072,
    "created_at" : "Fri Aug 05 01:19:40 +0000 2011",
    "user" : {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "protected" : false,
      "id_str" : "20",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3210333557/3a25ada51adaf2e372cb5a04b5800596_normal.jpeg",
      "id" : 20,
      "verified" : true
    }
  },
  "id" : 99306567807139840,
  "created_at" : "Fri Aug 05 02:31:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 20, 33 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99285353378226176",
  "text" : "I can never tell if @TheEconomist articles are making fun of America or just written in a very British tone. Or both.",
  "id" : 99285353378226176,
  "created_at" : "Fri Aug 05 01:07:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99253396401430529",
  "text" : "Office 2010, why u spellcheck Oxford commas??",
  "id" : 99253396401430529,
  "created_at" : "Thu Aug 04 23:00:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99247152605302784",
  "text" : "RT @WSJ: 13.9 billion shares changed hands today, nearly double normal volume; the VIX \"fear index\" jumped 35%. More data: http://wsj.co ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "99235068089860096",
    "text" : "13.9 billion shares changed hands today, nearly double normal volume; the VIX \"fear index\" jumped 35%. More data: http://wsj.com/marketbeat",
    "id" : 99235068089860096,
    "created_at" : "Thu Aug 04 21:47:38 +0000 2011",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702671908/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 99247152605302784,
  "created_at" : "Thu Aug 04 22:35:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    }, {
      "name" : "Joi Ito",
      "screen_name" : "Joi",
      "indices" : [ 46, 50 ],
      "id_str" : "691353",
      "id" : 691353
    }, {
      "name" : "color hsu",
      "screen_name" : "colorma",
      "indices" : [ 128, 136 ],
      "id_str" : "60040287",
      "id" : 60040287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http://t.co/NKiec0S",
      "expanded_url" : "http://www.colormagazineusa.com/index.php?option=com_content&view=article&id=553",
      "display_url" : "colormagazineusa.com/index.php?opti\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "99156019560722433",
  "text" : "RT @medialab: The new head of MIT's Media Lab @Joi Ito brings an off-the-beaten-track record of success http://t.co/NKiec0S via @ColorMa ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joi Ito",
        "screen_name" : "Joi",
        "indices" : [ 32, 36 ],
        "id_str" : "691353",
        "id" : 691353
      }, {
        "name" : "Color Magazine",
        "screen_name" : "ColorMagazine",
        "indices" : [ 114, 128 ],
        "id_str" : "18877612",
        "id" : 18877612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 109 ],
        "url" : "http://t.co/NKiec0S",
        "expanded_url" : "http://www.colormagazineusa.com/index.php?option=com_content&view=article&id=553",
        "display_url" : "colormagazineusa.com/index.php?opti\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "99147836444250112",
    "text" : "The new head of MIT's Media Lab @Joi Ito brings an off-the-beaten-track record of success http://t.co/NKiec0S via @ColorMagazine",
    "id" : 99147836444250112,
    "created_at" : "Thu Aug 04 16:01:00 +0000 2011",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 99156019560722433,
  "created_at" : "Thu Aug 04 16:33:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "indices" : [ 3, 15 ],
      "id_str" : "717313",
      "id" : 717313
    }, {
      "name" : "Jacqui Cheng",
      "screen_name" : "ejacqui",
      "indices" : [ 101, 109 ],
      "id_str" : "46023",
      "id" : 46023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http://t.co/FyChQdZ",
      "expanded_url" : "http://arst.ch/qgg",
      "display_url" : "arst.ch/qgg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "99155499223760896",
  "text" : "RT @arstechnica: Microsoft calls Google out over patent bullying accusations: http://t.co/FyChQdZ by @ejacqui",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jacqui Cheng",
        "screen_name" : "ejacqui",
        "indices" : [ 84, 92 ],
        "id_str" : "46023",
        "id" : 46023
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 80 ],
        "url" : "http://t.co/FyChQdZ",
        "expanded_url" : "http://arst.ch/qgg",
        "display_url" : "arst.ch/qgg"
      } ]
    },
    "geo" : {
    },
    "id_str" : "99135414337667072",
    "text" : "Microsoft calls Google out over patent bullying accusations: http://t.co/FyChQdZ by @ejacqui",
    "id" : 99135414337667072,
    "created_at" : "Thu Aug 04 15:11:39 +0000 2011",
    "user" : {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "protected" : false,
      "id_str" : "717313",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2215576731/ars-logo_normal.png",
      "id" : 717313,
      "verified" : true
    }
  },
  "id" : 99155499223760896,
  "created_at" : "Thu Aug 04 16:31:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 0, 13 ],
      "id_str" : "279390084",
      "id" : 279390084
    }, {
      "name" : "Metropolitan Police",
      "screen_name" : "metpoliceuk",
      "indices" : [ 14, 26 ],
      "id_str" : "66967746",
      "id" : 66967746
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoTW",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98915358492205058",
  "geo" : {
  },
  "id_str" : "98916244224360448",
  "in_reply_to_user_id" : 279390084,
  "text" : "@YourAnonNews @metpoliceuk it's not like the entire police force got a cut of the #NoTW scandal. You don't blame a body for it's cancer.",
  "id" : 98916244224360448,
  "in_reply_to_status_id" : 98915358492205058,
  "created_at" : "Thu Aug 04 00:40:45 +0000 2011",
  "in_reply_to_screen_name" : "YourAnonNews",
  "in_reply_to_user_id_str" : "279390084",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 0, 13 ],
      "id_str" : "279390084",
      "id" : 279390084
    }, {
      "name" : "Metropolitan Police",
      "screen_name" : "metpoliceuk",
      "indices" : [ 14, 26 ],
      "id_str" : "66967746",
      "id" : 66967746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98914805208981504",
  "geo" : {
  },
  "id_str" : "98915928896573440",
  "in_reply_to_user_id" : 279390084,
  "text" : "@YourAnonNews @metpoliceuk I understand that society is not perfect but bucketing 'the police' as an evil force is counterproductive.",
  "id" : 98915928896573440,
  "in_reply_to_status_id" : 98914805208981504,
  "created_at" : "Thu Aug 04 00:39:29 +0000 2011",
  "in_reply_to_screen_name" : "YourAnonNews",
  "in_reply_to_user_id_str" : "279390084",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98857031200550913",
  "text" : "Bald eagle killed by metro bus in Seattle yesterday. There's a joke about liberals and freedom in here somewhere.",
  "id" : 98857031200550913,
  "created_at" : "Wed Aug 03 20:45:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FBI",
      "indices" : [ 32, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98794062357864449",
  "text" : "I hope this wifi SSID is a joke #FBI http://yfrog.com/h7kxllmj",
  "id" : 98794062357864449,
  "created_at" : "Wed Aug 03 16:35:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seniors",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98792685078458370",
  "text" : "Buf-Bos tickets booked for 8/25. Can't wait to get back to school. #seniors #2012",
  "id" : 98792685078458370,
  "created_at" : "Wed Aug 03 16:29:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 3, 9 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98790674190696448",
  "text" : "RT @hseas: Kit Parker on ROTC: Harvard \"is the most intellectually complex environment... our military has ever operated in\" http://t.co ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 133 ],
        "url" : "http://t.co/3olrjBi",
        "expanded_url" : "http://usat.ly/q0xkB0",
        "display_url" : "usat.ly/q0xkB0"
      } ]
    },
    "geo" : {
    },
    "id_str" : "98770547646808064",
    "text" : "Kit Parker on ROTC: Harvard \"is the most intellectually complex environment... our military has ever operated in\" http://t.co/3olrjBi",
    "id" : 98770547646808064,
    "created_at" : "Wed Aug 03 15:01:48 +0000 2011",
    "user" : {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "protected" : false,
      "id_str" : "236921052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212967976/Shield_normal.jpg",
      "id" : 236921052,
      "verified" : false
    }
  },
  "id" : 98790674190696448,
  "created_at" : "Wed Aug 03 16:21:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98562173541949441",
  "text" : "Summer is when I wrangle my inbox towards zero while allowing my \"to read\" book list to grow out of control.",
  "id" : 98562173541949441,
  "created_at" : "Wed Aug 03 01:13:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98560785495769088",
  "text" : "Any social media, stats, and/or natural language people want a job with Big Brother? http://j.mp/phA2Le",
  "id" : 98560785495769088,
  "created_at" : "Wed Aug 03 01:08:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 3, 11 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98560304132276224",
  "text" : "RT @digitil: apparently it's not common to bring your laptop with you during a fire alarm 0_0. oh well, i need this. what if there reall ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "98555390056341504",
    "text" : "apparently it's not common to bring your laptop with you during a fire alarm 0_0. oh well, i need this. what if there really was a fire?",
    "id" : 98555390056341504,
    "created_at" : "Wed Aug 03 00:46:50 +0000 2011",
    "user" : {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "protected" : false,
      "id_str" : "142513192",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1642320634/166801_1511992884964_1388640188_31084711_5921086_n_normal.jpg",
      "id" : 142513192,
      "verified" : false
    }
  },
  "id" : 98560304132276224,
  "created_at" : "Wed Aug 03 01:06:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http://t.co/y46SXXX",
      "expanded_url" : "http://dvice.com/archives/2011/08/kingdom-tower-t.php",
      "display_url" : "dvice.com/archives/2011/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98491600166072320",
  "text" : "The Kingdom Tower in Jeddah, Saudi Arabia is official. And massive. http://t.co/y46SXXX",
  "id" : 98491600166072320,
  "created_at" : "Tue Aug 02 20:33:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SAI",
      "screen_name" : "SAI",
      "indices" : [ 3, 7 ],
      "id_str" : "8841372",
      "id" : 8841372
    }, {
      "name" : "Alyson Shontell",
      "screen_name" : "shontelaylay",
      "indices" : [ 90, 103 ],
      "id_str" : "1395062234",
      "id" : 1395062234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98475730710704128",
  "text" : "RT @SAI: This 17-Year-Old Taught Himself To Code In 7 Days, Then He Got Into TechStars by @shontelaylay http://read.bi/pTMPTa",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.businessinsider.com\" rel=\"nofollow\">Business Insider</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alyson Shontell",
        "screen_name" : "shontelaylay",
        "indices" : [ 81, 94 ],
        "id_str" : "1395062234",
        "id" : 1395062234
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "98470743452557312",
    "text" : "This 17-Year-Old Taught Himself To Code In 7 Days, Then He Got Into TechStars by @shontelaylay http://read.bi/pTMPTa",
    "id" : 98470743452557312,
    "created_at" : "Tue Aug 02 19:10:29 +0000 2011",
    "user" : {
      "name" : "SAI",
      "screen_name" : "SAI",
      "protected" : false,
      "id_str" : "8841372",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1227602539/bi-sai_normal.png",
      "id" : 8841372,
      "verified" : false
    }
  },
  "id" : 98475730710704128,
  "created_at" : "Tue Aug 02 19:30:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hodinkee.com",
      "screen_name" : "HODINKEE",
      "indices" : [ 0, 9 ],
      "id_str" : "20568189",
      "id" : 20568189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womw",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98468673488039936",
  "in_reply_to_user_id" : 20568189,
  "text" : "@HODINKEE Seagull 1963 for me today #womw http://yfrog.com/h0z94muj",
  "id" : 98468673488039936,
  "created_at" : "Tue Aug 02 19:02:15 +0000 2011",
  "in_reply_to_screen_name" : "HODINKEE",
  "in_reply_to_user_id_str" : "20568189",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VANITY FAIR",
      "screen_name" : "VanityFair",
      "indices" : [ 3, 14 ],
      "id_str" : "15279429",
      "id" : 15279429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98429745309552640",
  "text" : "RT @VanityFair: The Dog Who Killed Bin Laden Would Make a Pretty Good Republican Congressional Candidate http://vnty.fr/rlUhwD",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "98375109156413441",
    "text" : "The Dog Who Killed Bin Laden Would Make a Pretty Good Republican Congressional Candidate http://vnty.fr/rlUhwD",
    "id" : 98375109156413441,
    "created_at" : "Tue Aug 02 12:50:28 +0000 2011",
    "user" : {
      "name" : "VANITY FAIR",
      "screen_name" : "VanityFair",
      "protected" : false,
      "id_str" : "15279429",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2908227317/64fda6ce2c8b39450a725b829c84990e_normal.png",
      "id" : 15279429,
      "verified" : true
    }
  },
  "id" : 98429745309552640,
  "created_at" : "Tue Aug 02 16:27:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98188896294289408",
  "text" : "Catching a carpool ride with Irish startup Avego! We'll see how this ride sharing goes :)",
  "id" : 98188896294289408,
  "created_at" : "Tue Aug 02 00:30:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]