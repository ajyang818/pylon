Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FedEx",
      "screen_name" : "FedEx",
      "indices" : [ 0, 6 ],
      "id_str" : "134887156",
      "id" : 134887156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75751216138821632",
  "text" : "@fedex provides no way to override signature on delivery even if you prove identity as shipper... meaning 2-day express is a 5 days late",
  "id" : 75751216138821632,
  "created_at" : "Wed Jun 01 02:31:11 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard SEAS",
      "screen_name" : "hseas",
      "indices" : [ 21, 27 ],
      "id_str" : "236921052",
      "id" : 236921052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http://t.co/X0PxqSP",
      "expanded_url" : "http://bit.ly/mlDimT",
      "display_url" : "bit.ly/mlDimT"
    } ]
  },
  "geo" : {
  },
  "id_str" : "75610452008239105",
  "text" : "Photo credit plz! RT @hseas: [Photos] Hack nights at Harvard http://t.co/X0PxqSP",
  "id" : 75610452008239105,
  "created_at" : "Tue May 31 17:11:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "_Eric_Chen",
      "indices" : [ 0, 11 ],
      "id_str" : "21061803",
      "id" : 21061803
    }, {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 12, 24 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75402178654765056",
  "geo" : {
  },
  "id_str" : "75440976985989120",
  "in_reply_to_user_id" : 21061803,
  "text" : "@_Eric_Chen @alishalisha I miss harvard SSP so much! Eric and I went back to proctor last year.",
  "id" : 75440976985989120,
  "in_reply_to_status_id" : 75402178654765056,
  "created_at" : "Tue May 31 05:58:25 +0000 2011",
  "in_reply_to_screen_name" : "_Eric_Chen",
  "in_reply_to_user_id_str" : "21061803",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75440356992352256",
  "text" : "Spaghetti, siracha, marinara, and bacon mess for dinner. I should appreciate my parents more for the 18 years of meals they made me.",
  "id" : 75440356992352256,
  "created_at" : "Tue May 31 05:55:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75255204022452225",
  "text" : "Day 3 in seattle: longboard shopping and a film festival.",
  "id" : 75255204022452225,
  "created_at" : "Mon May 30 17:40:13 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "indices" : [ 3, 7 ],
      "id_str" : "105192845",
      "id" : 105192845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75071461378891776",
  "text" : "RT @TNW: China admits existence of a cyber-warfare team called \u201CBlue Army\u201D http://tnw.co/lEoUZU",
  "retweeted_status" : {
    "source" : "<a href=\"http://dlvr.it\" rel=\"nofollow\">dlvr.it</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "75044527949352960",
    "text" : "China admits existence of a cyber-warfare team called \u201CBlue Army\u201D http://tnw.co/lEoUZU",
    "id" : 75044527949352960,
    "created_at" : "Mon May 30 03:43:04 +0000 2011",
    "user" : {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "protected" : false,
      "id_str" : "105192845",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1135834058/tnw-top-stories_normal.jpg",
      "id" : 105192845,
      "verified" : false
    }
  },
  "id" : 75071461378891776,
  "created_at" : "Mon May 30 05:30:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio",
      "screen_name" : "antrod",
      "indices" : [ 0, 7 ],
      "id_str" : "464493",
      "id" : 464493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74943410963877888",
  "geo" : {
  },
  "id_str" : "74955067886800896",
  "in_reply_to_user_id" : 464493,
  "text" : "@antrod dead-tree books will never exit my life. Dropped my iPhone too many times to trust myself using ereaders in the bathroom.",
  "id" : 74955067886800896,
  "in_reply_to_status_id" : 74943410963877888,
  "created_at" : "Sun May 29 21:47:35 +0000 2011",
  "in_reply_to_screen_name" : "antrod",
  "in_reply_to_user_id_str" : "464493",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74662572749623297",
  "text" : "Apparently theres NO citizens bank in Seattle?",
  "id" : 74662572749623297,
  "created_at" : "Sun May 29 02:25:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http://t.co/XKDkqtf",
      "expanded_url" : "http://yfrog.com/gz2q8xrj",
      "display_url" : "yfrog.com/gz2q8xrj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "74570592061370368",
  "text" : "Moved into Seattle! http://t.co/XKDkqtf",
  "id" : 74570592061370368,
  "created_at" : "Sat May 28 20:19:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74541954477731840",
  "text" : "Passed a car chalked with \"we love the Blue Angels!\" - I haven't gotten to see them yet :(",
  "id" : 74541954477731840,
  "created_at" : "Sat May 28 18:26:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74440248507105280",
  "text" : "The irony of me being banned from Amazon while using an iPhone in an Airbus going to Seattle is not lost on me.",
  "id" : 74440248507105280,
  "created_at" : "Sat May 28 11:41:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inefficient",
      "indices" : [ 89, 101 ]
    }, {
      "text" : "thingsthatpissmeoff",
      "indices" : [ 102, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74427014211305473",
  "text" : "Also people cutting it close to flights should have to pay a fee for expedited security. #inefficient #thingsthatpissmeoff",
  "id" : 74427014211305473,
  "created_at" : "Sat May 28 10:49:17 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WTF",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74425589058109440",
  "text" : "1 standard dev overweight person with 50lb bag still adds more deadweight to plane than me + my 57lb bag... But I have to pay $50 #WTF",
  "id" : 74425589058109440,
  "created_at" : "Sat May 28 10:43:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JetBlue Airways",
      "screen_name" : "JetBlue",
      "indices" : [ 19, 27 ],
      "id_str" : "6449282",
      "id" : 6449282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74425168654643200",
  "text" : "Dumb luggage rules @jetblue - to optimize profit limit total weight including person - otherwise save us the hassle of removing 5lbs clothes",
  "id" : 74425168654643200,
  "created_at" : "Sat May 28 10:41:57 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74417000427950080",
  "geo" : {
  },
  "id_str" : "74421760346431488",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee it was a jquery-mobile site that aggregated social buying deals based on city! I'm at Boston airport headed for Seattle",
  "id" : 74421760346431488,
  "in_reply_to_status_id" : 74417000427950080,
  "created_at" : "Sat May 28 10:28:25 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74407259123363840",
  "geo" : {
  },
  "id_str" : "74416064703893504",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee my CS179 project name was named Bundlr!",
  "id" : 74416064703893504,
  "in_reply_to_status_id" : 74407259123363840,
  "created_at" : "Sat May 28 10:05:47 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74312616482312193",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce thanks for the turntable invite, but mine's breaking in Mac chrome!",
  "id" : 74312616482312193,
  "created_at" : "Sat May 28 03:14:43 +0000 2011",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Taussig",
      "screen_name" : "ataussig",
      "indices" : [ 1, 10 ],
      "id_str" : "22097962",
      "id" : 22097962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74197785276186624",
  "text" : "\u201C@ataussig: \"Software is one of only two industries that refers to its customers as users.\"\u201D - Internet withdrawal is an ugly ugly thing.",
  "id" : 74197785276186624,
  "created_at" : "Fri May 27 19:38:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74197526714130432",
  "text" : "Cambridge went from stormy 40s to humid and mosquitos in 3 days. #wtf",
  "id" : 74197526714130432,
  "created_at" : "Fri May 27 19:37:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74196627581186048",
  "geo" : {
  },
  "id_str" : "74197027071856640",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern meebo is pretty good, but there's no REALLY good chat support for iPhone",
  "id" : 74197027071856640,
  "in_reply_to_status_id" : 74196627581186048,
  "created_at" : "Fri May 27 19:35:24 +0000 2011",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "indices" : [ 3, 9 ],
      "id_str" : "14782518",
      "id" : 14782518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74184591795175424",
  "text" : "RT @cltom: Too bad: data.gov is being shut down http://wapo.st/lXuRr3",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.brizzly.com\" rel=\"nofollow\">Brizzly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "74118647345446914",
    "text" : "Too bad: data.gov is being shut down http://wapo.st/lXuRr3",
    "id" : 74118647345446914,
    "created_at" : "Fri May 27 14:23:57 +0000 2011",
    "user" : {
      "name" : "Christian L. Tom",
      "screen_name" : "cltom",
      "protected" : false,
      "id_str" : "14782518",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2908096260/d10e7982fa92f0bf560a50a76d76e392_normal.png",
      "id" : 14782518,
      "verified" : false
    }
  },
  "id" : 74184591795175424,
  "created_at" : "Fri May 27 18:45:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "indices" : [ 3, 7 ],
      "id_str" : "105192845",
      "id" : 105192845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73829523434651648",
  "text" : "RT @TNW: Amazon launches Mac Store competitor: Mac Download Store http://tnw.co/kjFXyB",
  "retweeted_status" : {
    "source" : "<a href=\"http://dlvr.it\" rel=\"nofollow\">dlvr.it</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "73811900168802304",
    "text" : "Amazon launches Mac Store competitor: Mac Download Store http://tnw.co/kjFXyB",
    "id" : 73811900168802304,
    "created_at" : "Thu May 26 18:05:03 +0000 2011",
    "user" : {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "protected" : false,
      "id_str" : "105192845",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1135834058/tnw-top-stories_normal.jpg",
      "id" : 105192845,
      "verified" : false
    }
  },
  "id" : 73829523434651648,
  "created_at" : "Thu May 26 19:15:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvard",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73798106885525504",
  "text" : "Bittersweet moment as the #harvard class of 2011 walks. We'll miss you!",
  "id" : 73798106885525504,
  "created_at" : "Thu May 26 17:10:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 3, 17 ],
      "id_str" : "16005250",
      "id" : 16005250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73671651333644288",
  "text" : "RT @angryasianman: Who invented bubble tea? This woman, apparently: http://bit.ly/jhk39M",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "73533227389816832",
    "text" : "Who invented bubble tea? This woman, apparently: http://bit.ly/jhk39M",
    "id" : 73533227389816832,
    "created_at" : "Wed May 25 23:37:42 +0000 2011",
    "user" : {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "protected" : false,
      "id_str" : "16005250",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/60849027/n636101424_111915_8115_normal.jpg",
      "id" : 16005250,
      "verified" : false
    }
  },
  "id" : 73671651333644288,
  "created_at" : "Thu May 26 08:47:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 38 ],
      "url" : "http://t.co/jiA8uDg",
      "expanded_url" : "http://yfrog.com/h2cmdriwj",
      "display_url" : "yfrog.com/h2cmdriwj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "73476376665128961",
  "text" : "Harvard class day! http://t.co/jiA8uDg",
  "id" : 73476376665128961,
  "created_at" : "Wed May 25 19:51:47 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73198840307646464",
  "text" : "Theres a circle in hell for people that insist on faxing.",
  "id" : 73198840307646464,
  "created_at" : "Wed May 25 01:28:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http://t.co/cgtBDJS",
      "expanded_url" : "http://yfrog.com/h8l2pkhj",
      "display_url" : "yfrog.com/h8l2pkhj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "73093358817513472",
  "text" : "RT @HarvardCSA: Congratulations to former CSA presidents Dan and Lisa on their engagement! http://t.co/cgtBDJS",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 94 ],
        "url" : "http://t.co/cgtBDJS",
        "expanded_url" : "http://yfrog.com/h8l2pkhj",
        "display_url" : "yfrog.com/h8l2pkhj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "73093208594329600",
    "text" : "Congratulations to former CSA presidents Dan and Lisa on their engagement! http://t.co/cgtBDJS",
    "id" : 73093208594329600,
    "created_at" : "Tue May 24 18:29:13 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 73093358817513472,
  "created_at" : "Tue May 24 18:29:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "indices" : [ 3, 12 ],
      "id_str" : "13982132",
      "id" : 13982132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72724743597469696",
  "text" : "RT @medialab: Data Privacy Is Your Problem (or Asset):  http://on.wsj.com/jiarxO",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "72717231968096256",
    "text" : "Data Privacy Is Your Problem (or Asset):  http://on.wsj.com/jiarxO",
    "id" : 72717231968096256,
    "created_at" : "Mon May 23 17:35:13 +0000 2011",
    "user" : {
      "name" : "MIT Media Lab",
      "screen_name" : "medialab",
      "protected" : false,
      "id_str" : "13982132",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2611389609/kk361c71bj3fmyu0aee6_normal.jpeg",
      "id" : 13982132,
      "verified" : true
    }
  },
  "id" : 72724743597469696,
  "created_at" : "Mon May 23 18:05:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony DeVincenzi",
      "screen_name" : "tonydevincenzi",
      "indices" : [ 0, 15 ],
      "id_str" : "10425532",
      "id" : 10425532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72431009265758208",
  "geo" : {
  },
  "id_str" : "72439598126612481",
  "in_reply_to_user_id" : 10425532,
  "text" : "@tonydevincenzi hope you didn't overpay! They're $20 at BN",
  "id" : 72439598126612481,
  "in_reply_to_status_id" : 72431009265758208,
  "created_at" : "Sun May 22 23:12:00 +0000 2011",
  "in_reply_to_screen_name" : "tonydevincenzi",
  "in_reply_to_user_id_str" : "10425532",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 3, 15 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72414576620224512",
  "text" : "RT @alishalisha: UUhhhhh I can't wait for Senior Week 2012.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "72413535493296128",
    "text" : "UUhhhhh I can't wait for Senior Week 2012.",
    "id" : 72413535493296128,
    "created_at" : "Sun May 22 21:28:26 +0000 2011",
    "user" : {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "protected" : false,
      "id_str" : "15101900",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1746276803/Picture_10_normal.png",
      "id" : 15101900,
      "verified" : false
    }
  },
  "id" : 72414576620224512,
  "created_at" : "Sun May 22 21:32:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Tang",
      "screen_name" : "tangykat",
      "indices" : [ 19, 28 ],
      "id_str" : "282642031",
      "id" : 282642031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72414156288032768",
  "text" : "Going shooting? RT @tangykat: Its glock time!",
  "id" : 72414156288032768,
  "created_at" : "Sun May 22 21:30:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayumi Yu",
      "screen_name" : "colour",
      "indices" : [ 3, 10 ],
      "id_str" : "52940903",
      "id" : 52940903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makerfaire",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http://t.co/Ro3IhcH",
      "expanded_url" : "http://twitpic.com/50t8f4",
      "display_url" : "twitpic.com/50t8f4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "72108318235172864",
  "text" : "RT @colour: Best license plates EVER, spotted at #makerfaire http://t.co/Ro3IhcH",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "makerfaire",
        "indices" : [ 37, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 68 ],
        "url" : "http://t.co/Ro3IhcH",
        "expanded_url" : "http://twitpic.com/50t8f4",
        "display_url" : "twitpic.com/50t8f4"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.54359517, -122.29218874 ]
    },
    "id_str" : "72102394615447552",
    "text" : "Best license plates EVER, spotted at #makerfaire http://t.co/Ro3IhcH",
    "id" : 72102394615447552,
    "created_at" : "Sun May 22 00:52:05 +0000 2011",
    "user" : {
      "name" : "Ayumi Yu",
      "screen_name" : "colour",
      "protected" : false,
      "id_str" : "52940903",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3210715553/dd532c8b88fbd0c2f8054a8f2300f6ce_normal.png",
      "id" : 52940903,
      "verified" : false
    }
  },
  "id" : 72108318235172864,
  "created_at" : "Sun May 22 01:15:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa",
      "screen_name" : "aistern",
      "indices" : [ 0, 8 ],
      "id_str" : "45038875",
      "id" : 45038875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71977333606715392",
  "geo" : {
  },
  "id_str" : "72012217284964352",
  "in_reply_to_user_id" : 45038875,
  "text" : "@aistern grooveshark is available only if you jailbreak!",
  "id" : 72012217284964352,
  "in_reply_to_status_id" : 71977333606715392,
  "created_at" : "Sat May 21 18:53:45 +0000 2011",
  "in_reply_to_screen_name" : "aistern",
  "in_reply_to_user_id_str" : "45038875",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://taptaptap.com/camera+\" rel=\"nofollow\">Camera+</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 18, 26 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3738594214, -71.1162090954 ]
  },
  "id_str" : "72010284876828672",
  "text" : "Getting ready for @Harvard commencement! http://campl.us/bb9a",
  "id" : 72010284876828672,
  "created_at" : "Sat May 21 18:46:04 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71672214818275328",
  "text" : "Cambridge is finally beautiful again. Just in time for the weekend!",
  "id" : 71672214818275328,
  "created_at" : "Fri May 20 20:22:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "citizen lab",
      "screen_name" : "citizenlab",
      "indices" : [ 8, 19 ],
      "id_str" : "35341530",
      "id" : 35341530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http://t.co/G89dasi",
      "expanded_url" : "http://bit.ly/ldIqP3",
      "display_url" : "bit.ly/ldIqP3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "71362199775481857",
  "text" : "Wut? RT @citizenlab: Norwegian military under major DDoS attack http://t.co/G89dasi\u201D",
  "id" : 71362199775481857,
  "created_at" : "Thu May 19 23:50:48 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cult of Mac",
      "screen_name" : "cultofmac",
      "indices" : [ 3, 13 ],
      "id_str" : "9688342",
      "id" : 9688342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71296674470965249",
  "text" : "RT @cultofmac: New post: Verizon CFO Confirms That iPhone 5 Will Work On Any Network http://bit.ly/lnAgIl",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.cultofmac.com\" rel=\"nofollow\">Cult of Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "71285496164257792",
    "text" : "New post: Verizon CFO Confirms That iPhone 5 Will Work On Any Network http://bit.ly/lnAgIl",
    "id" : 71285496164257792,
    "created_at" : "Thu May 19 18:46:01 +0000 2011",
    "user" : {
      "name" : "Cult of Mac",
      "screen_name" : "cultofmac",
      "protected" : false,
      "id_str" : "9688342",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1827297831/tinsy_normal.jpg",
      "id" : 9688342,
      "verified" : false
    }
  },
  "id" : 71296674470965249,
  "created_at" : "Thu May 19 19:30:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft News",
      "screen_name" : "MSFTnews",
      "indices" : [ 11, 20 ],
      "id_str" : "24741685",
      "id" : 24741685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http://t.co/0eqWBFW",
      "expanded_url" : "http://bit.ly/iUoB1B",
      "display_url" : "bit.ly/iUoB1B"
    } ]
  },
  "geo" : {
  },
  "id_str" : "71278041829085185",
  "text" : "finally RT @MSFTnews: Windows Phone on Verizon - Verizon HTC Trophy on sale May 26 at Verizon site http://t.co/0eqWBFW",
  "id" : 71278041829085185,
  "created_at" : "Thu May 19 18:16:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spring",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 52 ],
      "url" : "http://t.co/xhDsOAe",
      "expanded_url" : "http://yfrog.com/h2dacifwj",
      "display_url" : "yfrog.com/h2dacifwj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "71275396708052992",
  "text" : "WTF cambridge seriously? #spring http://t.co/xhDsOAe",
  "id" : 71275396708052992,
  "created_at" : "Thu May 19 18:05:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipo",
      "indices" : [ 41, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71265755164966913",
  "text" : "So... Does anyone actually USE LinkedIn? #ipo",
  "id" : 71265755164966913,
  "created_at" : "Thu May 19 17:27:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 0, 14 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71037166469386240",
  "in_reply_to_user_id" : 16303106,
  "text" : "@StephenAtHome ripping Amy Kremer aparton The Report",
  "id" : 71037166469386240,
  "created_at" : "Thu May 19 02:19:14 +0000 2011",
  "in_reply_to_screen_name" : "StephenAtHome",
  "in_reply_to_user_id_str" : "16303106",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyanogen",
      "screen_name" : "cyanogen",
      "indices" : [ 0, 9 ],
      "id_str" : "8131122",
      "id" : 8131122
    }, {
      "name" : "\u265A Calvin McEachron",
      "screen_name" : "digitil",
      "indices" : [ 51, 59 ],
      "id_str" : "142513192",
      "id" : 142513192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71029726944301056",
  "in_reply_to_user_id" : 8131122,
  "text" : "@cyanogen supporting Galaxy S devices. Get on that @digitil!",
  "id" : 71029726944301056,
  "created_at" : "Thu May 19 01:49:41 +0000 2011",
  "in_reply_to_screen_name" : "cyanogen",
  "in_reply_to_user_id_str" : "8131122",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 0, 8 ],
      "id_str" : "86144785",
      "id" : 86144785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71005194133049344",
  "geo" : {
  },
  "id_str" : "71029333552140288",
  "in_reply_to_user_id" : 86144785,
  "text" : "@xobabyb Chengdu hot pot would really hit the spot. Take lots of pictures too!",
  "id" : 71029333552140288,
  "in_reply_to_status_id" : 71005194133049344,
  "created_at" : "Thu May 19 01:48:07 +0000 2011",
  "in_reply_to_screen_name" : "xobabyb",
  "in_reply_to_user_id_str" : "86144785",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 0, 8 ],
      "id_str" : "86144785",
      "id" : 86144785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70985909918633984",
  "geo" : {
  },
  "id_str" : "70990188175835136",
  "in_reply_to_user_id" : 86144785,
  "text" : "@xobabyb incredibly jealous that you're on hong kong. Eat lots for me.",
  "id" : 70990188175835136,
  "in_reply_to_status_id" : 70985909918633984,
  "created_at" : "Wed May 18 23:12:34 +0000 2011",
  "in_reply_to_screen_name" : "xobabyb",
  "in_reply_to_user_id_str" : "86144785",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 3, 16 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70957171906584576",
  "text" : "RT @kevinmitnick: My offer still stands: If Sony wants some security help, I am here :-)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70929052122361856",
    "text" : "My offer still stands: If Sony wants some security help, I am here :-)",
    "id" : 70929052122361856,
    "created_at" : "Wed May 18 19:09:38 +0000 2011",
    "user" : {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "protected" : false,
      "id_str" : "14666934",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/53807085/Mitnick_Color_normal.jpg",
      "id" : 14666934,
      "verified" : true
    }
  },
  "id" : 70957171906584576,
  "created_at" : "Wed May 18 21:01:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Biz Review",
      "screen_name" : "HarvardBiz",
      "indices" : [ 3, 14 ],
      "id_str" : "14800270",
      "id" : 14800270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70921692079337472",
  "text" : "RT @HarvardBiz: Don't Sell Your Soul, Market It http://s.hbr.org/lK73Gh",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70913519511543808",
    "text" : "Don't Sell Your Soul, Market It http://s.hbr.org/lK73Gh",
    "id" : 70913519511543808,
    "created_at" : "Wed May 18 18:07:55 +0000 2011",
    "user" : {
      "name" : "Harvard Biz Review",
      "screen_name" : "HarvardBiz",
      "protected" : false,
      "id_str" : "14800270",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/661586716/favicon_64_normal.png",
      "id" : 14800270,
      "verified" : true
    }
  },
  "id" : 70921692079337472,
  "created_at" : "Wed May 18 18:40:23 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon",
      "screen_name" : "bc3tech",
      "indices" : [ 0, 8 ],
      "id_str" : "254162335",
      "id" : 254162335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70507466953195520",
  "geo" : {
  },
  "id_str" : "70902960552546304",
  "in_reply_to_user_id" : 254162335,
  "text" : "@bc3tech HTC is pretty good about expandable memory though!",
  "id" : 70902960552546304,
  "in_reply_to_status_id" : 70507466953195520,
  "created_at" : "Wed May 18 17:25:57 +0000 2011",
  "in_reply_to_screen_name" : "bc3tech",
  "in_reply_to_user_id_str" : "254162335",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70899954922692609",
  "text" : "PSN hacked again. Poor Sony.",
  "id" : 70899954922692609,
  "created_at" : "Wed May 18 17:14:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "indices" : [ 3, 11 ],
      "id_str" : "38399009",
      "id" : 38399009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70899782561972224",
  "text" : "RT @bznotes: Prof at MIT: \"There are 4 types of technologies. Hardware, software, wetware, vaporware. Not all claims are true, you know?\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70896805440798720",
    "text" : "Prof at MIT: \"There are 4 types of technologies. Hardware, software, wetware, vaporware. Not all claims are true, you know?\"",
    "id" : 70896805440798720,
    "created_at" : "Wed May 18 17:01:30 +0000 2011",
    "user" : {
      "name" : "Bilal Zuberi",
      "screen_name" : "bznotes",
      "protected" : false,
      "id_str" : "38399009",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3533284802/8d7bfe9ec4e35adeefd3a77fa9382e8d_normal.jpeg",
      "id" : 38399009,
      "verified" : false
    }
  },
  "id" : 70899782561972224,
  "created_at" : "Wed May 18 17:13:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 35, 47 ],
      "id_str" : "110823121",
      "id" : 110823121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70730511957508096",
  "text" : "Aren't you glad you listened to me @badboyboyce Re: new MacBook airs in June/July",
  "id" : 70730511957508096,
  "created_at" : "Wed May 18 06:00:42 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Francis Tan \uF8FF",
      "screen_name" : "francistan",
      "indices" : [ 118, 129 ],
      "id_str" : "16668321",
      "id" : 16668321
    }, {
      "name" : "Babak",
      "screen_name" : "TN",
      "indices" : [ 133, 136 ],
      "id_str" : "1188301",
      "id" : 1188301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70730050844110848",
  "text" : "RT @TheNextWeb: New MacBook Airs with Thunderbolt and Sandy Bridge to be launched in June-July http://tnw.to/18LqC by @francistan on @TN ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Francis Tan \uF8FF",
        "screen_name" : "francistan",
        "indices" : [ 102, 113 ],
        "id_str" : "16668321",
        "id" : 16668321
      }, {
        "name" : "TNW's Apple Channel",
        "screen_name" : "TNWapple",
        "indices" : [ 117, 126 ],
        "id_str" : "90745047",
        "id" : 90745047
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70711152174301186",
    "text" : "New MacBook Airs with Thunderbolt and Sandy Bridge to be launched in June-July http://tnw.to/18LqC by @francistan on @TNWapple",
    "id" : 70711152174301186,
    "created_at" : "Wed May 18 04:43:47 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 70730050844110848,
  "created_at" : "Wed May 18 05:58:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Alex Wilhelm",
      "screen_name" : "alex",
      "indices" : [ 100, 105 ],
      "id_str" : "7380362",
      "id" : 7380362
    }, {
      "name" : "TNW Microsoft",
      "screen_name" : "TNWmicrosoft",
      "indices" : [ 109, 122 ],
      "id_str" : "127874471",
      "id" : 127874471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70668547331854336",
  "text" : "RT @TheNextWeb: The Mango update to WP7 is set to revolutionize the platform http://tnw.to/18L80 by @Alex on @TNWmicrosoft",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Wilhelm",
        "screen_name" : "alex",
        "indices" : [ 84, 89 ],
        "id_str" : "7380362",
        "id" : 7380362
      }, {
        "name" : "TNW Microsoft",
        "screen_name" : "TNWmicrosoft",
        "indices" : [ 93, 106 ],
        "id_str" : "127874471",
        "id" : 127874471
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70602666815922176",
    "text" : "The Mango update to WP7 is set to revolutionize the platform http://tnw.to/18L80 by @Alex on @TNWmicrosoft",
    "id" : 70602666815922176,
    "created_at" : "Tue May 17 21:32:42 +0000 2011",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 70668547331854336,
  "created_at" : "Wed May 18 01:54:29 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tana Jambaldorj",
      "screen_name" : "tanajambaldorj",
      "indices" : [ 0, 15 ],
      "id_str" : "281189476",
      "id" : 281189476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70598013822828544",
  "geo" : {
  },
  "id_str" : "70598202314858496",
  "in_reply_to_user_id" : 281189476,
  "text" : "@tanajambaldorj I'm here for commencement! What iPhone/provider are you using?",
  "id" : 70598202314858496,
  "in_reply_to_status_id" : 70598013822828544,
  "created_at" : "Tue May 17 21:14:57 +0000 2011",
  "in_reply_to_screen_name" : "tanajambaldorj",
  "in_reply_to_user_id_str" : "281189476",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa Wu ",
      "screen_name" : "resawu",
      "indices" : [ 0, 7 ],
      "id_str" : "14732370",
      "id" : 14732370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70584263342432256",
  "geo" : {
  },
  "id_str" : "70586891392647168",
  "in_reply_to_user_id" : 14732370,
  "text" : "@resawu make it custom shortcuts and I'm sold too! #nerdtweet",
  "id" : 70586891392647168,
  "in_reply_to_status_id" : 70584263342432256,
  "created_at" : "Tue May 17 20:30:01 +0000 2011",
  "in_reply_to_screen_name" : "resawu",
  "in_reply_to_user_id_str" : "14732370",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VANITY FAIR",
      "screen_name" : "VanityFair",
      "indices" : [ 3, 14 ],
      "id_str" : "15279429",
      "id" : 15279429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70583444186464256",
  "text" : "RT @VanityFair: Finding Nemo and Bin Laden: Disney Files to Trademark Navy SEALs Team Six Logo http://bit.ly/lYuutB",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70582027631599616",
    "text" : "Finding Nemo and Bin Laden: Disney Files to Trademark Navy SEALs Team Six Logo http://bit.ly/lYuutB",
    "id" : 70582027631599616,
    "created_at" : "Tue May 17 20:10:41 +0000 2011",
    "user" : {
      "name" : "VANITY FAIR",
      "screen_name" : "VanityFair",
      "protected" : false,
      "id_str" : "15279429",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2908227317/64fda6ce2c8b39450a725b829c84990e_normal.png",
      "id" : 15279429,
      "verified" : true
    }
  },
  "id" : 70583444186464256,
  "created_at" : "Tue May 17 20:16:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa Wu ",
      "screen_name" : "resawu",
      "indices" : [ 44, 51 ],
      "id_str" : "14732370",
      "id" : 14732370
    }, {
      "name" : "Googletest",
      "screen_name" : "googledocs",
      "indices" : [ 77, 88 ],
      "id_str" : "488683847",
      "id" : 488683847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http://t.co/vVC4IBk",
      "expanded_url" : "http://goo.gl/TCwFs",
      "display_url" : "goo.gl/TCwFs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "70582639765102593",
  "text" : "My banker friends are going to love this RT @resawu: pivot tables are now in @GoogleDocs spreadsheets! http://t.co/vVC4IBk",
  "id" : 70582639765102593,
  "created_at" : "Tue May 17 20:13:07 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70579950964580352",
  "text" : "RT @Gizmodo: ZOMG HOW CAN THIS REALLY BE A PHOTOGRAPH?! Looks like a drawing from a children's book. http://gizmo.do/koKMal",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70575210839015424",
    "text" : "ZOMG HOW CAN THIS REALLY BE A PHOTOGRAPH?! Looks like a drawing from a children's book. http://gizmo.do/koKMal",
    "id" : 70575210839015424,
    "created_at" : "Tue May 17 19:43:36 +0000 2011",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1860214036/Gizmodo-Twitter-Avatar_normal.jpeg",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 70579950964580352,
  "created_at" : "Tue May 17 20:02:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70554714365886464",
  "text" : "Apple to make \"nano\"-SIM? Sounds like a pain in the ass for travellers.",
  "id" : 70554714365886464,
  "created_at" : "Tue May 17 18:22:09 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 48 ],
      "url" : "http://t.co/mWaeOUW",
      "expanded_url" : "http://centralnj.ebayclassifieds.com/cell-phones/iselin/verizon-htc-trophy-7-windows-phone-new-global/?ad=11332864",
      "display_url" : "centralnj.ebayclassifieds.com/cell-phones/is\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "70399031347658752",
  "text" : "Wow, Verizon WP7 phone leak? http://t.co/mWaeOUW",
  "id" : 70399031347658752,
  "created_at" : "Tue May 17 08:03:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70285768475676672",
  "text" : "Anyone have strong opinions on Alienware m11x versus Lenovo x220 or x1? Need a windows comp in my life.",
  "id" : 70285768475676672,
  "created_at" : "Tue May 17 00:33:27 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70257895937282048",
  "geo" : {
  },
  "id_str" : "70258427108134912",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee hitting up Les with some friends at 7. Are you free? Otherwise I am down down for dinner #2 when you are!",
  "id" : 70258427108134912,
  "in_reply_to_status_id" : 70257895937282048,
  "created_at" : "Mon May 16 22:44:49 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70218370095656961",
  "geo" : {
  },
  "id_str" : "70256273341427712",
  "in_reply_to_user_id" : 16573515,
  "text" : "@scottisasian \"Brothers\" by Yu Hua. He actually lived in Cambridge for a bit! It's a very heavy story. Def teared up reading it.",
  "id" : 70256273341427712,
  "in_reply_to_status_id" : 70218370095656961,
  "created_at" : "Mon May 16 22:36:15 +0000 2011",
  "in_reply_to_screen_name" : "thenscottsaid",
  "in_reply_to_user_id_str" : "16573515",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    }, {
      "name" : "Naveen Srivatsa",
      "screen_name" : "NaveenSrivatsa",
      "indices" : [ 99, 114 ],
      "id_str" : "18107808",
      "id" : 18107808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70188094183325696",
  "geo" : {
  },
  "id_str" : "70255879420772352",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha I would keep one if it was free, but honestly it was more frustrating than useful cc/ @NaveenSrivatsa",
  "id" : 70255879420772352,
  "in_reply_to_status_id" : 70188094183325696,
  "created_at" : "Mon May 16 22:34:41 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 0, 10 ],
      "id_str" : "1976841",
      "id" : 1976841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70224878653018112",
  "geo" : {
  },
  "id_str" : "70254651458596864",
  "in_reply_to_user_id" : 1976841,
  "text" : "@jenny8lee back on campus?",
  "id" : 70254651458596864,
  "in_reply_to_status_id" : 70224878653018112,
  "created_at" : "Mon May 16 22:29:48 +0000 2011",
  "in_reply_to_screen_name" : "jenny8lee",
  "in_reply_to_user_id_str" : "1976841",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hobby",
      "screen_name" : "strobist",
      "indices" : [ 3, 12 ],
      "id_str" : "14305530",
      "id" : 14305530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70253909641404416",
  "text" : "RT @strobist: The immutable law of great photogrphy: f/8 and Be There. http://gaw.kr/jvkMve",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70202140957736960",
    "text" : "The immutable law of great photogrphy: f/8 and Be There. http://gaw.kr/jvkMve",
    "id" : 70202140957736960,
    "created_at" : "Mon May 16 19:01:09 +0000 2011",
    "user" : {
      "name" : "David Hobby",
      "screen_name" : "strobist",
      "protected" : false,
      "id_str" : "14305530",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1771314706/image1327173868_normal.png",
      "id" : 14305530,
      "verified" : true
    }
  },
  "id" : 70253909641404416,
  "created_at" : "Mon May 16 22:26:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70180918173769728",
  "geo" : {
  },
  "id_str" : "70184332676964352",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha Would rather have a smartphone + fast laptop than one mediocre laptop",
  "id" : 70184332676964352,
  "in_reply_to_status_id" : 70180918173769728,
  "created_at" : "Mon May 16 17:50:23 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Ramos",
      "screen_name" : "alishalisha",
      "indices" : [ 0, 12 ],
      "id_str" : "15101900",
      "id" : 15101900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70180918173769728",
  "geo" : {
  },
  "id_str" : "70184273348534272",
  "in_reply_to_user_id" : 15101900,
  "text" : "@alishalisha chromebooks were really limiting and claustrophobic! I ended up selling mine...",
  "id" : 70184273348534272,
  "in_reply_to_status_id" : 70180918173769728,
  "created_at" : "Mon May 16 17:50:09 +0000 2011",
  "in_reply_to_screen_name" : "alishalisha",
  "in_reply_to_user_id_str" : "15101900",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http://t.co/lZXVbMa",
      "expanded_url" : "http://www.everydaynodaysoff.com/2011/05/16/disney-trademarks-seal-team-6/",
      "display_url" : "everydaynodaysoff.com/2011/05/16/dis\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "70160720972615682",
  "text" : "Disney trademarks \"SEAL Team 6\" http://t.co/lZXVbMa",
  "id" : 70160720972615682,
  "created_at" : "Mon May 16 16:16:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70153057064853504",
  "text" : "Wow, HootSuite emails don't have an unsubscribe link. Party Foul.",
  "id" : 70153057064853504,
  "created_at" : "Mon May 16 15:46:06 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "GlobalAsianista",
      "indices" : [ 0, 16 ],
      "id_str" : "228489296",
      "id" : 228489296
    }, {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 17, 23 ],
      "id_str" : "49019553",
      "id" : 49019553
    }, {
      "name" : "Vivian Lee",
      "screen_name" : "viverzz",
      "indices" : [ 24, 32 ],
      "id_str" : "26429725",
      "id" : 26429725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70123550249467905",
  "geo" : {
  },
  "id_str" : "70128136649580545",
  "in_reply_to_user_id" : 228489296,
  "text" : "@GlobalAsianista @mjoyw @viverzz I saw that! Should be an interesting year.",
  "id" : 70128136649580545,
  "in_reply_to_status_id" : 70123550249467905,
  "created_at" : "Mon May 16 14:07:05 +0000 2011",
  "in_reply_to_screen_name" : "GlobalAsianista",
  "in_reply_to_user_id_str" : "228489296",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie L",
      "screen_name" : "n2li",
      "indices" : [ 14, 19 ],
      "id_str" : "114686650",
      "id" : 114686650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69999546897408000",
  "geo" : {
  },
  "id_str" : "70040583783186433",
  "in_reply_to_user_id" : 16573515,
  "text" : "@scottisasian @n2li Also \"Brothers!\" my favorite read this past semester.",
  "id" : 70040583783186433,
  "in_reply_to_status_id" : 69999546897408000,
  "created_at" : "Mon May 16 08:19:11 +0000 2011",
  "in_reply_to_screen_name" : "thenscottsaid",
  "in_reply_to_user_id_str" : "16573515",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.372379303, -71.1209320464 ]
  },
  "id_str" : "69939375693250561",
  "text" : "WTF camera+ just disappeared a sweet photo from the lightbox...",
  "id" : 69939375693250561,
  "created_at" : "Mon May 16 01:37:01 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3724726355, -71.1209942401 ]
  },
  "id_str" : "69937963693375488",
  "text" : "Is there a local shop in Cambridge that sells arduinos?",
  "id" : 69937963693375488,
  "created_at" : "Mon May 16 01:31:24 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinay Trivedi",
      "screen_name" : "trivinay",
      "indices" : [ 3, 12 ],
      "id_str" : "236627145",
      "id" : 236627145
    }, {
      "name" : "Vinicius Vacanti",
      "screen_name" : "vacanti",
      "indices" : [ 69, 77 ],
      "id_str" : "14424445",
      "id" : 14424445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69937803672289280",
  "text" : "RT @trivinay: The Harvard startup community is growing - watch out! \u201C@vacanti: Wow. 1 out of 5 Harvard freshman taking Intro to Computer ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vinicius Vacanti",
        "screen_name" : "vacanti",
        "indices" : [ 55, 63 ],
        "id_str" : "14424445",
        "id" : 14424445
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "69912773596950528",
    "text" : "The Harvard startup community is growing - watch out! \u201C@vacanti: Wow. 1 out of 5 Harvard freshman taking Intro to Computer Science course\u201D",
    "id" : 69912773596950528,
    "created_at" : "Sun May 15 23:51:18 +0000 2011",
    "user" : {
      "name" : "Vinay Trivedi",
      "screen_name" : "trivinay",
      "protected" : false,
      "id_str" : "236627145",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1311537445/SciOlympiad09_001_normal.jpg",
      "id" : 236627145,
      "verified" : false
    }
  },
  "id" : 69937803672289280,
  "created_at" : "Mon May 16 01:30:46 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69930535237062656",
  "text" : "The full page ads by IBM, Oracle, and HP slinging mud at each other in the economist are pretty obnoxious.",
  "id" : 69930535237062656,
  "created_at" : "Mon May 16 01:01:53 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chen Fang",
      "screen_name" : "chenbfang",
      "indices" : [ 3, 13 ],
      "id_str" : "74640882",
      "id" : 74640882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69885742322696192",
  "text" : "RT @chenbfang: Love how history repeats itself http://bit.ly/jlOrW0",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/seesmic_desktop/sd2\" rel=\"nofollow\">Seesmic Desktop</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "69487893751672832",
    "text" : "Love how history repeats itself http://bit.ly/jlOrW0",
    "id" : 69487893751672832,
    "created_at" : "Sat May 14 19:42:59 +0000 2011",
    "user" : {
      "name" : "Chen Fang",
      "screen_name" : "chenbfang",
      "protected" : false,
      "id_str" : "74640882",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1874956711/23535353_normal.png",
      "id" : 74640882,
      "verified" : false
    }
  },
  "id" : 69885742322696192,
  "created_at" : "Sun May 15 22:03:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 0, 12 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 13, 24 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69179955342356480",
  "geo" : {
  },
  "id_str" : "69187232157798400",
  "in_reply_to_user_id" : 110823121,
  "text" : "@badboyboyce @techcrunch just add bacon and it sounds like a perfect weekend.",
  "id" : 69187232157798400,
  "in_reply_to_status_id" : 69179955342356480,
  "created_at" : "Fri May 13 23:48:16 +0000 2011",
  "in_reply_to_screen_name" : "badboyboyce",
  "in_reply_to_user_id_str" : "110823121",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68550042193104896",
  "text" : "Mulan and margaritas!",
  "id" : 68550042193104896,
  "created_at" : "Thu May 12 05:36:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndarKness",
      "screen_name" : "Alex_IndarKness",
      "indices" : [ 0, 16 ],
      "id_str" : "90575128",
      "id" : 90575128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68265320955121664",
  "geo" : {
  },
  "id_str" : "68352554546905088",
  "in_reply_to_user_id" : 90575128,
  "text" : "@Alex_IndarKness is it the government whitelist?",
  "id" : 68352554546905088,
  "in_reply_to_status_id" : 68265320955121664,
  "created_at" : "Wed May 11 16:31:33 +0000 2011",
  "in_reply_to_screen_name" : "Alex_IndarKness",
  "in_reply_to_user_id_str" : "90575128",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndarKness",
      "screen_name" : "Alex_IndarKness",
      "indices" : [ 3, 19 ],
      "id_str" : "90575128",
      "id" : 90575128
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 21, 28 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68352267606179840",
  "text" : "RT @Alex_IndarKness: @khsieh It depends.My friend in Zhejiang cannot access *ALL* the websites outside.Traceroute shows &gt;80% packages ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://en.wikipedia.org/wiki/Singularity\" rel=\"nofollow\">singularity</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 0, 7 ],
        "id_str" : "111999960",
        "id" : 111999960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "68248483915767808",
    "geo" : {
    },
    "id_str" : "68262958505013248",
    "in_reply_to_user_id" : 19380775,
    "text" : "@khsieh It depends.My friend in Zhejiang cannot access *ALL* the websites outside.Traceroute shows &gt;80% packages dropped in Guangdong.",
    "id" : 68262958505013248,
    "in_reply_to_status_id" : 68248483915767808,
    "created_at" : "Wed May 11 10:35:32 +0000 2011",
    "in_reply_to_screen_name" : "kane",
    "in_reply_to_user_id_str" : "19380775",
    "user" : {
      "name" : "IndarKness",
      "screen_name" : "Alex_IndarKness",
      "protected" : false,
      "id_str" : "90575128",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1175393890/1_normal.jpg",
      "id" : 90575128,
      "verified" : false
    }
  },
  "id" : 68352267606179840,
  "created_at" : "Wed May 11 16:30:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndarKness",
      "screen_name" : "Alex_IndarKness",
      "indices" : [ 0, 16 ],
      "id_str" : "90575128",
      "id" : 90575128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68206430355857408",
  "geo" : {
  },
  "id_str" : "68248483915767808",
  "in_reply_to_user_id" : 90575128,
  "text" : "@Alex_IndarKness what are they blocking in PRC now?",
  "id" : 68248483915767808,
  "in_reply_to_status_id" : 68206430355857408,
  "created_at" : "Wed May 11 09:38:01 +0000 2011",
  "in_reply_to_screen_name" : "Alex_IndarKness",
  "in_reply_to_user_id_str" : "90575128",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68147129130029057",
  "text" : "The new South Park season is so disappointing.",
  "id" : 68147129130029057,
  "created_at" : "Wed May 11 02:55:16 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "indices" : [ 3, 7 ],
      "id_str" : "105192845",
      "id" : 105192845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67786643276435456",
  "text" : "RT @TNW: Microsoft to close $7b Skype acquisition deal http://tnw.co/l9kbxT",
  "retweeted_status" : {
    "source" : "<a href=\"http://dlvr.it\" rel=\"nofollow\">dlvr.it</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "67780345357012992",
    "text" : "Microsoft to close $7b Skype acquisition deal http://tnw.co/l9kbxT",
    "id" : 67780345357012992,
    "created_at" : "Tue May 10 02:37:48 +0000 2011",
    "user" : {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "protected" : false,
      "id_str" : "105192845",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1135834058/tnw-top-stories_normal.jpg",
      "id" : 105192845,
      "verified" : false
    }
  },
  "id" : 67786643276435456,
  "created_at" : "Tue May 10 03:02:49 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 3, 14 ],
      "id_str" : "80887653",
      "id" : 80887653
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 55, 63 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67640369004818432",
  "text" : "RT @HarvardCSA: Ai Weiwei's installation Remberance at @Harvard northwest labs; he was detained before he had a chance to open it http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 39, 47 ],
        "id_str" : "39585367",
        "id" : 39585367
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 133 ],
        "url" : "http://t.co/oasq05L",
        "expanded_url" : "http://yfrog.com/hs2prtsj",
        "display_url" : "yfrog.com/hs2prtsj"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.3768039002, -71.1162631587 ]
    },
    "id_str" : "67623950523441152",
    "text" : "Ai Weiwei's installation Remberance at @Harvard northwest labs; he was detained before he had a chance to open it http://t.co/oasq05L",
    "id" : 67623950523441152,
    "created_at" : "Mon May 09 16:16:20 +0000 2011",
    "user" : {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "protected" : false,
      "id_str" : "80887653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/607153720/hrcsaseal_normal.jpg",
      "id" : 80887653,
      "verified" : false
    }
  },
  "id" : 67640369004818432,
  "created_at" : "Mon May 09 17:21:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drobo",
      "screen_name" : "drobo",
      "indices" : [ 11, 17 ],
      "id_str" : "14721260",
      "id" : 14721260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67430227776782336",
  "text" : "Anyone use @drobo? Looking to buy one instead of building a RAID box for backup!",
  "id" : 67430227776782336,
  "created_at" : "Mon May 09 03:26:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Asia Cafe",
      "screen_name" : "Blueasiacafe",
      "indices" : [ 16, 29 ],
      "id_str" : "101114131",
      "id" : 101114131
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boba",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67417582919094272",
  "text" : "I need to go to @BlueAsiaCafe. #boba withdrawal kicking in.",
  "id" : 67417582919094272,
  "created_at" : "Mon May 09 02:36:18 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mitnick",
      "screen_name" : "kevinmitnick",
      "indices" : [ 0, 13 ],
      "id_str" : "14666934",
      "id" : 14666934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67393624589074432",
  "geo" : {
  },
  "id_str" : "67396307014270976",
  "in_reply_to_user_id" : 14666934,
  "text" : "@kevinmitnick social engineering: it works!",
  "id" : 67396307014270976,
  "in_reply_to_status_id" : 67393624589074432,
  "created_at" : "Mon May 09 01:11:46 +0000 2011",
  "in_reply_to_screen_name" : "kevinmitnick",
  "in_reply_to_user_id_str" : "14666934",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http://t.co/IU7HeUL",
      "expanded_url" : "http://www.thecrimson.com/series/office-hours/article/2011/5/7/evolutionary-biologyand-office-harvards/",
      "display_url" : "thecrimson.com/series/office-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "66921706429755392",
  "text" : "Doctor Berry nails the interview. I miss having him as an advisor http://t.co/IU7HeUL",
  "id" : 66921706429755392,
  "created_at" : "Sat May 07 17:45:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7562827412, -73.9880647045 ]
  },
  "id_str" : "66770805421383680",
  "text" : "Stuck in Times Square because apparently Greyhound overbooks their buses...",
  "id" : 66770805421383680,
  "created_at" : "Sat May 07 07:46:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66744519512702976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7493031, -73.98093813 ]
  },
  "id_str" : "66744646704955392",
  "in_reply_to_user_id" : 18734681,
  "text" : "@themonkeychow are you still sick??",
  "id" : 66744646704955392,
  "in_reply_to_status_id" : 66744519512702976,
  "created_at" : "Sat May 07 06:02:18 +0000 2011",
  "in_reply_to_screen_name" : "melody_who",
  "in_reply_to_user_id_str" : "18734681",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://taptaptap.com/camera+\" rel=\"nofollow\">Camera+</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielsuo",
      "screen_name" : "danielsuo",
      "indices" : [ 14, 24 ],
      "id_str" : "18029822",
      "id" : 18029822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7493031, -73.98093813 ]
  },
  "id_str" : "66741678907727872",
  "text" : "Bon Chon with @danielsuo! http://campl.us/4Yw",
  "id" : 66741678907727872,
  "created_at" : "Sat May 07 05:50:30 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emi Meyer",
      "screen_name" : "EmiMeyer",
      "indices" : [ 9, 18 ],
      "id_str" : "98080993",
      "id" : 98080993
    }, {
      "name" : "Dave Liang",
      "screen_name" : "daveliang",
      "indices" : [ 23, 33 ],
      "id_str" : "20615976",
      "id" : 20615976
    }, {
      "name" : "Harvard CSA",
      "screen_name" : "HarvardCSA",
      "indices" : [ 46, 57 ],
      "id_str" : "80887653",
      "id" : 80887653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7234712365, -74.0078776796 ]
  },
  "id_str" : "66679041549271040",
  "text" : "Watching @EmiMeyer and @daveliang in NYC with @HarvardCSA alum!",
  "id" : 66679041549271040,
  "created_at" : "Sat May 07 01:41:37 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 3, 17 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66593740294332416",
  "text" : "RT @StephenAtHome: Barnes & Noble is rumored to be releasing a new Nook later this month. If their marketing team is smart, they'll call ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialoomph.com\" rel=\"nofollow\">SocialOomph</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "66592151135465473",
    "text" : "Barnes & Noble is rumored to be releasing a new Nook later this month. If their marketing team is smart, they'll call it the iPad 3.",
    "id" : 66592151135465473,
    "created_at" : "Fri May 06 19:56:20 +0000 2011",
    "user" : {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "protected" : false,
      "id_str" : "16303106",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3291883997/fae26d278dac0db23cc44e0465f42c4a_normal.png",
      "id" : 16303106,
      "verified" : true
    }
  },
  "id" : 66593740294332416,
  "created_at" : "Fri May 06 20:02:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smart Gourmet",
      "screen_name" : "momogoose",
      "indices" : [ 38, 48 ],
      "id_str" : "182074162",
      "id" : 182074162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66588169822416896",
  "text" : "Just ate my last lunch of the year at @momogoose. Bring the food truck to Harvard next year!",
  "id" : 66588169822416896,
  "created_at" : "Fri May 06 19:40:31 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66580984778330112",
  "text" : "\"We invented a camera that shouldn't exist. Then one of our postdocs built it.\" - MIT Media Lab",
  "id" : 66580984778330112,
  "created_at" : "Fri May 06 19:11:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66572038730555392",
  "text" : "The M11x is looking pretty sweet now that my MacBook is dead in the water.",
  "id" : 66572038730555392,
  "created_at" : "Fri May 06 18:36:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thinkgeek",
      "screen_name" : "thinkgeek",
      "indices" : [ 3, 13 ],
      "id_str" : "12611642",
      "id" : 12611642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66531604046163969",
  "text" : "RT @thinkgeek: This is NOT tilt shift trickery. Mind-bogglingly detailed model airport took 7 yrs & is totally worth it: http://j.mp/ipqyCd",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "66497062547632128",
    "text" : "This is NOT tilt shift trickery. Mind-bogglingly detailed model airport took 7 yrs & is totally worth it: http://j.mp/ipqyCd",
    "id" : 66497062547632128,
    "created_at" : "Fri May 06 13:38:29 +0000 2011",
    "user" : {
      "name" : "thinkgeek",
      "screen_name" : "thinkgeek",
      "protected" : false,
      "id_str" : "12611642",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3522713236/268f433597dc1e82d2eafcfb9c5c5b20_normal.png",
      "id" : 12611642,
      "verified" : true
    }
  },
  "id" : 66531604046163969,
  "created_at" : "Fri May 06 15:55:45 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 61, 73 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Natalia",
      "screen_name" : "NataliaZarina",
      "indices" : [ 78, 92 ],
      "id_str" : "74196868",
      "id" : 74196868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66395156261257216",
  "text" : "Two classes down, two to go. Weekend study break in NYC with @badboyboyce and @nataliazarina to catch The Shanghai Restoration Project!",
  "id" : 66395156261257216,
  "created_at" : "Fri May 06 06:53:33 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "readingperiod",
      "indices" : [ 61, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66364395307020289",
  "text" : "MacBook Pro fan died. Running 90*C+. Very inopportune timing #readingperiod",
  "id" : 66364395307020289,
  "created_at" : "Fri May 06 04:51:19 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 3, 10 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66336861496418304",
  "text" : "RT @cnnbrk: Air Force grounds all F-22 Raptors http://on.cnn.com/jRWsO5",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "66298076498898945",
    "text" : "Air Force grounds all F-22 Raptors http://on.cnn.com/jRWsO5",
    "id" : 66298076498898945,
    "created_at" : "Fri May 06 00:27:47 +0000 2011",
    "user" : {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "protected" : false,
      "id_str" : "428333",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1762504301/128x128_cnnbrk_avatar_normal.gif",
      "id" : 428333,
      "verified" : true
    }
  },
  "id" : 66336861496418304,
  "created_at" : "Fri May 06 03:01:54 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia",
      "screen_name" : "NataliaZarina",
      "indices" : [ 3, 17 ],
      "id_str" : "74196868",
      "id" : 74196868
    }, {
      "name" : "Bwog",
      "screen_name" : "bwog",
      "indices" : [ 25, 30 ],
      "id_str" : "15652511",
      "id" : 15652511
    }, {
      "name" : "Kevin Hsieh",
      "screen_name" : "khsieh",
      "indices" : [ 124, 131 ],
      "id_str" : "111999960",
      "id" : 111999960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http://t.co/pBaljmE",
      "expanded_url" : "http://youtu.be/u011XHmYq1Q",
      "display_url" : "youtu.be/u011XHmYq1Q"
    } ]
  },
  "geo" : {
  },
  "id_str" : "66335790044688384",
  "text" : "RT @NataliaZarina: epic \u201C@Bwog: everyone knows you're not *really* studying! here, watch this instead: http://t.co/pBaljmE\u201D @khsieh",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bwog",
        "screen_name" : "bwog",
        "indices" : [ 6, 11 ],
        "id_str" : "15652511",
        "id" : 15652511
      }, {
        "name" : "Kevin Hsieh",
        "screen_name" : "khsieh",
        "indices" : [ 105, 112 ],
        "id_str" : "111999960",
        "id" : 111999960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 103 ],
        "url" : "http://t.co/pBaljmE",
        "expanded_url" : "http://youtu.be/u011XHmYq1Q",
        "display_url" : "youtu.be/u011XHmYq1Q"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.3684303789, -71.1156319176 ]
    },
    "id_str" : "66335695291158528",
    "text" : "epic \u201C@Bwog: everyone knows you're not *really* studying! here, watch this instead: http://t.co/pBaljmE\u201D @khsieh",
    "id" : 66335695291158528,
    "created_at" : "Fri May 06 02:57:16 +0000 2011",
    "user" : {
      "name" : "Natalia",
      "screen_name" : "NataliaZarina",
      "protected" : false,
      "id_str" : "74196868",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3489396704/acd0fac2e201624d3ac30e29033feb5a_normal.jpeg",
      "id" : 74196868,
      "verified" : false
    }
  },
  "id" : 66335790044688384,
  "created_at" : "Fri May 06 02:57:39 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://taptaptap.com/camera+\" rel=\"nofollow\">Camera+</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.37840676, -71.11453008 ]
  },
  "id_str" : "66193422544945152",
  "text" : "Making a massive poster for CS179 http://campl.us/4di",
  "id" : 66193422544945152,
  "created_at" : "Thu May 05 17:31:56 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http://t.co/5cymXBm",
      "expanded_url" : "http://yfrog.com/h7r2uajj",
      "display_url" : "yfrog.com/h7r2uajj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "65905257905004544",
  "text" : "I'm on a boat.  http://t.co/5cymXBm",
  "id" : 65905257905004544,
  "created_at" : "Wed May 04 22:26:52 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 35, 41 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http://t.co/7wCLgk0",
      "expanded_url" : "http://wrd.tw/mcFPHl",
      "display_url" : "wrd.tw/mcFPHl"
    } ]
  },
  "geo" : {
  },
  "id_str" : "65891629990547456",
  "text" : "I love a good conspiracy theory RT @wired: scramble to ID the mystery copter that crashed during the OBL raid: http://t.co/7wCLgk0",
  "id" : 65891629990547456,
  "created_at" : "Wed May 04 21:32:43 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Voice",
      "screen_name" : "harvardvoice",
      "indices" : [ 24, 37 ],
      "id_str" : "45716794",
      "id" : 45716794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/nvZ1rlk",
      "expanded_url" : "http://bit.ly/mrMkt4",
      "display_url" : "bit.ly/mrMkt4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.7559787, -70.68699026 ]
  },
  "id_str" : "65888740668739584",
  "text" : "Check out my photos! RT @harvardvoice: We're releasing a calendar of the \"10 Guys You'll Meet at Harvard\"! for charity. http://t.co/nvZ1rlk",
  "id" : 65888740668739584,
  "created_at" : "Wed May 04 21:21:14 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Joy ",
      "screen_name" : "mjoyw",
      "indices" : [ 0, 6 ],
      "id_str" : "49019553",
      "id" : 49019553
    }, {
      "name" : "bonnie w",
      "screen_name" : "xobabyb",
      "indices" : [ 7, 15 ],
      "id_str" : "86144785",
      "id" : 86144785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65875656113782784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.78282839, -70.76382368 ]
  },
  "id_str" : "65888155898871808",
  "in_reply_to_user_id" : 49019553,
  "text" : "@mjoyw @xobabyb JoJo Taipei has really food xi fan!! Maybe they deliver too?",
  "id" : 65888155898871808,
  "in_reply_to_status_id" : 65875656113782784,
  "created_at" : "Wed May 04 21:18:55 +0000 2011",
  "in_reply_to_screen_name" : "mjoyw",
  "in_reply_to_user_id_str" : "49019553",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Klee",
      "screen_name" : "CKlee",
      "indices" : [ 23, 29 ],
      "id_str" : "1144949670",
      "id" : 1144949670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65871753926287360",
  "text" : "Off to Woods Hole with @cklee. Hacknight off campus!",
  "id" : 65871753926287360,
  "created_at" : "Wed May 04 20:13:44 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "indices" : [ 3, 13 ],
      "id_str" : "1976841",
      "id" : 1976841
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 41, 52 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65841629705142273",
  "text" : "RT @jenny8lee: Looking for a summer job? @foursquare is looking for a product intern.  Paid! http://bit.ly/i92kvX",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Foursquare",
        "screen_name" : "foursquare",
        "indices" : [ 26, 37 ],
        "id_str" : "14120151",
        "id" : 14120151
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "65833115662299136",
    "text" : "Looking for a summer job? @foursquare is looking for a product intern.  Paid! http://bit.ly/i92kvX",
    "id" : 65833115662299136,
    "created_at" : "Wed May 04 17:40:12 +0000 2011",
    "user" : {
      "name" : "Jennifer 8. Lee",
      "screen_name" : "jenny8lee",
      "protected" : false,
      "id_str" : "1976841",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1842465869/jenny_baby_graduation_cap_cropped_normal.jpg",
      "id" : 1976841,
      "verified" : true
    }
  },
  "id" : 65841629705142273,
  "created_at" : "Wed May 04 18:14:02 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Ramsey",
      "screen_name" : "willdanieley",
      "indices" : [ 57, 70 ],
      "id_str" : "141380372",
      "id" : 141380372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65687318857658369",
  "text" : "Thad Jones Mel Lewis orchestra, pizza, and papering with @willdanieley",
  "id" : 65687318857658369,
  "created_at" : "Wed May 04 08:00:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://taptaptap.com/camera+\" rel=\"nofollow\">Camera+</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3683333333, -71.1158333333 ]
  },
  "id_str" : "65671594718134272",
  "text" : "Most absurd pizza. Ever. http://campl.us/3BX",
  "id" : 65671594718134272,
  "created_at" : "Wed May 04 06:58:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Harvard Voice",
      "screen_name" : "harvardvoice",
      "indices" : [ 59, 72 ],
      "id_str" : "45716794",
      "id" : 45716794
    }, {
      "name" : "Michelle N",
      "screen_name" : "michellevoice",
      "indices" : [ 124, 138 ],
      "id_str" : "271022340",
      "id" : 271022340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65666469240913920",
  "text" : "Just spent waaaay too much time tweaking pics of dudes for @harvardvoice calendar shoot! Looking forward to the final print @michellevoice",
  "id" : 65666469240913920,
  "created_at" : "Wed May 04 06:38:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifesgood",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65657638121259008",
  "text" : "28\" bacon cheeseburger pizza with the roommates. #lifesgood",
  "id" : 65657638121259008,
  "created_at" : "Wed May 04 06:02:55 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65657525135097857",
  "text" : "Anyone testing Chrome Canary on OSX?",
  "id" : 65657525135097857,
  "created_at" : "Wed May 04 06:02:28 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siddarth",
      "screen_name" : "sidd",
      "indices" : [ 0, 5 ],
      "id_str" : "132319630",
      "id" : 132319630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65505546647769088",
  "geo" : {
  },
  "id_str" : "65505829704568832",
  "in_reply_to_user_id" : 132319630,
  "text" : "@sidd I forgot all about CS179 too!",
  "id" : 65505829704568832,
  "in_reply_to_status_id" : 65505546647769088,
  "created_at" : "Tue May 03 19:59:41 +0000 2011",
  "in_reply_to_screen_name" : "sidd",
  "in_reply_to_user_id_str" : "132319630",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crunchtime",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65502846430359552",
  "text" : "Four papers. Boston, NYC, and Rome, NY. 40 hours. #crunchtime",
  "id" : 65502846430359552,
  "created_at" : "Tue May 03 19:47:50 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://taptaptap.com/camera+\" rel=\"nofollow\">Camera+</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.6883434169, -70.5969464221 ]
  },
  "id_str" : "65421191938195456",
  "text" : "Breaking out of the Harvard bubble during reading period. http://campl.us/3ji",
  "id" : 65421191938195456,
  "created_at" : "Tue May 03 14:23:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Archer",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65266825373564928",
  "text" : "Addicted to #Archer after South Park's disappointing season premiere.",
  "id" : 65266825373564928,
  "created_at" : "Tue May 03 04:09:58 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "fangjon",
      "indices" : [ 0, 8 ],
      "id_str" : "46477577",
      "id" : 46477577
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "harvardlife",
      "indices" : [ 53, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65225272286384128",
  "geo" : {
  },
  "id_str" : "65227178870190081",
  "in_reply_to_user_id" : 46477577,
  "text" : "@fangjon we do eat cubes of cheese at brain break... #harvardlife",
  "id" : 65227178870190081,
  "in_reply_to_status_id" : 65225272286384128,
  "created_at" : "Tue May 03 01:32:25 +0000 2011",
  "in_reply_to_screen_name" : "fangjon",
  "in_reply_to_user_id_str" : "46477577",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Boyce",
      "screen_name" : "badboyboyce",
      "indices" : [ 19, 31 ],
      "id_str" : "110823121",
      "id" : 110823121
    }, {
      "name" : "Harvard Biz Review",
      "screen_name" : "HarvardBiz",
      "indices" : [ 35, 46 ],
      "id_str" : "14800270",
      "id" : 14800270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http://t.co/tKRxIs3",
      "expanded_url" : "http://s.hbr.org/iJE8c4",
      "display_url" : "s.hbr.org/iJE8c4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "65124287748644865",
  "text" : "Gotta keep hustlin @badboyboyce RT @HarvardBiz: Tough Bargaining Gets You Higher Starting Pay http://t.co/tKRxIs3",
  "id" : 65124287748644865,
  "created_at" : "Mon May 02 18:43:34 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Asian Man",
      "screen_name" : "angryasianman",
      "indices" : [ 0, 14 ],
      "id_str" : "16005250",
      "id" : 16005250
    }, {
      "name" : "Dave Liang",
      "screen_name" : "daveliang",
      "indices" : [ 59, 69 ],
      "id_str" : "20615976",
      "id" : 20615976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65110944400932864",
  "geo" : {
  },
  "id_str" : "65120166547169281",
  "in_reply_to_user_id" : 16005250,
  "text" : "@angryasianman are you going to be in NYC on Friday to see @daveliang?",
  "id" : 65120166547169281,
  "in_reply_to_status_id" : 65110944400932864,
  "created_at" : "Mon May 02 18:27:12 +0000 2011",
  "in_reply_to_screen_name" : "angryasianman",
  "in_reply_to_user_id_str" : "16005250",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 65, 76 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http://t.co/mwPTDWh",
      "expanded_url" : "http://techcrunch.com/2011/05/02/rim-announces-blackberry-bold-9900-and-9930-with-bbos-7-and-nfc",
      "display_url" : "techcrunch.com/2011/05/02/rim\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "65118153365131264",
  "text" : "Blackberry to get NFC, touchscreen, OS7, and better browser? via @techcrunch http://t.co/mwPTDWh",
  "id" : 65118153365131264,
  "created_at" : "Mon May 02 18:19:12 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIT",
      "indices" : [ 43, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65117686274867201",
  "text" : "Amar Bose donates majority of Bose Corp to #MIT",
  "id" : 65117686274867201,
  "created_at" : "Mon May 02 18:17:20 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65109441846059008",
  "text" : "The white flowering trees between Quincy and Lowell smell like moldy bread...",
  "id" : 65109441846059008,
  "created_at" : "Mon May 02 17:44:35 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http://t.co/Ds5nmHY",
      "expanded_url" : "http://www.businessinsider.com/obama-watched-live-video-of-bin-laden-raid-2011-5",
      "display_url" : "businessinsider.com/obama-watched-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "65101997296189440",
  "text" : "Obama got to watch the raid in Abbottabad live http://t.co/Ds5nmHY",
  "id" : 65101997296189440,
  "created_at" : "Mon May 02 17:15:00 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alpha kane",
      "screen_name" : "KaneAlpha",
      "indices" : [ 3, 13 ],
      "id_str" : "397045818",
      "id" : 397045818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64949263058206720",
  "text" : "or @KaneAlpha... I'm tired of people asking me how to spell \"hsieh\"",
  "id" : 64949263058206720,
  "created_at" : "Mon May 02 07:08:05 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin O'Kane",
      "screen_name" : "iMokane",
      "indices" : [ 36, 44 ],
      "id_str" : "369526454",
      "id" : 369526454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64945056913698816",
  "text" : "Should I change twitter username to @imOKane? People can't spell khsieh phonetically.",
  "id" : 64945056913698816,
  "created_at" : "Mon May 02 06:51:22 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64909084834533376",
  "text" : "I wonder if Toby Keith is working on a song *right this second*",
  "id" : 64909084834533376,
  "created_at" : "Mon May 02 04:28:26 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 3, 5 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "osamabinladen",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64894987531333632",
  "text" : "RT @k: Terrorism is OVER. Threat level: Rainbow! #osamabinladen",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "osamabinladen",
        "indices" : [ 42, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "64885268032921601",
    "text" : "Terrorism is OVER. Threat level: Rainbow! #osamabinladen",
    "id" : 64885268032921601,
    "created_at" : "Mon May 02 02:53:48 +0000 2011",
    "user" : {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "protected" : false,
      "id_str" : "11222",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1766843478/plain_normal.jpeg",
      "id" : 11222,
      "verified" : false
    }
  },
  "id" : 64894987531333632,
  "created_at" : "Mon May 02 03:32:25 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Harvard",
      "indices" : [ 27, 35 ]
    }, {
      "text" : "Tivli",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64887581283856384",
  "text" : "Watching bin Laden news on #Harvard startup TV service #Tivli!",
  "id" : 64887581283856384,
  "created_at" : "Mon May 02 03:02:59 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Taiwan",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64805103001018368",
  "text" : "May Fair, while fun, was just a lamer, smaller, more expensive version of a night market. I miss #Taiwan",
  "id" : 64805103001018368,
  "created_at" : "Sun May 01 21:35:15 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Liu",
      "screen_name" : "eliseliu",
      "indices" : [ 0, 9 ],
      "id_str" : "14458332",
      "id" : 14458332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64743814392324096",
  "geo" : {
  },
  "id_str" : "64752430772002816",
  "in_reply_to_user_id" : 14458332,
  "text" : "@eliseliu May fair is going on in Harvard Square!",
  "id" : 64752430772002816,
  "in_reply_to_status_id" : 64743814392324096,
  "created_at" : "Sun May 01 18:05:57 +0000 2011",
  "in_reply_to_screen_name" : "eliseliu",
  "in_reply_to_user_id_str" : "14458332",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li",
      "screen_name" : "l_jin",
      "indices" : [ 0, 6 ],
      "id_str" : "23689891",
      "id" : 23689891
    }, {
      "name" : "Harvard Asian Guy",
      "screen_name" : "HarvardAsianGuy",
      "indices" : [ 7, 23 ],
      "id_str" : "263122363",
      "id" : 263122363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64620606364188672",
  "in_reply_to_user_id" : 23689891,
  "text" : "@l_jin @HarvardAsianGuy and I share a (lack of) sleeping schedule.",
  "id" : 64620606364188672,
  "created_at" : "Sun May 01 09:22:07 +0000 2011",
  "in_reply_to_screen_name" : "l_jin",
  "in_reply_to_user_id_str" : "23689891",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Harvard",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64619280460824576",
  "text" : "Post Fete, post Kong, post Portal exhaustion. Life of a #Harvard student during reading period.",
  "id" : 64619280460824576,
  "created_at" : "Sun May 01 09:16:51 +0000 2011",
  "user" : {
    "name" : "Kane",
    "screen_name" : "kane",
    "protected" : false,
    "id_str" : "19380775",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2615940335/cum6t95dronv9dhs7epy_normal.png",
    "id" : 19380775,
    "verified" : false
  }
} ]