var payload_details =  {
  "tweets" : 3935,
  "created_at" : "Sat May 04 19:46:19 +0000 2013",
  "lang" : "en"
}