var user_details =  {
  "screen_name" : "kane",
  "location" : "+40\u00B045'9.3, -73\u00B058'38.3",
  "full_name" : "Kane",
  "bio" : "Now: @RRE Ventures. Past: @HSEAS. Always: Buffalonian, technophile, neophile, DIY-er, wanderluster, bubble tea snob.",
  "id" : "19380775",
  "created_at" : "Fri Jan 23 04:13:12 +0000 2009"
}